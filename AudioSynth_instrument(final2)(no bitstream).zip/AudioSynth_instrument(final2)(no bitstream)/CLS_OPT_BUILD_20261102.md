# 当前4×10整机源码与已通过构建

2026-11-02已合回15个RTL源文件及3份过程配置，保持两个137输入GPRJ、原顶层端口/引脚/时钟/约束和4×10调用链。优化核心仍由sd_tdm_cores40实例化四次；没有新增核或降低40独立声部。保留原五种FM/NES以及此前候选的SD/菜单功能。原impl报告/位流不覆盖，GUI过程状态已清除，避免旧报告冒充当前构建。

已通过的隔离构建：`F:/GOWIN_138K_AudioSynth/build/cls-opt-20261102/integrated4`。

- CLS59995/69120=86.80%，BSRAM248/340=72.94%，DSP119.5，PLL3，官方AE350维持50MHz。
- Setup/Hold违例0/0；最差Setup +0.005ns、Hold +0.183ns、Recovery +4.515ns、Removal +0.347ns。Setup余量较紧，未以修改约束或降频取得通过。
- Place2/Route2，时序驱动/hold修复开启，Clock_Route_Order0，Route_Maxfan23，无增量引用，SDP转换false；手动重建不依赖旧.pr/.p种子路径。
- 位流SHA256 `bc7f067922d9975111ec4325f12710e46f57219101a6a6a2873bc25d316299fb`。
- 本轮仅SRAM操作4，100%读回校验；COM7启动/FAT32/256预设正常。内置5种音色触发、NES40槽、4种SD音色分配40独立声部，短段69965帧PCM无缺口、10项诊断增量0，录音complete。

修改前备份：`F:/GOWIN_138K_AudioSynth/build/cls-opt-20261102/promotion1/before`。完整资源、STA、下载和短测记录：`F:/GOWIN_138K_AudioSynth/docs/sd-adapt/CLS_OPT_20261102.md`及该构建根目录的CLOSEOUT.json。未写FPGA Flash或CH569固件，断电后SRAM镜像会丢失。

此轮没有新增长时/主观音质/TFT实机菜单验收，也不宣称完整DX7 LFO和pitch EG已实现。下一步仅建议听感对照及后续改善时序余量，本轮不自动扩展测试。
