`default_nettype none
// The 4x16 production engine runs at 50 MHz. DAC boundaries generate a slow toggle.
// The boundary toggle is synchronized into the engine domain; PCM crosses as complete stereo frames.
module instrument_tdm64_audio_adapter #(parameter TRACE_ENABLE=1,parameter RELEASE_CONTROL_ENABLE=0,parameter CHANNEL_CONTROL_ENABLE=0,parameter SD_ONLY=0,parameter HW_PATCH=0,parameter integer VOICES_PER_CORE=10)(
 input wire clk_50m,common_ready,event_valid,input wire [39:0] event_data,
 input wire online,fault,input wire [2:0] patch_select,input wire bclk,tx_rst_n,ws,
 output wire sdout,output wire [31:0] underrun,
 input wire signed [15:0] nes_pcm,output wire nes_rst_n,nes_sample_tick,
 input wire [23:0] string_ratio,output wire [23:0] string_bend_ratio,
 input wire [95:0] event_tag,output wire capture_valid,output wire [47:0] capture_pcm,
 output reg [31:0] capture_index,output wire exec_valid,output wire [39:0] exec_data,output wire [95:0] exec_tag,
 output wire [623:0] actual_state,
 input wire [15:0] dynamic_mask,input wire cpu_enabled,
 output wire cpu_event_valid,output wire [39:0] cpu_event_data,output wire [95:0] cpu_event_tag,input wire cpu_event_ready,
 input wire cpu_ack_valid,input wire [95:0] cpu_ack_tag,
 output wire allocation_valid,output wire [5:0] allocation_slot,output wire [31:0] allocation_token,
 input wire config_valid,output wire config_ready,input wire [2:0] config_kind,
 input wire [5:0] config_slot,input wire [31:0] config_token,input wire [2:0] config_op,
 input wire [107:0] config_data,input wire [7:0] config_meta,
 output wire config_resp_valid,config_resp_ok,output wire [31:0] config_resp_token,
 output wire [31:0] config_faults,
 input wire [15:0] release_channels,
 input wire [3:0] release_sources,
 input wire control_valid,output wire control_ready,input wire [3:0] control_channel,input wire [34:0] control_data,
 input wire [8:0] library_count,
 output wire library_read,output wire [10:0] library_address,
 input wire [127:0] library_data,
 input wire hw_write,input wire [11:0] hw_address,input wire [31:0] hw_data,
 output wire [31:0] hw_read,output wire [15:0] hw_active,input wire string_mode,output wire [8:0] piano_patch,output wire [15:0] nes_status);
 wire core_rst_n,read_rst_n;
 audio_usb_reset reset_core(clk_50m,common_ready,core_rst_n);
 audio_usb_reset reset_read(bclk,common_ready,read_rst_n);
 wire tx_ready;
 (* syn_preserve=1 *) reg frame_toggle;
 always @(posedge bclk or negedge read_rst_n)
  if(!read_rst_n)frame_toggle<=0;else if(tx_ready)frame_toggle<=~frame_toggle;
 (* syn_preserve=1 *) reg tick_meta,tick_sync;
 reg tick_old;
 always @(posedge clk_50m)begin
  if(!core_rst_n)begin tick_meta<=0;tick_sync<=0;tick_old<=0;end
  else begin tick_meta<=frame_toggle;tick_sync<=tick_meta;tick_old<=tick_sync;end
 end
 // Register the domain-local edge pulse before the high-fanout audio enables.
 (* syn_preserve=1 *) reg sample_tick /* synthesis syn_maxfan=16 */;
 always @(posedge clk_50m)if(!core_rst_n)sample_tick<=0;else sample_tick<=tick_sync!=tick_old;
 wire signed [23:0] pcm;wire pcm_valid,wr_ready,rd_valid;
 wire [47:0] frame;
 (* syn_keep=1 *) wire [4*VOICES_PER_CORE-1:0] busy,gate,releasing;
 wire [63:0] status_gate=gate,status_busy=busy;
 (* syn_keep=1 *) wire [31:0] deadline_miss,clips,range_errors,event_overflow,pcm_overflow;
 (* syn_keep=1 *) wire [15:0] last_cycles;
 wire [4*VOICES_PER_CORE*32-1:0] voice_raw;
 instrument_tdm64_engine #(.TRACE_ENABLE(TRACE_ENABLE),.VOICES_PER_CORE(VOICES_PER_CORE),.RELEASE_CONTROL_ENABLE(RELEASE_CONTROL_ENABLE),.CHANNEL_CONTROL_ENABLE(CHANNEL_CONTROL_ENABLE),.SD_ONLY(SD_ONLY),.HW_PATCH(HW_PATCH)) engine(clk_50m,core_rst_n,sample_tick,event_valid,event_data,online && !fault,patch_select,
  pcm,pcm_valid,busy,gate,releasing,deadline_miss,clips,range_errors,event_overflow,last_cycles,voice_raw,string_ratio,string_bend_ratio,event_tag,exec_valid,exec_data,exec_tag,
  dynamic_mask,cpu_enabled,cpu_event_valid,cpu_event_data,cpu_event_tag,cpu_event_ready,cpu_ack_valid,cpu_ack_tag,
  allocation_valid,allocation_slot,allocation_token,config_valid,config_ready,config_kind,config_slot,config_token,config_op,config_data,config_meta,
  config_resp_valid,config_resp_ok,config_resp_token,config_faults,release_channels,release_sources,control_valid,control_ready,control_channel,control_data,
  library_count,library_read,library_address,library_data,
  hw_write,hw_address,hw_data,hw_read,hw_active,string_mode,piano_patch,nes_status);
 // The board top owns the CH10 APU. Export the exact same reset and tick;
 // its signed PCM returns on this 50MHz domain before engine pcm_valid.
 assign nes_rst_n=core_rst_n;
 assign nes_sample_tick=sample_tick;
 // NES-only level trim 11/128 (-21.32dB), matched to existing four timbres.
 // PCM16 -> PCM24 is 256 * 11/128 = 22, exact with no rounding or DSP.
 wire signed [23:0] nes_extended={{8{nes_pcm[15]}},nes_pcm};
 wire signed [23:0] nes_balanced=(nes_extended<<<4)+(nes_extended<<<2)+(nes_extended<<<1);
 wire signed [24:0] combined=$signed({pcm[23],pcm})+$signed({nes_balanced[23],nes_balanced});
 wire signed [23:0] mixed_pcm=(combined > 25'sd8388607) ? 24'sh7fffff :
  (combined < -25'sd8388608) ? 24'sh800000 : combined[23:0];
 wire signed [23:0] effects_pcm;wire effects_valid;wire [351:0] effects_state;
 instrument_effects effects(clk_50m,core_rst_n,sample_tick,event_valid,event_data,online && !fault,
  pcm_valid,mixed_pcm,effects_valid,effects_pcm,effects_state);
 assign capture_valid=effects_valid && wr_ready;
 assign capture_pcm={effects_pcm,effects_pcm};
 always @(posedge clk_50m)if(!core_rst_n)capture_index<=0;else if(sample_tick)capture_index<=capture_index+1'b1;
 assign actual_state={status_gate[63:48],status_busy[63:48],status_gate[47:40],status_busy[47:40],last_cycles,status_gate[39:32],status_busy[39:32],pcm_overflow,clips,deadline_miss,event_overflow,status_gate[31:0],status_busy[31:0],effects_state};
 wire dac_pop,dac_valid;
 wire [47:0] dac_frame;
 instrument_dac_playout #(.PREFILL(VOICES_PER_CORE>=16)) playout(
  bclk,read_rst_n,tx_ready,rd_valid,frame,dac_pop,dac_valid,dac_frame);
 usb_packet_async_fifo #(.WIDTH(48),.ADDR_BITS(2)) pcm_fifo(
  clk_50m,core_rst_n,effects_valid,{effects_pcm,effects_pcm},wr_ready,pcm_overflow,
  bclk,read_rst_n,rd_valid,frame,dac_pop);
 audio_usb_i2s_tx24 tx(bclk,tx_rst_n,ws,dac_valid,dac_frame,tx_ready,sdout,underrun);
endmodule

// Reserve one complete frame before advancing the DAC read pointer. The DAC
// boundary still requests one new synthesis frame while the queue fills.
module instrument_dac_playout #(parameter PREFILL=0)(
 input wire bclk,rst_n,boundary,frame_valid,input wire [47:0] frame,
 output wire pop,output wire valid,output wire [47:0] data
);
 generate if(PREFILL)begin:prefill
  reg primed;
  always @(posedge bclk)
   if(!rst_n)primed<=0;
   else if(boundary && frame_valid)primed<=1;
  assign pop=boundary && primed && rst_n;
  assign valid=rst_n && (!primed || frame_valid);
  assign data=primed?frame:48'd0;
 end else begin:direct
  assign pop=boundary;
  assign valid=rst_n && frame_valid;
  assign data=frame;
 end endgenerate
endmodule
`default_nettype wire
