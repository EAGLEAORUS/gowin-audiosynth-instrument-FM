create_clock -name clk_50m -period 20.000 [get_ports {clk_50m}]
create_generated_clock -name clk_usb -source [get_ports {clk_50m}] -multiply_by 48 -divide_by 25 [get_pins {*PLL_inst/CLKOUT0}]
// PHY pins are asynchronous; cut only pad -> first synchronizer stage.
set_false_path -from [get_ports {usb_dp usb_dm}] -to [get_pins {*dp_meta_s0/D *dm_meta_s0/D}]
// Gray FIFO/memory paths cross domains under pointer synchronization.
// Bound propagation instead of cutting whole clock domains. Core captures a
// committed word only after two pointer synchronizer stages (>40ns).
set_max_delay -from [get_clocks {clk_usb}] -to [get_clocks {clk_50m}] 20.000
set_min_delay -from [get_clocks {clk_usb}] -to [get_clocks {clk_50m}] 0.000
set_max_delay -from [get_clocks {clk_50m}] -to [get_clocks {clk_usb}] 10.000
set_min_delay -from [get_clocks {clk_50m}] -to [get_clocks {clk_usb}] 0.000
// First Gray synchronizer stages intentionally sample asynchronously. Only
// their HOLD checks are excepted; bounded setup propagation above remains.
set_false_path -hold -to [get_regs {*records/rg_meta*_s0 *records/wg_meta*_s0 cdc_fault_meta_s0}]
// POR/PLL reset is asynchronous to USB. The first reset synchronizer may
// release near an edge; stage 2 synchronizes release before protocol use.
// The broad cross-domain min_delay otherwise treats its async CLEAR as a
// synchronous data capture. Exempt only this first-stage CLEAR hold check;
// stage-1 Q -> stage-2 D and every stage-2 check remain timed.
set_false_path -hold -to [get_pins {reset_usb_0_s0/CLEAR}]
// USB write pointer can change every 10.417ns: also bound its Gray bits to
// <one source period; the wider payload remains under the 20ns bound above.
set_max_delay -to [get_regs {*records/wg_meta*_s0}] 10.000
// UART external receiver does not capture on an FPGA clock.
set_false_path -to [get_ports {uart_tx}]
