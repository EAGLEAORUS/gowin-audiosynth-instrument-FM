`default_nettype none
// Eight DX7 VMEM banks. Payload is volatile, with no reset/initialization on
// the RAM itself. The catalog is visible only after firmware validates it.
module sd_patch_store #(parameter HW_PATCH=0)(
 input wire clk,rst_n,seek,put,get,seal,
 input wire [31:0] data,
 output wire [31:0] read_word,status,
 input wire synth_read,input wire [10:0] synth_address,
 output wire [127:0] synth_data,output wire [255:0] string_catalog
);
 reg [13:0] cursor;
 reg [8:0] count;
 wire [31:0] q;
 wire in_range=!cursor[13];
 wire writing=put && !seal && in_range && count==0 && rst_n;
 generate if(HW_PATCH)begin:patch_families
  reg [255:0] eligible;
  reg [47:0] name_head;
  reg [7:0] name_id;
  reg [1:0] name_stage;
  function is_string_patch;
   input [79:0] name;
   reg [79:0] upper_name;
   reg [7:0] next_char;
   integer i;
   begin
    // ASCII letters are case insensitive; BASSOON is a separate family.
    for(i=0;i<10;i=i+1)upper_name[i*8+:8]=name[i*8+:8]&8'hdf;
    is_string_patch=0;
    for(i=0;i<7;i=i+1)begin
     next_char=i==6?8'd0:upper_name[(i+4)*8+:8];
     if(upper_name[i*8+:32]==32'h54495547 ||
        (upper_name[i*8+:32]==32'h53534142 && (next_char<8'h41 || next_char>8'h5a)))
      is_string_patch=1;
    end
    for(i=0;i<8;i=i+1)
     if(upper_name[i*8+:24]==24'h525447)is_string_patch=1;
   end
  endfunction
  assign string_catalog=eligible;
  always @(posedge clk)begin
   if(!rst_n || seal)begin
    name_stage<=0;
    if(!rst_n || data==0)eligible<=0;
   end else if(seek)name_stage<=0;
   else if(writing)case(cursor[4:0])
    5'd29:begin name_head[15:0]<=data[31:16];name_id<=cursor[12:5];name_stage<=1;end
    5'd30:begin name_head[47:16]<=data;name_stage<=name_stage==1 && name_id==cursor[12:5]?2:0;end
    5'd31:begin
     eligible[cursor[12:5]]<=name_stage==2 && name_id==cursor[12:5] && is_string_patch({data,name_head});
     name_stage<=0;
    end
    default:name_stage<=0;
   endcase
  end
 end else begin:no_patch_families
  assign string_catalog=0;
 end endgenerate
 wire readable=in_range && {1'b0,cursor[12:5]}<count;
 // The APB SETUP phase occurs after seek/increment and before ACCESS, so
 // the synchronous output has settled when the APB slave captures it.
 generate if(HW_PATCH)begin:wide_read
  wire [10:0] address=synth_read?synth_address:cursor[12:2];
  genvar g;
  for(g=0;g<4;g=g+1)begin:banks
   (* syn_ramstyle="block_ram" *) reg [31:0] words[0:2047];
   reg [31:0] word_q;
   always @(posedge clk)begin
    if(writing && cursor[1:0]==g)words[address]<=data;
    else word_q<=words[address];
   end
   assign synth_data[g*32+:32]=word_q;
  end
  assign q=synth_data[cursor[1:0]*32+:32];
 end else begin:narrow_read
  (* syn_ramstyle="block_ram" *) reg [31:0] words[0:8191];
  reg [31:0] word_q;
  always @(posedge clk)begin
   if(writing)words[cursor[12:0]]<=data;
   else word_q<=words[cursor[12:0]];
  end
  assign q=word_q;
  assign synth_data=0;
 end endgenerate
 always @(posedge clk)begin
  if(!rst_n)begin cursor<=0;count<=0;end
  else if(seal)begin cursor<=0;count<=(data<=32'd256) ? data[8:0] : 9'd0;end
  else if(seek)cursor<={1'b0,data[12:0]};
  else if(writing || (get && readable))cursor<=cursor+1'b1;
 end
 assign read_word=readable?q:32'd0;
 assign status={23'd0,count};
endmodule
`default_nettype wire
