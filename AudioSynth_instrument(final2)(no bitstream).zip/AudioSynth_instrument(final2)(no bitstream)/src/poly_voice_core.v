`default_nettype none
// Polyphonic command adapter for the already-verified mono DDS arithmetic.
// Reuses the same note LUT, synchronous sine ROM and synth_adsr unchanged.
module poly_voice_core #(
 parameter integer PITCH_ENABLE=0,
 parameter integer ATTACK_SAMPLES=146, DECAY_SAMPLES=3906, RELEASE_SAMPLES=5859,
 parameter [15:0] SUSTAIN_LEVEL=16'd49151
)(input wire clk,rst_n,sample_tick,note_on,note_off,
 input wire [6:0] note,velocity,input wire online,
 // Same-clock update port reserved for future per-voice pitch control.
 // NoteOn wins a simultaneous write; phase is never reset by a frequency write.
 input wire freq_write,input wire [31:0] freq_data,
 output wire signed [23:0] pcm,output wire [15:0] envelope,
 output wire [2:0] env_state,output reg [6:0] active_note,output reg gate,
 output wire busy,releasing,output wire [31:0] phase_debug,increment_debug,
 output reg [31:0] accepted_events,
 input wire [23:0] pitch_ratio);
 wire trigger=online && note_on && velocity!=0 && note>=48 && note<=72;
 wire stop=(!online && gate) || (note_off && gate);
 reg [15:0] velocity_target,velocity_gain;
 // Unbent base word is retained across pitch messages and NoteOff.
 reg [31:0] increment;
 reg [31:0] sampled_increment;
 wire [55:0] pitch_product=increment*pitch_ratio;
 wire [56:0] pitch_rounded={1'b0,pitch_product}+57'd2097152;
 wire [34:0] pitch_scaled=pitch_rounded[56:22];
 wire [31:0] bent_increment=(pitch_scaled>35'd4294967295)?32'hffffffff:pitch_scaled[31:0];
 wire [31:0] step_increment=PITCH_ENABLE?bent_increment:increment;
 wire [31:0] note_increment;
 reg [31:0] phase;
 wire signed [15:0] sine;
 synth_note_lut tuning(note,note_increment);
 poly_sine_interp waveform(clk,phase,sine);
 synth_adsr #(.ATTACK_SAMPLES(ATTACK_SAMPLES),.DECAY_SAMPLES(DECAY_SAMPLES),
 .RELEASE_SAMPLES(RELEASE_SAMPLES),.SUSTAIN_LEVEL(SUSTAIN_LEVEL)) adsr(
 clk,rst_n,sample_tick,trigger,stop,envelope,env_state);
 always @(posedge clk)begin
  if(!rst_n)begin active_note<=48;gate<=0;velocity_target<=0;velocity_gain<=0;phase<=0;increment<=0;sampled_increment<=0;accepted_events<=0;end
  else begin
   if(trigger)begin
    active_note<=note;gate<=1;
    // 127*516=65532, unsigned Q0.16; the gain slew prevents a velocity step.
    velocity_target<={9'd0,velocity}*16'd516;accepted_events<=accepted_events+1'b1;
   end else if(stop)begin gate<=0;accepted_events<=accepted_events+1'b1;end
   if(trigger)increment<=note_increment;
   else if(freq_write && online && (gate || env_state!=0))increment<=freq_data;
   if(sample_tick)begin
    sampled_increment<=step_increment;
    // Never reset phase on retrigger: frequency changes retain phase continuity.
    if(env_state!=0 || gate)phase<=phase+step_increment;
    if(velocity_gain<velocity_target)begin
     if({1'b0,velocity_target}-{1'b0,velocity_gain}<=17'd449)velocity_gain<=velocity_target;
     else velocity_gain<=velocity_gain+16'd449;
    end else if(velocity_gain>velocity_target)begin
     if({1'b0,velocity_gain}-{1'b0,velocity_target}<=17'd449)velocity_gain<=velocity_target;
     else velocity_gain<=velocity_gain-16'd449;
    end
   end
  end
 end
 // Explicit signed 16x17 -> 33, then 33x17 -> 50 bit products. Pipeline runs
 // every BCLK and settles well before the next 64-BCLK frame boundary.
 reg signed [32:0] env_product;
 reg signed [49:0] gain_product;
 reg signed [49:0] rounded;
 reg signed [23:0] pcm_reg;
 always @* begin
  if(gain_product>=0)rounded=(gain_product+50'sd67108864)>>>27;
  else rounded=-(((-gain_product)+50'sd67108864)>>>27);
 end
 always @(posedge clk)begin
  if(!rst_n)begin env_product<=0;gain_product<=0;pcm_reg<=0;end
  else begin
   env_product<=$signed(sine)*$signed({1'b0,envelope});
   gain_product<=env_product*$signed({1'b0,velocity_gain});
   // Conservative 1/8 peak gain (-18.06 dB), symmetric nearest rounding.
   if(rounded>50'sd8388607)pcm_reg<=24'sh7fffff;
   else if(rounded< -50'sd8388608)pcm_reg<=24'sh800000;
   else pcm_reg<=rounded[23:0];
  end
 end
 assign pcm=pcm_reg;
 assign busy=gate || env_state!=0 || pcm!=0;
 assign releasing=env_state==3'd4;
 assign phase_debug=phase;
 assign increment_debug=PITCH_ENABLE?sampled_increment:increment;
endmodule
`default_nettype wire
