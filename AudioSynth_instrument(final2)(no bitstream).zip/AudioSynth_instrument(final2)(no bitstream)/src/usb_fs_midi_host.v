`default_nettype none
// EP0 frame scheduling/reset policy adapted from usb_hid_host-main/rom/ukp.s.
// Copyright 2023 nand2mario; Copyright 2026 Mateusz Nalewajski. Apache-2.0.
// Restricted full-speed extension of the supplied HID Host: one direct device,
// EP0 and one descriptor-selected MIDI 1.0 Bulk IN. No hub/CPU/audio-class engine.
module usb_fs_midi_host #(
 parameter ATTACH_CYCLES=19200000,RESET_CYCLES=1920000,RECOVER_CYCLES=3840000,
 parameter ADDRESS_CYCLES=192000,FRAME_CYCLES=96000,POLL_CYCLES=9600,
 parameter FRAME_PACED_CONTROL=1,PRE_ADDRESS_RESET=1
)(input wire clk,rst_n,inout wire usb_dp,usb_dm,
 input wire record_ready,output reg record_valid,output reg [522:0] record_data,
 output reg [7:0] error_code,output reg [31:0] protocol_errors,
 output wire midi_ready,output wire [3:0] midi_endpoint,output wire [6:0] midi_mps);
 localparam ATTACH=0,RESET=1,RECOVER=2,CTRL_START=3,CTRL_WAIT=4,CFG_CHECK=5,
            ADDRESS_WAIT=6,CONFIG_LOG=7,READY_LOG=8,RUN=9,FAULT=10;
 reg [3:0] state /* synthesis syn_maxfan = 16 */;
 reg main_valid;reg [522:0] main_data;
 reg diag_pending;reg [522:0] diag_record;
 reg [31:0] diag_dropped;reg [127:0] last_transaction;
 reg tr_diag_event;
 reg [7:0] saved_ctrl_reason,saved_ctrl_stage,saved_ctrl_faults;
 wire [15:0] ctrl_retries;reg [15:0] saved_ctrl_retries;
 reg setup_sent,setup_acked;
 wire [127:0] tr_diagnostic;
 wire [7:0] phy_faults;wire phy_active;
 wire [3:0] ctrl_stage,ctrl_failure_stage;wire [2:0] ctrl_faults;wire [7:0] ctrl_reason;
 reg [2:0] step;
 reg [26:0] timer;
 reg [8:0] disconnect_count;
 reg [3:0] idle_guard;
 wire bus_reset=state==RESET;
 // Reference usb_hid_host-main/rom/ukp.s reset: recover with SOFs running,
 // but defer all EP0 traffic. Silence for >3ms would allow USB suspend.
 wire session_n=rst_n && state!=ATTACH && state!=RESET && state!=FAULT;
 wire line_j,line_se0,driving,phy_tx_ready,phy_tx_done,phy_rx_done,phy_rx_error,phy_crc;
 wire phy_tx_start;
 wire [3:0] phy_tx_len;
 wire [87:0] phy_tx_data;
 wire [6:0] phy_rx_len;
 wire [535:0] phy_rx_data;
 usb_fs_phy phy(clk,rst_n,bus_reset,usb_dp,usb_dm,
  phy_tx_start,phy_tx_len,phy_tx_data,phy_tx_ready,phy_tx_done,
  phy_rx_done,phy_rx_error,phy_crc,phy_rx_len,phy_rx_data,line_j,line_se0,driving,phy_faults,phy_active);
 reg ctrl_start;
 reg [63:0] setup;
 reg [6:0] device_address,ep0_mps;
 wire ctrl_busy,ctrl_done,ctrl_error,ctrl_data_valid;
 wire [6:0] ctrl_length;
 wire [511:0] ctrl_data;
 wire ctrl_request,ctrl_accept,ctrl_toggle;
 wire [1:0] ctrl_kind;
 wire [3:0] ctrl_out_length;
 wire [63:0] ctrl_out_data;
 wire tr_ready,tr_start,tr_done;
 wire [2:0] tr_result;
 wire [6:0] tr_length;
 wire [511:0] tr_data;
 reg [1:0] owner;
 usb_fs_control control(clk,session_n,ctrl_start,setup,device_address,ep0_mps,
  ctrl_busy,ctrl_done,ctrl_error,ctrl_data_valid,ctrl_length,ctrl_data,
  ctrl_request,ctrl_accept,ctrl_kind,ctrl_toggle,ctrl_out_length,ctrl_out_data,
  tr_done && owner==1,tr_result,tr_length,tr_data,ctrl_stage,ctrl_faults,ctrl_failure_stage,ctrl_reason,ctrl_retries);
 reg [16:0] frame_count;
 reg [10:0] frame_number;
 reg sof_pending,bulk_toggle,bulk_error_seen,control_slot;
 reg [13:0] poll_count;
 reg poll_due;
 reg bulk_waiting;
 // Record FIFO readiness is advisory at transaction launch (the response is
 // many cycles later). Register it so the FIFO pointer/full cone cannot drive
 // the USB packet register enables in the same 96MHz cycle.
 reg record_ready_q;
 wire bulk_request=state==RUN && !bulk_waiting && poll_due && record_ready_q;
 // Reserve >worst complete transaction including timeout before next SOF.
 // Exact next-count predicate; removes 17bit comparator from launch enables.
 reg allow_packet;
 // Reference setup_frame/read_control/status_read all call frame first.
 // USB hardware ACK does not imply endpoint firmware has retired the request.
 wire choose_ctrl=!sof_pending && allow_packet && ctrl_request && state!=RECOVER &&
                  (!FRAME_PACED_CONTROL || control_slot);
 wire choose_bulk=!sof_pending && allow_packet && !ctrl_request && bulk_request;
 assign tr_start=tr_ready && (sof_pending || choose_ctrl || choose_bulk);
 assign ctrl_accept=tr_ready && choose_ctrl;
 // Outside SOF, ctrl_request uniquely distinguishes EP0 from Bulk IN. Use it
 // for the payload mux while choose_ctrl remains the launch/arbitration grant.
 wire transaction_ctrl=ctrl_request;
 wire [1:0] tr_kind=sof_pending?2'd3:transaction_ctrl?ctrl_kind:2'd0;
 usb_fs_transaction transaction(clk,session_n,tr_start,tr_kind,device_address,
  transaction_ctrl?4'd0:midi_endpoint,frame_number,
  transaction_ctrl?ctrl_toggle:bulk_toggle,
  transaction_ctrl?ctrl_out_length:4'd0,transaction_ctrl?ctrl_out_data:64'd0,
  transaction_ctrl?ep0_mps:midi_mps,
  tr_ready,tr_done,tr_result,tr_length,tr_data,
  phy_tx_start,phy_tx_len,phy_tx_data,phy_tx_ready,phy_tx_done,
  phy_rx_done,phy_rx_error,phy_crc,phy_rx_len,phy_rx_data,phy_faults,phy_active,tr_diagnostic);
 always @(posedge clk)begin
  if(!session_n)begin frame_count<=0;frame_number<=0;sof_pending<=0;owner<=0;control_slot<=0;record_ready_q<=0;allow_packet<=1;end
  else begin
   record_ready_q<=record_ready;
   allow_packet<=frame_count==FRAME_CYCLES-1 || frame_count<FRAME_CYCLES-10001;
   if(tr_start)begin owner<=sof_pending?0:choose_ctrl?1:2;if(sof_pending)sof_pending<=0;end
   if(tr_done && owner==0)control_slot<=1;
   if(tr_start && choose_ctrl)control_slot<=0;
   if(frame_count==FRAME_CYCLES-1)begin frame_count<=0;frame_number<=frame_number+1'b1;sof_pending<=1;end
   else frame_count<=frame_count+1'b1;
  end
 end
 reg scan_start,scan_finish,feeding,control_finished,descriptor_bad;
 reg [511:0] feed_data;
 reg [6:0] feed_length,feed_index;
 reg [15:0] feed_offset,config_length;
 // Shift one byte/cycle instead of a 64:1 variable byte select on scanner path.
 wire [7:0] feed_byte=feed_data[7:0];
 wire scan_found,scan_error;
 wire [7:0] config_value,interface_number,alternate;
 usb_midi_descriptor_scan scanner(clk,session_n,scan_start,feeding && step==4,
  feed_byte,scan_finish,scan_found,scan_error,config_value,interface_number,alternate,
  midi_endpoint,midi_mps);
 assign midi_ready=state==RUN;
 // Diagnostics never backpressure protocol. Existing complete-record CDC is reused.
 // code7/len127 is a 32-byte metadata snapshot; code7/len<=64 is descriptor RAW.
 always @* begin
  record_valid=main_valid || (diag_pending && record_ready);
  record_data=main_valid?main_data:diag_record;
 end
 always @(posedge clk)begin
  if(!rst_n)begin diag_pending<=1;diag_record<={1'b1,3'd7,7'd127,256'd0,8'd5,8'd1,224'd0,8'h01,8'hd1};tr_diag_event<=0;
   diag_dropped<=0;last_transaction<=0;saved_ctrl_reason<=0;saved_ctrl_stage<=0;saved_ctrl_faults<=0;saved_ctrl_retries<=0;setup_sent<=0;setup_acked<=0;end
  else begin
   // Pipeline the diagnostic-only trigger; last_transaction is captured on
   // tr_done, so the next cycle carries the same complete snapshot without a
   // high-fanout transaction.done -> 523-bit record-enable path.
   tr_diag_event<=tr_done && owner==1 && (step<=1 || tr_result>=2);
   if(diag_pending && record_ready && !main_valid)diag_pending<=0;
   if(ctrl_start)begin setup_sent<=0;setup_acked<=0;end
   if(tr_done && owner==1 && tr_diagnostic[7:0]==8'h2d)begin
    setup_sent<=tr_diagnostic[25];setup_acked<=tr_result==0;
   end
   if(tr_done && owner!=0)last_transaction<=tr_diagnostic;
   if(ctrl_done)begin saved_ctrl_retries<=ctrl_retries;saved_ctrl_reason<=ctrl_reason;saved_ctrl_stage<={4'd0,ctrl_failure_stage};saved_ctrl_faults<={5'd0,ctrl_faults};end
   if((ctrl_start && step<=1) || tr_diag_event ||
      ctrl_data_valid || (main_valid && main_data[522] && (main_data[521:519]==5 || main_data[521:519]==4)))begin
    if(!diag_pending || (record_ready && !main_valid))begin
     diag_pending<=1;diag_record<=0;
     if(ctrl_data_valid)diag_record<={1'b1,3'd7,ctrl_length,ctrl_data};
     else begin
      diag_record[522:512]<={1'b1,3'd7,7'd127};
      diag_record[7:0]<=8'hd1;diag_record[15:8]<=8'h01; // format/build USBDBG1
      diag_record[23:16]<={4'd0,state};diag_record[31:24]<={5'd0,step};
      diag_record[39:32]<={4'd0,ctrl_stage};diag_record[47:40]<=main_valid?saved_ctrl_faults:{5'd0,ctrl_faults};
      diag_record[55:48]<=error_code;diag_record[63:56]<=main_valid?saved_ctrl_reason:ctrl_reason;
      diag_record[191:64]<=last_transaction;
      diag_record[223:192]<=diag_dropped;
      diag_record[231:224]<=main_valid?saved_ctrl_stage:{4'd0,ctrl_failure_stage};
      diag_record[247:240]<=main_valid?(main_data[521:519]==4?8'd4:8'd3):8'd2;
      diag_record[183:176]<={1'b0,midi_mps};
      diag_record[191:184]<={setup_acked,setup_sent,2'd0,midi_endpoint};
      diag_record[255:248]<=main_valid?saved_ctrl_retries[7:0]:ctrl_retries[7:0];
      diag_record[175:168]<=main_valid?saved_ctrl_retries[15:8]:ctrl_retries[15:8];
      diag_record[239:232]<={6'd0,line_se0,line_j};
      // Type5 is the exact eight-byte SETUP submitted to the transaction layer.
      // Keep the USBDBG1 framing; decoder branches on record type before fields.
      if(ctrl_start)begin
       diag_record[191:64]<=0;diag_record[127:64]<=setup;
       diag_record[135:128]<={1'b0,device_address};
       diag_record[247:240]<=8'd5;
      end
     end
    end else diag_dropped<=diag_dropped+1'b1;
   end
  end
 end
 task status;input [2:0] code;
  begin main_valid<=1;main_data[522:512]<={1'b1,code,7'd0};end
 endtask
 task fail;input [7:0] code;
  begin error_code<=code;protocol_errors<=protocol_errors+1'b1;status(5);state<=FAULT;timer<=0;end
 endtask
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=ATTACH;step<=0;timer<=0;disconnect_count<=0;idle_guard<=0;main_valid<=0;main_data<=0;
   ctrl_start<=0;setup<=0;device_address<=0;ep0_mps<=8;
   scan_start<=0;scan_finish<=0;feeding<=0;feed_data<=0;feed_length<=0;feed_index<=0;
   feed_offset<=0;config_length<=0;control_finished<=0;descriptor_bad<=0;
   bulk_toggle<=0;bulk_waiting<=0;bulk_error_seen<=0;poll_count<=0;poll_due<=1;error_code<=0;protocol_errors<=0;
  end else begin
   main_valid<=0;ctrl_start<=0;scan_start<=0;scan_finish<=0;
   // Observe undriven pins even while a transaction waits for a response.
   // Gating this on tr_ready misses unplug/replug inside the 85us IN timeout.
   // After the pad synchronizers settle, qualify 288 SE0 clocks (3us at
   // 96MHz). Normal two-bit EOP (~0.167us) cannot trigger this detector.
   // Host-driven reset/EOP is excluded; interrupted observations start anew.
   if(driving)idle_guard<=0;else if(idle_guard!=15)idle_guard<=idle_guard+1'b1;
   if(driving || idle_guard!=15 || !line_se0)disconnect_count<=0;
   else if(disconnect_count!=9'd288)disconnect_count<=disconnect_count+1'b1;
   if(poll_count!=0)poll_count<=poll_count-1'b1;
   poll_due<=poll_count<=1;
   if(ctrl_data_valid)begin
    feeding<=ctrl_length!=0;feed_data<=ctrl_data;feed_length<=ctrl_length;feed_index<=0;
   end else if(feeding)begin
    feed_data<=feed_data>>8;
    if(step==0 && feed_offset==7)begin
     if(feed_byte==8 || feed_byte==16 || feed_byte==32 || feed_byte==64)ep0_mps<=feed_byte[6:0];
     else descriptor_bad<=1;
    end
    if((step==0 || step==2) && ((feed_offset==0 && feed_byte!=18) || (feed_offset==1 && feed_byte!=1)))descriptor_bad<=1;
    if(step==3)begin
     if(feed_offset==0 && feed_byte!=9)descriptor_bad<=1;
     if(feed_offset==1 && feed_byte!=2)descriptor_bad<=1;
     if(feed_offset==2)config_length[7:0]<=feed_byte;
     if(feed_offset==3)config_length[15:8]<=feed_byte;
    end
    feed_offset<=feed_offset+1'b1;feed_index<=feed_index+1'b1;
    if(feed_index==feed_length-1'b1)feeding<=0;
   end
   if(ctrl_done)control_finished<=1;
   case(state)
    ATTACH:begin
     // Payload may be prepared while invalid; ready gates publication only.
     main_data[522:512]<={1'b1,3'd0,7'd0};
     device_address<=0;ep0_mps<=8;bulk_toggle<=0;bulk_waiting<=0;bulk_error_seen<=0;feeding<=0;step<=0;
     if(line_j)begin
      if(timer==ATTACH_CYCLES-1 && record_ready)begin main_valid<=1;error_code<=0;timer<=0;state<=RESET;end
      else timer<=timer+1'b1;
     end else timer<=0;
    end
    RESET:begin
     if(timer==0)status(1);
     if(timer==RESET_CYCLES-1)begin timer<=0;state<=RECOVER;end else timer<=timer+1'b1;
    end
    RECOVER:if(timer==RECOVER_CYCLES-1)begin timer<=0;state<=CTRL_START;end else timer<=timer+1'b1;
    CTRL_START:begin
     // Setup byte order is little endian, first byte at bits 7:0.
     case(step)
      0:setup<=64'h0008_0000_0100_0680; // GET Device initial 8
      1:setup<=64'h0000_0000_0001_0500; // SET address 1
      2:setup<=64'h0012_0000_0100_0680; // GET full Device
      3:setup<=64'h0009_0000_0200_0680; // GET Configuration header
      4:setup<={config_length,16'd0,16'h0200,16'h0680};
      5:setup<={32'd0,8'd0,config_value,16'h0900};
      6:setup<={16'd0,8'd0,interface_number,8'd0,alternate,16'h0b01};
      default:setup<=0;
     endcase
     feed_offset<=0;descriptor_bad<=0;control_finished<=0;ctrl_start<=1;
     if(step==4)scan_start<=1;
     state<=CTRL_WAIT;
    end
    CTRL_WAIT:if(control_finished && !feeding)begin
     if(ctrl_error || descriptor_bad)fail(8'h10+{5'd0,step});
     else case(step)
      // Reference probes descriptors, then resets again before SET_ADDRESS.
      // Preserve the observed EP0 MPS; all endpoint/control state is reset.
      0:if(feed_offset!=8)fail(8'h20);else begin step<=1;timer<=0;state<=PRE_ADDRESS_RESET?RESET:CTRL_START;end
      1:begin device_address<=1;timer<=0;state<=ADDRESS_WAIT;end
      2:if(feed_offset!=18)fail(8'h22);else begin status(2);step<=3;state<=CTRL_START;end
      3:if(feed_offset!=9 || config_length<9 || config_length>4096)fail(8'h23);
        else begin step<=4;state<=CTRL_START;end
      4:begin scan_finish<=1;state<=CFG_CHECK;end
      5:if(alternate!=0)begin step<=6;state<=CTRL_START;end else state<=CONFIG_LOG;
      6:state<=CONFIG_LOG;
      default:fail(8'h2f);
     endcase
    end
    CFG_CHECK:if(!scan_finish)begin
     if(scan_error || !scan_found)fail(8'h30);
     else begin step<=5;state<=CTRL_START;end
    end
    ADDRESS_WAIT:if(timer==ADDRESS_CYCLES-1)begin step<=2;state<=CTRL_START;timer<=0;end else timer<=timer+1'b1;
    CONFIG_LOG:begin main_data[522:512]<={1'b1,3'd3,7'd0};if(record_ready)begin main_valid<=1;state<=READY_LOG;end end
    READY_LOG:begin main_data[522:512]<={1'b1,3'd4,7'd0};if(record_ready)begin main_valid<=1;state<=RUN;poll_count<=0;poll_due<=1;bulk_toggle<=0;end end
    RUN:begin
     if(tr_start && choose_bulk)bulk_waiting<=1;
     if(tr_done && owner==2)begin
      bulk_waiting<=0;poll_count<=POLL_CYCLES-1;poll_due<=POLL_CYCLES<=1;
      if(tr_result==0)begin
       bulk_error_seen<=0;
       bulk_toggle<=!bulk_toggle;
       if(tr_length!=0)begin main_valid<=1;main_data<={1'b0,3'd0,tr_length,tr_data};end
      end else if(tr_result==2)fail(8'h41);
      else if(tr_result==3)begin
       protocol_errors<=protocol_errors+1'b1;error_code<=8'h42;
       // Count every failure, but log once per error burst so an unplugged
       // device cannot flood the status FIFO while disconnect is qualified.
       if(!bulk_error_seen)status(5);
       bulk_error_seen<=1;
      end
     end
    end
    FAULT:if(timer==95999999)begin timer<=0;state<=ATTACH;end else timer<=timer+1'b1;
    default:state<=ATTACH;
   endcase
   if(state!=ATTACH && state!=RESET && disconnect_count==9'd287 && line_se0 && !driving)begin
    status(6);state<=ATTACH;timer<=0;disconnect_count<=0;
    // Prevent an old-session packet from being fed after the reconnect.
    ctrl_start<=0;feeding<=0;control_finished<=0;bulk_waiting<=0;
   end
  end
 end
endmodule
`default_nettype wire
