# Core-board 50MHz active oscillator, user-confirmed, not a PLL-derived clock.
create_clock -name core_50m -period 20.000 -waveform {0.000 10.000} [get_ports {clk_50m}]
# Static asynchronous USB line probes only. Only input->first FF paths start here;
# synchronizer stage1->stage2 and all internal synchronous paths remain timed.
set_false_path -from [get_ports {usb_dp usb_dm}]
# UART is asynchronous 8N1, not a synchronous source-synchronous output interface.
# This cuts the pad path only; UART state/timer and output FF are still timed.
set_false_path -to [get_ports {uart_tx}]
