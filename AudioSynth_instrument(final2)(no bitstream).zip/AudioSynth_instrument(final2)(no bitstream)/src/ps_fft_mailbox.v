`default_nettype none
// The 50 MHz capture side never waits for the CPU or the panel.
module ps_fft_mailbox(
 input wire clk,rst_n,clear,stream_ok,sample_valid,pcm,
 input wire [31:0] sample_data,
 input wire apb_read,apb_write,input wire [3:0] address,input wire [31:0] wdata,
 output reg [31:0] rdata,
 input wire [4:0] column_word,output reg [23:0] heights,
 output reg feature_ready,input wire feature_taken,feature_busy
);
 reg [9:0] wr_addr,rd_addr;
 reg wr_bank,published_bank,window_ready,window_pcm;
 reg [29:0] sequence_id;
 reg [31:0] completed;
 (* syn_ramstyle="block_ram" *) reg [31:0] samples[0:2047];
 reg feature_bank;
 (* syn_ramstyle="block_ram" *) reg [23:0] feature_words[0:63];
 reg [31:0] sample_q;
 wire release_window=apb_write && address==4'h8 && wdata[31:2]==sequence_id;
 wire publish_features=release_window && wdata[0] && !feature_busy;
 always @(posedge clk)begin
  if(rst_n && !clear && stream_ok && sample_valid)
   samples[{wr_bank,wr_addr}]<=sample_data;
  sample_q<=samples[{published_bank,rd_addr}];
  if(rst_n && !clear && apb_write && address==4'hc && window_ready)
   feature_words[{!feature_bank,wdata[28:24]}]<=wdata[23:0];
  heights<=feature_words[{feature_bank,column_word}];
 end
 always @*begin
  case(address)
   4'h0:rdata={sequence_id,window_pcm,window_ready};
   4'h4:rdata=sample_q;
   4'h8:rdata={31'd0,feature_ready};
   4'hc:rdata=completed;
   default:rdata=0;
  endcase
 end
 always @(posedge clk)begin
  if(!rst_n)begin
   wr_addr<=0;rd_addr<=0;wr_bank<=0;published_bank<=0;window_ready<=0;
   window_pcm<=0;sequence_id<=0;feature_ready<=0;feature_bank<=0;completed<=0;
  end else if(clear)begin
   wr_addr<=0;rd_addr<=0;window_ready<=0;feature_ready<=0;
   sequence_id<=sequence_id+1'b1;
  end else begin
   if(feature_taken)feature_ready<=0;
   if(window_ready && apb_read && address==4'h4)rd_addr<=rd_addr+1'b1;
   if(window_ready && release_window)begin
    window_ready<=0;
    if(publish_features)begin
     feature_bank<=!feature_bank;feature_ready<=1;completed<=completed+1'b1;
    end
   end
   if(!stream_ok)wr_addr<=0;
   else if(sample_valid)begin
    wr_addr<=wr_addr+1'b1;
    if(wr_addr==1023 && !window_ready)begin
     published_bank<=wr_bank;wr_bank<=!wr_bank;rd_addr<=0;
     window_ready<=1;window_pcm<=pcm;sequence_id<=sequence_id+1'b1;
    end
   end
  end
 end
endmodule
`default_nettype wire
