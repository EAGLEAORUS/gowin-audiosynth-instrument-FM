`default_nettype none
// Linear exact-duration ADSR. A/D/R are positive sample counts, not BCLK counts.
// Remainder accumulation prevents early termination when released from low levels.
module synth_adsr #(
 parameter integer ATTACK_SAMPLES=146, DECAY_SAMPLES=3906, RELEASE_SAMPLES=5859,
 parameter [15:0] SUSTAIN_LEVEL=16'd49151
)(input wire clk,rst_n,sample_tick,trigger,release_note,
 output reg [15:0] envelope,output reg [2:0] state);
 localparam IDLE=3'd0,ATTACK=3'd1,DECAY=3'd2,SUSTAIN=3'd3,RELEASE=3'd4;
 reg [31:0] step_size,remainder,error_acc,length,remaining;
 wire [32:0] sum_error={1'b0,error_acc}+{1'b0,remainder};
 wire carry=sum_error>={1'b0,length};
 wire [32:0] next_error=carry?(sum_error-{1'b0,length}):sum_error;
 wire [32:0] change={1'b0,step_size}+{{32{1'b0}},carry};
 wire [31:0] attack_distance=32'd65535-{16'd0,envelope};
 always @(posedge clk)begin
  if(!rst_n)begin envelope<=0;state<=IDLE;step_size<=0;remainder<=0;error_acc<=0;length<=1;remaining<=0;end
  else if(trigger)begin
   state<=ATTACK;length<=ATTACK_SAMPLES;remaining<=ATTACK_SAMPLES;error_acc<=0;
   step_size<=attack_distance/ATTACK_SAMPLES;remainder<=attack_distance%ATTACK_SAMPLES;
  end else if(release_note && state!=IDLE && state!=RELEASE)begin
   state<=RELEASE;length<=RELEASE_SAMPLES;remaining<=RELEASE_SAMPLES;error_acc<=0;
   step_size<={16'd0,envelope}/RELEASE_SAMPLES;remainder<={16'd0,envelope}%RELEASE_SAMPLES;
  end else if(sample_tick)begin
   if(state==ATTACK || state==DECAY || state==RELEASE)begin
    error_acc<=next_error[31:0];
    remaining<=remaining-32'd1;
    if(state==ATTACK)envelope<=envelope+change[15:0];
    else envelope<=envelope-change[15:0];
    if(remaining==1)begin
     error_acc<=0;
     case(state)
      ATTACK:begin
       envelope<=16'd65535;state<=DECAY;length<=DECAY_SAMPLES;remaining<=DECAY_SAMPLES;
       step_size<=(32'd65535-SUSTAIN_LEVEL)/DECAY_SAMPLES;
       remainder<=(32'd65535-SUSTAIN_LEVEL)%DECAY_SAMPLES;
      end
      DECAY:begin envelope<=SUSTAIN_LEVEL;state<=SUSTAIN;end
      RELEASE:begin envelope<=0;state<=IDLE;end
      default:begin envelope<=0;state<=IDLE;end
     endcase
    end
   end else if(state==IDLE)envelope<=0;
   else if(state==SUSTAIN)envelope<=SUSTAIN_LEVEL;
   else begin envelope<=0;state<=IDLE;end
  end
 end
endmodule
`default_nettype wire
