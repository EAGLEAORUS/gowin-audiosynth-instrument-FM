`default_nettype none
// Single-clock, power-of-two FIFO. rst_n is synchronous, active low.
module midi_sync_fifo #(parameter WIDTH=8, parameter ADDR_BITS=4)(
 input wire clk, input wire rst_n, input wire push, input wire [WIDTH-1:0] din,
 output wire ready, output wire valid, output wire [WIDTH-1:0] dout,
 input wire pop, output reg [31:0] overflow_count
);
 localparam DEPTH=1<<ADDR_BITS;
 // This FIFO requires asynchronous first-word fall-through. Gowin's default
 // BSRAM inference retimes the read/capture logic and fails the post-route
 // packet/event oracle. These shallow queues deliberately use registers;
 // see SUG550 5.16. No read latency is added to the public FIFO contract.
 reg [WIDTH-1:0] mem[0:DEPTH-1] /* synthesis syn_ramstyle="registers" */;
 reg [ADDR_BITS-1:0] rd,wr;
 reg [ADDR_BITS:0] count;
 wire take=pop && valid;
 wire put=push && ready;
 assign valid=(count!=0);
 assign ready=(count<DEPTH)||take;
 assign dout=mem[rd];
 always @(posedge clk) begin
  if(!rst_n) begin rd<=0;wr<=0;count<=0;overflow_count<=0;end
  else begin
   if(put) begin mem[wr]<=din;wr<=wr+1'b1;end
   if(take) rd<=rd+1'b1;
   case({put,take})
    2'b10:count<=count+1'b1;
    2'b01:count<=count-1'b1;
    default:count<=count;
   endcase
   if(push && !ready && overflow_count!=32'hffffffff)
    overflow_count<=overflow_count+1'b1;
  end
 end
endmodule

// Same-clock FIFO with an explicit registered output buffer.  This form is
// used only for the wide diagnostic/descriptor queue: unlike the FWFT FIFO
// above, its read port has a full clock of latency and can safely infer BSRAM.
// The output buffer is counted in capacity and remains stable under backpressure.
module midi_sync_fifo_buffered #(parameter WIDTH=8, parameter ADDR_BITS=4)(
 input wire clk, input wire rst_n, input wire push, input wire [WIDTH-1:0] din,
 output wire ready, output wire valid, output wire [WIDTH-1:0] dout,
 input wire pop, output reg [31:0] overflow_count
);
 localparam DEPTH=1<<ADDR_BITS;
 reg [WIDTH-1:0] mem[0:DEPTH-1];
 reg [ADDR_BITS-1:0] rd,wr;
 reg [ADDR_BITS:0] stored_count;
 reg output_valid;
 reg [WIDTH-1:0] output_data;
 wire take=pop && output_valid;
 wire [ADDR_BITS:0] used=stored_count+output_valid;
 wire put=push && ready;
 wire load=(!output_valid || take) && stored_count!=0;
 assign ready=(used<DEPTH)||take;
 assign valid=output_valid;
 assign dout=output_data;
 always @(posedge clk)begin
  if(!rst_n)begin
   rd<=0;wr<=0;stored_count<=0;output_valid<=0;output_data<=0;
   overflow_count<=0;
  end else begin
   if(put)begin mem[wr]<=din;wr<=wr+1'b1;end
   if(load)begin
    output_data<=mem[rd];rd<=rd+1'b1;output_valid<=1;
   end else if(take)output_valid<=0;
   case({put,load})
    2'b10:stored_count<=stored_count+1'b1;
    2'b01:stored_count<=stored_count-1'b1;
    default:stored_count<=stored_count;
   endcase
   if(push && !ready && overflow_count!=32'hffffffff)
    overflow_count<=overflow_count+1'b1;
  end
 end
endmodule
// Synchronous BSRAM read with a registered FWFT head and one-word lookahead.
// Same valid/ready/take cycle contract as midi_sync_fifo; no consumer retime.
// Forward the most recent write explicitly instead of depending on BSRAM's
// device-specific same-address read/write behavior. ADDR_BITS must be >=2.
module midi_sync_fifo_fwft_ram #(parameter WIDTH=8,parameter ADDR_BITS=4)(
 input wire clk,rst_n,push,input wire [WIDTH-1:0] din,
 output wire ready,valid,output wire [WIDTH-1:0] dout,
 input wire pop,output reg [31:0] overflow_count);
 localparam integer DEPTH=1<<ADDR_BITS;
 localparam [ADDR_BITS-1:0] ONE=1,TWO=2;
 (* syn_ramstyle="block_ram" *) reg [WIDTH-1:0] mem[0:DEPTH-1];
 reg [ADDR_BITS-1:0] rd,wr;
 reg [ADDR_BITS:0] count;
 reg [WIDTH-1:0] head,ram_q,forward_data;
 reg forward_valid;
 wire take=pop && valid,put=push && ready;
 wire [ADDR_BITS-1:0] lookahead_addr=rd+(take?TWO:ONE);
 wire [WIDTH-1:0] next_head=forward_valid?forward_data:ram_q;
 assign valid=count!=0;
 assign ready=count<DEPTH || take;
 assign dout=head;
 always @(posedge clk)begin
  if(rst_n && put)mem[wr]<=din;
  ram_q<=mem[lookahead_addr];
  forward_valid<=rst_n && put && wr==lookahead_addr;
  if(put)forward_data<=din;
  if(!rst_n)begin rd<=0;wr<=0;count<=0;head<=0;overflow_count<=0;end
  else begin
   if(put)wr<=wr+1'b1;
   if(take)rd<=rd+1'b1;
   if(put && (count==0 || (count==1 && take)))head<=din;
   else if(take && count>1)head<=next_head;
   case({put,take})2'b10:count<=count+1'b1;2'b01:count<=count-1'b1;default:begin end endcase
   if(push && !ready && !(&overflow_count))overflow_count<=overflow_count+1'b1;
  end
 end
endmodule
// Narrow dual-port RAM holding complete wide records. Capacity includes the
// write stage, read stage and output; no partial record is ever made valid.
// One18-bit chunk/clock; ready explicitly refuses a new record while staging
// is occupied. Production USB packets are separated by more than29 clocks.
// This buffered queue changes diagnostic packet latency, never MIDI contents.
module midi_sync_fifo_packed #(parameter WIDTH=520,parameter ADDR_BITS=5)(
 input wire clk,rst_n,push,input wire [WIDTH-1:0] din,
 output wire ready,output reg valid,output wire [WIDTH-1:0] dout,
 input wire pop,output reg [31:0] overflow_count);
 localparam integer DEPTH=1<<ADDR_BITS;
 localparam integer CHUNKS=(WIDTH+17)/18;
 localparam integer CB=(CHUNKS<=1)?1:$clog2(CHUNKS);
 localparam integer PAD=CHUNKS*18;
 (* syn_ramstyle="block_ram" *) reg [17:0] mem[0:(1<<(ADDR_BITS+CB))-1];
 reg [PAD-1:0] stage,assembled;
 reg [17:0] ram_q;
 reg writing,reading;reg [CB:0] wp,rp;
 reg [ADDR_BITS-1:0] wr_record,rd_record;
 reg [ADDR_BITS:0] committed,level;
 wire take=pop && valid;
 wire finish_write=writing && wp==CHUNKS-1;
 assign ready=(level<DEPTH || take) && (!writing || finish_write);
 wire put=push && ready;
 wire begin_read=!reading && !valid && committed!=0;
 assign dout=assembled[WIDTH-1:0];
 always @(posedge clk)begin
  if(rst_n && writing)mem[{wr_record,wp[CB-1:0]}]<=stage[17:0];
  ram_q<=mem[{rd_record,rp[CB-1:0]}];
  if(!rst_n)begin
   stage<=0;assembled<=0;writing<=0;reading<=0;wp<=0;rp<=0;
   wr_record<=0;rd_record<=0;committed<=0;level<=0;valid<=0;overflow_count<=0;
  end else begin
   case({put,take})2'b10:level<=level+1'b1;2'b01:level<=level-1'b1;default:begin end endcase
   case({finish_write,begin_read})2'b10:committed<=committed+1'b1;2'b01:committed<=committed-1'b1;default:begin end endcase
   if(take)valid<=0;
   if(writing)begin
    stage<=stage>>18;wp<=wp+1'b1;
    if(finish_write)begin writing<=0;wr_record<=wr_record+1'b1;end
   end
   if(put)begin stage<={{(PAD-WIDTH){1'b0}},din};writing<=1;wp<=0;end
   if(!reading)rp<=0;
   if(begin_read)begin reading<=1;rp<=0;end
   if(reading)begin
    rp<=rp+1'b1;
    if(rp!=0)assembled<=({ram_q,assembled} >>18);
    if(rp==CHUNKS)begin valid<=1;reading<=0;rd_record<=rd_record+1'b1;end
   end
   if(push && !ready && !(&overflow_count))overflow_count<=overflow_count+1'b1;
  end
 end
endmodule
`default_nettype wire
