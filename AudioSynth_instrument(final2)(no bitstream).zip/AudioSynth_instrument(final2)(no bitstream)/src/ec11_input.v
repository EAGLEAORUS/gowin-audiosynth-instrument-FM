`default_nettype none
// No generated clock: synchronization, debounce and quadrature use clk_50m.
module ec11_input #(parameter integer FILTER_CYCLES=2500, PRESS_CYCLES=500000)(
 input wire clk,rst_n,a,b,push_n,output reg turn,clockwise,press);
 (* syn_preserve=1 *) reg a_meta,a_sync,b_meta,b_sync,p_meta,p_sync;
 localparam integer FB=FILTER_CYCLES>1?$clog2(FILTER_CYCLES):1;
 localparam integer PB=PRESS_CYCLES>1?$clog2(PRESS_CYCLES):1;
 reg [FB-1:0] fc;reg [PB-1:0] pc;
 reg [1:0] ab;reg p_stable;
 reg signed [3:0] quarter;reg signed [3:0] delta;
 always @* begin
  delta=0;
  case({ab,a_sync,b_sync})
   4'b1101,4'b0100,4'b0010,4'b1011:delta=1;
   4'b1110,4'b1000,4'b0001,4'b0111:delta=-1;
   default:delta=0;
  endcase
 end
 always @(posedge clk)begin
  if(!rst_n)begin
   a_meta<=1;a_sync<=1;b_meta<=1;b_sync<=1;p_meta<=1;p_sync<=1;
   fc<=0;pc<=0;ab<=3;p_stable<=1;quarter<=0;turn<=0;clockwise<=0;press<=0;
  end else begin
   a_meta<=a;a_sync<=a_meta;b_meta<=b;b_sync<=b_meta;p_meta<=push_n;p_sync<=p_meta;
   turn<=0;press<=0;
   if({a_sync,b_sync}==ab)fc<=0;
   else if(fc==FILTER_CYCLES-1)begin
    fc<=0;ab<={a_sync,b_sync};
    if(delta==0)quarter<=0;
    else if({a_sync,b_sync}==2'b11)begin
     if(quarter+delta==4 || quarter+delta==-4)begin turn<=1;clockwise<=delta>0;end
     quarter<=0;
    end else quarter<=quarter+delta;
   end else fc<=fc+1'b1;
   if(p_sync==p_stable)pc<=0;
   else if(pc==PRESS_CYCLES-1)begin
    pc<=0;p_stable<=p_sync;if(!p_sync)press<=1;
   end else pc<=pc+1'b1;
  end
 end
endmodule
`default_nettype wire
