`default_nettype none
module tft_st7789 #(parameter integer RESET_CYCLES=5000000, SETTLE_CYCLES=2500000,
 SLEEP_CYCLES=6000000, SPI_HALF_PERIOD=4)(
 input wire clk,rst_n,input wire [15:0] pixel,
 output reg [8:0] x,output reg [7:0] y,output reg frame_start,
 output wire cs_n,sclk,mosi,dc,output reg res_n,blk);
 reg tx_start,tx_dc;reg [7:0] tx_data;wire busy,done;
 tft_spi_byte #(.HALF_PERIOD(SPI_HALF_PERIOD)) spi(clk,rst_n,tx_start,tx_dc,tx_data,busy,done,cs_n,sclk,mosi,dc);
 reg [4:0] state;reg [22:0] wait_count;reg [6:0] init_index;reg [3:0] cmd_index;
 reg [15:0] pixel_latch;
 function [8:0] init_word;input [6:0] address;
 begin case(address)
   7'd0:init_word=9'h036;
   7'd1:init_word=9'h100;
   7'd2:init_word=9'h03a;
   7'd3:init_word=9'h105;
   7'd4:init_word=9'h0b2;
   7'd5:init_word=9'h10c;
   7'd6:init_word=9'h10c;
   7'd7:init_word=9'h100;
   7'd8:init_word=9'h133;
   7'd9:init_word=9'h133;
   7'd10:init_word=9'h0b7;
   7'd11:init_word=9'h135;
   7'd12:init_word=9'h0bb;
   7'd13:init_word=9'h128;
   7'd14:init_word=9'h0c0;
   7'd15:init_word=9'h12c;
   7'd16:init_word=9'h0c2;
   7'd17:init_word=9'h101;
   7'd18:init_word=9'h0c3;
   7'd19:init_word=9'h10b;
   7'd20:init_word=9'h0c4;
   7'd21:init_word=9'h120;
   7'd22:init_word=9'h0c6;
   7'd23:init_word=9'h10f;
   7'd24:init_word=9'h0d0;
   7'd25:init_word=9'h1a4;
   7'd26:init_word=9'h1a1;
   7'd27:init_word=9'h0e0;
   7'd28:init_word=9'h1d0;
   7'd29:init_word=9'h101;
   7'd30:init_word=9'h108;
   7'd31:init_word=9'h10f;
   7'd32:init_word=9'h111;
   7'd33:init_word=9'h12a;
   7'd34:init_word=9'h136;
   7'd35:init_word=9'h155;
   7'd36:init_word=9'h144;
   7'd37:init_word=9'h13a;
   7'd38:init_word=9'h10b;
   7'd39:init_word=9'h106;
   7'd40:init_word=9'h111;
   7'd41:init_word=9'h120;
   7'd42:init_word=9'h0e1;
   7'd43:init_word=9'h1d0;
   7'd44:init_word=9'h102;
   7'd45:init_word=9'h107;
   7'd46:init_word=9'h10a;
   7'd47:init_word=9'h10b;
   7'd48:init_word=9'h118;
   7'd49:init_word=9'h134;
   7'd50:init_word=9'h143;
   7'd51:init_word=9'h14a;
   7'd52:init_word=9'h12b;
   7'd53:init_word=9'h11b;
   7'd54:init_word=9'h11c;
   7'd55:init_word=9'h122;
   7'd56:init_word=9'h11f;
   7'd57:init_word=9'h029;
   7'd58:init_word=9'h011;
   7'd59:init_word=9'h029;
   7'd60:init_word=9'h036;
   7'd61:init_word=9'h160;
   default:init_word=0;
  endcase end endfunction
 wire [8:0] iw=init_word(init_index);
 function [8:0] window_word;input [3:0] address;
 begin case(address)
  0:window_word=9'h02a;1:window_word=9'h100;2:window_word=9'h100;
  3:window_word=9'h101;4:window_word=9'h13f;
  5:window_word=9'h02b;6:window_word=9'h100;7:window_word=9'h100;
  8:window_word=9'h100;9:window_word=9'h1ef;10:window_word=9'h02c;
  default:window_word=0;
 endcase end endfunction
 wire [8:0] ww=window_word(cmd_index);
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=0;wait_count<=0;init_index<=0;cmd_index<=0;tx_start<=0;tx_dc<=0;tx_data<=0;
   res_n<=0;blk<=0;x<=0;y<=0;frame_start<=0;pixel_latch<=0;
  end else begin
   tx_start<=0;frame_start<=0;
   case(state)
    0:if(wait_count==RESET_CYCLES-1)begin res_n<=1;wait_count<=0;state<=1;end else wait_count<=wait_count+1'b1;
    1:if(wait_count==SETTLE_CYCLES-1)begin wait_count<=0;state<=2;end else wait_count<=wait_count+1'b1;
    2:begin tx_start<=1;tx_dc<=iw[8];tx_data<=iw[7:0];state<=3;end
    3:if(done)begin
     init_index<=init_index+1'b1;
     if(init_index==7'd58)begin wait_count<=0;state<=4;end
     else if(init_index==7'd61)state<=5;
     else state<=2;
    end
    4:if(wait_count==SLEEP_CYCLES-1)begin wait_count<=0;state<=2;end else wait_count<=wait_count+1'b1;
    5:begin frame_start<=1;cmd_index<=0;x<=0;y<=0;state<=6;end
    6:begin tx_start<=1;tx_dc<=ww[8];tx_data<=ww[7:0];state<=7;end
    7:if(done)begin
     if(cmd_index==10)state<=8;else begin cmd_index<=cmd_index+1'b1;state<=6;end
    end
    // Three cycles for registered text/font/pixel lookup; x/y stay fixed.
    8:state<=9;9:state<=10;10:state<=11;
    11:begin pixel_latch<=pixel;tx_start<=1;tx_dc<=1;tx_data<=pixel[15:8];state<=12;end
    12:if(done)state<=13;
    13:begin tx_start<=1;tx_dc<=1;tx_data<=pixel_latch[7:0];state<=14;end
    14:if(done)begin
     if(x==319)begin
      x<=0;
      if(y==239)begin blk<=1;state<=5;end else begin y<=y+1'b1;state<=8;end
     end else begin x<=x+1'b1;state<=8;end
    end
    default:state<=0;
   endcase
  end
 end
endmodule
`default_nettype wire
