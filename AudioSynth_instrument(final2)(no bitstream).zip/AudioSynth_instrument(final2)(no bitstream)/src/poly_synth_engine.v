`default_nettype none
module poly_synth_engine(
 input wire clk,rst_n,sample_tick,event_valid,input wire [39:0] event_data,input wire online,
 // Same-domain unbent base-frequency override; channel pitch is applied afterward.
 input wire freq_write,input wire [1:0] freq_voice,input wire [31:0] freq_data,
 output wire signed [23:0] pcm,output wire [3:0] busy,gate,releasing,
 output wire [27:0] active_notes,output wire [63:0] envelopes,output wire [11:0] env_states,
 output wire [95:0] voice_pcm,output wire [127:0] phases,increments,
 output wire [31:0] routed_events,steal_count,retrigger_count,clip_count);
 (* syn_keep=1 *) wire [13:0] pitch_value;
 wire [23:0] pitch_ratio;
 (* syn_keep=1 *) wire [31:0] pitch_events;
 synth_pitch_control pitch(clk,rst_n,event_valid,event_data,online,pitch_value,pitch_ratio,pitch_events);
 wire [3:0] on,off;wire [6:0] note,velocity;
 wire [27:0] assigned_notes;wire [15:0] assigned_channels;
 voice_allocator allocator(clk,rst_n,event_valid,event_data,online,busy,gate,releasing,
  on,off,note,velocity,assigned_notes,assigned_channels,routed_events,steal_count,retrigger_count);
 genvar g;generate for(g=0;g<4;g=g+1)begin:voices
  localparam [1:0] VOICE_INDEX=g;
  wire [31:0] accepted;
  poly_voice_core #(.PITCH_ENABLE(1)) core(clk,rst_n,sample_tick,on[g],off[g],note,velocity,online,
   freq_write && freq_voice==VOICE_INDEX,freq_data,voice_pcm[g*24+:24],envelopes[g*16+:16],env_states[g*3+:3],
   active_notes[g*7+:7],gate[g],busy[g],releasing[g],phases[g*32+:32],increments[g*32+:32],accepted,pitch_ratio);
 end endgenerate
 voice_mixer mixer(clk,rst_n,sample_tick,voice_pcm,pcm,clip_count);
endmodule
`default_nettype wire
