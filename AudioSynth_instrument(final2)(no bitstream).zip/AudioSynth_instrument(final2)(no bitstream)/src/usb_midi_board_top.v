`default_nettype none
// Pin/PnR/UART SELFTEST ONLY. No USB Host, USB reset, control or IN tokens.
// USB pins are input-only static line probes; no USB traffic is decoded.
module usb_midi_board_top #(
 parameter CLK_HZ=50000000,parameter BAUD=115200,parameter POR_BITS=16,
 parameter SELFTEST_WAIT_CYCLES=CLK_HZ/5,
 parameter USB_STABLE_CYCLES=CLK_HZ/100,
 parameter HEARTBEAT_CYCLES=CLK_HZ*2
)(input wire clk_50m,input wire usb_dp,input wire usb_dm,output wire uart_tx);
 // Explicit FPGA power-up state. Gowin init-to-GSR mapping is checked in netlist.
 reg [POR_BITS-1:0] por_count=0;
 wire rst_n=&por_count;
 always @(posedge clk_50m)if(!rst_n)por_count<=por_count+1'b1;
 // Independent asynchronous single-bit inputs, used ONLY after static debounce.
 (* syn_preserve=1 *) reg usb_dp_meta,usb_dp_sync;
 (* syn_preserve=1 *) reg usb_dm_meta,usb_dm_sync;
 reg [1:0] candidate,stable_state,reported_state;
 reg [31:0] stable_count,heartbeat_count;
 reg stable_valid,reported_valid;
 always @(posedge clk_50m)begin
  if(!rst_n)begin usb_dp_meta<=0;usb_dp_sync<=0;usb_dm_meta<=0;usb_dm_sync<=0;
   candidate<=0;stable_state<=0;stable_count<=0;stable_valid<=0;end
  else begin
   usb_dp_meta<=usb_dp;usb_dp_sync<=usb_dp_meta;
   usb_dm_meta<=usb_dm;usb_dm_sync<=usb_dm_meta;
   if({usb_dp_sync,usb_dm_sync}!=candidate)begin
    candidate<={usb_dp_sync,usb_dm_sync};stable_count<=0;
   end else if(stable_count<USB_STABLE_CYCLES-1)stable_count<=stable_count+1'b1;
   else begin stable_state<=candidate;stable_valid<=1;end
  end
 end
 localparam BOOT=3'd0,BOOT_WAIT=3'd1,SELFTEST=3'd2,
            END_SEND=3'd3,END_WAIT=3'd4,MONITOR=3'd5,MONITOR_WAIT=3'd6;
 reg [2:0] state;
 reg [31:0] wait_count;
 reg msg_start,packet_valid;
 reg [1:0] msg_id;
 reg dp_for_message,dm_for_message;
 wire message_tx,payload_tx,msg_done;
 midi_board_message_tx #(CLK_HZ,BAUD) messages(
 clk_50m,rst_n,msg_start,msg_id,dp_for_message,dm_for_message,message_tx,msg_done);
 // Six unmistakably SYNTHETIC test events, not keyboard data.
 wire [511:0] test_payload={320'd0,
   32'h000ac00c,32'h4000e00e,32'h4001b00b,
   32'h003c8008,32'h00409009,32'h643c9009};
 usb_midi_debug #(.CLK_HZ(CLK_HZ),.BAUD(BAUD)) payload(
  .clk(clk_50m),.rst_n(rst_n),.packet_valid(packet_valid),
  .packet_length(7'd24),.packet_data(test_payload),.raw_enable(1'b1),
  .status_valid(1'b0),.status_code(3'd0),.uart_tx(payload_tx),
  .evt_valid(),.evt_ready(1'b1),.evt_data(),.packet_overflow(),.event_overflow(),
  .event_log_overflow(),.raw_log_overflow(),.status_log_overflow(),
  .malformed_count(),.unsupported_count(),.recovery_required(),.packet_ready(),.raw_ready());
 assign uart_tx=(state==SELFTEST)?payload_tx:message_tx;
 always @(posedge clk_50m)begin
  if(!rst_n)begin state<=BOOT;wait_count<=0;msg_start<=0;msg_id<=0;packet_valid<=0;
   dp_for_message<=0;dm_for_message<=0;reported_state<=0;reported_valid<=0;heartbeat_count<=0;end
  else begin
   msg_start<=0;packet_valid<=0;
   if(heartbeat_count<HEARTBEAT_CYCLES-1)heartbeat_count<=heartbeat_count+1'b1;
   case(state)
    BOOT:begin msg_id<=0;msg_start<=1;state<=BOOT_WAIT;end
    BOOT_WAIT:if(msg_done)begin packet_valid<=1;wait_count<=0;state<=SELFTEST;end
    SELFTEST:begin
     // At default parameters the complete block takes <40ms; reserve 200ms.
     if(wait_count==SELFTEST_WAIT_CYCLES-1)state<=END_SEND;
     else wait_count<=wait_count+1'b1;
    end
    END_SEND:begin msg_id<=1;msg_start<=1;state<=END_WAIT;end
    END_WAIT:if(msg_done)state<=MONITOR;
    MONITOR:if(stable_valid && (!reported_valid || reported_state!=stable_state || heartbeat_count==HEARTBEAT_CYCLES-1))begin
     msg_id<=2;msg_start<=1;dp_for_message<=stable_state[1];dm_for_message<=stable_state[0];
     reported_state<=stable_state;reported_valid<=1;heartbeat_count<=0;state<=MONITOR_WAIT;
    end
    MONITOR_WAIT:if(msg_done)state<=MONITOR;
    default:state<=BOOT;
   endcase
  end
 end
endmodule
`default_nettype wire
