`default_nettype none
// REAL USB path. No synthetic MIDI and no UART mux with the SELFTEST image.
module usb_midi_fs_top #(parameter RAW_ENABLE=0, EXTERNAL_RESET=0, SERVICE_ENABLE=0)(
 input wire clk_50m,inout wire usb_dp,usb_dm,output wire uart_tx,
 output wire audio_evt_valid,output wire [39:0] audio_evt_data,
 output wire audio_online,audio_fault,audio_core_rst_n,
 output wire audio_ref_clk,audio_ref_locked,input wire system_rst_n,
 input wire service_lock,service_valid,input wire [7:0] service_data,output wire service_ready,midi_trigger
);
 reg [15:0] por_count=0;
 wire por_done=&por_count;
 always @(posedge clk_50m)if(EXTERNAL_RESET && !system_rst_n)por_count<=0;else if(!por_done)por_count<=por_count+1'b1;
 wire clk_usb,locked;
 assign audio_ref_clk=clk_usb;assign audio_ref_locked=locked;
 usb_fs_pll96 clock_usb(clk_usb,locked,clk_50m,!por_done);
 wire reset_async_n=por_done && locked && (!EXTERNAL_RESET || system_rst_n);
 // Assert into stage 1 asynchronously. Stage 2 has no asynchronous control:
 // it clears/releases on its own clock, so protocol logic cannot observe an
 // asynchronous reset removal and PLL restart still clears it on the first edge.
 (* syn_preserve=1, syn_maxfan=16 *) reg [1:0] reset_usb=0,reset_core=0;
 always @(posedge clk_usb or negedge reset_async_n)
  if(!reset_async_n)reset_usb[0]<=0;else reset_usb[0]<=1;
 always @(posedge clk_usb)
  if(!reset_usb[0])reset_usb[1]<=0;else reset_usb[1]<=1;
 always @(posedge clk_50m or negedge reset_async_n)
  if(!reset_async_n)reset_core[0]<=0;else reset_core[0]<=1;
 always @(posedge clk_50m)
  if(!reset_core[0])reset_core[1]<=0;else reset_core[1]<=1;
 wire record_valid,record_ready;
 wire [522:0] record;
 wire [7:0] error_code;
 (* syn_keep=1 *) wire [31:0] protocol_errors,cdc_overflow;
 wire midi_ready;
 wire [3:0] midi_endpoint;
 wire [6:0] midi_mps;
 usb_fs_midi_host host(clk_usb,reset_usb[1],usb_dp,usb_dm,
  record_ready,record_valid,record,error_code,protocol_errors,midi_ready,midi_endpoint,midi_mps);
 midi_frame_trigger trigger_frame(clk_usb,reset_usb[1],record_valid && record_ready && !record[522],record[518:512],record[511:0],midi_trigger);
 wire core_valid,core_ready,debug_packet_ready,debug_raw_ready;
 wire [522:0] core_record;
 usb_packet_async_fifo records(clk_usb,reset_usb[1],record_valid,record,record_ready,cdc_overflow,
  clk_50m,reset_core[1],core_valid,core_record,core_ready);
 // Hold the complete CDC record until the selected packed queue can accept it.
 // Gate the valid strobes with the SAME take to prevent duplicate diagnostics.
 assign core_ready=core_record[522] ? (core_record[521:519]==3'd7 ? debug_raw_ready:1'b1)
  :(debug_packet_ready && (RAW_ENABLE==0 || debug_raw_ready));
 // Audio tap is a nonblocking consumer; the original UART path is independent.
 wire evt_valid;
 wire [39:0] evt_data;
 (* syn_keep=1 *) wire [31:0] packet_overflow,event_overflow,event_log_overflow,raw_log_overflow,status_log_overflow;
 wire [31:0] malformed_count,unsupported_count;
 wire recovery_required;
 // Counters remain available in the netlist, and a FIFO overflow is reported
 // once without feeding a recursive status-overflow logging loop.
 reg cdc_fault;
 (* syn_preserve=1 *) reg cdc_fault_meta,cdc_fault_sync;
 reg overflow_reported;
 wire log_fault=cdc_fault_sync || packet_overflow!=0 || event_overflow!=0 ||
                event_log_overflow!=0 || raw_log_overflow!=0 || status_log_overflow!=0;
 wire overflow_status=!core_valid && log_fault && !overflow_reported;
 always @(posedge clk_usb)begin
  if(!reset_usb[1])cdc_fault<=0;else if(cdc_overflow!=0)cdc_fault<=1;
 end
 always @(posedge clk_50m)begin
  if(!reset_core[1])begin cdc_fault_meta<=0;cdc_fault_sync<=0;overflow_reported<=0;end
  else begin cdc_fault_meta<=cdc_fault;cdc_fault_sync<=cdc_fault_meta;
   if(overflow_status)overflow_reported<=1;
  end
 end
 usb_midi_debug #(.RAW_ADDR_BITS(5),.SERVICE_ENABLE(SERVICE_ENABLE)) debug_stream(
  .clk(clk_50m),.rst_n(reset_core[1]),
  .packet_valid(core_valid && core_ready && !core_record[522]),
  .packet_length(core_record[518:512]),.packet_data(core_record[511:0]),
  .raw_enable(RAW_ENABLE!=0),.status_valid((core_valid && core_ready && core_record[522]) || overflow_status),
  .status_code(overflow_status?3'd5:core_record[521:519]),.uart_tx(uart_tx),
  .evt_valid(evt_valid),.evt_ready(1'b1),.evt_data(evt_data),
  .packet_overflow(packet_overflow),.event_overflow(event_overflow),
  .event_log_overflow(event_log_overflow),.raw_log_overflow(raw_log_overflow),
  .status_log_overflow(status_log_overflow),.malformed_count(malformed_count),
  .unsupported_count(unsupported_count),.recovery_required(recovery_required),
  .packet_ready(debug_packet_ready),.raw_ready(debug_raw_ready),.service_lock(service_lock),.service_valid(service_valid),.service_data(service_data),.service_ready(service_ready));
 // Single session bit crosses USB -> core; event payload already crossed in records.
 (* syn_preserve=1 *) reg midi_online_meta,midi_online_sync;
 always @(posedge clk_50m)begin
  if(!reset_core[1])begin midi_online_meta<=0;midi_online_sync<=0;end
  else begin midi_online_meta<=midi_ready;midi_online_sync<=midi_online_meta;end
 end
 assign audio_evt_valid=evt_valid;
 assign audio_evt_data=evt_data;
 assign audio_online=midi_online_sync;
 assign audio_fault=recovery_required || cdc_fault_sync;
 assign audio_core_rst_n=reset_core[1];
endmodule
`default_nettype wire

`default_nettype none
module midi_frame_trigger #(parameter integer HOLD_CYCLES=201600)(
 input wire clk,rst_n,packet_valid,input wire [6:0] length,input wire [511:0] data,output wire pulse);
 reg [$clog2(HOLD_CYCLES+1)-1:0] remaining;
 reg packet_q,hit_q;
 integer i;reg hit;
 always @*begin hit=0;
  for(i=0;i<16;i=i+1)if(length>=4*(i+1) && data[i*32+:8]==8'h09 &&
    data[i*32+12+:4]==4'h9 && !data[i*32+23] && data[i*32+24+:8]!=0 && !data[i*32+31])hit=1;
 end
 always @(posedge clk)begin
  if(!rst_n)begin remaining<=0;packet_q<=0;hit_q<=0;end
  else begin
   packet_q<=packet_valid;hit_q<=hit;
   if(packet_q && hit_q)remaining<=HOLD_CYCLES;
   else if(remaining!=0)remaining<=remaining-1'b1;
  end
 end
 assign pulse=remaining!=0;
endmodule
`default_nettype wire
