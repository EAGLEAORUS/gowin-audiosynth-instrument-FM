`default_nettype none
// One composite instrument, latest-note retrigger. Minimum gate 1440 samples.
// Q16 master de-click envelope outside the exact four-bit nonlinear DAC.
module nes_note_gate(
 input wire clk,rst_n,sample_tick,note_on,note_off,
 output reg active,output reg [16:0] gain,output reg [3:0] state
);
 reg [10:0] age;reg pending_off;reg [7:0] ramp,error;
 wire [8:0] attack_error={1'b0,error}+9'd64;
 wire [8:0] release_error={1'b0,error}+9'd16;
 always @(posedge clk)begin
  if(!rst_n)begin active<=0;gain<=0;state<=0;age<=0;pending_off<=0;ramp<=0;error<=48;end
  else if(note_on)begin active<=1;gain<=0;state<=1;age<=0;pending_off<=0;ramp<=0;error<=48;end
  else begin
   if(note_off && active)pending_off<=1;
   if(sample_tick && active)begin
    if(age<1440)age<=age+1'b1;
    case(state)
     1:begin
      gain<=gain+17'd682+(attack_error>=96?17'd1:17'd0);
      error<=attack_error>=96?attack_error-9'd96:attack_error[7:0];
      if(ramp==95)begin state<=2;ramp<=0;end else ramp<=ramp+1'b1;
     end
     2:gain<=17'd65536;
     3:begin
      gain<=gain-17'd273-(release_error>=240?17'd1:17'd0);
      error<=release_error>=240?release_error-9'd240:release_error[7:0];
      if(ramp==239)begin active<=0;state<=0;gain<=0;end else ramp<=ramp+1'b1;
     end
     default:begin active<=0;gain<=0;state<=0;end
    endcase
    if(state!=3 && (pending_off || note_off) && age>=1439)begin state<=3;ramp<=0;error<=120;end
   end
  end
 end
endmodule
`default_nettype wire
