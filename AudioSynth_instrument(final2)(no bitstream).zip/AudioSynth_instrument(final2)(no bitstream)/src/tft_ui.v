`default_nettype none
module tft_ui #(parameter integer HOME_DEBOUNCE_CYCLES=500000,parameter SD_ONLY=0)(input wire clk,rst_n,effects_rst_n,a,b,push_n,
 input wire [2:0] patch,input wire mode,input wire [6:0] volume,
 input wire event_valid,input wire [39:0] event_data,input wire online,
 output wire patch_set,output wire [2:0] patch_value,output wire mode_set,mode_value,
 output wire [2:0] wave_color,spectrum_color,overload_color,xy_color,
 output wire cs_n,sclk,mosi,dc,res_n,blk,input wire home_n,
 output wire sd_action_valid,output wire [3:0] sd_action,
 input wire menu_begin,menu_commit,glyph_we,cell_we,menu_home,
 input wire [10:0] glyph_address,input wire [15:0] glyph_data,input wire [6:0] cell_address,input wire [7:0] cell_data,input wire [2:0] menu_selected,output wire menu_ready,input wire [31:0] source_status,
 input wire ui_read,ui_write,input wire [3:0] ui_address,input wire [31:0] ui_wdata,output reg [31:0] ui_rdata);

 // K0/Home is active low (module SW2/R7); synchronous release in this clock domain.
 (* syn_preserve=1 *) reg home_meta,home_sync;
 localparam integer HOME_COUNT_BITS=HOME_DEBOUNCE_CYCLES>1?$clog2(HOME_DEBOUNCE_CYCLES):1;
 reg [HOME_COUNT_BITS-1:0] home_count;
 reg home_stable,home_press;
 always @(posedge clk)begin
  if(!rst_n)begin home_meta<=1'b1;home_sync<=1'b1;home_stable<=1'b1;home_count<=0;home_press<=1'b0;end
  else begin
   home_meta<=home_n;home_sync<=home_meta;home_press<=1'b0;
   if(home_sync==home_stable)home_count<=0;
   else if(home_count==HOME_DEBOUNCE_CYCLES-1)begin
    home_count<=0;home_stable<=home_sync;if(!home_sync)home_press<=1'b1;
   end else home_count<=home_count+1'b1;
  end
 end
 wire turn,clockwise,press;reg [3:0] page,cursor;reg [1:0] target;
 ec11_input encoder(clk,rst_n,a,b,push_n,turn,clockwise,press);
 // PL captures debounced controls and renders the PS-owned menu state.
 reg [11:0] colors;
 reg loading_done,mode_pulse,requested_mode,home_pending;
 wire key_valid,key_ready;
 wire home_text_pending;
 wire [1:0] key_data;
 wire key_push=home_press || press || turn;
 wire [1:0] key_in=home_press?2'd3:press?2'd2:clockwise?2'd1:2'd0;
 wire pop=ui_read && ui_address==0;
 wire [31:0] key_drops;
 midi_sync_fifo_fwft_ram #(2,4) keys(clk,rst_n,key_push,key_in,key_ready,key_valid,key_data,pop,key_drops);
 assign {xy_color,overload_color,spectrum_color,wave_color}=colors;
 assign patch_set=0;assign patch_value=0;
 assign mode_set=mode_pulse;assign mode_value=requested_mode;
 assign sd_action_valid=0;assign sd_action=0;
 always @*begin
  case(ui_address)
   0:ui_rdata={28'd0,home_pending,key_valid,key_data};
   4:ui_rdata=key_drops;
   12:ui_rdata={31'd0,home_text_pending};
   default:ui_rdata=0;
  endcase
 end
 always @(posedge clk)begin
  if(!rst_n)begin
   page<=0;cursor<=0;target<=0;colors<={3'd2,3'd6,3'd3,3'd5};
   loading_done<=0;mode_pulse<=0;requested_mode<=0;home_pending<=0;
  end else begin
   mode_pulse<=0;
   if(pop)home_pending<=0;
   if(menu_home)home_pending<=1;
   if(ui_write && ui_address==4)begin
    page<=ui_wdata[3:0];cursor<=ui_wdata[7:4];target<=ui_wdata[9:8];
    colors<=ui_wdata[21:10];loading_done<=ui_wdata[22];
    mode_pulse<=ui_wdata[23];requested_mode<=ui_wdata[24];
   end
  end
 end
 // Same committed-event predicate and reset as instrument_effects_control.
 // This read-only telemetry never enters the audio sample path.
 reg [6:0] delay_value,chorus_value,reverb_value,phaser_depth;
 wire selected=event_valid && online && event_data[39:36]==0 && event_data[35:32]==4'hb &&
  event_data[31:28]==3 && event_data[27:24]==0 && event_data[9:8]==3 && event_data[7:0]==8'hb0;
 always @(posedge clk)begin
  if(!effects_rst_n)begin delay_value<=0;chorus_value<=0;reverb_value<=0;phaser_depth<=0;end
  else if(selected)case(event_data[23:17])
   77:delay_value<=event_data[16:10];93:chorus_value<=event_data[16:10];73:reverb_value<=event_data[16:10];
   75:phaser_depth<=event_data[16:10];
   default:begin end
  endcase
 end
 wire [8:0] x;wire [7:0] y;wire frame_start;wire [15:0] pixel,legacy_pixel,sd_pixel;
 reg [3:0] spinner;
 reg [1:0] startup_frames;
 reg loading_frame,sd_frame,home_frame;
 always @(posedge clk)begin
  if(!rst_n)begin spinner<=0;startup_frames<=0;loading_frame<=1;sd_frame<=0;home_frame<=0;end
  else if(frame_start)begin
   spinner<=spinner+1'b1;
   if(startup_frames!=2)startup_frames<=startup_frames+1'b1;
   loading_frame<=!loading_done || startup_frames!=2;sd_frame<=page==8;home_frame<=page==0;
  end
 end
 wire [3:0] segment=x[7:4]-4'd2;
 wire [15:0] boot_pixel=(y>=112 && y<128 && x>=32 && x<288)?
   (segment==spinner?16'h07ff:16'h18e3):16'h0841;
 wire home_ink;
 tft_home_status home_status(clk,rst_n,frame_start,x,y,ui_write,ui_address,ui_wdata,home_text_pending,home_ink);
 wire [3:0] text_row=y[7:4];
 wire home_status_row=home_frame && (text_row==6 || text_row==7);
 assign pixel=loading_frame?boot_pixel:sd_frame?sd_pixel:
              home_status_row?(home_ink?16'hffff:16'h0841):legacy_pixel;
 sd_menu_render sd_page(clk,rst_n,frame_start,x,y,menu_begin,menu_commit,glyph_we,glyph_address,glyph_data,cell_we,cell_address,cell_data,menu_selected,sd_pixel,menu_ready);
 tft_render_status #(.SD_ENABLE(1),.SD_ONLY(SD_ONLY),.COMPACT_FX(1)) render(clk,rst_n,frame_start,x,y,page,cursor,target,patch,mode,volume,
  delay_value,chorus_value,reverb_value,wave_color,spectrum_color,overload_color,xy_color,legacy_pixel,source_status,phaser_depth);
 tft_st7789 display(clk,rst_n,pixel,x,y,frame_start,cs_n,sclk,mosi,dc,res_n,blk);
endmodule
// Two 40-column status lines, written to the inactive bank by the PS.
module tft_home_status(input wire clk,rst_n,frame_start,input wire [8:0] x,input wire [7:0] y,
 input wire write,input wire [3:0] addr,input wire [31:0] data,output reg pending,output reg ink);
 reg visible,bank;
 reg [4:0] cursor;
 reg [31:0] words[0:63];
 reg [31:0] word_q;
 reg [7:0] character;
 reg [7:0] bits;
 wire [127:0] glyph_rows=glyph(character);
 always @(posedge clk)begin
  if(!rst_n)begin visible<=0;bank<=0;pending<=0;cursor<=0;ink<=0;end
  else begin
   if(write && addr==8 && !pending)begin
    if(data[8])pending<=1;
    else cursor<=data[4:0];
   end
   if(write && addr==12 && !pending)begin
    words[{!bank,cursor}]<=data;
    cursor<=cursor+1'b1;
   end
   if(frame_start && pending)begin bank<=!bank;visible<=1;pending<=0;end
   word_q<=words[{bank,(y[7:4]==7),x[8:5]}];
   case(x[4:3])
    0:character<=word_q[7:0];
    1:character<=word_q[15:8];
    2:character<=word_q[23:16];
    3:character<=word_q[31:24];
   endcase
   bits=glyph_rows[127-{y[3:0],3'd0} -:8];
   ink<=visible && bits[7-x[2:0]];
  end
 end
 // Existing SimSun ASCII fallback, using the left 8 pixels for 40 columns.
 function [127:0] glyph(input [7:0] code);
 begin case(code)
  8'd32:glyph=128'h00000000000000000000000000000000;
  8'd33:glyph=128'h00000018181818181800000018180000;
  8'd34:glyph=128'h0012366c480000000000000000000000;
  8'd35:glyph=128'h00000012127e7e2424247e7e24240000;
  8'd36:glyph=128'h0000083c6a4a68381c0e0a4a4e3c0808;
  8'd37:glyph=128'h00000042a0a4a0a84215052505420000;
  8'd38:glyph=128'h00000038484848706ea49498c9770000;
  8'd39:glyph=128'h00606020400000000000000000000000;
  8'd40:glyph=128'h00020408081810101010180808040200;
  8'd41:glyph=128'h00402010101808080808181010204000;
  8'd42:glyph=128'h0000000008086b3e3e6b080800000000;
  8'd43:glyph=128'h00000000080808087f08080808000000;
  8'd44:glyph=128'h00000000000000000000000060602040;
  8'd45:glyph=128'h00000000000000007e00000000000000;
  8'd46:glyph=128'h00000000000000000000000060600000;
  8'd47:glyph=128'h00000206040c08081810102020604000;
  8'd48:glyph=128'h00000018246642424242426624180000;
  8'd49:glyph=128'h000000083808080808080808083e0000;
  8'd50:glyph=128'h0000003c4642420204081020427e0000;
  8'd51:glyph=128'h0000003c4642020418060242463c0000;
  8'd52:glyph=128'h000000040c0c143424447f04041f0000;
  8'd53:glyph=128'h0000007e4040407c46020242463c0000;
  8'd54:glyph=128'h0000001c2460405c66424242263c0000;
  8'd55:glyph=128'h0000007e400400080800101010100000;
  8'd56:glyph=128'h0000003c664242343c664242663c0000;
  8'd57:glyph=128'h0000003c64424242663a020624380000;
  8'd58:glyph=128'h00000000000018180000000018180000;
  8'd59:glyph=128'h00000000000000101000000010101010;
  8'd60:glyph=128'h00000002040810204020100804020000;
  8'd61:glyph=128'h0000000000007e00007e000000000000;
  8'd62:glyph=128'h00000040201008040204081020400000;
  8'd63:glyph=128'h0000003c664262060c08080018180000;
  8'd64:glyph=128'h0000001c326d5d5555515b7e311e0000;
  8'd65:glyph=128'h0000001818082c24243c464242c70000;
  8'd66:glyph=128'h000000fc464242447846424246fc0000;
  8'd67:glyph=128'h0000001e2662404040404062241c0000;
  8'd68:glyph=128'h000000f84c464242424242464cf80000;
  8'd69:glyph=128'h000000fe464248487848484246fe0000;
  8'd70:glyph=128'h000000fe464248487848484040e00000;
  8'd71:glyph=128'h0000003c4c448080808e84c444380000;
  8'd72:glyph=128'h000000e7424242427e42424242e70000;
  8'd73:glyph=128'h0000003e0808080808080808083e0000;
  8'd74:glyph=128'h0000001f040404040404040404044c78;
  8'd75:glyph=128'h000000ee444850707058484c44ee0000;
  8'd76:glyph=128'h000000702020202020202022227e0000;
  8'd77:glyph=128'h000000e366666666565a5a5a5ae70000;
  8'd78:glyph=128'h000000e7627252524a4a4e4646e20000;
  8'd79:glyph=128'h00000018246642424242426224180000;
  8'd80:glyph=128'h000000fc464242467c40404040e00000;
  8'd81:glyph=128'h00000038246242424242427a2c1c0600;
  8'd82:glyph=128'h000000fc464242467c484c4446e30000;
  8'd83:glyph=128'h0000003e664240301c060242667c0000;
  8'd84:glyph=128'h000000fe929210101010101010380000;
  8'd85:glyph=128'h000000e74242424242424242663c0000;
  8'd86:glyph=128'h000000e3424260242434181818100000;
  8'd87:glyph=128'h000000dbd84a4a5a5a5c6c2424240000;
  8'd88:glyph=128'h000000ee446028301018280c44ce0000;
  8'd89:glyph=128'h000000ee444420203010101010380000;
  8'd90:glyph=128'h0000007e6444080818101022227e0000;
  8'd91:glyph=128'h001e1010101010101010101010101e00;
  8'd92:glyph=128'h00004020203010101808080c04040602;
  8'd93:glyph=128'h00780808080808080808080808087800;
  8'd94:glyph=128'h00182400000000000000000000000000;
  8'd95:glyph=128'h000000000000000000000000000000ff;
  8'd96:glyph=128'h00601000000000000000000000000000;
  8'd97:glyph=128'h000000000000003c440c3c4446760000;
  8'd98:glyph=128'h000000c0c040405c66424242665c0000;
  8'd99:glyph=128'h000000000000001c22404040623c0000;
  8'd100:glyph=128'h000000060602023e66424242673b0000;
  8'd101:glyph=128'h000000000000003c66427e40623c0000;
  8'd102:glyph=128'h000000000e12107c10101010107c0000;
  8'd103:glyph=128'h000000000000003e444438407c42623c;
  8'd104:glyph=128'h000000c0c040405c6242424242e70000;
  8'd105:glyph=128'h000000000800003808080808083e0000;
  8'd106:glyph=128'h000000000400001c0404040404044c78;
  8'd107:glyph=128'h000000c0c040404c4850704844ee0000;
  8'd108:glyph=128'h000000383808080808080808083e0000;
  8'd109:glyph=128'h00000000000000ff6d49494949ff0000;
  8'd110:glyph=128'h00000000000000dce242424242e70000;
  8'd111:glyph=128'h000000000000003c66424242663c0000;
  8'd112:glyph=128'h00000000000000dce6424242665c40e0;
  8'd113:glyph=128'h000000000000003a66424242663a0207;
  8'd114:glyph=128'h00000000000000ee7a20202020f80000;
  8'd115:glyph=128'h000000000000003e42603c06427c0000;
  8'd116:glyph=128'h000000000010107c10101010121c0000;
  8'd117:glyph=128'h00000000000000c642424242673b0000;
  8'd118:glyph=128'h00000000000000762424101818100000;
  8'd119:glyph=128'h00000000000000fb5a5a5e7c24240000;
  8'd120:glyph=128'h000000000000007624181818246e0000;
  8'd121:glyph=128'h00000000000000662424101818001060;
  8'd122:glyph=128'h000000000000007e464c1832627e0000;
  8'd123:glyph=128'h00030604040404040804040404060300;
  8'd124:glyph=128'h08080808080808080808080808080808;
  8'd125:glyph=128'h00c0602020202020102020202060c000;
  8'd126:glyph=128'h305d0600000000000000000000000000;
  default:glyph=0;
 endcase end
 endfunction
endmodule
`default_nettype wire
