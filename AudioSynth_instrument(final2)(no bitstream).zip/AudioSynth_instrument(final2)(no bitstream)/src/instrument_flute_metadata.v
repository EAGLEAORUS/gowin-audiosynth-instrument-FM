`default_nettype none
module instrument_flute_metadata(input wire [2:0] op,output reg [3:0] sensitivity,output reg [12:0] offset0,offset1,offset2);
 always @* begin sensitivity=0;offset0=4256;offset1=4256;offset2=4256;case(op)
 0:begin sensitivity=4'd2;offset0=13'd224;offset1=13'd1248;offset2=13'd1696;end
 1:begin sensitivity=4'd0;offset0=13'd224;offset1=13'd4256;offset2=13'd4256;end
 2:begin sensitivity=4'd0;offset0=13'd224;offset1=13'd224;offset2=13'd288;end
 3:begin sensitivity=4'd0;offset0=13'd544;offset1=13'd1952;offset2=13'd2592;end
 4:begin sensitivity=4'd2;offset0=13'd224;offset1=13'd224;offset2=13'd480;end
 5:begin sensitivity=4'd2;offset0=13'd416;offset1=13'd544;offset2=13'd224;end
 default:begin end
 endcase end
endmodule
`default_nettype wire
