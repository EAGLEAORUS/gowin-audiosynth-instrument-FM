`default_nettype none
// DAC boundaries generate a slow toggle, synchronized into 50MHz. PCM returns
// through a WHOLE stereo frame FIFO. No PCM bus uses two-flop synchronization.
module FM6_audio_adapter(
 input wire clk_50m,common_ready,event_valid,input wire [39:0] event_data,
 input wire online,fault,input wire bclk,tx_rst_n,ws,
 output wire sdout,output wire [31:0] underrun
);
 wire core_rst_n,read_rst_n;
 audio_usb_reset reset_core(clk_50m,common_ready,core_rst_n);
 audio_usb_reset reset_read(bclk,common_ready,read_rst_n);
 wire tx_ready;
 (* syn_preserve=1 *) reg frame_toggle;
 always @(posedge bclk or negedge read_rst_n)
  if(!read_rst_n)frame_toggle<=0;else if(tx_ready)frame_toggle<=~frame_toggle;
 (* syn_preserve=1 *) reg tick_meta,tick_sync;
 reg tick_old;
 always @(posedge clk_50m)begin
  if(!core_rst_n)begin tick_meta<=0;tick_sync<=0;tick_old<=0;end
  else begin tick_meta<=frame_toggle;tick_sync<=tick_meta;tick_old<=tick_sync;end
 end
 wire sample_tick=tick_sync!=tick_old;
 wire signed [23:0] pcm;wire pcm_valid,wr_ready,rd_valid;
 wire [47:0] frame;
 (* syn_keep=1 *) wire [3:0] busy,gate,releasing;
 (* syn_keep=1 *) wire [31:0] deadline_miss,clips,range_errors,event_overflow,pcm_overflow;
 (* syn_keep=1 *) wire [15:0] last_cycles;
 wire [111:0] voice_raw;
 FM6_engine engine(clk_50m,core_rst_n,sample_tick,event_valid,event_data,online && !fault,
  pcm,pcm_valid,busy,gate,releasing,deadline_miss,clips,range_errors,event_overflow,last_cycles,voice_raw);
 usb_packet_async_fifo #(.WIDTH(48),.ADDR_BITS(2)) pcm_fifo(
  clk_50m,core_rst_n,pcm_valid,{pcm,pcm},wr_ready,pcm_overflow,
  bclk,read_rst_n,rd_valid,frame,tx_ready);
 audio_usb_i2s_tx24 tx(bclk,tx_rst_n,ws,rd_valid && read_rst_n,frame,tx_ready,sdout,underrun);
endmodule
`default_nettype wire
