`default_nettype none
// Audio-clock channel state. The existing whole-event FIFO transports both
// data bytes atomically; no new USB parsing or multi-bit synchronizers.
module synth_pitch_control #(parameter [3:0] MIDI_CHANNEL=4'd0)(
 input wire clk,rst_n,event_valid,input wire [39:0] event_data,input wire online,
 output reg [13:0] value /* synthesis syn_maxfan = 32 */,output wire [23:0] ratio,output reg [31:0] accepted);
 wire pitch=event_valid && event_data[31:28]==4'd5 && event_data[27:24]==MIDI_CHANNEL;
 always @(posedge clk)begin
  if(!rst_n || !online)begin value<=14'd8192;accepted<=0;end
  else if(pitch)begin
   // d1=LL in [23:17], d2=HH in [16:10], NOT the USB cable/CIN header.
   value<={event_data[16:10],event_data[23:17]};accepted<=accepted+32'd1;
  end
 end
 synth_pitch_ratio_pipe tuning(clk,rst_n,value,ratio);
endmodule
`default_nettype wire
