`default_nettype none
// 5x7 ASCII, doubled to 10x14 on the existing 128x64 matrix. No frame RAM.
module octave_prompt(input wire [6:0] x,input wire [5:0] y,
 input wire [1:0] octave,input wire direction_up,output reg ink);
 // The installed panel presents scan Y bottom-up. Text coordinates are
 // top-down; invert only this overlay, leaving the existing plots alone.
 wire [5:0] text_y=~y;
 function [34:0] glyph;
 input [7:0] c;
 begin case(c)
  "o":glyph=35'b00000_00000_01110_10001_10001_10001_01110;
  "c":glyph=35'b00000_00000_01111_10000_10000_10000_01111;
  "t":glyph=35'b00100_00100_11111_00100_00100_00100_00011;
  "a":glyph=35'b00000_00000_01110_00001_01111_10001_01111;
  "v":glyph=35'b00000_00000_10001_10001_10001_01010_00100;
  "e":glyph=35'b00000_00000_01110_10001_11111_10000_01111;
  "+":glyph=35'b00000_00100_00100_11111_00100_00100_00000;
  "-":glyph=35'b00000_00000_00000_11111_00000_00000_00000;
  "C":glyph=35'b01110_10001_10000_10000_10000_10001_01110;
  "1":glyph=35'b00100_01100_00100_00100_00100_00100_01110;
  "3":glyph=35'b11110_00001_00001_01110_00001_00001_11110;
  "5":glyph=35'b11111_10000_10000_11110_00001_00001_11110;
  "7":glyph=35'b11111_00001_00010_00100_01000_01000_01000;
  default:glyph=0;
 endcase end endfunction
 reg [7:0] c;reg [6:0] pos;reg [3:0] index;reg [2:0] gx,gy;
 reg [34:0] bits;reg in_text;integer k;
 always @*begin
  c=32;pos=0;index=0;gx=0;gy=0;in_text=0;
  if(text_y>=12 && text_y<26 && x>=23 && x<105)begin
   pos=x-7'd23;gy=(text_y-6'd12)>>1;in_text=1;
   for(k=0;k<7;k=k+1)if(pos>=k*12 && pos<k*12+12)begin index=k;gx=(pos-k*12)>>1;end
   case(index)0:c="o";1:c="c";2:c="t";3:c="a";4:c="v";5:c="e";6:c=direction_up?"+":"-";default:c=32;endcase
  end else if(text_y>=36 && text_y<50 && x>=17 && x<111)begin
   pos=x-7'd17;gy=(text_y-6'd36)>>1;in_text=1;
   for(k=0;k<8;k=k+1)if(pos>=k*12 && pos<k*12+12)begin index=k;gx=(pos-k*12)>>1;end
   case(index)
    0,6:c="C";1:c=octave==0?"1":octave==2?"5":"3";
    3:c="t";4:c="o";7:c=octave==0?"3":octave==2?"7":"5";
    default:c=32;
   endcase
  end
  bits=glyph(c);ink=in_text && gx<5 && bits[34-gy*5-gx];
 end
endmodule
`default_nettype wire

`default_nettype none
module source_prompt(input wire [6:0] x,input wire [5:0] y,input wire pcm,output reg ink);
 wire [5:0] ty=~y;
 function [34:0] glyph;
 input [7:0] c;
 begin case(c)
 "S":glyph=35'b01111_10000_10000_01110_00001_00001_11110;
 "O":glyph=35'b01110_10001_10001_10001_10001_10001_01110;
 "U":glyph=35'b10001_10001_10001_10001_10001_10001_01110;
 "R":glyph=35'b11110_10001_10001_11110_10100_10010_10001;
 "C":glyph=35'b01110_10001_10000_10000_10000_10001_01110;
 "E":glyph=35'b11111_10000_10000_11110_10000_10000_11111;
 "P":glyph=35'b11110_10001_10001_11110_10000_10000_10000;
 "M":glyph=35'b10001_11011_10101_10101_10001_10001_10001;
 "A":glyph=35'b01110_10001_10001_11111_10001_10001_10001;
 "D":glyph=35'b11110_10001_10001_10001_10001_10001_11110;
 default:glyph=0;
 endcase end endfunction
 reg [7:0] c;reg [6:0] pos;reg [2:0] gx,gy;reg [34:0] bits;integer k;
 always @*begin
  c=32;pos=0;gx=7;gy=0;
  if(ty>=12 && ty<26 && x>=29 && x<99)begin
   pos=x-7'd29;gy=(ty-6'd12)>>1;
   for(k=0;k<6;k=k+1)if(pos>=k*12 && pos<k*12+12)begin
    gx=(pos-k*12)>>1;
    case(k)0:c="S";1:c="O";2:c="U";3:c="R";4:c="C";5:c="E";endcase
   end
  end else if(ty>=36 && ty<50 && x>=47 && x<81)begin
   pos=x-7'd47;gy=(ty-6'd36)>>1;
   for(k=0;k<3;k=k+1)if(pos>=k*12 && pos<k*12+12)begin
    gx=(pos-k*12)>>1;
    case(k)0:c=pcm?"P":"A";1:c=pcm?"C":"D";2:c=pcm?"M":"C";endcase
   end
  end
  bits=glyph(c);ink=gx<5 && bits[34-gy*5-gx];
 end
endmodule
`default_nettype wire

`default_nettype none
module string_prompt(input wire [6:0] x,input wire [5:0] y,input wire enabled,output reg ink);
 wire [5:0] ty=~y;
 function [34:0] glyph;
 input [7:0] c;
 begin case(c)
 "s":glyph=35'b00000_01111_10000_01110_00001_11110_00000;
 "t":glyph=35'b00100_00100_11111_00100_00100_00100_00011;
 "r":glyph=35'b00000_00000_10110_11001_10000_10000_10000;
 "i":glyph=35'b00100_00000_01100_00100_00100_00100_01110;
 "n":glyph=35'b00000_00000_11110_10001_10001_10001_10001;
 "g":glyph=35'b00000_01111_10001_01111_00001_10001_01110;
 "o":glyph=35'b00000_00000_01110_10001_10001_10001_01110;
 "f":glyph=35'b00110_01001_01000_11100_01000_01000_01000;
 default:glyph=0;
 endcase end endfunction
 reg [7:0] c;reg [6:0] pos;reg [2:0] gx,gy;reg [34:0] bits;integer k;
 always @*begin
  c=32;pos=0;gx=7;gy=0;
  if(ty>=12 && ty<26 && x>=29 && x<99)begin
   pos=x-7'd29;gy=(ty-6'd12)>>1;
   for(k=0;k<6;k=k+1)if(pos>=k*12 && pos<k*12+12)begin
    gx=(pos-k*12)>>1;
    case(k)0:c="s";1:c="t";2:c="r";3:c="i";4:c="n";5:c="g";endcase
   end
  end else if(ty>=36 && ty<50 && x>=(enabled?53:47) && x<(enabled?75:81))begin
   pos=x-(enabled?7'd53:7'd47);gy=(ty-6'd36)>>1;
   for(k=0;k<3;k=k+1)if(pos>=k*12 && pos<k*12+12)begin
    gx=(pos-k*12)>>1;
    case(k)0:c="o";1:c=enabled?"n":"f";2:c="f";endcase
   end
  end
  bits=glyph(c);ink=gx<5 && bits[34-gy*5-gx];
 end
endmodule
`default_nettype wire
