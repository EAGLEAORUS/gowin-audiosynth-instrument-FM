`default_nettype none
module FM6_audio_usb_loop(
 input wire clk_50m,output wire es0_mclk,es1_mclk,
 output wire es7243_scl,inout wire es7243_sda,
 output wire es8156_scl,inout wire es8156_sda,
 input wire es0_dsclk,es0_alrck,es0_sdin,es1_dsclk,es1_dlrc,
 output wire es1_sdout,lin_led,
 input wire midi_evt_valid,input wire [39:0] midi_evt_data,
 input wire midi_online,midi_fault,midi_core_rst_n,
 output wire ws2812,input wire audio_ref_clk,audio_ref_locked
);
 reg [15:0] por=0;
 always @(posedge clk_50m)if(!(&por))por<=por+1'b1;
 wire mclk,locked,core_rst_n;
 FM6_pll12288 clock_audio(mclk,locked,audio_ref_clk,!(&por) || !audio_ref_locked);
 assign es0_mclk=mclk;assign es1_mclk=mclk;
 audio_usb_reset reset_core(clk_50m,(&por)&&locked,core_rst_n);
 // Preserve at least the old 0x50000-MCLK startup guard at 12.288MHz:
 // ceil(327680 * 50MHz / 12.288MHz) = 1,333,334 core cycles (26.66668ms).
 reg [20:0] startup=0;
 always @(posedge clk_50m)if(!core_rst_n)startup<=0;
 else if(startup!=21'd1333334)startup<=startup+1'b1;
 wire config_rst_n=core_rst_n && startup==21'd1333334;
 reg [7:0] ce_count=0;
 wire ce=ce_count==8'd247;
 always @(posedge clk_50m)if(ce)ce_count<=0;else ce_count<=ce_count+1'b1;
 wire adc_done,dac_done,adc_ack,dac_ack;
 (* syn_keep=1 *) wire adc_healthy,dac_healthy;
 wire adc_retry,dac_retry;
 wire adc_config_rst_n=config_rst_n && !adc_retry;
 wire dac_config_rst_n=config_rst_n && !dac_retry;
 audio_usb_codec_health adc_health(clk_50m,config_rst_n,adc_done,es0_dsclk,es0_alrck,adc_healthy,adc_retry);
 audio_usb_codec_health dac_health(clk_50m,config_rst_n,dac_done,es1_dsclk,es1_dlrc,dac_healthy,dac_retry);
 audio_usb_es7243e_config adc_config(clk_50m,ce,adc_config_rst_n,es7243_scl,es7243_sda,adc_done,adc_ack);
 (* syn_keep=1 *) wire [6:0] output_volume;
 wire [7:0] volume_code;wire volume_mute;
 (* syn_keep=1 *) wire [31:0] volume_events,volume_nacks;
 (* syn_keep=1 *) wire [7:0] applied_volume;
 (* syn_keep=1 *) wire applied_mute,volume_busy;
 FM6_output_volume volume_control(clk_50m,core_rst_n,midi_evt_valid,midi_evt_data,
  midi_online && !midi_fault && midi_core_rst_n,output_volume,volume_code,volume_mute,volume_events);
 audio_usb_es8156_config #(.VOLUME_ENABLE(1)) dac_config(
  .clk_50m(clk_50m),.ce(ce),.rstn(dac_config_rst_n),.i2c_sclk(es8156_scl),.i2c_sdat(es8156_sda),
  .reg_conf_done(dac_done),.i2c_ack(dac_ack),.volume_code(volume_code),.mute_request(volume_mute),
  .applied_volume(applied_volume),.applied_mute(applied_mute),.volume_busy(volume_busy),.volume_nacks(volume_nacks));
 // DAC/DDS startup never waits for ADC configuration or ADC clock activity.
 wire audio_ready=dac_config_rst_n && dac_done;
 wire frame_ready=audio_ready && adc_config_rst_n && adc_done && adc_healthy;
 audio_usb_ws2812_status rgb_status(clk_50m,(&por),dac_healthy,adc_healthy,ws2812);
 audio_usb_status_led status_led(clk_50m,core_rst_n,(dac_healthy && adc_healthy),lin_led);
 wire rx_rst_n,tx_rst_n,frame_rd_rst_n;
 audio_usb_reset reset_rx(es0_dsclk,frame_ready,rx_rst_n);
 audio_usb_reset reset_tx(es1_dsclk,audio_ready,tx_rst_n);
 audio_usb_reset reset_frame_rd(es1_dsclk,frame_ready,frame_rd_rst_n);
 wire frame_valid,fifo_ready,out_valid,out_ready;
 wire signed [23:0] pcm_l,pcm_r;
 wire [47:0] out_frame;
 (* syn_keep=1 *) wire [31:0] overflow,underrun,frame_errors;
 audio_usb_i2s_rx24 rx(es0_dsclk,rx_rst_n,es0_alrck,es0_sdin,frame_valid,pcm_l,pcm_r,frame_errors);
 // Reuse the proven whole-record Gray FIFO without changing USB production RTL.
 usb_packet_async_fifo #(.WIDTH(48),.ADDR_BITS(3)) frame_fifo(
  es0_dsclk,rx_rst_n,frame_valid,{pcm_l,pcm_r},fifo_ready,overflow,
  es1_dsclk,frame_rd_rst_n,out_valid,out_frame,out_ready);
 wire tx_ready;
 // Keep ADC CDC draining even in synth mode, making loopback rollback explicit.
 assign out_ready=tx_ready;
 FM6_audio_adapter synth(clk_50m,audio_ready && midi_core_rst_n,midi_evt_valid,midi_evt_data,
  midi_online,midi_fault,es1_dsclk,tx_rst_n,es1_dlrc,es1_sdout,underrun);
 // ADC loop remains independently drained; synth startup only depends on DAC.
 assign tx_ready=synth.tx_ready;
endmodule
`default_nettype wire
