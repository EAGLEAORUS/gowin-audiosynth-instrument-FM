`default_nettype none
// Streaming Configuration walker. No device-specific VID/PID/endpoint assumptions.
// Select MIDI 1.0 Audio/MIDIStreaming Bulk IN with class-specific jack association.
module usb_midi_descriptor_scan(
 input wire clk,rst_n,start,byte_valid,input wire [7:0] byte_data,input wire finish,
 output reg found,error,output reg [7:0] configuration,interface_number,alternate,
 output reg [3:0] endpoint,output reg [6:0] max_packet
);
 reg [7:0] pos,dlen,dtype,subtype,if_num,if_alt,if_class,if_sub;
 reg midi_if,ep_pending,padding;
 reg [7:0] ep_addr,ep_attr,mps_lo;
 reg [3:0] candidate_ep;
 reg [6:0] candidate_mps;
 reg [15:0] count,total;
 always @(posedge clk)begin
  if(!rst_n || start)begin
   found<=0;error<=0;configuration<=0;interface_number<=0;alternate<=0;
   endpoint<=0;max_packet<=0;pos<=0;dlen<=0;dtype<=0;subtype<=0;
   if_num<=0;if_alt<=0;if_class<=0;if_sub<=0;midi_if<=0;ep_pending<=0;padding<=0;
   ep_addr<=0;ep_attr<=0;mps_lo<=0;candidate_ep<=0;candidate_mps<=0;count<=0;total<=0;
  end else begin
   if(byte_valid)begin
    count<=count+1'b1;
    if(padding)begin
     // Some real devices include all-zero bytes at the end of wTotalLength.
     // Accept them only after a complete MIDI endpoint was selected; any
     // later nonzero byte proves that the zero was not trailing padding.
     if(byte_data!=0)error<=1;
    end else if(pos==0)begin
     if(byte_data==0)begin padding<=1;if(!found)error<=1;end
     else begin dlen<=byte_data;pos<=1;if(byte_data<2)error<=1;end
    end else begin
     if(pos==1)begin
      dtype<=byte_data;
      if(byte_data==4)begin midi_if<=0;ep_pending<=0;if(dlen<9)error<=1;end
      if(byte_data==5)begin ep_pending<=0;if(dlen<7)error<=1;end
      if(count==1 && (byte_data!=2 || dlen!=9))error<=1;
     end
     if(dtype==2)begin
      if(pos==2)total[7:0]<=byte_data;
      if(pos==3)total[15:8]<=byte_data;
      if(pos==5)configuration<=byte_data;
     end
     if(dtype==4)case(pos)
      2:if_num<=byte_data;3:if_alt<=byte_data;
      5:if_class<=byte_data;6:if_sub<=byte_data;
      7:midi_if<=if_class==1 && if_sub==3 && byte_data==0;
      default:begin end
     endcase
     if(dtype==5)case(pos)
      2:ep_addr<=byte_data;3:ep_attr<=byte_data;4:mps_lo<=byte_data;
      5:if(midi_if && ep_addr[7] && ep_addr[6:4]==0 && ep_addr[3:0]!=0 && ep_attr[1:0]==2 &&
           byte_data==0 && (mps_lo==8 || mps_lo==16 || mps_lo==32 || mps_lo==64))begin
        candidate_ep<=ep_addr[3:0];candidate_mps<=mps_lo[6:0];ep_pending<=1;
       end
      default:begin end
     endcase
     if(dtype==8'h24 && midi_if)begin
      if(pos==2)subtype<=byte_data;
      // MIDIStreaming header bcdMSC must be USB-MIDI 1.0.
      if(pos==4 && subtype==1 && byte_data!=1)begin midi_if<=0;ep_pending<=0;end
     end
     if(dtype==8'h25 && ep_pending)begin
      if(pos==2)subtype<=byte_data;
      if(pos==3 && subtype==1 && byte_data!=0 && {8'd0,byte_data}+16'd4<=dlen && !found)begin
       found<=1;endpoint<=candidate_ep;max_packet<=candidate_mps;
       interface_number<=if_num;alternate<=if_alt;
      end
     end
     if(pos==dlen-1'b1)pos<=0;else pos<=pos+1'b1;
    end
   end
   if(finish && (pos!=0 || count!=total || total<9 || configuration==0))error<=1;
  end
 end
endmodule
`default_nettype wire
