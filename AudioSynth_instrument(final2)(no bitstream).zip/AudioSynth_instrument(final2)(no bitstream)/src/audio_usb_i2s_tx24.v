`default_nettype none
// Capture one whole stereo frame at a left boundary. Starvation emits BOTH
// channels zero. Never stalls BCLK or substitutes a previous right channel.
module audio_usb_i2s_tx24(
 input wire sck,rst_n,ws,input wire valid,input wire [47:0] frame,
 output wire ready,output wire sda,output reg [31:0] underrun
);
 reg ws_old;
 reg [23:0] active_l,active_r;
 reg [1:0] ws_pipe;
 reg [23:0] shift;
 wire boundary=ws!=ws_old;
 assign ready=rst_n && boundary && !ws;
 always @(posedge sck)begin
  if(!rst_n)begin ws_old<=0;ws_pipe<=0;active_l<=0;active_r<=0;underrun<=0;end
  else begin
   ws_old<=ws;ws_pipe<={ws_pipe[0],ws};
   if(boundary && !ws)begin
    if(valid)begin active_l<=frame[47:24];active_r<=frame[23:0];end
    else begin active_l<=0;active_r<=0;underrun<=underrun+1'b1;end
   end
  end
 end
 // Changes only at falling BCLK; MSB is launched one bit after WS transition.
 always @(negedge sck)begin
  if(!rst_n)shift<=0;
  else if(ws_pipe[0]!=ws_pipe[1])shift<=ws_pipe[0]?active_r:active_l;
  else shift<={shift[22:0],1'b0};
 end
 assign sda=shift[23];
endmodule
`default_nettype wire
