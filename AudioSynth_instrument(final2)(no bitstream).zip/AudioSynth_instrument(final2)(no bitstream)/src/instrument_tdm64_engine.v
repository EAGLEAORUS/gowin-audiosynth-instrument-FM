`default_nettype none
// Four shared six-operator lanes. Production uses 16 voices per lane (64 total).
module instrument_tdm64_engine #(parameter TRACE_ENABLE=1,parameter integer VOICES_PER_CORE=10,parameter integer CONFIG_TIMEOUT_CYCLES=12500000,parameter RELEASE_CONTROL_ENABLE=0,parameter CHANNEL_CONTROL_ENABLE=0,parameter SD_ONLY=0,parameter HW_PATCH=0)(
 input wire clk,rst_n,sample_tick,event_valid,input wire [39:0] event_data,input wire online,input wire [2:0] patch_select,
 output reg signed [23:0] pcm,output reg pcm_valid,
 output wire [4*VOICES_PER_CORE-1:0] busy,gate,releasing,
 output reg [31:0] deadline_miss,clip_count,range_errors,output wire [31:0] event_overflow,
 output reg [15:0] last_cycles,output wire [4*VOICES_PER_CORE*32-1:0] voice_raw,
 input wire [23:0] string_ratio,output wire [23:0] string_bend_ratio,
 input wire [95:0] event_tag,output wire exec_valid,output wire [39:0] exec_data,output wire [95:0] exec_tag,
 input wire [15:0] dynamic_mask,input wire cpu_enabled,
 output wire cpu_event_valid,output wire [39:0] cpu_event_data,output wire [95:0] cpu_event_tag,input wire cpu_event_ready,
 input wire cpu_ack_valid,input wire [95:0] cpu_ack_tag,
 output wire allocation_valid,output wire [5:0] allocation_slot,output wire [31:0] allocation_token,
 input wire config_valid,output wire config_ready,input wire [2:0] config_kind,
 input wire [5:0] config_slot,input wire [31:0] config_token,input wire [2:0] config_op,
 input wire [107:0] config_data,input wire [7:0] config_meta,
 output wire config_resp_valid,config_resp_ok,output wire [31:0] config_resp_token,
 output reg [31:0] config_faults,
 input wire [15:0] release_channels,
 input wire [3:0] release_sources,
 input wire control_valid,output wire control_ready,input wire [3:0] control_channel,input wire [34:0] control_data,
 input wire [8:0] library_count,
 output wire library_read,output wire [10:0] library_address,
 input wire [127:0] library_data,
 input wire hw_write,input wire [11:0] hw_address,input wire [31:0] hw_data,
 output wire [31:0] hw_read,output wire [15:0] hw_active,input wire string_mode,output wire [8:0] piano_patch,output wire [15:0] nes_status);
 wire queue_valid,queue_ready,pop,fetch;wire [39:0] queue_data;
 reg [39:0] routed_data;reg event_pending;reg [2:0] event_age;
 localparam integer EVENT_WARMUP=VOICES_PER_CORE>8?4:3;
 wire dynamic_on,commit_fire,retire_event,hw_control_busy,hw_control_we;
 wire [3:0] hw_control_channel;wire [34:0] hw_control_data;reg [3:0] dispatch_state;
 // Mirror the FIFO's saturating overflow counter with a one-bit predicate.
 // This is its exact post-edge zero test, including reset and simultaneous
 // pop/push; it adds no fault-response cycle and removes a wide decode from
 // the high-fanout allocator/LFO enable path.
 reg events_clean;
 always @(posedge clk)begin
  if(!rst_n || !online)events_clean<=1'b1;
  else if(event_valid && !queue_ready)events_clean<=1'b0;
 end
 wire safe_online=online && events_clean;
 wire [4*VOICES_PER_CORE-1:0] on,off,allocated_on,allocated_off;
 localparam integer VOICES=4*VOICES_PER_CORE;
 wire [VOICES-1:0] kill_slots,config_reserved;reg [VOICES-1:0] claim,sd_running;wire [6:0] raw_note,velocity;
 wire [4*VOICES_PER_CORE*7-1:0] assigned_notes;wire [4*VOICES_PER_CORE*4-1:0] channels;
 (* syn_keep=1 *) wire [31:0] accepted_events,steals,retriggers;
 wire [3:0] lane_idle,lane_valid;
 wire [15:0] lane_cycles[0:3];wire [31:0] lane_deadline[0:3],lane_ranges[0:3];
 wire signed [33:0] ep_mix[0:3],cel_mix[0:3];
 midi_sync_fifo_fwft_ram #(.WIDTH(40),.ADDR_BITS(7)) events(clk,rst_n && online,event_valid && online,event_data,
  queue_ready,queue_valid,queue_data,fetch,event_overflow);
 // Supplemental immutable tags use the SAME put/fetch boundaries as the
 // existing event FIFO. Payload and tags cannot be consumed independently.
 wire [95:0] routed_event_tag;
 generate if(TRACE_ENABLE)begin:trace
  reg [95:0] tags[0:127];reg [6:0] wp,rp;reg [95:0] routed_tag;
  always @(posedge clk)begin
   if(event_valid && online && queue_ready)tags[wp]<=event_tag;
   if(!rst_n || !online)begin wp<=0;rp<=0;routed_tag<=0;end
   else begin
    if(event_valid && queue_ready)wp<=wp+1'b1;
    if(fetch)begin routed_tag<=tags[rp];rp<=rp+1'b1;end
   end
  end
  assign routed_event_tag=routed_tag;
 end else begin:no_trace assign routed_event_tag=96'd0;end endgenerate
 // Only the local arbiter creates the private string marker and patch snapshot.
 wire event_string=HW_PATCH && routed_event_tag[95:80]==16'h00f1;
 wire string_current=string_mode && routed_event_tag[79:72]==piano_patch[7:0];
 wire stale_pluck=event_string && routed_data[31:28]==2 && !string_current;
 wire [VOICES-1:0] held_string;
 reg [8:0] prior_piano_patch;
 always @(posedge clk)if(!rst_n)prior_piano_patch<=0;else prior_piano_patch<=piano_patch;
 wire release_string=!string_mode || prior_piano_patch!=piano_patch;
 assign exec_tag=event_string?{64'd0,routed_event_tag[31:0]}:routed_event_tag;
 assign exec_valid=TRACE_ENABLE && safe_online && ((pop && !dynamic_on && !stale_pluck) || commit_fire);
 assign exec_data=routed_data;
 reg working;reg [3:0] completed;reg [15:0] elapsed;reg [3:0] mix_index;
 reg event_window_ready;
 always @(posedge clk)begin
  if(!rst_n)event_window_ready<=0;
  else event_window_ready<=(&lane_idle) && !working;
 end
 // Register lane-idle reduction before the high-fanout event enables.
 // working and sample_tick close the window immediately on a frame boundary.
 wire event_window=event_window_ready && !working && !sample_tick;
 assign control_ready=!HW_PATCH && CHANNEL_CONTROL_ENABLE!=0 && event_window && cpu_enabled;
 // Break FIFO mux -> 32-way selection -> rank update into registered stages.
 // A fetched record stays stable through group + winner registers.
 // Three warm-up cycles include the new winner stage (+20ns event latency).
 assign fetch=event_window && !event_pending && queue_valid;
 assign pop=event_window && event_pending && event_age==EVENT_WARMUP && dispatch_state==0 && (HW_PATCH ? !hw_control_busy : (!cpu_enabled || cpu_event_ready));
 always @(posedge clk)begin
  if(!rst_n || !online)begin routed_data<=0;event_pending<=0;event_age<=0;end
  else begin
   if(fetch)begin routed_data<=queue_data;event_pending<=1;event_age<=0;end
   else if(event_pending && event_age!=EVENT_WARMUP)event_age<=event_age+1'b1;
   if(retire_event)event_pending<=0;
  end
 end
 // The allocator reserves an occupied slot before the CPU computes the new
 // parameters. A pending dynamic event blocks subsequent musical dispatch,
 // preserving NoteOn/Off and bank/program order while audio frames continue.
 wire [15:0] enabled_mask=HW_PATCH?hw_active:cpu_enabled?dynamic_mask:16'd0;
 wire dynamic_event=event_string?string_current:enabled_mask[routed_data[27:24]];
 assign dynamic_on=dynamic_event && routed_data[31:28]==2 && routed_data[16:10]!=0 &&
  (!HW_PATCH || routed_data[27:24]!=9 || (raw_note>=36 && raw_note<=51));
 // Route only built-in pad Note On to the dedicated eight-slot pool.
 // Broadcast CH10 release to both pools so changing the preset while a
 // note is held cannot strand the old owner. Each allocator checks source.
 wire pad_note=routed_data[27:24]==9 && raw_note>=36 && raw_note<=51 && !event_string;
 wire pad_on=pad_note && routed_data[31:28]==2 && velocity!=0;
 wire nes_on=SD_ONLY && HW_PATCH && pad_on && !hw_active[9];
 wire nes_release=!event_string && routed_data[27:24]==9 && (routed_data[31:28]!=2 || velocity==0);
 wire nes_idle;
 wire [31:0] nes_preset_status,performance_read;
 wire signed [18:0] nes_sum;
 generate if(SD_ONLY && HW_PATCH)begin:dedicated_percussion
  instrument_nes_tdm8 #(.PRESETS(1)) engine(.clk(clk),.rst_n(rst_n),.sample_tick(sample_tick),
   .event_valid(pop && (nes_on || nes_release)),.online(safe_online),.event_data(routed_data),
   .event_source(routed_event_tag[89:88]),
   .release_sources(RELEASE_CONTROL_ENABLE?release_sources:4'd0),
   .release_channel(RELEASE_CONTROL_ENABLE && release_channels[9]),
   .busy(nes_status[7:0]),.gate(nes_status[15:8]),.idle(nes_idle),.sample_sum(nes_sum),
   .preset_write(hw_write),.preset_address(hw_address),.preset_data(hw_data),.preset_status(nes_preset_status));
 end else begin:no_dedicated_percussion
  assign nes_status=0;assign nes_idle=1'b1;assign nes_sum=19'sd0;assign nes_preset_status=0;
 end endgenerate
 assign hw_read=hw_address==12'h428 ? nes_preset_status:performance_read;
 wire signed [23:0] nes_extended={{5{nes_sum[18]}},nes_sum};
 // 176/8 is exactly 22. Schedule the two additions in existing mix states.
 reg signed [23:0] nes_scale_stage,nes_pcm_stage;
 wire cpu_barrier=cpu_enabled && (dynamic_event || ((SD_ONLY || routed_event_tag[95:88]==3) &&
  (routed_data[31:28]==4 || (routed_data[31:28]==3 && routed_data[23:17]==0))));
 reg [5:0] claimed_slot;reg [31:0] claimed_token;reg [23:0] watchdog;
 wire port_ready,port_resp_valid,port_resp_ok,port_commit_valid;wire [31:0] port_resp_token;
 wire cfg_we,meta_we;wire [5:0] cfg_slot,commit_slot;wire [2:0] cfg_op;wire [107:0] cfg_data;wire [7:0] metadata;
 wire [6:0] commit_note,commit_velocity;
 wire [VOICES-1:0] control_off;wire [VOICES*2-1:0] assigned_sources;
 wire [15:0] pedal_snapshot;
 genvar r;
 generate for(r=0;r<VOICES;r=r+1)begin:controlled_release
  assign control_off[r]=RELEASE_CONTROL_ENABLE!=0 && (HW_PATCH?busy[r]:sd_running[r]) &&
   (release_channels[held_string[r]?4'd0:channels[r*4+:4]] || release_sources[assigned_sources[r*2+:2]] ||
    (held_string[r] && release_string));
 end endgenerate
 assign off=allocated_off | ((HW_PATCH?library_count==0:!cpu_enabled)?sd_running:{VOICES{1'b0}}) | control_off;
 // Record private plucks on the selected piano channel for ordinary SMF playback.
 assign cpu_event_data=event_string?{4'd0,routed_data[35:28],4'd0,routed_data[23:4],4'd0}:routed_data;
 assign cpu_event_tag=routed_event_tag;
 assign kill_slots=(pop && dynamic_on)?allocated_on:{VOICES{1'b0}};
 assign on=commit_fire?claim:(pop && !dynamic_on && (!SD_ONLY || HW_PATCH))?allocated_on:{VOICES{1'b0}};
 generate if(HW_PATCH)begin:hardware_patch
  wire [7:0] patch_id;
  wire [6:0] patch_key;
  sd_performance performance(clk,rst_n,pop && !event_string,event_window,routed_data,library_count,pedal_snapshot,
   hw_write,hw_address,hw_data,performance_read,hw_active,patch_id,patch_key,
   hw_control_busy,hw_control_we,hw_control_channel,hw_control_data,piano_patch);
  wire source_cancel=release_channels[event_string?4'd0:routed_data[27:24]] ||
   release_sources[routed_event_tag[89:88]] || (event_string && !string_current);
  wire note_start=pop && dynamic_on && (|allocated_on) && !source_cancel;
  wire cancel_note=dispatch_state!=0 && (library_count==0 || source_cancel);
  wire op_valid,done;
  wire [107:0] operator_data;
  wire [3:0] gain_code;
  sd_syx_note #(.VOICES(VOICES)) prepare_note(
   .clk(clk),.rst_n(rst_n && safe_online && library_count!=0 && !cancel_note),.start(note_start),
   .patch(event_string?piano_patch[7:0]:patch_id),.key(patch_key),.velocity(velocity),
   .ram_read(library_read),.ram_address(library_address),.ram_data(library_data),
   .op_valid(op_valid),.op_index(cfg_op),.op_data(operator_data),
   .done(done),.metadata(metadata),.boost(gain_code));
  assign cfg_slot=claimed_slot;
  assign cfg_we=op_valid && dispatch_state!=0 && !cancel_note && safe_online;
  assign meta_we=commit_fire;
  assign cfg_data=meta_we?{76'd0,28'h554f010,gain_code}:operator_data;
  assign commit_fire=dispatch_state!=0 && done && event_window && !cancel_note && safe_online;
  assign retire_event=(pop && !note_start) || commit_fire || cancel_note;
  assign commit_note=raw_note;
  assign commit_velocity=velocity;
  assign config_reserved=0;
  assign allocation_valid=0;assign allocation_slot=0;assign allocation_token=0;
  assign config_ready=0;assign config_resp_valid=0;assign config_resp_ok=0;assign config_resp_token=0;
  // Recording is a passive copy. The audio engine never waits for its FIFO.
  assign cpu_event_valid=pop && safe_online && !stale_pluck;
  integer slot;
  always @(posedge clk)begin
   if(!rst_n || !safe_online)begin
    dispatch_state<=0;claim<=0;claimed_slot<=0;sd_running<=0;config_faults<=0;
   end else begin
    if(note_start)begin
     dispatch_state<=1;claim<=allocated_on;
     for(slot=0;slot<VOICES;slot=slot+1)if(allocated_on[slot])claimed_slot<=slot;
    end else if(commit_fire || cancel_note)begin dispatch_state<=0;claim<=0;end
    for(slot=0;slot<VOICES;slot=slot+1)begin
     if(!busy[slot] || (pop && allocated_on[slot]))sd_running[slot]<=0;
     if(commit_fire && claim[slot])sd_running[slot]<=1;
    end
   end
  end
 end else begin:firmware_patch
 assign library_read=0;assign library_address=0;assign performance_read=0;assign hw_active=0;assign piano_patch=0;
 assign hw_control_busy=0;assign hw_control_we=0;assign hw_control_channel=0;assign hw_control_data=0;
 reg cpu_inflight;reg [2:0] cpu_kind;
 wire port_request=(dispatch_state==1 || dispatch_state==6) || (dispatch_state==4 && config_valid);
 wire [2:0] port_kind=dispatch_state==1?3'd0:dispatch_state==6?3'd4:config_kind==0?3'd7:config_kind;
 wire [5:0] port_slot=(dispatch_state==1 || dispatch_state==6)?claimed_slot:config_slot;
 wire [31:0] port_token=dispatch_state==6?claimed_token:config_token;
 wire commit_window=event_window && (dispatch_state==4 || dispatch_state==6);
 assign commit_fire=port_commit_valid && commit_window;
 // Keep byte comparisons separate: a single 96-bit == otherwise maps to a
 // long ALU carry chain in Gowin. Purely combinational, no ACK latency change.
 (* syn_keep=1 *) wire [11:0] ack_equal;
 genvar ack_byte;
 for(ack_byte=0;ack_byte<12;ack_byte=ack_byte+1)begin:ack_compare
  assign ack_equal[ack_byte]=cpu_ack_tag[ack_byte*8+:8]==routed_event_tag[ack_byte*8+:8];
 end
 wire acknowledged=cpu_ack_valid && (&ack_equal);
 wire cancelled=dispatch_state==4 && config_resp_valid && config_resp_ok && cpu_kind==4;
 wire reserve_failed=dispatch_state==2 && port_resp_valid && !port_resp_ok;
 assign retire_event=(pop && !dynamic_on && !cpu_barrier) || (dispatch_state==5 && acknowledged) ||
  commit_fire || cancelled || reserve_failed || (dispatch_state==7 && port_resp_valid) || (!cpu_enabled && dispatch_state!=0);
 assign config_ready=dispatch_state==4 && port_ready;
 assign config_resp_valid=port_resp_valid && cpu_inflight;
 assign config_resp_ok=port_resp_ok;assign config_resp_token=port_resp_token;
 assign allocation_valid=dispatch_state==3 || dispatch_state==4 || dispatch_state==6;
 assign allocation_slot=claimed_slot;assign allocation_token=claimed_token;
 assign cpu_event_valid=cpu_enabled && ((pop && !dynamic_on) || dispatch_state==3);
 sd_tdm_config_port #(.ABORT_ENABLE(1),.VOICES(VOICES)) publication(.clk(clk),.rst_n(rst_n),.abort(!cpu_enabled || !online),.req_valid(port_request),.req_ready(port_ready),
  .req_kind(port_kind),.req_slot(port_slot),.req_token(port_token),.req_op(config_op),.req_data(config_data),.req_meta(config_meta),
  .req_note(raw_note),.req_velocity(velocity),.slot_safe(~busy),.commit_ready(commit_window),
  .resp_valid(port_resp_valid),.resp_ok(port_resp_ok),.resp_token(port_resp_token),
  .cfg_we(cfg_we),.meta_we(meta_we),.cfg_slot(cfg_slot),.cfg_op(cfg_op),.cfg_data(cfg_data),.meta_data(metadata),
  .commit_valid(port_commit_valid),.commit_slot(commit_slot),.commit_note(commit_note),.commit_velocity(commit_velocity),.reserved(config_reserved));
 integer slot_index;
 always @(posedge clk)begin
  if(!rst_n || !online)begin dispatch_state<=0;claim<=0;sd_running<=0;claimed_slot<=0;claimed_token<=0;watchdog<=0;cpu_inflight<=0;cpu_kind<=0;config_faults<=0;end
  else begin
   if(config_resp_valid)cpu_inflight<=0;
   if(config_valid && config_ready)begin cpu_inflight<=1;cpu_kind<=config_kind;end
   if(dispatch_state==4)watchdog<=watchdog+1'b1;else watchdog<=0;
   for(slot_index=0;slot_index<VOICES;slot_index=slot_index+1)begin
    if(!busy[slot_index] || !cpu_enabled)sd_running[slot_index]<=0;
    if(pop && !dynamic_on && allocated_on[slot_index])sd_running[slot_index]<=0;
    if(commit_fire && claim[slot_index])sd_running[slot_index]<=1;
   end
   if(!cpu_enabled && dispatch_state!=0)begin dispatch_state<=0;claim<=0;cpu_inflight<=0;config_faults<=config_faults+1'b1;end
   else case(dispatch_state)
    0:if(pop)begin
     if(dynamic_on)begin claim<=allocated_on;for(slot_index=0;slot_index<VOICES;slot_index=slot_index+1)if(allocated_on[slot_index])claimed_slot<=slot_index;dispatch_state<=1;end
     else if(cpu_barrier)dispatch_state<=5;
    end
    1:if(port_ready)dispatch_state<=2;
    2:if(port_resp_valid)begin
     if(port_resp_ok)begin claimed_token<=port_resp_token;dispatch_state<=3;end
     else begin claim<=0;dispatch_state<=0;config_faults<=config_faults+1'b1;end
    end
    3:if(cpu_event_ready)dispatch_state<=4;
    4:if(commit_fire)begin claim<=0;dispatch_state<=0;end
      else if(cancelled)begin claim<=0;dispatch_state<=0;config_faults<=config_faults+1'b1;end
      else if(watchdog==CONFIG_TIMEOUT_CYCLES-1)dispatch_state<=6;
    5:if(acknowledged)dispatch_state<=0;
    6:if(commit_fire)begin claim<=0;dispatch_state<=0;end else if(port_ready)dispatch_state<=7;
    7:if(port_resp_valid)begin claim<=0;dispatch_state<=0;config_faults<=config_faults+1'b1;end
    default:dispatch_state<=0;
   endcase
  end
 end
 end endgenerate
 instrument_tdm64_allocator #(.SUSTAIN_ENABLE(1),.VOICES(4*VOICES_PER_CORE),.SOURCE_ENABLE(1),.SD_ONLY(SD_ONLY),.NES_ENABLE(HW_PATCH),
  .SPLIT_NES(SD_ONLY && HW_PATCH)) allocator(clk,rst_n,pop && !stale_pluck,routed_data,safe_online,
  busy,gate,releasing,allocated_on,allocated_off,raw_note,velocity,assigned_notes,channels,accepted_events,steals,retriggers,patch_select,enabled_mask,claim|config_reserved,routed_event_tag[89:88],assigned_sources,
  RELEASE_CONTROL_ENABLE!=0?release_sources:4'd0,RELEASE_CONTROL_ENABLE!=0?release_channels:16'd0,pedal_snapshot,event_string,held_string);
 wire [2:0] core_patch=commit_fire?3'd6:HW_PATCH?3'd5:SD_ONLY?3'd6:routed_data[27:24]==9?3'd5:patch_select;
 wire [6:0] model_note=commit_fire?commit_note:raw_note+7'd12;
 wire [6:0] core_velocity=commit_fire?commit_velocity:velocity;
 (* syn_keep=1 *) wire [13:0] pitch_value;wire [23:0] pitch_ratio;
 assign string_bend_ratio=pitch_ratio;
 (* syn_keep=1 *) wire [31:0] pitch_events;
 generate if(!SD_ONLY)begin:legacy_pitch
  synth_pitch_control pitch(clk,rst_n,pop,routed_data,safe_online,pitch_value,pitch_ratio,pitch_events);
 end else begin:no_legacy_pitch
  assign pitch_value=14'd8192;assign pitch_ratio=24'd4194304;assign pitch_events=32'd0;
 end endgenerate
 wire [23:0] flute_ratio;wire [17:0] flute_am_pt;
 // For builtin flute the allocator selects only CH1 notes <=103.
 // The winner is always a valid slot after EVENT_WARMUP. Decode the event
 // directly instead of reducing the distributed one-hot output.
 wire flute_keydown=pop && safe_online && !dynamic_on && core_patch==3'd3 &&
  routed_data[31:28]==4'd2 && velocity!=0 && routed_data[27:24]==0 && raw_note<=103;
 generate if(!SD_ONLY)begin:legacy_lfo
  instrument_flute_lfo flute_lfo(clk,rst_n,sample_tick,flute_keydown,pitch_ratio,flute_ratio,flute_am_pt);
 end else begin:no_legacy_lfo
  assign flute_ratio=24'd4194304;assign flute_am_pt=18'd0;
 end endgenerate
 wire [135:0] ep_flat,cel_flat;wire [127:0] deadline_flat,range_flat;wire [63:0] cycle_flat;
 instrument_tdm64_bank #(.VOICES_PER_CORE(VOICES_PER_CORE),.KILL_ENABLE(1),.CHANNEL_CONTROL_ENABLE(CHANNEL_CONTROL_ENABLE),.SD_ONLY(SD_ONLY),.NES_ENABLE(HW_PATCH && !SD_ONLY)) bank(.clk(clk),.rst_n(rst_n),.sample_tick(sample_tick),.note_on(on),.note_off(off),
  .note(model_note),.velocity(core_velocity),.patch_select(core_patch),.pitch_ratio(pitch_ratio),.flute_pitch_ratio(flute_ratio),.string_ratio(string_ratio),.flute_am_pt(flute_am_pt),
  .cfg_we(cfg_we),.meta_we(meta_we),.cfg_slot(cfg_slot),.cfg_op(cfg_op),.cfg_data(cfg_data),.meta_data(metadata),
  .busy(busy),.gate(gate),.releasing(releasing),.voice_raw(voice_raw),.lane_idle(lane_idle),.lane_valid(lane_valid),.ep_mix(ep_flat),.cel_mix(cel_flat),
  .lane_deadline(deadline_flat),.lane_ranges(range_flat),.lane_cycles(cycle_flat),.kill_slot(kill_slots),
  .note_channel(routed_data[27:24]),.control_we(HW_PATCH?hw_control_we:(control_valid && control_ready)),
  .control_channel(HW_PATCH?hw_control_channel:control_channel),.control_data(HW_PATCH?hw_control_data:control_data));
 genvar g;generate for(g=0;g<4;g=g+1)begin:lane_status
  assign ep_mix[g]=ep_flat[g*34+:34];assign cel_mix[g]=cel_flat[g*34+:34];assign lane_deadline[g]=deadline_flat[g*32+:32];assign lane_ranges[g]=range_flat[g*32+:32];assign lane_cycles[g]=cycle_flat[g*16+:16];
 end endgenerate
 reg signed [35:0] ep_sum,cel_sum;
 reg signed [59:0] dc_y,dc_x1; // PCM24 units with 20 fractional guard bits.
 reg signed [71:0] dc_product;
 reg signed [59:0] dc_next;
 reg signed [36:0] mixed;
 reg [3:0] mix_state;
 // r=0.997375 = 1-126/48000; exact decay is 21/8000. Q20 coefficient
 // round(r*2^20)=1045823. Shift/add constant multiply, no floating point.
 always @(posedge clk)begin
  if(!rst_n)begin
   pcm<=0;pcm_valid<=0;deadline_miss<=0;clip_count<=0;range_errors<=0;last_cycles<=0;
   working<=0;completed<=0;elapsed<=0;mix_index<=0;mix_state<=0;
   ep_sum<=0;cel_sum<=0;dc_y<=0;dc_x1<=0;dc_product<=0;dc_next<=0;mixed<=0;
   nes_scale_stage<=0;nes_pcm_stage<=0;
  end else begin
   pcm_valid<=0;
   if(sample_tick)begin
    if(working)deadline_miss<=deadline_miss+1'b1;
    else begin working<=1;completed<=0;elapsed<=0;mix_state<=0;end
   end
   if(working)begin
    elapsed<=elapsed+1'b1;completed<=completed|lane_valid;
    case(mix_state)
     0:if((&(completed|lane_valid)) && nes_idle)begin ep_sum<=0;cel_sum<=0;mix_index<=0;mix_state<=1;end
     1:begin
      ep_sum<=ep_sum+ep_mix[mix_index];cel_sum<=cel_sum+cel_mix[mix_index];
      if(lane_deadline[mix_index]!=0 || lane_ranges[mix_index]!=0)range_errors<=range_errors+1'b1;
      if(mix_index==3)mix_state<=2;else mix_index<=mix_index+1'b1;
     end
     2:begin
      // Quantization only in the output DC blocker; six-OP raw remains exact.
      if(!SD_ONLY)dc_product<=dc_y*21'sd1045823;
      else nes_scale_stage<=(nes_extended<<<4)+(nes_extended<<<2);
      mix_state<=3;
     end
     3:begin
      if(!SD_ONLY)dc_next<=($signed(cel_sum)<<<20)-dc_x1+(dc_product>>>20);
      else nes_pcm_stage<=nes_scale_stage+(nes_extended<<<1);
      mix_state<=4;
     end
     4:begin
      if(!SD_ONLY)begin dc_x1<=$signed(cel_sum)<<<20;dc_y<=dc_next;end
      // Fixed /8 scaling. The SYX preparation gain accounts for bank capacity.
      mixed<=SD_ONLY?(($signed(ep_sum)>>>3)+$signed(nes_pcm_stage)):($signed(ep_sum)+(dc_next>>>20))>>>3;mix_state<=5;
     end
     5:begin
      if(mixed>37'sd8388607)begin pcm<=24'sh7fffff;clip_count<=clip_count+1'b1;end
      else if(mixed< -37'sd8388608)begin pcm<=24'sh800000;clip_count<=clip_count+1'b1;end
      else pcm<=mixed[23:0];
      pcm_valid<=1;last_cycles<=elapsed;working<=0;mix_state<=0;
     end
     default:mix_state<=0;
    endcase
   end
  end
 end
endmodule
`default_nettype wire
