`default_nettype none
// ESP32 private link: 8N1 UART at DIV=434 (50 MHz/115200 = 434.03, +0.0064%),
// the same divisor already used by midi_uart_tx. The RX pad is asynchronous to
// the 50 MHz core; sampling happens after a two-flop synchronizer.
module bt_uart_rx #(parameter integer DIV=434)(
 input wire clk,rst_n,rx,
 output reg valid,output reg [7:0] data,output reg frame_error
);
 localparam [15:0] HALF=DIV/2;
 localparam [15:0] FULL=DIV-1;
 reg meta,sync,old;
 always @(posedge clk)begin meta<=rx;sync<=meta;old<=sync;end
 wire start_edge=old && !sync;
 reg [1:0] state;
 reg [15:0] cnt;
 reg [2:0] idx;
 reg [7:0] sh;
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=2'd0;cnt<=16'd0;idx<=3'd0;sh<=8'd0;valid<=0;frame_error<=0;
  end else begin
   valid<=0;frame_error<=0;
   case(state)
    2'd0:if(start_edge)begin cnt<=HALF;state<=2'd1;end
    2'd1:if(cnt==16'd0)begin
     if(!sync)begin cnt<=FULL;idx<=3'd0;state<=2'd2;end
     else begin frame_error<=1;state<=2'd0;end
    end else cnt<=cnt-1'b1;
    2'd2:if(cnt==16'd0)begin
     sh[idx]<=sync;
     cnt<=FULL;
     if(idx==3'd7)state<=2'd3;else idx<=idx+1'b1;
    end else cnt<=cnt-1'b1;
    2'd3:if(cnt==16'd0)begin
     state<=2'd0;
     if(sync)begin valid<=1;data<=sh;end
     else frame_error<=1;
    end else cnt<=cnt-1'b1;
    default:state<=2'd0;
   endcase
  end
 end
endmodule

// 10-bit 8N1 transmitter. The stop bit always occupies a full bit period:
// busy drops only after the stop period has elapsed.
module bt_uart_tx #(parameter integer DIV=434)(
 input wire clk,rst_n,valid,input wire [7:0] data,
 output wire ready,output reg tx
);
 localparam [15:0] FULL=DIV-1;
 reg busy;
 reg [15:0] cnt;
 reg [10:0] sh;
 reg [3:0] bi;
 assign ready=!busy;
 always @(posedge clk)begin
  if(!rst_n)begin busy<=0;cnt<=16'd0;sh<=11'h7ff;bi<=4'd0;tx<=1'b1;end
  else if(!busy)begin
   tx<=1'b1;
   if(valid)begin
    busy<=1;sh<={1'b1,data,1'b0};tx<=1'b0;cnt<=FULL;bi<=4'd0;
   end
  end else if(cnt!=16'd0)cnt<=cnt-1'b1;
  else begin
   cnt<=FULL;
   if(bi==4'd9)begin busy<=0;tx<=1'b1;bi<=4'd0;end
   else begin bi<=bi+1'b1;tx<=sh[bi+1'b1];end
  end
 end
endmodule
`default_nettype wire
