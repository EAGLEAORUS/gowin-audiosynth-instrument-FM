`default_nettype none
module instrument_allocator40 #(parameter integer VOICES=40,parameter [3:0] MIDI_CHANNEL=4'd0,parameter integer SUSTAIN_ENABLE=0)(
 input wire clk,rst_n,event_valid,input wire [39:0] event_data,input wire online,
 input wire [VOICES-1:0] voice_busy,voice_gate,voice_releasing,
 output reg [VOICES-1:0] note_on,note_off,
 output wire [6:0] note,velocity,
 output wire [VOICES*7-1:0] assigned_notes,output wire [VOICES*4-1:0] assigned_channels,
 output reg [31:0] routed_events,steal_count,retrigger_count,
 input wire [2:0] patch_select);
 localparam integer B=$clog2(VOICES), LEAVES=1<<B, CW=2+3*B;
 wire [3:0] kind=event_data[31:28],channel=event_data[27:24];
 assign note=event_data[23:17];assign velocity=event_data[16:10];
 wire nes_channel=channel==9;
 wire selected=(channel==MIDI_CHANNEL && note<=103) || (nes_channel && note>=36 && note<=51);
 wire on_event=selected && kind==2 && velocity!=0;
 wire off_event=selected && (kind==1 || (kind==2 && velocity==0));
 wire all_off=(channel==MIDI_CHANNEL || nes_channel) && kind==3 && (note==120 || note==123);
 reg [VOICES-1:0] owned;
 // Same core-clock domain as the queued MIDI events. Eligibility is latched
 // on each NoteOn, so later patch selection never changes a held voice.
 reg sustain_down;
 reg [VOICES-1:0] sustain_eligible,deferred_off;
 wire pedal_event=SUSTAIN_ENABLE!=0 && event_data[39:36]==4'd0 &&
  event_data[35:32]==4'hb && kind==4'd3 && channel==MIDI_CHANNEL &&
  note==7'd64 && event_data[9:8]==2'd3 && event_data[7:0]=={4'hb,MIDI_CHANNEL};
 wire pedal_up=pedal_event && !velocity[6];
 reg [6:0] held_note[0:VOICES-1];reg [3:0] held_channel[0:VOICES-1];reg [B-1:0] rank[0:VOICES-1];
 // Low five payload bits carry the true old LRU rank, independently of
 // the free-slot search rank (zero, so free slots retain index priority).
 wire [CW-1:0] choice[1:2*LEAVES-1];reg [CW-1:0] grouped[0:LEAVES/4-1];reg [CW-1:0] middle[0:LEAVES/8-1];
 genvar g;generate for(g=0;g<LEAVES;g=g+1)begin:leaves
  if(g<VOICES)begin:valid_slot
  wire matching=channel==MIDI_CHANNEL && owned[g] && voice_busy[g] && held_note[g]==note && held_channel[g]==channel;
  wire [1:0] priority_class=matching?2'd0:!voice_busy[g]?2'd1:voice_releasing[g]?2'd2:2'd3;
  localparam [B-1:0] SLOT=g;
  assign choice[LEAVES+g]={priority_class,(!voice_busy[g]?{B{1'b0}}:rank[g]),SLOT,rank[g]};
  assign assigned_notes[g*7+:7]=held_note[g];assign assigned_channels[g*4+:4]=held_channel[g];
  end else begin:padding assign choice[LEAVES+g]={CW{1'b1}};end
 end
 for(g=1;g<LEAVES;g=g+1)begin:tree
  if(g>=LEAVES/4 && g<LEAVES/2)begin:registered_group
   always @(posedge clk)grouped[g-LEAVES/4]<=choice[2*g][CW-1:B]<=choice[2*g+1][CW-1:B]?choice[2*g]:choice[2*g+1];
   assign choice[g]=grouped[g-LEAVES/4];
  end else if(VOICES>32 && g>=LEAVES/8 && g<LEAVES/4)begin:middle_stage
   always @(posedge clk)middle[g-LEAVES/8]<=choice[2*g][CW-1:B]<=choice[2*g+1][CW-1:B]?choice[2*g]:choice[2*g+1];
   assign choice[g]=middle[g-LEAVES/8];
  end else begin:combinational_group
   assign choice[g]=choice[2*g][CW-1:B]<=choice[2*g+1][CW-1:B]?choice[2*g]:choice[2*g+1];
  end
 end endgenerate
 // Register the complete winner before distributed voice/rank enables.
 // Data-only pipeline register; the engine waits three cycles after fetching
 // an event, so no uninitialized winner can be consumed after reset.
 reg [CW-1:0] selected_choice /* synthesis syn_maxfan = 16 */;
 always @(posedge clk)selected_choice<=choice[1];
 wire [B-1:0] chosen=selected_choice[2*B-1:B];
 wire stealing=(selected_choice[CW-1:CW-2]>=2),retriggering=selected_choice[CW-1:CW-2]==0;
 integer i;
 always @* begin
  note_on=0;note_off=0;
  if(!online)note_off=voice_gate;
  else if(event_valid)begin
   if(on_event)note_on={{(VOICES-1){1'b0}},1'b1}<<chosen;
   else if(pedal_up)note_off=deferred_off & owned & voice_gate;
   else if(off_event || all_off)begin
    for(i=0;i<VOICES;i=i+1)
     if(owned[i] && voice_gate[i] && held_channel[i]==channel && (all_off || held_note[i]==note))
      if(all_off || !sustain_down || !sustain_eligible[i])note_off[i]=1;
   end
  end
 end
 integer k;
 always @(posedge clk)begin
  if(!rst_n)begin
   owned<=0;routed_events<=0;steal_count<=0;retrigger_count<=0;
   sustain_down<=0;sustain_eligible<=0;deferred_off<=0;
   for(k=0;k<VOICES;k=k+1)begin held_note[k]<=0;held_channel[k]<=0;rank[k]<=k[B-1:0];end
  end else begin
   if(!online)begin sustain_down<=0;deferred_off<=0;end
   else if(event_valid)begin
    if(pedal_event)sustain_down<=velocity[6];
    if(pedal_up || (all_off && channel==MIDI_CHANNEL))deferred_off<=0;
   end
   for(k=0;k<VOICES;k=k+1)begin
    if(!voice_busy[k])begin owned[k]<=0;sustain_eligible[k]<=0;deferred_off[k]<=0;end
    if(online && event_valid && off_event && sustain_down && sustain_eligible[k] &&
       owned[k] && voice_gate[k] && held_channel[k]==channel && held_note[k]==note)deferred_off[k]<=1;
    if(note_on[k])begin
     owned[k]<=1;held_note[k]<=note;held_channel[k]<=channel;rank[k]<=VOICES-1;
     sustain_eligible[k]<=SUSTAIN_ENABLE!=0 && channel==MIDI_CHANNEL && (patch_select==2'd0 || patch_select==2'd1);
     deferred_off[k]<=0;
    end
    else if(note_on!=0 && rank[k]>selected_choice[B-1:0])rank[k]<=rank[k]-1'b1;
   end
   if(online && event_valid && (note_on!=0 || note_off!=0))routed_events<=routed_events+1'b1;
   if(note_on!=0 && stealing)steal_count<=steal_count+1'b1;
   if(note_on!=0 && retriggering)retrigger_count<=retrigger_count+1'b1;
  end
 end
endmodule
`default_nettype wire
