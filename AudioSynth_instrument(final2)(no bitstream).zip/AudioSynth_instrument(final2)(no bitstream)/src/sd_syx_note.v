`default_nettype none
// One pipelined operator per cycle. No runtime CPU or SD transaction.
module sd_syx_note #(parameter integer VOICES=40)(
 input wire clk,rst_n,start,
 input wire [7:0] patch,
 input wire [6:0] key,velocity,
 output wire ram_read,output wire [10:0] ram_address,
 input wire [127:0] ram_data,
 output wire op_valid,output wire [2:0] op_index,output wire [107:0] op_data,
 output wire done,output wire [7:0] metadata,output reg [3:0] boost
);
 // Generated lookup constants from the integer model.
function [30:0] note_qr;
 input [6:0] index;
 begin
  case(index)
   7'd0: note_qr=31'd936378;
   7'd1: note_qr=31'd992059;
   7'd2: note_qr=31'd1051054;
   7'd3: note_qr=31'd1113546;
   7'd4: note_qr=31'd1179781;
   7'd5: note_qr=31'd1249933;
   7'd6: note_qr=31'd1324239;
   7'd7: note_qr=31'd1402979;
   7'd8: note_qr=31'd1486412;
   7'd9: note_qr=31'd1574813;
   7'd10: note_qr=31'd1668440;
   7'd11: note_qr=31'd1767650;
   7'd12: note_qr=31'd1872784;
   7'd13: note_qr=31'd1984146;
   7'd14: note_qr=31'd2102108;
   7'd15: note_qr=31'd2227120;
   7'd16: note_qr=31'd2359563;
   7'd17: note_qr=31'd2499866;
   7'd18: note_qr=31'd2648507;
   7'd19: note_qr=31'd2805985;
   7'd20: note_qr=31'd2972852;
   7'd21: note_qr=31'd3149626;
   7'd22: note_qr=31'd3336909;
   7'd23: note_qr=31'd3535328;
   7'd24: note_qr=31'd3745568;
   7'd25: note_qr=31'd3968291;
   7'd26: note_qr=31'd4204245;
   7'd27: note_qr=31'd4454240;
   7'd28: note_qr=31'd4719126;
   7'd29: note_qr=31'd4999732;
   7'd30: note_qr=31'd5297042;
   7'd31: note_qr=31'd5611999;
   7'd32: note_qr=31'd5945732;
   7'd33: note_qr=31'd6299281;
   7'd34: note_qr=31'd6673845;
   7'd35: note_qr=31'd7070683;
   7'd36: note_qr=31'd7491137;
   7'd37: note_qr=31'd7936582;
   7'd38: note_qr=31'd8408518;
   7'd39: note_qr=31'd8908509;
   7'd40: note_qr=31'd9438252;
   7'd41: note_qr=31'd9999491;
   7'd42: note_qr=31'd10594083;
   7'd43: note_qr=31'd11224025;
   7'd44: note_qr=31'd11891465;
   7'd45: note_qr=31'd12598561;
   7'd46: note_qr=31'd13347719;
   7'd47: note_qr=31'd14141394;
   7'd48: note_qr=31'd14982302;
   7'd49: note_qr=31'd15873193;
   7'd50: note_qr=31'd16817063;
   7'd51: note_qr=31'd17817046;
   7'd52: note_qr=31'd18876503;
   7'd53: note_qr=31'd19998983;
   7'd54: note_qr=31'd21188166;
   7'd55: note_qr=31'd22448079;
   7'd56: note_qr=31'd23782930;
   7'd57: note_qr=31'd25197123;
   7'd58: note_qr=31'd26695438;
   7'd59: note_qr=31'd28282817;
   7'd60: note_qr=31'd29964603;
   7'd61: note_qr=31'd31746386;
   7'd62: note_qr=31'd33634127;
   7'd63: note_qr=31'd35634119;
   7'd64: note_qr=31'd37753035;
   7'd65: note_qr=31'd39997965;
   7'd66: note_qr=31'd42376361;
   7'd67: note_qr=31'd44896186;
   7'd68: note_qr=31'd47565859;
   7'd69: note_qr=31'd50394274;
   7'd70: note_qr=31'd53390875;
   7'd71: note_qr=31'd56565662;
   7'd72: note_qr=31'd59929235;
   7'd73: note_qr=31'd63492800;
   7'd74: note_qr=31'd67268281;
   7'd75: note_qr=31'd71268266;
   7'd76: note_qr=31'd75506097;
   7'd77: note_qr=31'd79995930;
   7'd78: note_qr=31'd84752721;
   7'd79: note_qr=31'd89792400;
   7'd80: note_qr=31'd95131719;
   7'd81: note_qr=31'd100788547;
   7'd82: note_qr=31'd106781751;
   7'd83: note_qr=31'd113131323;
   7'd84: note_qr=31'd119858469;
   7'd85: note_qr=31'd126985628;
   7'd86: note_qr=31'd134536591;
   7'd87: note_qr=31'd142536533;
   7'd88: note_qr=31'd151012194;
   7'd89: note_qr=31'd159991861;
   7'd90: note_qr=31'd169505470;
   7'd91: note_qr=31'd179584799;
   7'd92: note_qr=31'd190263465;
   7'd93: note_qr=31'd201577122;
   7'd94: note_qr=31'd213563529;
   7'd95: note_qr=31'd226262675;
   7'd96: note_qr=31'd239716938;
   7'd97: note_qr=31'd253971256;
   7'd98: note_qr=31'd269073181;
   7'd99: note_qr=31'd285073094;
   7'd100: note_qr=31'd302024416;
   7'd101: note_qr=31'd319983749;
   7'd102: note_qr=31'd339010968;
   7'd103: note_qr=31'd359169599;
   7'd104: note_qr=31'd380526930;
   7'd105: note_qr=31'd403154244;
   7'd106: note_qr=31'd427127058;
   7'd107: note_qr=31'd452525350;
   7'd108: note_qr=31'd479433905;
   7'd109: note_qr=31'd507942540;
   7'd110: note_qr=31'd538146362;
   7'd111: note_qr=31'd570146216;
   7'd112: note_qr=31'd604048860;
   7'd113: note_qr=31'd639967499;
   7'd114: note_qr=31'd678021936;
   7'd115: note_qr=31'd718339226;
   7'd116: note_qr=31'd761053889;
   7'd117: note_qr=31'd806308517;
   7'd118: note_qr=31'd854254117;
   7'd119: note_qr=31'd905050700;
   7'd120: note_qr=31'd958867810;
   7'd121: note_qr=31'd1015885079;
   7'd122: note_qr=31'd1076292752;
   7'd123: note_qr=31'd1140292432;
   7'd124: note_qr=31'd1208097749;
   7'd125: note_qr=31'd1279934998;
   7'd126: note_qr=31'd1356043873;
   7'd127: note_qr=31'd1436678452;
   default: note_qr=0;
  endcase
 end
endfunction
function [31:0] fixed_fcw;
 input [8:0] index;
 begin
  case(index)
   9'd0: fixed_fcw=32'd89478;
   9'd1: fixed_fcw=32'd91563;
   9'd2: fixed_fcw=32'd93695;
   9'd3: fixed_fcw=32'd95878;
   9'd4: fixed_fcw=32'd98111;
   9'd5: fixed_fcw=32'd100397;
   9'd6: fixed_fcw=32'd102735;
   9'd7: fixed_fcw=32'd105128;
   9'd8: fixed_fcw=32'd107577;
   9'd9: fixed_fcw=32'd110083;
   9'd10: fixed_fcw=32'd112647;
   9'd11: fixed_fcw=32'd115271;
   9'd12: fixed_fcw=32'd117956;
   9'd13: fixed_fcw=32'd120703;
   9'd14: fixed_fcw=32'd123515;
   9'd15: fixed_fcw=32'd126392;
   9'd16: fixed_fcw=32'd129336;
   9'd17: fixed_fcw=32'd132348;
   9'd18: fixed_fcw=32'd135431;
   9'd19: fixed_fcw=32'd138586;
   9'd20: fixed_fcw=32'd141814;
   9'd21: fixed_fcw=32'd145117;
   9'd22: fixed_fcw=32'd148497;
   9'd23: fixed_fcw=32'd151956;
   9'd24: fixed_fcw=32'd155496;
   9'd25: fixed_fcw=32'd159118;
   9'd26: fixed_fcw=32'd162824;
   9'd27: fixed_fcw=32'd166617;
   9'd28: fixed_fcw=32'd170498;
   9'd29: fixed_fcw=32'd174469;
   9'd30: fixed_fcw=32'd178533;
   9'd31: fixed_fcw=32'd182692;
   9'd32: fixed_fcw=32'd186947;
   9'd33: fixed_fcw=32'd191302;
   9'd34: fixed_fcw=32'd195758;
   9'd35: fixed_fcw=32'd200317;
   9'd36: fixed_fcw=32'd204983;
   9'd37: fixed_fcw=32'd209758;
   9'd38: fixed_fcw=32'd214644;
   9'd39: fixed_fcw=32'd219644;
   9'd40: fixed_fcw=32'd224760;
   9'd41: fixed_fcw=32'd229995;
   9'd42: fixed_fcw=32'd235352;
   9'd43: fixed_fcw=32'd240834;
   9'd44: fixed_fcw=32'd246444;
   9'd45: fixed_fcw=32'd252185;
   9'd46: fixed_fcw=32'd258059;
   9'd47: fixed_fcw=32'd264070;
   9'd48: fixed_fcw=32'd270221;
   9'd49: fixed_fcw=32'd276515;
   9'd50: fixed_fcw=32'd282956;
   9'd51: fixed_fcw=32'd289547;
   9'd52: fixed_fcw=32'd296291;
   9'd53: fixed_fcw=32'd303193;
   9'd54: fixed_fcw=32'd310255;
   9'd55: fixed_fcw=32'd317482;
   9'd56: fixed_fcw=32'd324877;
   9'd57: fixed_fcw=32'd332444;
   9'd58: fixed_fcw=32'd340188;
   9'd59: fixed_fcw=32'd348112;
   9'd60: fixed_fcw=32'd356220;
   9'd61: fixed_fcw=32'd364518;
   9'd62: fixed_fcw=32'd373008;
   9'd63: fixed_fcw=32'd381697;
   9'd64: fixed_fcw=32'd390588;
   9'd65: fixed_fcw=32'd399686;
   9'd66: fixed_fcw=32'd408996;
   9'd67: fixed_fcw=32'd418522;
   9'd68: fixed_fcw=32'd428271;
   9'd69: fixed_fcw=32'd438247;
   9'd70: fixed_fcw=32'd448455;
   9'd71: fixed_fcw=32'd458901;
   9'd72: fixed_fcw=32'd469590;
   9'd73: fixed_fcw=32'd480528;
   9'd74: fixed_fcw=32'd491721;
   9'd75: fixed_fcw=32'd503175;
   9'd76: fixed_fcw=32'd514895;
   9'd77: fixed_fcw=32'd526888;
   9'd78: fixed_fcw=32'd539161;
   9'd79: fixed_fcw=32'd551720;
   9'd80: fixed_fcw=32'd564571;
   9'd81: fixed_fcw=32'd577722;
   9'd82: fixed_fcw=32'd591178;
   9'd83: fixed_fcw=32'd604949;
   9'd84: fixed_fcw=32'd619040;
   9'd85: fixed_fcw=32'd633459;
   9'd86: fixed_fcw=32'd648214;
   9'd87: fixed_fcw=32'd663313;
   9'd88: fixed_fcw=32'd678764;
   9'd89: fixed_fcw=32'd694574;
   9'd90: fixed_fcw=32'd710753;
   9'd91: fixed_fcw=32'd727308;
   9'd92: fixed_fcw=32'd744250;
   9'd93: fixed_fcw=32'd761585;
   9'd94: fixed_fcw=32'd779325;
   9'd95: fixed_fcw=32'd797478;
   9'd96: fixed_fcw=32'd816053;
   9'd97: fixed_fcw=32'd835062;
   9'd98: fixed_fcw=32'd854513;
   9'd99: fixed_fcw=32'd874417;
   9'd100: fixed_fcw=32'd894785;
   9'd101: fixed_fcw=32'd915627;
   9'd102: fixed_fcw=32'd936955;
   9'd103: fixed_fcw=32'd958779;
   9'd104: fixed_fcw=32'd981112;
   9'd105: fixed_fcw=32'd1003965;
   9'd106: fixed_fcw=32'd1027350;
   9'd107: fixed_fcw=32'd1051281;
   9'd108: fixed_fcw=32'd1075768;
   9'd109: fixed_fcw=32'd1100826;
   9'd110: fixed_fcw=32'd1126467;
   9'd111: fixed_fcw=32'd1152706;
   9'd112: fixed_fcw=32'd1179556;
   9'd113: fixed_fcw=32'd1207032;
   9'd114: fixed_fcw=32'd1235147;
   9'd115: fixed_fcw=32'd1263917;
   9'd116: fixed_fcw=32'd1293358;
   9'd117: fixed_fcw=32'd1323484;
   9'd118: fixed_fcw=32'd1354312;
   9'd119: fixed_fcw=32'd1385858;
   9'd120: fixed_fcw=32'd1418138;
   9'd121: fixed_fcw=32'd1451171;
   9'd122: fixed_fcw=32'd1484973;
   9'd123: fixed_fcw=32'd1519563;
   9'd124: fixed_fcw=32'd1554958;
   9'd125: fixed_fcw=32'd1591177;
   9'd126: fixed_fcw=32'd1628241;
   9'd127: fixed_fcw=32'd1666167;
   9'd128: fixed_fcw=32'd1704977;
   9'd129: fixed_fcw=32'd1744691;
   9'd130: fixed_fcw=32'd1785330;
   9'd131: fixed_fcw=32'd1826916;
   9'd132: fixed_fcw=32'd1869471;
   9'd133: fixed_fcw=32'd1913016;
   9'd134: fixed_fcw=32'd1957576;
   9'd135: fixed_fcw=32'd2003174;
   9'd136: fixed_fcw=32'd2049834;
   9'd137: fixed_fcw=32'd2097580;
   9'd138: fixed_fcw=32'd2146439;
   9'd139: fixed_fcw=32'd2196436;
   9'd140: fixed_fcw=32'd2247598;
   9'd141: fixed_fcw=32'd2299951;
   9'd142: fixed_fcw=32'd2353524;
   9'd143: fixed_fcw=32'd2408345;
   9'd144: fixed_fcw=32'd2464442;
   9'd145: fixed_fcw=32'd2521846;
   9'd146: fixed_fcw=32'd2580588;
   9'd147: fixed_fcw=32'd2640697;
   9'd148: fixed_fcw=32'd2702207;
   9'd149: fixed_fcw=32'd2765150;
   9'd150: fixed_fcw=32'd2829558;
   9'd151: fixed_fcw=32'd2895467;
   9'd152: fixed_fcw=32'd2962911;
   9'd153: fixed_fcw=32'd3031926;
   9'd154: fixed_fcw=32'd3102549;
   9'd155: fixed_fcw=32'd3174816;
   9'd156: fixed_fcw=32'd3248767;
   9'd157: fixed_fcw=32'd3324441;
   9'd158: fixed_fcw=32'd3401877;
   9'd159: fixed_fcw=32'd3481117;
   9'd160: fixed_fcw=32'd3562203;
   9'd161: fixed_fcw=32'd3645177;
   9'd162: fixed_fcw=32'd3730084;
   9'd163: fixed_fcw=32'd3816969;
   9'd164: fixed_fcw=32'd3905878;
   9'd165: fixed_fcw=32'd3996857;
   9'd166: fixed_fcw=32'd4089956;
   9'd167: fixed_fcw=32'd4185223;
   9'd168: fixed_fcw=32'd4282710;
   9'd169: fixed_fcw=32'd4382467;
   9'd170: fixed_fcw=32'd4484547;
   9'd171: fixed_fcw=32'd4589006;
   9'd172: fixed_fcw=32'd4695898;
   9'd173: fixed_fcw=32'd4805279;
   9'd174: fixed_fcw=32'd4917209;
   9'd175: fixed_fcw=32'd5031745;
   9'd176: fixed_fcw=32'd5148949;
   9'd177: fixed_fcw=32'd5268884;
   9'd178: fixed_fcw=32'd5391612;
   9'd179: fixed_fcw=32'd5517199;
   9'd180: fixed_fcw=32'd5645711;
   9'd181: fixed_fcw=32'd5777216;
   9'd182: fixed_fcw=32'd5911785;
   9'd183: fixed_fcw=32'd6049488;
   9'd184: fixed_fcw=32'd6190399;
   9'd185: fixed_fcw=32'd6334592;
   9'd186: fixed_fcw=32'd6482143;
   9'd187: fixed_fcw=32'd6633132;
   9'd188: fixed_fcw=32'd6787637;
   9'd189: fixed_fcw=32'd6945742;
   9'd190: fixed_fcw=32'd7107529;
   9'd191: fixed_fcw=32'd7273084;
   9'd192: fixed_fcw=32'd7442496;
   9'd193: fixed_fcw=32'd7615854;
   9'd194: fixed_fcw=32'd7793250;
   9'd195: fixed_fcw=32'd7974778;
   9'd196: fixed_fcw=32'd8160535;
   9'd197: fixed_fcw=32'd8350618;
   9'd198: fixed_fcw=32'd8545129;
   9'd199: fixed_fcw=32'd8744171;
   9'd200: fixed_fcw=32'd8947849;
   9'd201: fixed_fcw=32'd9156271;
   9'd202: fixed_fcw=32'd9369548;
   9'd203: fixed_fcw=32'd9587792;
   9'd204: fixed_fcw=32'd9811121;
   9'd205: fixed_fcw=32'd10039651;
   9'd206: fixed_fcw=32'd10273505;
   9'd207: fixed_fcw=32'd10512805;
   9'd208: fixed_fcw=32'd10757680;
   9'd209: fixed_fcw=32'd11008259;
   9'd210: fixed_fcw=32'd11264674;
   9'd211: fixed_fcw=32'd11527062;
   9'd212: fixed_fcw=32'd11795562;
   9'd213: fixed_fcw=32'd12070316;
   9'd214: fixed_fcw=32'd12351469;
   9'd215: fixed_fcw=32'd12639172;
   9'd216: fixed_fcw=32'd12933576;
   9'd217: fixed_fcw=32'd13234838;
   9'd218: fixed_fcw=32'd13543117;
   9'd219: fixed_fcw=32'd13858577;
   9'd220: fixed_fcw=32'd14181384;
   9'd221: fixed_fcw=32'd14511711;
   9'd222: fixed_fcw=32'd14849732;
   9'd223: fixed_fcw=32'd15195627;
   9'd224: fixed_fcw=32'd15549579;
   9'd225: fixed_fcw=32'd15911775;
   9'd226: fixed_fcw=32'd16282408;
   9'd227: fixed_fcw=32'd16661674;
   9'd228: fixed_fcw=32'd17049774;
   9'd229: fixed_fcw=32'd17446914;
   9'd230: fixed_fcw=32'd17853305;
   9'd231: fixed_fcw=32'd18269162;
   9'd232: fixed_fcw=32'd18694705;
   9'd233: fixed_fcw=32'd19130161;
   9'd234: fixed_fcw=32'd19575760;
   9'd235: fixed_fcw=32'd20031738;
   9'd236: fixed_fcw=32'd20498337;
   9'd237: fixed_fcw=32'd20975804;
   9'd238: fixed_fcw=32'd21464394;
   9'd239: fixed_fcw=32'd21964364;
   9'd240: fixed_fcw=32'd22475979;
   9'd241: fixed_fcw=32'd22999512;
   9'd242: fixed_fcw=32'd23535240;
   9'd243: fixed_fcw=32'd24083446;
   9'd244: fixed_fcw=32'd24644421;
   9'd245: fixed_fcw=32'd25218464;
   9'd246: fixed_fcw=32'd25805877;
   9'd247: fixed_fcw=32'd26406973;
   9'd248: fixed_fcw=32'd27022071;
   9'd249: fixed_fcw=32'd27651495;
   9'd250: fixed_fcw=32'd28295582;
   9'd251: fixed_fcw=32'd28954670;
   9'd252: fixed_fcw=32'd29629111;
   9'd253: fixed_fcw=32'd30319262;
   9'd254: fixed_fcw=32'd31025488;
   9'd255: fixed_fcw=32'd31748165;
   9'd256: fixed_fcw=32'd32487674;
   9'd257: fixed_fcw=32'd33244410;
   9'd258: fixed_fcw=32'd34018771;
   9'd259: fixed_fcw=32'd34811170;
   9'd260: fixed_fcw=32'd35622027;
   9'd261: fixed_fcw=32'd36451770;
   9'd262: fixed_fcw=32'd37300841;
   9'd263: fixed_fcw=32'd38169689;
   9'd264: fixed_fcw=32'd39058775;
   9'd265: fixed_fcw=32'd39968571;
   9'd266: fixed_fcw=32'd40899559;
   9'd267: fixed_fcw=32'd41852232;
   9'd268: fixed_fcw=32'd42827096;
   9'd269: fixed_fcw=32'd43824667;
   9'd270: fixed_fcw=32'd44845475;
   9'd271: fixed_fcw=32'd45890060;
   9'd272: fixed_fcw=32'd46958977;
   9'd273: fixed_fcw=32'd48052792;
   9'd274: fixed_fcw=32'd49172085;
   9'd275: fixed_fcw=32'd50317450;
   9'd276: fixed_fcw=32'd51489494;
   9'd277: fixed_fcw=32'd52688838;
   9'd278: fixed_fcw=32'd53916119;
   9'd279: fixed_fcw=32'd55171987;
   9'd280: fixed_fcw=32'd56457107;
   9'd281: fixed_fcw=32'd57772162;
   9'd282: fixed_fcw=32'd59117849;
   9'd283: fixed_fcw=32'd60494881;
   9'd284: fixed_fcw=32'd61903987;
   9'd285: fixed_fcw=32'd63345916;
   9'd286: fixed_fcw=32'd64821432;
   9'd287: fixed_fcw=32'd66331318;
   9'd288: fixed_fcw=32'd67876372;
   9'd289: fixed_fcw=32'd69457416;
   9'd290: fixed_fcw=32'd71075287;
   9'd291: fixed_fcw=32'd72730843;
   9'd292: fixed_fcw=32'd74424962;
   9'd293: fixed_fcw=32'd76158542;
   9'd294: fixed_fcw=32'd77932503;
   9'd295: fixed_fcw=32'd79747784;
   9'd296: fixed_fcw=32'd81605349;
   9'd297: fixed_fcw=32'd83506181;
   9'd298: fixed_fcw=32'd85451290;
   9'd299: fixed_fcw=32'd87441706;
   9'd300: fixed_fcw=32'd89478485;
   9'd301: fixed_fcw=32'd91562707;
   9'd302: fixed_fcw=32'd93695476;
   9'd303: fixed_fcw=32'd95877924;
   9'd304: fixed_fcw=32'd98111208;
   9'd305: fixed_fcw=32'd100396512;
   9'd306: fixed_fcw=32'd102735047;
   9'd307: fixed_fcw=32'd105128054;
   9'd308: fixed_fcw=32'd107576801;
   9'd309: fixed_fcw=32'd110082586;
   9'd310: fixed_fcw=32'd112646739;
   9'd311: fixed_fcw=32'd115270619;
   9'd312: fixed_fcw=32'd117955616;
   9'd313: fixed_fcw=32'd120703156;
   9'd314: fixed_fcw=32'd123514693;
   9'd315: fixed_fcw=32'd126391720;
   9'd316: fixed_fcw=32'd129335761;
   9'd317: fixed_fcw=32'd132348378;
   9'd318: fixed_fcw=32'd135431168;
   9'd319: fixed_fcw=32'd138585765;
   9'd320: fixed_fcw=32'd141813842;
   9'd321: fixed_fcw=32'd145117111;
   9'd322: fixed_fcw=32'd148497323;
   9'd323: fixed_fcw=32'd151956270;
   9'd324: fixed_fcw=32'd155495786;
   9'd325: fixed_fcw=32'd159117748;
   9'd326: fixed_fcw=32'd162824077;
   9'd327: fixed_fcw=32'd166616737;
   9'd328: fixed_fcw=32'd170497739;
   9'd329: fixed_fcw=32'd174469141;
   9'd330: fixed_fcw=32'd178533050;
   9'd331: fixed_fcw=32'd182691619;
   9'd332: fixed_fcw=32'd186947053;
   9'd333: fixed_fcw=32'd191301609;
   9'd334: fixed_fcw=32'd195757596;
   9'd335: fixed_fcw=32'd200317377;
   9'd336: fixed_fcw=32'd204983368;
   9'd337: fixed_fcw=32'd209758044;
   9'd338: fixed_fcw=32'd214643936;
   9'd339: fixed_fcw=32'd219643636;
   9'd340: fixed_fcw=32'd224759793;
   9'd341: fixed_fcw=32'd229995121;
   9'd342: fixed_fcw=32'd235352396;
   9'd343: fixed_fcw=32'd240834457;
   9'd344: fixed_fcw=32'd246444213;
   9'd345: fixed_fcw=32'd252184636;
   9'd346: fixed_fcw=32'd258058771;
   9'd347: fixed_fcw=32'd264069732;
   9'd348: fixed_fcw=32'd270220706;
   9'd349: fixed_fcw=32'd276514955;
   9'd350: fixed_fcw=32'd282955815;
   9'd351: fixed_fcw=32'd289546703;
   9'd352: fixed_fcw=32'd296291112;
   9'd353: fixed_fcw=32'd303192619;
   9'd354: fixed_fcw=32'd310254882;
   9'd355: fixed_fcw=32'd317481646;
   9'd356: fixed_fcw=32'd324876744;
   9'd357: fixed_fcw=32'd332444095;
   9'd358: fixed_fcw=32'd340187713;
   9'd359: fixed_fcw=32'd348111703;
   9'd360: fixed_fcw=32'd356220266;
   9'd361: fixed_fcw=32'd364517702;
   9'd362: fixed_fcw=32'd373008410;
   9'd363: fixed_fcw=32'd381696892;
   9'd364: fixed_fcw=32'd390587755;
   9'd365: fixed_fcw=32'd399685712;
   9'd366: fixed_fcw=32'd408995589;
   9'd367: fixed_fcw=32'd418522320;
   9'd368: fixed_fcw=32'd428270957;
   9'd369: fixed_fcw=32'd438246669;
   9'd370: fixed_fcw=32'd448454745;
   9'd371: fixed_fcw=32'd458900598;
   9'd372: fixed_fcw=32'd469589766;
   9'd373: fixed_fcw=32'd480527917;
   9'd374: fixed_fcw=32'd491720850;
   9'd375: fixed_fcw=32'd503174500;
   9'd376: fixed_fcw=32'd514894940;
   9'd377: fixed_fcw=32'd526888384;
   9'd378: fixed_fcw=32'd539161191;
   9'd379: fixed_fcw=32'd551719868;
   9'd380: fixed_fcw=32'd564571075;
   9'd381: fixed_fcw=32'd577721625;
   9'd382: fixed_fcw=32'd591178490;
   9'd383: fixed_fcw=32'd604948806;
   9'd384: fixed_fcw=32'd619039874;
   9'd385: fixed_fcw=32'd633459165;
   9'd386: fixed_fcw=32'd648214324;
   9'd387: fixed_fcw=32'd663313176;
   9'd388: fixed_fcw=32'd678763724;
   9'd389: fixed_fcw=32'd694574162;
   9'd390: fixed_fcw=32'd710752873;
   9'd391: fixed_fcw=32'd727308434;
   9'd392: fixed_fcw=32'd744249624;
   9'd393: fixed_fcw=32'd761585425;
   9'd394: fixed_fcw=32'd779325028;
   9'd395: fixed_fcw=32'd797477840;
   9'd396: fixed_fcw=32'd816053485;
   9'd397: fixed_fcw=32'd835061813;
   9'd398: fixed_fcw=32'd854512901;
   9'd399: fixed_fcw=32'd874417063;
   default: fixed_fcw=0;
  endcase
 end
endfunction
function [20:0] detune_q20;
 input [3:0] index;
 begin
  case(index)
   4'd0: detune_q20=21'd1044760;
   4'd1: detune_q20=21'd1045304;
   4'd2: detune_q20=21'd1045849;
   4'd3: detune_q20=21'd1046394;
   4'd4: detune_q20=21'd1046939;
   4'd5: detune_q20=21'd1047484;
   4'd6: detune_q20=21'd1048030;
   4'd7: detune_q20=21'd1048576;
   4'd8: detune_q20=21'd1049122;
   4'd9: detune_q20=21'd1049669;
   4'd10: detune_q20=21'd1050216;
   4'd11: detune_q20=21'd1050763;
   4'd12: detune_q20=21'd1051310;
   4'd13: detune_q20=21'd1051858;
   4'd14: detune_q20=21'd1052406;
   default: detune_q20=0;
  endcase
 end
endfunction
function [22:0] peak_q22;
 input [3:0] index;
 begin
  case(index)
   4'd0: peak_q22=23'd4194304;
   4'd1: peak_q22=23'd4380002;
   4'd2: peak_q22=23'd4573921;
   4'd3: peak_q22=23'd4776426;
   4'd4: peak_q22=23'd4987897;
   4'd5: peak_q22=23'd5208730;
   4'd6: peak_q22=23'd5439340;
   4'd7: peak_q22=23'd5680160;
   4'd8: peak_q22=23'd5931642;
   4'd9: peak_q22=23'd6194258;
   4'd10: peak_q22=23'd6468502;
   4'd11: peak_q22=23'd6754887;
   4'd12: peak_q22=23'd7053951;
   4'd13: peak_q22=23'd7366256;
   4'd14: peak_q22=23'd7692388;
   4'd15: peak_q22=23'd8032959;
   default: peak_q22=0;
  endcase
 end
endfunction
function [7:0] exp_scale;
 input [5:0] index;
 begin
  case(index)
   6'd0: exp_scale=8'd0;
   6'd1: exp_scale=8'd1;
   6'd2: exp_scale=8'd2;
   6'd3: exp_scale=8'd3;
   6'd4: exp_scale=8'd4;
   6'd5: exp_scale=8'd5;
   6'd6: exp_scale=8'd6;
   6'd7: exp_scale=8'd7;
   6'd8: exp_scale=8'd8;
   6'd9: exp_scale=8'd9;
   6'd10: exp_scale=8'd11;
   6'd11: exp_scale=8'd14;
   6'd12: exp_scale=8'd16;
   6'd13: exp_scale=8'd19;
   6'd14: exp_scale=8'd23;
   6'd15: exp_scale=8'd27;
   6'd16: exp_scale=8'd33;
   6'd17: exp_scale=8'd39;
   6'd18: exp_scale=8'd47;
   6'd19: exp_scale=8'd56;
   6'd20: exp_scale=8'd66;
   6'd21: exp_scale=8'd80;
   6'd22: exp_scale=8'd94;
   6'd23: exp_scale=8'd110;
   6'd24: exp_scale=8'd126;
   6'd25: exp_scale=8'd142;
   6'd26: exp_scale=8'd158;
   6'd27: exp_scale=8'd174;
   6'd28: exp_scale=8'd190;
   6'd29: exp_scale=8'd206;
   6'd30: exp_scale=8'd222;
   6'd31: exp_scale=8'd238;
   6'd32: exp_scale=8'd250;
   default: exp_scale=0;
  endcase
 end
endfunction
function [5:0] level_scale_low;
 input [4:0] index;
 begin
  case(index)
   5'd0: level_scale_low=6'd0;
   5'd1: level_scale_low=6'd5;
   5'd2: level_scale_low=6'd9;
   5'd3: level_scale_low=6'd13;
   5'd4: level_scale_low=6'd17;
   5'd5: level_scale_low=6'd20;
   5'd6: level_scale_low=6'd23;
   5'd7: level_scale_low=6'd25;
   5'd8: level_scale_low=6'd27;
   5'd9: level_scale_low=6'd29;
   5'd10: level_scale_low=6'd31;
   5'd11: level_scale_low=6'd33;
   5'd12: level_scale_low=6'd35;
   5'd13: level_scale_low=6'd37;
   5'd14: level_scale_low=6'd39;
   5'd15: level_scale_low=6'd41;
   5'd16: level_scale_low=6'd42;
   5'd17: level_scale_low=6'd43;
   5'd18: level_scale_low=6'd45;
   5'd19: level_scale_low=6'd46;
   default: level_scale_low=0;
  endcase
 end
endfunction
 localparam [63:0] PEAK_BUDGET=64'd8388000*1024;
 localparam IDLE=0,READ=1,ISSUE=2,DRAIN=3,FINALIZE=4,COMPLETE=5;
 reg [2:0] state;
 reg [7:0] patch_q;
 reg [6:0] key_q,velocity_q,note;
 reg [3:0] read_index;
 reg [2:0] issue;
 reg [1023:0] payload;
 reg [26:0] peak_sum;
 wire [2:0] captured_block=read_index[2:0]-3'd1;
 assign ram_read=state==READ && read_index<8;
 assign ram_address={patch_q,read_index[2:0]};
 assign done=state==COMPLETE;
 assign metadata={payload[111*8+:3],payload[110*8+:5]};

 function [6:0] clip99;
  input [7:0] value;
  begin clip99=value>99  ?  7'd99:value[6:0];end
 endfunction
 function [7:0] scale_level;
  input [7:0] value;
  reg [6:0] limited;
  begin limited=clip99(value);scale_level=limited<20  ?  {2'b0,level_scale_low(limited[4:0])}:8'd28+{1'b0,limited};end
 endfunction
 function [12:0] target;
  input [7:0] level;input [12:0] key_level;
  reg signed [14:0] sum;
  begin
   sum=$signed({2'b0,key_level})+$signed({2'b0,level[7:1],6'b0})-15'sd4256;
   target=sum<15'sd16  ?  13'd16:sum>15'sd4096  ?  13'd4096:sum[12:0];
  end
 endfunction
 function [5:0] rate;
  input [7:0] value;input [4:0] offset;
  reg [12:0] scaled;
  reg [6:0] sum;
  begin
   scaled=clip99(value)*6'd41;
   sum=scaled[12:6]+{2'b0,offset};
   rate=sum>63  ?  6'd63:sum[5:0];
  end
 endfunction

 reg [6:0] valid;
 reg [2:0] tags[0:6];
 reg [5:0] modes;
 wire [135:0] selected_op=payload[issue*136+:136];
 reg [135:0] op0;
 wire [7:0] vel_curve;
 FM6_velocity_lut velocities(velocity_q[6:1],vel_curve);
 wire [30:0] qr=note_qr(note);
 wire [5:0] coarse=op0[15*8+1+:6];
 wire [6:0] fine=clip99(op0[16*8+:8]);
 wire [13:0] factor=(coarse==0  ?  6'd1:coarse)*(8'd100+{1'b0,fine});
 wire [8:0] fixed_index=op0[15*8+1+:2]*7'd100+{2'b0,fine};
 wire [4:0] detune_index=op0[12*8+3+:5];
 wire signed [8:0] key_distance=$signed({2'b0,note})-$signed({2'b0,clip99(op0[8*8+:8])})-9'sd17;
 wire [7:0] distance=key_distance<0  ?  8'(-key_distance):key_distance[7:0];
 wire [8:0] group_value=({1'b0,distance}+9'd1)/9'd3;
 wire [1:0] curve=key_distance<0  ?  op0[11*8+:2]:op0[11*8+2+:2];
 wire [6:0] depth=clip99(key_distance<0  ?  op0[9*8+:8]:op0[10*8+:8]);
 wire signed [9:0] vel_diff=$signed({2'b0,vel_curve})-10'sd239;
 wire signed [13:0] vel_product=$signed({1'b0,op0[13*8+2+:3]})*vel_diff+14'sd7;
 wire [6:0] key_third=note/7'd3;
 wire [4:0] key_rate=key_third<7  ?  5'd0:key_third>38  ?  5'd31:5'(key_third-7);
 wire [7:0] key_rate_product=op0[12*8+:3]*key_rate;
 reg [37:0] quotient_product;
 reg [20:0] remainder_product;
 reg [31:0] fixed1;
 reg [20:0] detune1,detune2,detune3;
 reg half1,half2;
 reg [31:0] levels1,levels2,levels3,levels4;
 reg [23:0] rates1,rates2,rates3,rates4,rates5,rates6;
 reg signed [10:0] vel1,vel2,vel3;
 reg [2:0] sensitivity1,sensitivity2,sensitivity3;
 reg [7:0] level1,level2;
 reg [1:0] curve1,curve2;
 reg [14:0] adjustment_product;
 reg [23:0] adjustment2;
 wire [43:0] remainder_div100=remainder_product*23'd5368710;
 reg [37:0] base2,base3;
 reg [58:0] detuned4;
 reg [38:0] fcw5,fcw6;
 reg [64:0] correction6;
 reg [51:0] targets5,targets6;
 wire [11:0] adjustment=(curve2==0 || curve2==3)  ?  adjustment2[23:12]:{3'b0,adjustment2[23:15]};
 wire signed [13:0] scaled_level=$signed({6'b0,level2})+
  (curve2<2  ?  -$signed({2'b0,adjustment}):$signed({2'b0,adjustment}));
 wire [6:0] clipped_level=scaled_level<0  ?  7'd0:scaled_level>127  ?  7'd127:scaled_level[6:0];
 reg [6:0] clipped_level3;
 wire signed [13:0] velocity_level=$signed({2'b0,clipped_level3,5'b0})+($signed({{3{vel3[10]}},vel3})<<<4);
 reg [12:0] key_level4;
 // At velocity 127 the table value is 254. The velocity adjustment is
 // exactly 32 times sensitivity, the upper bound for every lower velocity.
 wire [7:0] max_velocity_base={1'b0,clipped_level3}+{5'b0,sensitivity3};
 reg [12:0] max_key_level4,peak_target5,peak_target6;
 reg [7:0] max_env01_4,max_env23_4;
 wire [38:0] corrected=modes[5]  ?  fcw6-{14'b0,correction6[64:40]}:fcw6;
 assign op_data={rates6,targets6,corrected>39'h7fffffff  ?  32'h7fffffff:corrected[31:0]};
 assign op_index=tags[6];
 assign op_valid=valid[6];
 wire [7:0] flags;
 syx_algorithm_flags graph(metadata[4:0],op_index,flags);
 wire [4:0] peak_exp=peak_target6[12:8];
 wire [23:0] peak_base={1'b0,peak_q22(peak_target6[7:4])};
 wire [24:0] operator_peak=(peak_exp>=14  ?  ({1'b0,peak_base}<<(peak_exp-5'd14)):({1'b0,peak_base}>>(5'd14-peak_exp)))+25'd128;
 reg [24:0] carrier_peak;
 reg peak_valid,last_peak;
 wire signed [9:0] shifted_note=$signed({3'b0,key_q})+
  $signed({2'b0,payload[117*8+:8]})-10'sd24;
 integer k;
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=IDLE;read_index<=0;issue<=0;valid<=0;modes<=0;peak_sum<=0;peak_valid<=0;last_peak<=0;
  end else begin
   valid<={valid[5:0],state==ISSUE};
   modes<={modes[4:0],op0[15*8]};
   for(k=1;k<=6;k=k+1)tags[k]<=tags[k-1];
   tags[0]<=issue;
   if(state==ISSUE)op0<=selected_op;
   quotient_product<=qr[30:7]*factor;
   remainder_product<=qr[6:0]*factor;
   fixed1<=fixed_fcw(fixed_index);
   detune1<=detune_q20(detune_index>14  ?  4'd14:detune_index[3:0]);
   half1<=coarse==0;
   level1<=scale_level(op0[14*8+:8]);curve1<=curve;
   adjustment_product<=(curve==0 || curve==3  ?  group_value[7:0]:exp_scale(group_value>32  ?  6'd32:group_value[5:0]))*depth;
   vel1<=11'(vel_product>>>3);
   sensitivity1<=op0[13*8+2+:3];sensitivity2<=sensitivity1;sensitivity3<=sensitivity2;
   for(k=0;k<4;k=k+1)begin
    levels1[8*k+:8]<=scale_level(op0[8*(4+k)+:8]);
    rates1[6*k+:6]<=rate(op0[8*k+:8],key_rate_product[7:3]);
   end
   base2<=modes[0]  ?  {6'b0,fixed1}:quotient_product+{23'b0,remainder_div100[43:29]};
   detune2<=detune1;half2<=half1;
   base3<=!modes[1] && half2  ?  base2>>1:base2;
   detune3<=detune2;
   detuned4<=base3*detune3;
   fcw5<=detuned4[58:20];
   fcw6<=fcw5;
   // Fixed-mode f < 2^30. The floor reciprocal underestimates by less than
   // 1/3125 on that domain, preserving ceil(53*f/3125) including multiples.
   correction6<=fcw5[29:0]*35'd18647717207+65'd1099511627775;
   level2<=level1;curve2<=curve1;
   adjustment2<=adjustment_product*9'd329;
   clipped_level3<=clipped_level;
   vel2<=vel1;vel3<=vel2;
   levels2<=levels1;levels3<=levels2;levels4<=levels3;
   rates2<=rates1;rates3<=rates2;rates4<=rates3;rates5<=rates4;rates6<=rates5;
   key_level4<=velocity_level<0  ?  13'd0:velocity_level[12:0];
   max_key_level4<={max_velocity_base,5'b0};
   max_env01_4<=levels3[7:0]>levels3[15:8] ? levels3[7:0]:levels3[15:8];
   max_env23_4<=levels3[23:16]>levels3[31:24] ? levels3[23:16]:levels3[31:24];
   peak_target5<=target(max_env01_4>max_env23_4 ? max_env01_4:max_env23_4,max_key_level4);
   peak_target6<=peak_target5;
   for(k=0;k<4;k=k+1)targets5[13*k+:13]<=target(levels4[8*k+:8],key_level4);
   targets6<=targets5;
   carrier_peak<=operator_peak;
   peak_valid<=op_valid && flags[2:0]==3'd4;
   last_peak<=op_valid && op_index==5;
   if(peak_valid)peak_sum<=peak_sum+{2'b0,carrier_peak};
   case(state)
    IDLE,COMPLETE:if(start)begin
     patch_q<=patch;key_q<=key;velocity_q<=velocity;
     read_index<=0;peak_sum<=0;state<=READ;
    end
    READ:begin
     if(read_index!=0)payload[128*captured_block+:128]<=ram_data;
     read_index<=read_index+1'b1;
     if(read_index==8)begin issue<=0;state<=ISSUE;end
    end
    ISSUE:begin
     note<=shifted_note<0  ?  7'd0:shifted_note>127  ?  7'd127:shifted_note[6:0];
     if(issue==5)state<=DRAIN;
     else issue<=issue+1'b1;
    end
    DRAIN:if(last_peak)state<=FINALIZE;
    FINALIZE:begin
     // Use the loudest safe gain for this preset and key at any velocity.
     // Encoding is {fraction, exponent}: (1 + fraction/4) * 2^exponent.
     // Floor thresholds satisfy peak_sum * gain * VOICES <= 8388000 * 1024.
     boost<=peak_sum<=(PEAK_BUDGET*4/(VOICES*32)) ? 4'h3: // 8x
            peak_sum<=(PEAK_BUDGET*4/(VOICES*28)) ? 4'he: // 7x
            peak_sum<=(PEAK_BUDGET*4/(VOICES*24)) ? 4'ha: // 6x
            peak_sum<=(PEAK_BUDGET*4/(VOICES*20)) ? 4'h6: // 5x
            peak_sum<=(PEAK_BUDGET*4/(VOICES*16)) ? 4'h2: // 4x
            peak_sum<=(PEAK_BUDGET*4/(VOICES*14)) ? 4'hd: // 3.5x
            peak_sum<=(PEAK_BUDGET*4/(VOICES*12)) ? 4'h9: // 3x
            peak_sum<=(PEAK_BUDGET*4/(VOICES*10)) ? 4'h5: // 2.5x
            peak_sum<=(PEAK_BUDGET*4/(VOICES*8)) ? 4'h1:4'h0;
     state<=COMPLETE;
    end
    default:state<=IDLE;
   endcase
  end
 end
endmodule
`default_nettype wire
