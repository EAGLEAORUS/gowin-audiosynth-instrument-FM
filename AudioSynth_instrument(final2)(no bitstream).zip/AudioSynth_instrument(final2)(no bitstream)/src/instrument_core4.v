`default_nettype none
// Algorithms 5 (EP) and 31 (Celesta), frozen integer models. One shared multi-cycle datapath, 24 independent OP states.
// Dynamic state uses synchronous RAM, read and write on different states.
// ROM pairs use one synchronous read port each.
// MIX_SHIFT=2: supplied solo /8; production four-voice MIX_SHIFT=4: fixed /32.
module instrument_core4 #(parameter integer MIX_SHIFT=4,parameter integer PITCH_ENABLE=0)(
 input wire clk,rst_n,sample_tick,input wire [3:0] note_on,note_off,
 input wire [6:0] note,velocity,
 output reg signed [23:0] pcm,output reg pcm_valid,
 output reg [3:0] busy,gate,output wire [3:0] releasing,
 output reg [31:0] deadline_miss,clip_count,range_errors,
 output reg [15:0] last_cycles,output reg [127:0] voice_raw,output wire idle,
 input wire [23:0] pitch_ratio,input wire patch_select,output wire signed [32:0] ep_mix,cel_mix
);
 reg [5:0] state;
 assign idle=state==0;
 reg [1:0] v;reg [2:0] op;
 wire [4:0] ix=({3'd0,v}<<2)+({3'd0,v}<<1)+{2'd0,op};
 reg [3:0] pending_on,pending_off,start_on,down;
 reg [3:0] pending_patch,run_patch,initialized,cold_on;
 reg [5:0] finished[0:3];
 // 24 records, one synchronous read and one write. Uninitialized records are
 // never consumed: cold_on initializes all fields on the first note.
 reg [155:0] op_mem[0:31] /* synthesis syn_ramstyle="block_ram" */;
 reg [155:0] op_q;

 reg [6:0] pending_note[0:3],pending_vel[0:3],run_note[0:3],run_vel[0:3];
 reg [5:0] block_pos[0:3];reg [3:0] run_off;
 reg [31:0] phase,fcw;
 // Base FCW includes the factory ratio/detune. Bend changes only its step;
 // one ratio snapshot serves every OP/voice in the current audio frame.
 reg [23:0] frame_ratio;
 // Radix-8 shift/add avoids Gowin's multi-DSP wide-product packing. Eight
 // registered iterations, shared by all 24 OPs; no truncated DSP cascade.
 reg [55:0] pitch_one,pitch_three,pitch_five,pitch_seven,pitch_product;
 reg [23:0] pitch_digits;
 reg [2:0] pitch_digit_index;
 reg [32:0] pitch_rounded;
 reg pitch_overflow;
 reg [55:0] pitch_term;
 reg [31:0] pitch_step;
 always @*case(pitch_digits[2:0])
  0:pitch_term=0;1:pitch_term=pitch_one;2:pitch_term=pitch_one<<1;
  3:pitch_term=pitch_three;4:pitch_term=pitch_one<<2;
  5:pitch_term=pitch_five;6:pitch_term=pitch_three<<1;default:pitch_term=pitch_seven;
 endcase
 reg signed [31:0] level,target0,target1;
 reg [31:0] inc0,inc1,inc2,inc3;
 reg [2:0] stage;
 reg [23:0] endpoint;reg signed [31:0] current_gain,delta_gain;
 reg silent_block;
 reg signed [27:0] fb0[0:3],fb1[0:3];
 reg signed [27:0] branch;
 reg signed [32:0] mix,mix_ep,mix_cel;reg signed [31:0] raw;
 assign ep_mix=mix_ep;assign cel_mix=mix_cel;
 reg [15:0] cycles;
 assign releasing=busy & ~gate;
 wire [172:0] config_q,ep_config_q,cel_config_q;
 wire [6:0] cel_note=run_note[v]+7'd12;
 instrument_ep_config config_rom(clk,{run_note[v],op},ep_config_q);
 instrument_celesta_config cel_config(clk,{cel_note,op},cel_config_q);
 assign config_q=run_patch[v]?cel_config_q:ep_config_q;
 wire [7:0] vel_value;
 FM6_velocity_lut velocity_rom(run_vel[v][6:1],vel_value);
 reg signed [15:0] velocity_adjust;
 reg signed [31:0] outlevel;
 reg [3:0] sensitivity;
 always @* if(run_patch[v])case(op)
  0,1:sensitivity=7;2:sensitivity=0;default:sensitivity=3;
 endcase
 else case(op)
  0,2:sensitivity=6;4:sensitivity=7;3,5:sensitivity=2;default:sensitivity=0;
 endcase
 reg signed [31:0] eg_target,eg_base;
 reg [31:0] eg_inc;
 reg [2:0] eg_stage;
 reg signed [39:0] eg_product;
 reg signed [40:0] eg_candidate;
 reg signed [31:0] eg_next;
 reg [2:0] stage_next;
 reg signed [5:0] eg_factor;
 wire [47:0] exp_q;
 FM6_exp_pairs exp_rom(clk,eg_next[23:14],exp_q);
 // exp2[i+1]-exp2[i] is positive and <=5677 in this immutable ROM.
 // Register the 13-bit difference before multiplication. In Gowin 1.9.12.03
 // the former (upper-lower)*fraction expression mapped to a DSP subtract/
 // multiply with a spurious bit24 carry, despite matching in RTL simulation.
 reg [12:0] exp_diff;
 reg [26:0] exp_product;
 reg [24:0] mantissa;
 reg [23:0] new_gain;
 reg signed [31:0] dg;
 reg [31:0] pm;
 wire [35:0] sine_q;
 FM6_sine_pairs sine_rom(clk,pm[31:20],sine_q);
 reg signed [18:0] sine_diff;
 reg signed [39:0] sine_product;
 reg signed [18:0] wave;
 reg signed [24:0] op_gain;
 reg signed [43:0] op_product;
 reg signed [27:0] result;
 reg signed [28:0] feedback_sum;
 reg signed [32:0] scaled_mix;
 wire [13:0] sin_log;
 wire [9:0] log_index=pm[22]?~pm[21:12]:pm[21:12];
 instrument_sin_log log_rom(clk,log_index,sin_log);
 reg [15:0] log_env;
 wire [11:0] sin_exp;
 instrument_sin_exp anti_log_rom(clk,~log_env[9:0],sin_exp);
 reg [12:0] exp_magnitude;
 wire [23:0] cel_g1=endpoint==0?24'd16383:endpoint;
 // PCM16 saturation occurs per voice, before mixing, exactly as MATLAB.
 reg signed [15:0] cel_pcm16;

 always @(posedge clk)begin
  if(rst_n && state==26)op_mem[ix]<={
   (run_patch[v]?{8'd0,phase[23:0]+pitch_step[23:0]}:phase+pitch_step),
   level,stage,endpoint,current_gain,delta_gain,silent_block};
  else op_q<=op_mem[ix];
 end
 integer i;
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=0;v<=0;op<=0;pcm<=0;pcm_valid<=0;busy<=0;gate<=0;down<=0;
   pending_on<=0;pending_off<=0;start_on<=0;run_off<=0;pending_patch<=0;run_patch<=0;initialized<=0;cold_on<=0;
   frame_ratio<=24'd4194304;pitch_one<=0;pitch_three<=0;pitch_five<=0;pitch_seven<=0;
   pitch_product<=0;pitch_digits<=0;pitch_digit_index<=0;pitch_rounded<=0;pitch_overflow<=0;pitch_step<=0;
   deadline_miss<=0;clip_count<=0;range_errors<=0;cycles<=0;last_cycles<=0;voice_raw<=0;mix<=0;mix_ep<=0;mix_cel<=0;raw<=0;branch<=0;
   for(i=0;i<4;i=i+1)begin block_pos[i]<=0;pending_note[i]<=0;pending_vel[i]<=0;run_note[i]<=0;run_vel[i]<=0;fb0[i]<=0;fb1[i]<=0;finished[i]<=0;end
   phase<=0;fcw<=0;level<=0;stage<=0;endpoint<=0;current_gain<=0;delta_gain<=0;silent_block<=1;
   target0<=0;target1<=0;inc0<=0;inc1<=0;inc2<=0;inc3<=0;

  end else begin
   pcm_valid<=0;
   if(state!=0)cycles<=cycles+1'b1;
   if(sample_tick && state!=0)deadline_miss<=deadline_miss+1'b1;
   case(state)
    0:if(sample_tick)begin
     frame_ratio<=pitch_ratio;
     start_on<=pending_on;run_off<=pending_off;pending_on<=0;pending_off<=0;
     for(i=0;i<4;i=i+1)begin
      if(pending_on[i])begin
       // Celesta reuse preserves phase/gain/feedback (factory key_sync=0).
       // Retriggers on the same Celesta slot wait for its local 64-sample boundary.
       if(pending_patch[i] && run_patch[i] && initialized[i] && block_pos[i]!=0)begin
        pending_on[i]<=1;start_on[i]<=0;
        if(pending_off[i])pending_off[i]<=1;
       end else begin
        busy[i]<=1;
        cold_on[i]<=!initialized[i] || pending_patch[i]!=run_patch[i] || !pending_patch[i];
        run_patch[i]<=pending_patch[i];initialized[i]<=1;finished[i]<=0;
        run_note[i]<=pending_note[i];run_vel[i]<=pending_vel[i];block_pos[i]<=0;
        if(!pending_patch[i] || !run_patch[i] || !initialized[i])begin fb0[i]<=0;fb1[i]<=0;end
        down[i]<=!pending_off[i];
       end
      end
     end
     v<=0;op<=0;mix<=0;mix_ep<=0;mix_cel<=0;raw<=0;cycles<=0;state<=1;
    end
    1:begin // Voice boundary: only local block boundary applies queued Note Off.
     if(!busy[v] && !start_on[v])begin
      voice_raw[v*32+:32]<=0;
      if(v==3)state<=30;else begin v<=v+1'b1;state<=1;end
     end else begin
      if(run_off[v])down[v]<=0;
      raw<=0;op<=0;state<=2;
     end
    end
    2:state<=3; // Configuration ROM read (synchronous).
    3:begin
     {phase,level,stage,endpoint,current_gain,delta_gain,silent_block}<=op_q;
     velocity_adjust<=($signed({1'b0,sensitivity})*($signed({1'b0,vel_value})-16'sd239)+16'sd7)>>>3;
     state<=4;
    end
    4:begin
     outlevel<=$signed({1'b0,config_q[172:160]})+($signed(velocity_adjust)<<<4);
     fcw<=config_q[31:0];inc3<=config_q[63:32];inc2<=config_q[95:64];inc1<=config_q[127:96];inc0<=config_q[159:128];
     if(start_on[v])begin
      level<=0;stage<=0;
      if(cold_on[v])begin phase<=0;endpoint<=0;current_gain<=0;delta_gain<=0;silent_block<=1;end
     end
     state<=5;
    end
    5:begin
     // This patch's L1=99, L2=95 (OP2/1=75), L3=L4=0.
     target0<=((outlevel<0?32'sd0:outlevel)-32'sd224)<<<16;
     target1<=((outlevel<0?32'sd0:outlevel)-(run_patch[v]?32'sd800:(op>=4?32'sd992:32'sd352)))<<<16;
     // Clamp the logarithmic floor, including very soft velocity settings.
     if(outlevel-32'sd224<16)target0<=32'sd1048576;
     if(outlevel-(run_patch[v]?32'sd800:(op>=4?32'sd992:32'sd352))<16)target1<=32'sd1048576;
     state<=33;
    end
    33:begin
     if(!PITCH_ENABLE || frame_ratio==24'd4194304)begin pitch_step<=fcw;state<=6;end
     else begin
      pitch_one<={24'd0,fcw};
      pitch_three<=({24'd0,fcw}<<1)+{24'd0,fcw};
      pitch_five<=({24'd0,fcw}<<2)+{24'd0,fcw};
      pitch_seven<=({24'd0,fcw}<<3)-{24'd0,fcw};
      pitch_digits<=frame_ratio;pitch_product<=0;pitch_digit_index<=0;state<=34;
     end
    end
    34:begin
     pitch_product<=pitch_product+pitch_term;
     pitch_one<=pitch_one<<3;pitch_three<=pitch_three<<3;pitch_five<=pitch_five<<3;pitch_seven<=pitch_seven<<3;
     pitch_digits<=pitch_digits>>3;pitch_digit_index<=pitch_digit_index+1'b1;
     if(pitch_digit_index==7)state<=35;
    end
    35:begin
     pitch_rounded<={1'b0,pitch_product[53:22]}+{32'd0,pitch_product[21]};
     pitch_overflow<=|pitch_product[55:54];state<=37;
    end
    37:begin
     pitch_step<=pitch_overflow || pitch_rounded[32]?32'hffffffff:pitch_rounded[31:0];state<=6;
    end
    6:begin
     if(block_pos[v]==0)begin
      eg_stage<=(!down[v]?3'd3:stage);
      if(stage==4 && !start_on[v])eg_stage<=4;
      state<=7;
     end else begin
      current_gain<=current_gain+delta_gain;state<=18;
     end
    end
    7:begin
     eg_base<=level;eg_target<=32'sd1048576;eg_inc<=inc3;
     case(eg_stage)
      0:begin eg_target<=target0;eg_inc<=inc0;end
      1:begin eg_target<=target1;eg_inc<=inc1;end
      2:begin eg_target<=32'sd1048576;eg_inc<=inc2;end
      default:begin end
     endcase
     state<=8;
    end
    8:begin
     if(eg_target>eg_base && eg_base<32'sd112459776)eg_base<=32'sd112459776;
     state<=9;
    end
    9:begin eg_factor<=(32'sd285212672-eg_base)>>>24;state<=10;end
    10:begin eg_product<=eg_factor*$signed({1'b0,eg_inc});state<=11;end
    11:begin
     if(eg_target>level)eg_candidate<=$signed(eg_base)+eg_product;
     else eg_candidate<=$signed(eg_base)-$signed({1'b0,eg_inc});
     state<=12;
    end
    12:begin
     eg_next<=eg_candidate[31:0];stage_next<=eg_stage;
     if(eg_stage==4 || (run_patch[v] && eg_stage==3 && down[v]))eg_next<=level;
     else if((eg_target>level && eg_candidate>=eg_target) || (eg_target<=level && eg_candidate<=eg_target))begin
      eg_next<=eg_target;
      if(eg_stage<2 || eg_stage==3 || (run_patch[v] && eg_stage==2))stage_next<=eg_stage+1'b1;
     end
     state<=13;
    end
    13:begin level<=eg_next;stage<=stage_next;state<=run_patch[v]?38:14;end // exp ROM read
    14:begin exp_diff<=exp_q[47:24]-exp_q[23:0];state<=36;end
    36:begin exp_product<=exp_diff*eg_next[13:0];state<=15;end
    15:begin mantissa<={1'b0,exp_q[23:0]}+(exp_product>>14);state<=16;end
    16:begin
     if(eg_next[31:24]>=14)new_gain<=mantissa<<(eg_next[31:24]-8'd14);
     else new_gain<=mantissa>>(8'd14-eg_next[31:24]);
     state<=17;
    end
    38:begin new_gain<=24'd16384-(eg_next>>>14);state<=17;end
    17:begin
     if(run_patch[v])begin
      dg<=($signed({1'b0,new_gain})-$signed({1'b0,cel_g1})+32'sd32)>>>6;
      silent_block<=new_gain>16284 && cel_g1>16284;
     end else begin
     dg<=($signed({1'b0,new_gain})-$signed({1'b0,endpoint})+32'sd32)>>>6;
     silent_block<=new_gain<280 && endpoint<280;end state<=31;
    end
    31:begin
     delta_gain<=dg;current_gain<=$signed({1'b0,(run_patch[v]?cel_g1:endpoint)})+dg;endpoint<=new_gain;state<=18;
    end
    18:begin
     feedback_sum<=$signed({fb0[v][27],fb0[v]})+$signed({fb1[v][27],fb1[v]});state<=19;
    end
    19:begin
     if(run_patch[v])begin
      if(op==0)pm<=$signed({8'd0,phase[23:0]})+(feedback_sum>>>4);
      else if(op==1)pm<=$signed({8'd0,phase[23:0]})+branch;
      else pm<={8'd0,phase[23:0]};
     end else if(op==0)pm<=phase+((feedback_sum>>>3)<<<10);
     else if(op[0])pm<=phase+(branch<<<10);
     else pm<=phase;
     op_gain<=silent_block?25'sd0:$signed({1'b0,current_gain[23:0]});
     state<=20;
    end
    20:state<=run_patch[v]?39:21; // sine ROM read
    39:begin log_env<=({pm[23],15'd0}|{2'd0,sin_log})+current_gain[15:0];state<=40;end
    40:state<=41;
    41:begin exp_magnitude<=({1'b0,1'b1,sin_exp})>>log_env[14:10];state<=42;end
    42:begin
     if(silent_block)result<=0;
     else if(log_env[15])result<=(-$signed({1'b0,exp_magnitude})-26'sd1)<<<13;
     else result<=$signed({1'b0,exp_magnitude})<<<13;
     state<=26;
    end
    21:begin sine_diff<=$signed({sine_q[35],sine_q[35:18]})-$signed({sine_q[17],sine_q[17:0]});state<=22;end
    22:begin sine_product<=sine_diff*$signed({1'b0,pm[19:0]});state<=23;end
    23:begin wave<=$signed({sine_q[17],sine_q[17:0]})+(sine_product>>>20);state<=24;end
    24:begin op_product<=wave*op_gain;state<=25;end
    25:begin
     result<=op_product>>>17;
     if((op_product>>>17)>44'sd33554431 || (op_product>>>17)<-44'sd33554432)range_errors<=range_errors+1'b1;
     state<=26;
    end
    26:begin

     if(op==0 || (!run_patch[v] && !op[0]))branch<=result;
     if((run_patch[v] && op!=0) || (!run_patch[v] && op[0]))raw<=raw+$signed(result);
     finished[v][op]<=stage==4 && (!run_patch[v] || endpoint>16284);
     if(op==0 && (!run_patch[v] || !silent_block))begin fb0[v]<=fb1[v];fb1[v]<=result;end
     if(op==5)state<=27;else begin op<=op+1'b1;state<=2;end
    end
    27:begin
     voice_raw[v*32+:32]<=raw;block_pos[v]<=block_pos[v]+1'b1;
     // Every OP has reached R4/L4 before recycling the slot.
     if(!gate[v] && !pending_on[v] && (&finished[v]) && (!run_patch[v] || block_pos[v]==63))busy[v]<=0;
     state<=43;
    end
    43:begin
     // EP unchanged raw/16; Celesta Plugin PCM16 then preview gain1/2.
     if((raw>>>4)>=28'sd16777216)cel_pcm16<=16'sh7fff;
     else if((raw>>>4)< -28'sd16777216)cel_pcm16<=16'sh8000;
     else cel_pcm16<=raw>>>13;
     state<=44;
    end
    44:begin
     if(run_patch[v])begin mix<=mix+($signed(cel_pcm16)<<<7);mix_cel<=mix_cel+($signed(cel_pcm16)<<<7);end
     else begin mix<=mix+($signed(raw)>>>MIX_SHIFT);mix_ep<=mix_ep+($signed(raw)>>>MIX_SHIFT);end
     if(v==3)state<=30;else begin v<=v+1'b1;state<=1;end
    end
    30:begin scaled_mix<=mix;state<=32;end
    32:begin
     if(scaled_mix>33'sd8388607)begin pcm<=24'sh7fffff;clip_count<=clip_count+1'b1;end
     else if(scaled_mix< -33'sd8388608)begin pcm<=24'sh800000;clip_count<=clip_count+1'b1;end
     else pcm<=scaled_mix[23:0];
     pcm_valid<=1;last_cycles<=cycles;state<=0;
    end
    default:state<=0;
   endcase
   // Event capture wins a simultaneous boundary; events apply next sample.
   for(i=0;i<4;i=i+1)begin
    if(note_on[i])begin
     pending_on[i]<=1;pending_off[i]<=0;pending_note[i]<=note;pending_vel[i]<=velocity;pending_patch[i]<=patch_select;busy[i]<=1;gate[i]<=1;
    end else if(note_off[i])begin pending_off[i]<=1;gate[i]<=0;end
   end
   // A release waits for this voice's next local block. Retain it until then.
   for(i=0;i<4;i=i+1)begin
    if(state==0 && sample_tick && pending_off[i] && !pending_on[i] && block_pos[i]!=0)pending_off[i]<=1;
   end
  end
 end
endmodule
`default_nettype wire
