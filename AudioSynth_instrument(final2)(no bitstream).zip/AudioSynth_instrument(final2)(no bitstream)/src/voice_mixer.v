`default_nettype none
// Fixed headroom: four full-velocity voices stay within the original mono
// output ceiling. No voice-count-dependent gain changes or limiter pumping.
module voice_mixer #(parameter integer GAIN_SHIFT=2)(
 input wire clk,rst_n,sample_tick,input wire [95:0] voices,
 output reg signed [23:0] pcm,output reg [31:0] clip_count);
 wire signed [25:0] a={{2{voices[23]}},voices[23:0]};
 wire signed [25:0] b={{2{voices[47]}},voices[47:24]};
 wire signed [25:0] c={{2{voices[71]}},voices[71:48]};
 wire signed [25:0] d={{2{voices[95]}},voices[95:72]};
 wire signed [25:0] sum=a+b+c+d;
 // Widen BEFORE abs/rounding: -4*2^23 is the 26-bit negative extreme.
 wire signed [26:0] wide_sum={sum[25],sum};
 localparam signed [26:0] ROUND_BIAS=(GAIN_SHIFT>0)?(27'sd1<<(GAIN_SHIFT-1)):27'sd0;
 wire signed [26:0] scaled=(wide_sum>=0)?
  ((wide_sum+ROUND_BIAS)>>>GAIN_SHIFT):
  -(((-wide_sum)+ROUND_BIAS)>>>GAIN_SHIFT);
 wire high_clip=scaled>27'sd8388607,low_clip=scaled< -27'sd8388608;
 always @(posedge clk)begin
  if(!rst_n)begin pcm<=0;clip_count<=0;end
  else begin
   if(high_clip)pcm<=24'sh7fffff;
   else if(low_clip)pcm<=24'sh800000;
   else pcm<=scaled[23:0];
   if(sample_tick && (high_clip || low_clip))clip_count<=clip_count+32'd1;
  end
 end
endmodule
`default_nettype wire
