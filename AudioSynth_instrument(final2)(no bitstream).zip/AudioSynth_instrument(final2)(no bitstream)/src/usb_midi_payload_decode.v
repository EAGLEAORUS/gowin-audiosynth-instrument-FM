`default_nettype none
// INPUT IS A COMMITTED USB ENDPOINT PAYLOAD, not D+/D- or a MIDI byte stream.
// Host must check CRC/PID/toggle and remove CRC/PID before this boundary.
// Byte zero is payload[7:0]. Maximum 64 bytes; complete events never span packets.
module usb_midi_payload_decode(
 input wire clk,input wire rst_n,
 input wire packet_valid,output wire packet_pop,input wire [518:0] packet,
 output reg event_push,output reg [39:0] event_data,
 output reg [31:0] malformed_count,output reg [31:0] unsupported_count
);
 reg busy;
 reg [511:0] data;
 reg [6:0] remaining;
 wire [3:0] cin=data[3:0];
 wire [7:0] status=data[15:8];
 wire [7:0] d1=data[23:16],d2=data[31:24];
 reg [3:0] kind;
 reg [1:0] nbytes;
 reg good,skip;
 assign packet_pop=packet_valid && !busy;
 always @* begin
  kind=0;nbytes=0;good=0;skip=0;
  case(cin)
   4'h8:begin kind=1;nbytes=3;good=(status[7:4]==8 && !d1[7] && !d2[7]);end
   4'h9:begin kind=(d2==0)?4'd1:4'd2;nbytes=3;good=(status[7:4]==9 && !d1[7] && !d2[7]);end
   4'ha:begin kind=6;nbytes=3;good=(status[7:4]==10 && !d1[7] && !d2[7]);end
   4'hb:begin kind=3;nbytes=3;good=(status[7:4]==11 && !d1[7] && !d2[7]);end
   4'hc:begin kind=4;nbytes=2;good=(status[7:4]==12 && !d1[7]);end
   4'hd:begin kind=7;nbytes=2;good=(status[7:4]==13 && !d1[7]);end
   4'he:begin kind=5;nbytes=3;good=(status[7:4]==14 && !d1[7] && !d2[7]);end
   // System common/realtime. SysEx is deliberately RAW-only, counted unsupported.
   4'h2:begin kind=8;nbytes=2;good=((status==8'hf1||status==8'hf3)&&!d1[7]);end
   4'h3:begin kind=8;nbytes=3;good=(status==8'hf2&&!d1[7]&&!d2[7]);end
   4'h5:begin kind=8;nbytes=1;good=(status==8'hf6);skip=(status==8'hf7);end
   4'hf:begin kind=8;nbytes=1;good=(status>=8'hf8 && status!=8'hf9 && status!=8'hfd);end
   4'h4,4'h6,4'h7:skip=1;
   4'h0:skip=(data[31:0]==0);
   default:skip=1;
  endcase
 end
 always @(posedge clk) begin
  if(!rst_n) begin busy<=0;remaining<=0;data<=0;event_push<=0;event_data<=0;malformed_count<=0;unsupported_count<=0;end
  else begin
   event_push<=0;
   if(packet_pop) begin
    if(packet[518:512]>64 || packet[513:512]!=0) begin
     if(malformed_count!=32'hffffffff) malformed_count<=malformed_count+1'b1;
    end else if(packet[518:512]!=0) begin
     data<=packet[511:0];remaining<=packet[518:512];busy<=1;
    end
   end else if(busy) begin
    if(good) begin
     event_push<=1;
     event_data<={data[7:4],cin,kind,(kind==8?4'd0:status[3:0]),
                  (nbytes>=2?d1[6:0]:7'd0),(nbytes==3?d2[6:0]:7'd0),nbytes,status};
    end else if(skip) begin
     if(data[31:0]!=0 && unsupported_count!=32'hffffffff) unsupported_count<=unsupported_count+1'b1;
    end else if(malformed_count!=32'hffffffff) malformed_count<=malformed_count+1'b1;
    data<=data>>32;remaining<=remaining-7'd4;
    if(remaining==4) busy<=0;
   end
  end
 end
endmodule
`default_nettype wire
