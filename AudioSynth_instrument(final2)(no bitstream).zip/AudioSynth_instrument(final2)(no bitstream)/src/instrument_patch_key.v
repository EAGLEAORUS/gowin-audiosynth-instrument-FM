`default_nettype none
// K1 (user-confirmed) active LOW, AB13, internal pull-up.
// Dock31004 Rev1.4 p7/p9: S2 / USER_BUTTON1 / EX_KEY.1 / AB13.
// Active low, no external pull-up: CST enables internal pull-up. 10ms debounce.
module instrument_patch_key #(parameter integer STABLE_CYCLES=500000, UI_ENABLE=0)(
 input wire clk,rst_n,k2_n,output reg [2:0] patch_select,
 input wire ui_set,input wire [2:0] ui_patch);
 (* syn_preserve=1 *) reg key_meta,key_sync;
 reg stable;reg [18:0] count;
 always @(posedge clk)begin
  if(!rst_n)begin key_meta<=1;key_sync<=1;stable<=1;count<=0;patch_select<=0;end
  else begin
   key_meta<=k2_n;key_sync<=key_meta;
   if(key_sync==stable)count<=0;
   else if(count==STABLE_CYCLES-1)begin
    count<=0;stable<=key_sync;
    if(!key_sync)patch_select<=patch_select==3'd4 ? 3'd0 : patch_select+3'd1;
   end else count<=count+1'b1;
   if(UI_ENABLE && ui_set && ui_patch<=3'd4)patch_select<=ui_patch;
  end
 end
endmodule
`default_nettype wire
