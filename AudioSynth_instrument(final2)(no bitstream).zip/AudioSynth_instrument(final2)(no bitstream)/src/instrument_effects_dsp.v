`default_nettype none
// HQ Q4.20 states, Q1.17 coefficients. One registered 26x26 lane supports
// the wider LFO depth product too. Signed 56-bit sums cover <2^50 safely.
module instrument_effects_dsp(
 input wire clk,rst_n,input wire input_valid,input wire signed [23:0] input_pcm,
 input wire [2:0] enable,input wire bypass,
 input wire [17:0] delay_mix,delay_feedback,delay_lp,chorus_mix,reverb_mix,
 input wire [23:0] chorus_depth,
 input wire [17:0] reverb_g0,reverb_g1,reverb_g2,reverb_g3,input_gain,allpass_g,master_gain,
 output wire output_valid,output wire signed [23:0] output_pcm,
 output reg ready,output wire busy,output reg [15:0] last_cycles,
 output reg [31:0] overruns,state_saturations,wet_saturations,output_clips
);
 reg [7:0] state,ret_state;
 reg [14:0] clear_addr,raddr,waddr;reg wen;
 // Depth-banked lossless RAM: avoid rounding 24541 words up to 32768.
 // All three banks read concurrently; registered selection retains one-cycle
 // read latency. The 35 unused physical words in bank2 are never addressed.
 reg signed [23:0] memory0[0:8191],memory1[0:8191],memory2[0:8191];
 reg signed [23:0] q0,q1,q2,wdata;reg [1:0] read_bank;
 wire signed [23:0] ram_q=read_bank==0 ? q0:(read_bank==1 ? q1:q2);
 wire [14:0] write_address=ready ? waddr:clear_addr;
 wire write_enable=!ready || wen;
 wire [23:0] write_data=ready ? wdata:24'd0;
 always @(posedge clk)begin
  q0<=memory0[raddr[12:0]];q1<=memory1[raddr[12:0]];q2<=memory2[raddr[12:0]];
  read_bank<=raddr[14:13];
  if(write_enable)case(write_address[14:13])
   0:memory0[write_address[12:0]]<=write_data;
   1:memory1[write_address[12:0]]<=write_data;
   2:memory2[write_address[12:0]]<=write_data;
   default:begin end
  endcase
 end
 reg signed [23:0] x,xc,xr,v,q,a,b,wet,lfo,u,xap,ay,dlp,lp0,lp1,lp2,lp3;
 reg signed [31:0] sum,value,rounded;reg [31:0] position,phase;
 reg [13:0] dptr;reg [9:0] cptr,ca,pptr,ap0,ap1;reg [10:0] p0,p1,p2,p3;
 reg [15:0] mu,cycles;
 reg [2:0] en;
 reg [17:0] dm,dg,da,cm,rm,g0,g1,g2,g3,gin,gap,master;reg [23:0] dep;
 reg [7:0] laddr;wire [15:0] lq;reg signed [15:0] s1,s2;
 instrument_effects_lfo lfo_rom(clk,laddr,lq);
 reg signed [25:0] ma,mb;reg signed [51:0] product;
 reg signed [55:0] addend,accumulator;
 reg [5:0] rshift;reg guard_zero,wide_result;
 reg signed [23:0] guard_ref;reg signed [31:0] clipped;
 reg signed [23:0] processed;reg processed_valid;
 wire pass=bypass || enable==0 || !ready;
 assign output_valid=(input_valid && pass) || processed_valid;
 assign output_pcm=processed_valid ? processed:input_pcm;
 assign busy=state!=0;
 function signed [25:0] sx;input signed [23:0] z;begin sx={{2{z[23]}},z};end endfunction
 function signed [55:0] ex;input signed [23:0] z;begin ex={{32{z[23]}},z};end endfunction
 function signed [55:0] ex16;input signed [15:0] z;begin ex16={{40{z[15]}},z};end endfunction
 function signed [23:0] sat24;input signed [55:0] z;begin
  if(z>56'sd8388607)sat24=24'sh7fffff;else if(z< -56'sd8388608)sat24=24'sh800000;else sat24=z[23:0];
 end endfunction
 // Arithmetic floor plus an explicit half test implements symmetric ties.
 function signed [31:0] round56;input signed [55:0] z;input [5:0] s;
 reg signed [55:0] h;reg inc;begin h=z;inc=0;
 case(s)
  1:begin h=z>>>1;inc=z[0] && !z[55];end
  2:begin h=z>>>2;inc=z[1:0]>2 || (z[1:0]==2 && !z[55]);end
  3:begin h=z>>>3;inc=z[2:0]>4 || (z[2:0]==4 && !z[55]);end
  16:begin h=z>>>16;inc=z[15:0]>32768 || (z[15:0]==32768 && !z[55]);end
  17:begin h=z>>>17;inc=z[16:0]>65536 || (z[16:0]==65536 && !z[55]);end
  23:begin h=z>>>23;inc=z[22:0]>4194304 || (z[22:0]==4194304 && !z[55]);end
  default:begin end
 endcase round56=h+inc;end endfunction
 function [31:0] magnitude;input signed [31:0] z;begin magnitude=z<0 ? -z:z;end endfunction
 wire signed [23:0] input_q=sat24({{32{input_pcm[23]}},input_pcm}>>>3);
 // Input rounding (rather than truncation) is completed in state 1 below.
 always @(posedge clk)begin
  if(!rst_n)begin
   ready<=0;clear_addr<=0;state<=0;wen<=0;processed_valid<=0;last_cycles<=0;cycles<=0;
   overruns<=0;state_saturations<=0;wet_saturations<=0;output_clips<=0;
   dptr<=0;cptr<=0;pptr<=0;p0<=0;p1<=0;p2<=0;p3<=0;ap0<=0;ap1<=0;phase<=0;
   dlp<=0;lp0<=0;lp1<=0;lp2<=0;lp3<=0;raddr<=0;
  end else begin
   wen<=0;processed_valid<=0;
   if(!ready)begin
    if(clear_addr==15'd24540)begin ready<=1;clear_addr<=0;end else clear_addr<=clear_addr+1'b1;
   end else if(state==0)begin
    cycles<=0;
    if(input_valid && !pass)begin x<=round56({{32{input_pcm[23]}},input_pcm},6'd3);en<=enable;dm<=delay_mix;dg<=delay_feedback;da<=delay_lp;cm<=chorus_mix;dep<=chorus_depth;rm<=reverb_mix;g0<=reverb_g0;g1<=reverb_g1;g2<=reverb_g2;g3<=reverb_g3;gin<=input_gain;gap<=allpass_g;master<=master_gain; state<=8'd2; end
   end else begin
    cycles<=cycles+1'b1;
    if(input_valid && !(&overruns))overruns<=overruns+1'b1;
    case(state)
8'd2:begin state<=en[0] ? 8'd3:8'd13; end
8'd3:begin raddr<={1'b0,(dptr+14'd1024)}; state<=8'd4; end
8'd4:begin  state<=8'd5; end
8'd5:begin v<=ram_q; state<=8'd6; end
8'd6:begin ma<=sx(dlp)-sx(v);mb<=$signed({8'd0,da});addend<=(ex(v)<<<17);rshift<=6'd17;guard_zero<=v==0;guard_ref<=dlp;wide_result<=1'b0;ret_state<=8'd7;state<=8'd240; end
8'd7:begin dlp<=value[23:0];q<=value[23:0]; state<=8'd8; end
8'd8:begin ma<=sx(q);mb<=$signed({8'd0,dg});addend<=(ex(x)<<<17);rshift<=6'd17;guard_zero<=x==0;guard_ref<=q;wide_result<=1'b0;ret_state<=8'd9;state<=8'd240; end
8'd9:begin wen<=1;waddr<={1'b0,dptr};wdata<=value[23:0]; state<=8'd10; end
8'd10:begin dptr<=dptr+1'b1; state<=8'd11; end
8'd11:begin ma<=sx(v)-sx(x);mb<=$signed({8'd0,dm});addend<=(ex(x)<<<17);rshift<=6'd17;guard_zero<=0;guard_ref<=24'sd0;wide_result<=1'b0;ret_state<=8'd12;state<=8'd240; end
8'd12:begin x<=value[23:0]; state<=8'd13; end
8'd13:begin state<=en[1] ? 8'd14:8'd37; end
8'd14:begin phase<=phase+32'd71583;xc<=x; state<=8'd15; end
8'd15:begin laddr<=phase[31:24]; state<=8'd16; end
8'd16:begin  state<=8'd17; end
8'd17:begin s1<=lq;laddr<=laddr+1'b1; state<=8'd18; end
8'd18:begin  state<=8'd19; end
8'd19:begin s2<=lq; state<=8'd20; end
8'd20:begin ma<=$signed({{10{s2[15]}},s2})-$signed({{10{s1[15]}},s1});mb<=$signed({18'd0,phase[23:16]});addend<=(ex16(s1)<<<8);rshift<=6'd0;guard_zero<=0;guard_ref<=24'sd0;wide_result<=1'b0;ret_state<=8'd21;state<=8'd240; end
8'd21:begin lfo<=value[23:0]; state<=8'd22; end
8'd22:begin ma<=sx(lfo);mb<=$signed({2'd0,dep});addend<=56'sd395824185999360;rshift<=6'd23;guard_zero<=0;guard_ref<=24'sd0;wide_result<=1'b1;ret_state<=8'd23;state<=8'd240; end
8'd23:begin position<=value<32'sd31457280 ? 32'd31457280:(value>32'sd62914560 ? 32'd62914560:value); state<=8'd24; end
8'd24:begin ca<=cptr-position[25:16];mu<=position[15:0]; state<=8'd25; end
8'd25:begin raddr<=15'd16384+{5'd0,ca}; state<=8'd26; end
8'd26:begin  state<=8'd27; end
8'd27:begin a<=ram_q; state<=8'd28; end
8'd28:begin raddr<=15'd16384+{5'd0,(ca-10'd1)}; state<=8'd29; end
8'd29:begin  state<=8'd30; end
8'd30:begin b<=ram_q; state<=8'd31; end
8'd31:begin ma<=sx(b)-sx(a);mb<=$signed({10'd0,mu});addend<=(ex(a)<<<16);rshift<=6'd16;guard_zero<=0;guard_ref<=24'sd0;wide_result<=1'b0;ret_state<=8'd32;state<=8'd240; end
8'd32:begin wet<=value[23:0]; state<=8'd33; end
8'd33:begin wen<=1;waddr<=15'd16384+{5'd0,cptr};wdata<=xc; state<=8'd34; end
8'd34:begin cptr<=cptr+1'b1; state<=8'd35; end
8'd35:begin ma<=sx(wet)-sx(xc);mb<=$signed({8'd0,cm});addend<=(ex(xc)<<<17);rshift<=6'd17;guard_zero<=0;guard_ref<=24'sd0;wide_result<=1'b0;ret_state<=8'd36;state<=8'd240; end
8'd36:begin x<=value[23:0]; state<=8'd37; end
8'd37:begin state<=en[2] ? 8'd38:8'd100; end
8'd38:begin xr<=x; state<=8'd39; end
8'd39:begin raddr<=15'd17408+(pptr==10'd720 ? 10'd0:pptr+10'd1); state<=8'd40; end
8'd40:begin  state<=8'd41; end
8'd41:begin v<=ram_q; state<=8'd42; end
8'd42:begin ma<=sx(v);mb<=$signed({8'd0,gin});addend<=56'sd0;rshift<=6'd17;guard_zero<=0;guard_ref<=24'sd0;wide_result<=1'b0;ret_state<=8'd43;state<=8'd240; end
8'd43:begin u<=value[23:0];sum<=0; state<=8'd44; end
8'd44:begin wen<=1;waddr<=15'd17408+pptr;wdata<=xr; state<=8'd45; end
8'd45:begin pptr<=pptr==10'd720 ? 10'd0:pptr+10'd1; state<=8'd46; end
8'd46:begin raddr<=15'd18129+(p0==11'd1213 ? 11'd0:p0+11'd1); state<=8'd47; end
8'd47:begin  state<=8'd48; end
8'd48:begin v<=ram_q; state<=8'd49; end
8'd49:begin ma<=26'sd0;mb<=26'sd0;addend<=ex(v)+ex(lp0);rshift<=6'd1;guard_zero<=v==0;guard_ref<=lp0;wide_result<=1'b0;ret_state<=8'd50;state<=8'd240; end
8'd50:begin lp0<=value[23:0];q<=value[23:0];sum<=sum+value; state<=8'd51; end
8'd51:begin ma<=sx(q)-sx(u);mb<=$signed({8'd0,g0});addend<=(ex(u)<<<17);rshift<=6'd17;guard_zero<=u==0;guard_ref<=q;wide_result<=1'b0;ret_state<=8'd52;state<=8'd240; end
8'd52:begin wen<=1;waddr<=15'd18129+p0;wdata<=value[23:0]; state<=8'd53; end
8'd53:begin p0<=p0==11'd1213 ? 11'd0:p0+11'd1; state<=8'd54; end
8'd54:begin raddr<=15'd19343+(p1==11'd1291 ? 11'd0:p1+11'd1); state<=8'd55; end
8'd55:begin  state<=8'd56; end
8'd56:begin v<=ram_q; state<=8'd57; end
8'd57:begin ma<=26'sd0;mb<=26'sd0;addend<=ex(v)+ex(lp1);rshift<=6'd1;guard_zero<=v==0;guard_ref<=lp1;wide_result<=1'b0;ret_state<=8'd58;state<=8'd240; end
8'd58:begin lp1<=value[23:0];q<=value[23:0];sum<=sum+value; state<=8'd59; end
8'd59:begin ma<=sx(q)-sx(u);mb<=$signed({8'd0,g1});addend<=(ex(u)<<<17);rshift<=6'd17;guard_zero<=u==0;guard_ref<=q;wide_result<=1'b0;ret_state<=8'd60;state<=8'd240; end
8'd60:begin wen<=1;waddr<=15'd19343+p1;wdata<=value[23:0]; state<=8'd61; end
8'd61:begin p1<=p1==11'd1291 ? 11'd0:p1+11'd1; state<=8'd62; end
8'd62:begin raddr<=15'd20635+(p2==11'd1381 ? 11'd0:p2+11'd1); state<=8'd63; end
8'd63:begin  state<=8'd64; end
8'd64:begin v<=ram_q; state<=8'd65; end
8'd65:begin ma<=26'sd0;mb<=26'sd0;addend<=ex(v)+ex(lp2);rshift<=6'd1;guard_zero<=v==0;guard_ref<=lp2;wide_result<=1'b0;ret_state<=8'd66;state<=8'd240; end
8'd66:begin lp2<=value[23:0];q<=value[23:0];sum<=sum+value; state<=8'd67; end
8'd67:begin ma<=sx(q)-sx(u);mb<=$signed({8'd0,g2});addend<=(ex(u)<<<17);rshift<=6'd17;guard_zero<=u==0;guard_ref<=q;wide_result<=1'b0;ret_state<=8'd68;state<=8'd240; end
8'd68:begin wen<=1;waddr<=15'd20635+p2;wdata<=value[23:0]; state<=8'd69; end
8'd69:begin p2<=p2==11'd1381 ? 11'd0:p2+11'd1; state<=8'd70; end
8'd70:begin raddr<=15'd22017+(p3==11'd1471 ? 11'd0:p3+11'd1); state<=8'd71; end
8'd71:begin  state<=8'd72; end
8'd72:begin v<=ram_q; state<=8'd73; end
8'd73:begin ma<=26'sd0;mb<=26'sd0;addend<=ex(v)+ex(lp3);rshift<=6'd1;guard_zero<=v==0;guard_ref<=lp3;wide_result<=1'b0;ret_state<=8'd74;state<=8'd240; end
8'd74:begin lp3<=value[23:0];q<=value[23:0];sum<=sum+value; state<=8'd75; end
8'd75:begin ma<=sx(q)-sx(u);mb<=$signed({8'd0,g3});addend<=(ex(u)<<<17);rshift<=6'd17;guard_zero<=u==0;guard_ref<=q;wide_result<=1'b0;ret_state<=8'd76;state<=8'd240; end
8'd76:begin wen<=1;waddr<=15'd22017+p3;wdata<=value[23:0]; state<=8'd77; end
8'd77:begin p3<=p3==11'd1471 ? 11'd0:p3+11'd1; state<=8'd78; end
8'd78:begin ma<=26'sd0;mb<=26'sd0;addend<={{24{sum[31]}},sum};rshift<=6'd2;guard_zero<=0;guard_ref<=24'sd0;wide_result<=1'b0;ret_state<=8'd79;state<=8'd240; end
8'd79:begin xap<=value[23:0]; state<=8'd80; end
8'd80:begin raddr<=15'd23489+(ap0==10'd607 ? 10'd0:ap0+10'd1); state<=8'd81; end
8'd81:begin  state<=8'd82; end
8'd82:begin v<=ram_q; state<=8'd83; end
8'd83:begin ma<=-sx(xap);mb<=$signed({8'd0,gap});addend<=(ex(v)<<<17);rshift<=6'd17;guard_zero<=0;guard_ref<=24'sd0;wide_result<=1'b0;ret_state<=8'd84;state<=8'd240; end
8'd84:begin ay<=value[23:0]; state<=8'd85; end
8'd85:begin ma<=sx(ay);mb<=$signed({8'd0,gap});addend<=(ex(xap)<<<17);rshift<=6'd17;guard_zero<=xap==0;guard_ref<=ay;wide_result<=1'b0;ret_state<=8'd86;state<=8'd240; end
8'd86:begin wen<=1;waddr<=15'd23489+ap0;wdata<=value[23:0]; state<=8'd87; end
8'd87:begin ap0<=ap0==10'd607 ? 10'd0:ap0+10'd1;xap<=ay; state<=8'd88; end
8'd88:begin raddr<=15'd24097+(ap1==10'd443 ? 10'd0:ap1+10'd1); state<=8'd89; end
8'd89:begin  state<=8'd90; end
8'd90:begin v<=ram_q; state<=8'd91; end
8'd91:begin ma<=-sx(xap);mb<=$signed({8'd0,gap});addend<=(ex(v)<<<17);rshift<=6'd17;guard_zero<=0;guard_ref<=24'sd0;wide_result<=1'b0;ret_state<=8'd92;state<=8'd240; end
8'd92:begin ay<=value[23:0]; state<=8'd93; end
8'd93:begin ma<=sx(ay);mb<=$signed({8'd0,gap});addend<=(ex(xap)<<<17);rshift<=6'd17;guard_zero<=xap==0;guard_ref<=ay;wide_result<=1'b0;ret_state<=8'd94;state<=8'd240; end
8'd94:begin wen<=1;waddr<=15'd24097+ap1;wdata<=value[23:0]; state<=8'd95; end
8'd95:begin ap1<=ap1==10'd443 ? 10'd0:ap1+10'd1;xap<=ay; state<=8'd96; end
8'd96:begin ma<=26'sd0;mb<=26'sd0;addend<=(ex(xap)<<<3);rshift<=6'd0;guard_zero<=0;guard_ref<=24'sd0;wide_result<=1'b0;ret_state<=8'd97;state<=8'd240; end
8'd97:begin wet<=value[23:0]; state<=8'd98; end
8'd98:begin ma<=sx(wet)-sx(xr);mb<=$signed({8'd0,rm});addend<=(ex(xr)<<<17);rshift<=6'd17;guard_zero<=0;guard_ref<=24'sd0;wide_result<=1'b0;ret_state<=8'd99;state<=8'd240; end
8'd99:begin x<=value[23:0]; state<=8'd100; end
8'd100:begin state<=master==0 ? 8'd103:8'd101; end
8'd101:begin ma<=sx(x);mb<=$signed({8'd0,master});addend<=56'sd0;rshift<=6'd17;guard_zero<=0;guard_ref<=24'sd0;wide_result<=1'b0;ret_state<=8'd102;state<=8'd240; end
8'd102:begin x<=value[23:0]; state<=8'd103; end
8'd103:begin processed<=sat24(ex(x)<<<3);if(x>24'sd1048575 || x< -24'sd1048576)if(!(&output_clips))output_clips<=output_clips+1'b1;processed_valid<=1;last_cycles<=cycles;state<=0; end
    8'd240:begin product<=ma*mb;state<=241;end
    8'd241:begin accumulator<={{4{product[51]}},product}+addend;state<=242;end
    8'd242:begin rounded<=round56(accumulator,rshift);state<=243;end
    8'd243:begin
     clipped<=wide_result ? rounded:$signed(sat24({{24{rounded[31]}},rounded}));
     if(!wide_result && (rounded>8388607 || rounded< -8388608))begin
      if(ret_state==8'd97)begin if(!(&wet_saturations))wet_saturations<=wet_saturations+1'b1;end
      else if(!(&state_saturations))state_saturations<=state_saturations+1'b1;
     end
     state<=244;
    end
    8'd244:begin
     if(guard_zero && magnitude(clipped)>=magnitude({{8{guard_ref[23]}},guard_ref}))
      value<=clipped>0 ? clipped-1:(clipped<0 ? clipped+1:clipped);
     else value<=clipped;
     state<=ret_state;
    end
    default:state<=0;
    endcase
   end
  end
 end
endmodule
`default_nettype wire
