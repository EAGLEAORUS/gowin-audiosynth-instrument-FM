`default_nettype none
// STRINGS1 LFO from local Apache-2.0 MSFA formulas: speed30, delay0, PMD8/PMS2.
// Q24 log step512, <=0.01832 cents quantization; bend Q22, half-up rounding.
module instrument_string_lfo(input wire clk,rst_n,sample_tick,input wire [23:0] bend_ratio,output reg [23:0] ratio);
 reg [5:0] block_pos;reg [31:0] phase;reg [23:0] triangle;reg [4:0] state;
 reg signed [28:0] sens;reg signed [58:0] pm_product;reg signed [23:0] pm_log;
 reg [8:0] pitch_address;reg [23:0] bend,factor,digits;reg [47:0] product;reg [2:0] iter;
 wire [31:0] phase_next=phase+32'd28486596;
 wire [23:0] triangle_next=phase_next[31]?~phase_next[30:7]:phase_next[30:7];
 wire [35:0] table_q;
 pROMX9 pitch_bank(.DO(table_q),.CLK(clk),.CE(1'b1),.OCE(1'b0),.RESET(1'b0),.AD({pitch_address,5'b00111}));
 defparam pitch_bank.BIT_WIDTH=36;
 defparam pitch_bank.READ_MODE=0;
 defparam pitch_bank.RESET_MODE="SYNC";
 defparam pitch_bank.INIT_RAM_00=288'h00040026d0004002140004001bc00040016300040010a0004000b1000400059000400000;
 defparam pitch_bank.INIT_RAM_01=288'h0004005330004004da0004004820004004290004003d000040037700040031f0004002c6;
 defparam pitch_bank.INIT_RAM_02=288'h0004007f90004007a00004007480004006ef00040069600040063d0004005e500040058c;
 defparam pitch_bank.INIT_RAM_03=288'h000400abf000400a67000400a0e0004009b500040095c0004009030004008ab000400852;
 defparam pitch_bank.INIT_RAM_04=288'h000400d86000400d2d000400cd4000400c7b000400c22000400bca000400b71000400b18;
 defparam pitch_bank.INIT_RAM_05=288'h00040104c000400ff3000400f9a000400f42000400ee9000400e90000400e37000400dde;
 defparam pitch_bank.INIT_RAM_06=288'h0004013130004012ba0004012610004012080004011af0004011560004010fe0004010a5;
 defparam pitch_bank.INIT_RAM_07=288'h0004015d90004015800004015280004014cf00040147600040141d0004013c400040136b;
 defparam pitch_bank.INIT_RAM_08=288'h0004018a00004018470004017ee00040179500040173d0004016e400040168b000401632;
 defparam pitch_bank.INIT_RAM_09=288'h000401b67000401b0e000401ab5000401a5c000401a030004019ab0004019520004018f9;
 defparam pitch_bank.INIT_RAM_0A=288'h000401e2e000401dd5000401d7c000401d23000401cca000401c72000401c19000401bc0;
 defparam pitch_bank.INIT_RAM_0B=288'h0004020f500040209c000402043000401fea000401f92000401f39000401ee0000401e87;
 defparam pitch_bank.INIT_RAM_0C=288'h0004023bc00040236300040230b0004022b20004022590004022000004021a700040214e;
 defparam pitch_bank.INIT_RAM_0D=288'h00040268400040262b0004025d20004025790004025200004024c700040246e000402415;
 defparam pitch_bank.INIT_RAM_0E=288'h00040294b0004028f20004028990004028400004027e800040278f0004027360004026dd;
 defparam pitch_bank.INIT_RAM_0F=288'h000402c13000402bba000402b61000402b08000402aaf000402a560004029fd0004029a4;
 defparam pitch_bank.INIT_RAM_10=288'h000402edb000402e82000402e29000402dd0000402d77000402d1e000402cc5000402c6c;
 defparam pitch_bank.INIT_RAM_11=288'h0004031a300040314a0004030f100040309800040303f000402fe6000402f8d000402f34;
 defparam pitch_bank.INIT_RAM_12=288'h00040346b0004034120004033b90004033600004033070004032ae0004032550004031fc;
 defparam pitch_bank.INIT_RAM_13=288'h0004037330004036da0004036810004036280004035cf00040357600040351d0004034c4;
 defparam pitch_bank.INIT_RAM_14=288'h0004039fb0004039a20004039490004038f000040389700040383e0004037e500040378c;
 defparam pitch_bank.INIT_RAM_15=288'h000403cc3000403c6a000403c11000403bb8000403b5f000403b06000403aad000403a54;
 defparam pitch_bank.INIT_RAM_16=288'h000403f8c000403f33000403eda000403e81000403e27000403dce000403d75000403d1c;
 defparam pitch_bank.INIT_RAM_17=288'h0004042540004041fb0004041a20004041490004040f000040409700040403e000403fe5;
 defparam pitch_bank.INIT_RAM_18=288'h00040451d0004044c400040446b0004044120004043b90004043600004043070004042ad;
 defparam pitch_bank.INIT_RAM_19=288'h0004047e600040478d0004047340004046db0004046810004046280004045cf000404576;
 defparam pitch_bank.INIT_RAM_1A=288'h000404aaf000404a560004049fd0004049a300040494a0004048f100040489800040483f;
 defparam pitch_bank.INIT_RAM_1B=288'h000404d78000404d1f000404cc6000404c6d000404c13000404bba000404b61000404b08;
 defparam pitch_bank.INIT_RAM_1C=288'h000405041000404fe8000404f8f000404f36000404edd000404e83000404e2a000404dd1;
 defparam pitch_bank.INIT_RAM_1D=288'h00040530a0004052b10004052580004051ff0004051a600040514d0004050f300040509a;
 defparam pitch_bank.INIT_RAM_1E=288'h0004055d400040557b0004055220004054c800040546f0004054160004053bd000405364;
 defparam pitch_bank.INIT_RAM_1F=288'h00040589d0004058440004057eb0004057920004057390004056df00040568600040562d;
 defparam pitch_bank.INIT_RAM_20=288'h0003fa9ee0003fa9960003fa93e0003fa8e50003fa88d0003fa8350003fa7dd0003fa784;
 defparam pitch_bank.INIT_RAM_21=288'h0003facb00003fac580003fac000003faba70003fab4f0003faaf70003faa9f0003faa46;
 defparam pitch_bank.INIT_RAM_22=288'h0003faf720003faf1a0003faec20003fae6a0003fae110003fadb90003fad610003fad08;
 defparam pitch_bank.INIT_RAM_23=288'h0003fb2350003fb1dc0003fb1840003fb12c0003fb0d40003fb07b0003fb0230003fafcb;
 defparam pitch_bank.INIT_RAM_24=288'h0003fb4f70003fb49f0003fb4470003fb3ee0003fb3960003fb33e0003fb2e50003fb28d;
 defparam pitch_bank.INIT_RAM_25=288'h0003fb7ba0003fb7620003fb7090003fb6b10003fb6590003fb6000003fb5a80003fb550;
 defparam pitch_bank.INIT_RAM_26=288'h0003fba7d0003fba240003fb9cc0003fb9740003fb91b0003fb8c30003fb86b0003fb812;
 defparam pitch_bank.INIT_RAM_27=288'h0003fbd3f0003fbce70003fbc8f0003fbc360003fbbde0003fbb860003fbb2d0003fbad5;
 defparam pitch_bank.INIT_RAM_28=288'h0003fc0020003fbfaa0003fbf520003fbef90003fbea10003fbe480003fbdf00003fbd98;
 defparam pitch_bank.INIT_RAM_29=288'h0003fc2c50003fc26d0003fc2150003fc1bc0003fc1640003fc10b0003fc0b30003fc05b;
 defparam pitch_bank.INIT_RAM_2A=288'h0003fc5890003fc5300003fc4d80003fc47f0003fc4270003fc3cf0003fc3760003fc31e;
 defparam pitch_bank.INIT_RAM_2B=288'h0003fc84c0003fc7f30003fc79b0003fc7430003fc6ea0003fc6920003fc6390003fc5e1;
 defparam pitch_bank.INIT_RAM_2C=288'h0003fcb0f0003fcab70003fca5e0003fca060003fc9ae0003fc9550003fc8fd0003fc8a4;
 defparam pitch_bank.INIT_RAM_2D=288'h0003fcdd30003fcd7a0003fcd220003fccca0003fcc710003fcc190003fcbc00003fcb68;
 defparam pitch_bank.INIT_RAM_2E=288'h0003fd0970003fd03e0003fcfe60003fcf8d0003fcf350003fcedc0003fce840003fce2b;
 defparam pitch_bank.INIT_RAM_2F=288'h0003fd35a0003fd3020003fd2a90003fd2510003fd1f80003fd1a00003fd1480003fd0ef;
 defparam pitch_bank.INIT_RAM_30=288'h0003fd61e0003fd5c60003fd56d0003fd5150003fd4bc0003fd4640003fd40b0003fd3b3;
 defparam pitch_bank.INIT_RAM_31=288'h0003fd8e20003fd88a0003fd8310003fd7d90003fd7800003fd7280003fd6cf0003fd677;
 defparam pitch_bank.INIT_RAM_32=288'h0003fdba60003fdb4e0003fdaf50003fda9d0003fda440003fd9ec0003fd9930003fd93b;
 defparam pitch_bank.INIT_RAM_33=288'h0003fde6b0003fde120003fddba0003fdd610003fdd090003fdcb00003fdc570003fdbff;
 defparam pitch_bank.INIT_RAM_34=288'h0003fe12f0003fe0d70003fe07e0003fe0250003fdfcd0003fdf740003fdf1c0003fdec3;
 defparam pitch_bank.INIT_RAM_35=288'h0003fe3f40003fe39b0003fe3420003fe2ea0003fe2910003fe2390003fe1e00003fe188;
 defparam pitch_bank.INIT_RAM_36=288'h0003fe6b80003fe6600003fe6070003fe5ae0003fe5560003fe4fd0003fe4a50003fe44c;
 defparam pitch_bank.INIT_RAM_37=288'h0003fe97d0003fe9240003fe8cc0003fe8730003fe81b0003fe7c20003fe7690003fe711;
 defparam pitch_bank.INIT_RAM_38=288'h0003fec420003febe90003feb910003feb380003feadf0003fea870003fea2e0003fe9d6;
 defparam pitch_bank.INIT_RAM_39=288'h0003fef070003feeae0003fee560003fedfd0003feda40003fed4c0003fecf30003fec9a;
 defparam pitch_bank.INIT_RAM_3A=288'h0003ff1cc0003ff1730003ff11b0003ff0c20003ff0690003ff0110003fefb80003fef5f;
 defparam pitch_bank.INIT_RAM_3B=288'h0003ff4910003ff4390003ff3e00003ff3870003ff32f0003ff2d60003ff27d0003ff225;
 defparam pitch_bank.INIT_RAM_3C=288'h0003ff7570003ff6fe0003ff6a50003ff64c0003ff5f40003ff59b0003ff5420003ff4ea;
 defparam pitch_bank.INIT_RAM_3D=288'h0003ffa1c0003ff9c30003ff96b0003ff9120003ff8b90003ff8610003ff8080003ff7af;
 defparam pitch_bank.INIT_RAM_3E=288'h0003ffce20003ffc890003ffc300003ffbd70003ffb7f0003ffb260003ffacd0003ffa75;
 defparam pitch_bank.INIT_RAM_3F=288'h0003fffa70003fff4f0003ffef60003ffe9d0003ffe440003ffdec0003ffd930003ffd3a;
 function [26:0] term;
 input [23:0] x;input [2:0] d;reg [26:0] z;
 begin z={3'd0,x};case(d)
 0:term=0;1:term=z;2:term=z<<1;3:term=(z<<1)+z;
 4:term=z<<2;5:term=(z<<2)+z;6:term=(z<<2)+(z<<1);default:term=(z<<3)-z;
 endcase end endfunction
 always @(posedge clk)begin
 if(!rst_n)begin block_pos<=0;phase<=0;triangle<=0;state<=0;sens<=0;pm_product<=0;pm_log<=0;pitch_address<=0;bend<=4194304;factor<=4194304;digits<=0;product<=0;iter<=0;ratio<=4194304;end
 else if(sample_tick)begin
  block_pos<=block_pos+1'b1;state<=1;
  if(block_pos==0)begin phase<=phase_next;triangle<=triangle_next;end
 end else case(state)
 1:begin bend<=bend_ratio;sens<=($signed({1'b0,triangle})-29'sd8388608)*29'sd20;state<=2;end
 2:begin pm_product<=59'sd335544320*sens;state<=3;end
 3:begin pm_log<=pm_product>>>39;state<=4;end
 4:begin pitch_address<=($signed(pm_log)+24'sd256)>>>9;state<=5;end
 5:state<=6;
 6:begin factor<=table_q[23:0];digits<=bend;product<=0;iter<=0;state<=7;end
 7:begin product<=(product<<3)+{21'd0,term(factor,digits[23:21])};digits<=digits<<3;if(iter==7)state<=8;else iter<=iter+1'b1;end
 8:begin ratio<=product[45:22]+{23'd0,product[21]};state<=0;end
 default:begin end
 endcase
 end
endmodule
`default_nettype wire
