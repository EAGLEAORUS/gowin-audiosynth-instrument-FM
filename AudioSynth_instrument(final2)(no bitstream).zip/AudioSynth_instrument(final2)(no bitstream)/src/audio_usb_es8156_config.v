`default_nettype none
// Migrated 24-bit register table. All writes ACK before done; NACK restarts list.
module audio_usb_es8156_config #(parameter VOLUME_ENABLE=0)(
    input wire clk_50m, input wire ce, 
    input  wire rstn,           
    output wire i2c_sclk,
    inout  wire i2c_sdat,
    output wire reg_conf_done,  
    output wire i2c_ack,
    input wire [7:0] volume_code,input wire mute_request,
    output reg [7:0] applied_volume,output reg applied_mute,
    output wire volume_busy,output reg [31:0] volume_nacks
);
    reg  [1:0]  config_step;
    reg  [23:0] i2c_data;
    reg  [15:0] reg_data;
    reg         start;
    reg         reg_conf_done_reg;
    reg  [8:0]  reg_index;
    wire        ack;
    wire        tr_end;
    wire [7:0] target_volume=mute_request ? 8'h3f : (volume_code>8'hbd ? 8'hbd : (volume_code<8'h3f ? 8'h3f : volume_code));
    assign volume_busy=VOLUME_ENABLE && (!reg_conf_done_reg || config_step!=0 ||
      applied_volume!=target_volume || applied_mute!=mute_request);
    audio_usb_i2c_write u_i2c_com (
        .clk_50m(clk_50m), .ce(ce),
        .rstn       (rstn       ),
        .ack        (ack        ),
        .i2c_data   (i2c_data   ),
        .start      (start      ),
        .tr_end     (tr_end     ),
        .i2c_sclk   (i2c_sclk   ),
        .i2c_sdat   (i2c_sdat   )
    );
    assign reg_conf_done = reg_conf_done_reg;
    reg ack_ok;
    always @(posedge clk_50m) begin
        if (ce) begin
        if (!rstn)
            ack_ok <= 1'b0;
        else if (tr_end && (ack == 1'b0))
            ack_ok <= 1'b1;
        end
    end
    assign i2c_ack = ack_ok;
    always @(posedge clk_50m) begin
        if (ce) begin
        if (!rstn) begin
            config_step       <= 2'd0;
            start             <= 1'b0;
            reg_index         <= 9'd0;
            reg_conf_done_reg <= 1'b0;
            applied_volume<=8'hbd;applied_mute<=0;volume_nacks<=0;
        end
        else if (reg_conf_done_reg == 1'b0) begin
            if (reg_index <= 9'd26) begin
                case (config_step)
                    2'd0: begin
                        i2c_data    <= {8'h12, reg_data};  
                        start       <= 1'b1;
                        config_step <= 2'd1;
                    end
                    2'd1: begin
                        if (tr_end) begin
                            start       <= 1'b0;
                            config_step <= 2'd2;
                        end
                    end
                    2'd2: begin
                        if(!ack)begin
                            if(i2c_data[15:8]==8'h14)applied_volume<=i2c_data[7:0];
                            if(i2c_data[15:8]==8'h11)applied_mute<=i2c_data[3];
                        end else if(VOLUME_ENABLE && !(&volume_nacks))volume_nacks<=volume_nacks+1'b1;
                        reg_index <= ack ? 9'd0 : reg_index + 1'b1;
                        config_step <= 2'd0;
                    end
                    default: config_step <= 2'd0;
                endcase
            end
            else begin
                reg_conf_done_reg <= 1'b1;
                // Let the I2C writer return to its idle counter before the
                // first runtime transaction; otherwise tr_end is still high.
                start<=0;config_step<=3;
            end
        end
        else if(VOLUME_ENABLE)begin
            // The same I2C master owns initialization and runtime writes.
            // Runtime NACK never clears configured/audio_ready or resets audio.
            case(config_step)
                0:begin
                    if(applied_mute && applied_volume!=8'h3f)begin
                        i2c_data<=24'h12143f;start<=1;config_step<=1;
                    end else if(applied_mute && !mute_request)begin
                        i2c_data<=24'h121100;start<=1;config_step<=1;
                    end else if(applied_volume!=target_volume)begin
                        i2c_data<={16'h1214,(applied_volume<target_volume?applied_volume+8'd1:applied_volume-8'd1)};
                        start<=1;config_step<=1;
                    end else if(applied_mute!=mute_request)begin
                        i2c_data<={16'h1211,4'd0,mute_request,3'd0};start<=1;config_step<=1;
                    end
                end
                1:if(tr_end)begin start<=0;config_step<=2;end
                2:begin
                    if(!ack)begin
                        if(i2c_data[15:8]==8'h14)applied_volume<=i2c_data[7:0];
                        else if(i2c_data[15:8]==8'h11)applied_mute<=i2c_data[3];
                    end else if(!(&volume_nacks))volume_nacks<=volume_nacks+1'b1;
                    config_step<=0;
                end
                default:begin start<=0;config_step<=0;end
            endcase
        end
        end
    end
    always @(*) begin
        case (reg_index)
             9'd0 : reg_data = 16'h1000;   
             9'd1 : reg_data = 16'h003C;
             9'd2 : reg_data = 16'h0005;
             9'd3 : reg_data = 16'h001C;
             9'd4 : reg_data = 16'h0205;
             9'd5 : reg_data = 16'h0301;   
             9'd6 : reg_data = 16'h0400;   
             9'd7 : reg_data = 16'h0504;   
             9'd8 : reg_data = 16'h0600;
             9'd9 : reg_data = 16'h0833;
             9'd10: reg_data = 16'h1300;
             9'd11: reg_data = 16'h202A;
             9'd12: reg_data = 16'h213C;
             9'd13: reg_data = 16'h2202;
             9'd14: reg_data = 16'h2407;
             9'd15: reg_data = 16'h233A;
             9'd16: reg_data = 16'h0A01;
             9'd17: reg_data = 16'h0B01;
             9'd18: reg_data = VOLUME_ENABLE?{8'h14,target_volume}:16'h14BD;
             9'd19: reg_data = 16'h0121;
             9'd20: reg_data = 16'h0D14;
             9'd21: reg_data = 16'h1800;
             9'd22: reg_data = 16'h083F;
             9'd23: reg_data = 16'h2520;
             9'd24: reg_data = 16'h0002;
             9'd25: reg_data = 16'h0003;
             9'd26: reg_data = VOLUME_ENABLE?{8'h11,4'd0,mute_request,3'd0}:16'h1100;
             default: reg_data = 16'hFFFF;
        endcase
    end
endmodule

`default_nettype wire
