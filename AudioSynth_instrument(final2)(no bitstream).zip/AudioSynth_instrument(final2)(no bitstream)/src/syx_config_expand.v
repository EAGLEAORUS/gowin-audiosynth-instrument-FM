`default_nettype none
// Lossless expansion of the108bit storage contract verified by tdm_patch.c.
// Algorithm flags are per-voice metadata, supplied separately to the router.
// SUG550-2.4E section5.17: small rate tables must not consume sixteen BSRAMs.
module syx_config_expand(input wire [107:0] packed_config,output wire [295:0] full_config) /* synthesis syn_romstyle="logic" */;
 // Algebraically exact: floor((4+(q&3))*15152644 / 2^(16-q/4)).
 // All four products are even; halve once and shift by complement(q[5:2]).
 function [31:0] rate_increment;
  input [5:0] rate;
  reg [25:0] mantissa;reg [3:0] shift;
  begin
   case(rate[1:0])
    2'd0:mantissa=26'd30305288;
    2'd1:mantissa=26'd37881610;
    2'd2:mantissa=26'd45457932;
    2'd3:mantissa=26'd53034254;
   endcase
   shift=~rate[5:2];rate_increment={6'd0,mantissa}>>shift;
  end
 endfunction
 assign full_config={8'd0,
  rate_increment(packed_config[107:102]),rate_increment(packed_config[101:96]),
  rate_increment(packed_config[95:90]),rate_increment(packed_config[89:84]),
  3'd0,packed_config[83:71],16'd0,3'd0,packed_config[70:58],16'd0,
  3'd0,packed_config[57:45],16'd0,3'd0,packed_config[44:32],16'd0,
  packed_config[31:0]};
endmodule
module syx_op_config #(parameter integer ADDR_BITS=6)(input wire clk,we,input wire [ADDR_BITS-1:0] write_address,read_address,
 input wire [107:0] write_data,output wire [295:0] config_q);
 (* syn_ramstyle="block_ram" *)reg [107:0] mem[0:(1<<ADDR_BITS)-1];reg [107:0] stored;
 always @(posedge clk)begin if(we)mem[write_address]<=write_data;stored<=mem[read_address];end
 syx_config_expand unpack(stored,config_q);
endmodule
`default_nettype wire
