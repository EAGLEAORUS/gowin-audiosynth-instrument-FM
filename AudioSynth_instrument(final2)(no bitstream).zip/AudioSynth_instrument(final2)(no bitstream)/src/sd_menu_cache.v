`default_nettype none
// Same50MHz domain as APB/TFT. Glyph data are uploaded from an SD font asset;
// no font alphabet is stored in logic. begin_page is only a cold cache reset.
// Firmware appends unused glyph IDs and can change cells while ready remains 1.
module sd_menu_cache(input wire clk,rst_n,begin_page,commit,
 input wire glyph_we,input wire [10:0] glyph_write_addr,input wire [15:0] glyph_data,
 input wire cell_we,input wire [6:0] cell_write_addr,input wire [7:0] cell_data,
 input wire [6:0] cell_read_addr,output reg [7:0] cell_q,
 input wire [10:0] glyph_read_addr,output reg [15:0] glyph_q,
 output reg ready);
 (* syn_ramstyle="block_ram" *)reg [15:0] glyphs[0:2047];
 (* syn_ramstyle="block_ram" *)reg [7:0] cells[0:127];
 always @(posedge clk)begin
  if(glyph_we)glyphs[glyph_write_addr]<=glyph_data;
  if(cell_we)cells[cell_write_addr]<=cell_data;
  cell_q<=cells[cell_read_addr];glyph_q<=glyphs[glyph_read_addr];
  if(!rst_n || begin_page)ready<=0;else if(commit)ready<=1;
 end
endmodule
`default_nettype wire
