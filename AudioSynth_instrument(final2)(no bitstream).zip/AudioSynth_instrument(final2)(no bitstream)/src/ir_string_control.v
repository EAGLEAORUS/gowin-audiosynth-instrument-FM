`default_nettype none
// Local keyboard selector and IR timing derived from the new8 string controller.
module ir_string_control #(parameter integer US_CYCLES=50,
 HOLD_US=1000000, PROMPT_US=3000000, STARTUP_US=500000,
 QUIET_US=30000,PAIR_US=5000,LOCK_US=120000,END_US=10000,
 FAST_US=150000,SLOW_US=200000)(
 input wire clk,rst_n,button_n,ir_rx,online,in_valid,out_ready,
 input wire [39:0] in_data,input wire [8:0] patch,
 output reg out_valid,output reg [39:0] out_data,
 output reg [7:0] event_patch,output reg enabled,output wire prompt,output wire ir_tx,output wire playing_mode);
 (* syn_preserve=1 *) reg rx_meta,rx_sync;
 reg prev_rx,latched;
 reg [5:0] us_div;wire utick=us_div==US_CYCLES-1;
 reg [19:0] hold_count;
 reg [21:0] prompt_count;
 reg [10:0] carrier;reg [9:0] envelope;
 assign ir_tx=enabled && envelope<400 && carrier<658;
 assign prompt=prompt_count!=0;
 wire mode=enabled && patch[8] && online;
 assign playing_mode=mode;
 reg last_mode;reg [8:0] last_patch;
 wire transition=(mode!=last_mode) || (mode && patch!=last_patch);
 wire fall=prev_rx && !rx_sync,rise=!prev_rx && rx_sync;
 reg [19:0] boot;reg [16:0] lock_count;
 reg [15:0] since_count;reg [13:0] quiet_count,pair_count;
 reg armed,measuring,confirmed;
 reg [22:0] elapsed,last_end;
 reg pluck;reg [6:0] pluck_velocity,velocity;
 // Bitmaps are bounded pending work, drained only on idle input cycles.
 // Releases dominate re-triggers; no fixed 60ms gate, key release owns NoteOff.
 reg [127:0] held,normal_notes,sounding,requests,cleanup;
 reg [6:0] scan;
 reg [3:0] cooldown;
 wire piano=in_data[39:36]==0 && in_data[27:24]==0;
 wire note_on=in_data[31:28]==2 && in_data[16:10]!=0;
 wire note_off=in_data[31:28]==1 || (in_data[31:28]==2 && in_data[16:10]==0);
 wire clear_keys=in_data[31:28]==3 && (in_data[23:17]==120 || in_data[23:17]==123);
 wire [6:0] key=in_data[23:17];
 function [39:0] message;
 input [3:0] kind,ch;input [6:0] n,v;
 begin message={4'hf,(kind==2?4'h9:4'h8),kind,ch,n,v,2'd3,(kind==2?4'h9:4'h8),ch};end
 endfunction
 always @(posedge clk)begin
  if(!rst_n)begin
   rx_meta<=1;rx_sync<=1;prev_rx<=1;
   us_div<=0;latched<=0;hold_count<=0;
   prompt_count<=0;enabled<=0;carrier<=0;envelope<=0;
   boot<=0;lock_count<=0;since_count<=0;quiet_count<=0;pair_count<=0;
   armed<=0;measuring<=0;confirmed<=0;elapsed<=0;last_end<=0;
   pluck<=0;pluck_velocity<=127;velocity<=127;
   held<=0;normal_notes<=0;sounding<=0;requests<=0;cleanup<=0;scan<=0;
   last_mode<=0;last_patch<=0;out_valid<=0;out_data<=0;event_patch<=0;cooldown<=0;
  end else begin
   rx_meta<=ir_rx;rx_sync<=rx_meta;prev_rx<=rx_sync;
   us_div<=utick?0:us_div+1'b1;
   carrier<=carrier==1315?0:carrier+1'b1;
   pluck<=0;last_mode<=mode;last_patch<=patch;
   if(utick)begin
    envelope<=envelope==799?0:envelope+1'b1;
    if(prompt_count!=0)prompt_count<=prompt_count-1'b1;
    if(button_n)begin hold_count<=0;latched<=0;end
    else if(!latched)begin
     if(hold_count==HOLD_US-1)begin enabled<=!enabled;latched<=1;prompt_count<=PROMPT_US;end
     else hold_count<=hold_count+1'b1;
    end
    if(boot<STARTUP_US)boot<=boot+1'b1;
    if(lock_count<LOCK_US)lock_count<=lock_count+1'b1;
    if(since_count!=65535)since_count<=since_count+1'b1;
    if(measuring)begin
     if(elapsed<6553500)elapsed<=elapsed+1'b1;
     if(pair_count<PAIR_US)pair_count<=pair_count+1'b1;
     if(rx_sync && quiet_count<END_US)quiet_count<=quiet_count+1'b1;
     if(rx_sync && quiet_count==END_US-1)begin
      measuring<=0;
      if(confirmed)begin pluck<=1;pluck_velocity<=last_end<=FAST_US?127:last_end<=SLOW_US?85:43;end
     end
    end
   end
   if(!measuring && boot>=STARTUP_US && lock_count>=LOCK_US && since_count>=QUIET_US)armed<=1;
   if(fall)begin
    since_count<=0;quiet_count<=0;
    if(armed && !measuring)begin
     measuring<=1;armed<=0;confirmed<=0;elapsed<=0;last_end<=0;pair_count<=0;
    end else if(measuring && !confirmed && pair_count<PAIR_US)begin confirmed<=1;lock_count<=0;end
   end
   if(rise && measuring)begin last_end<=elapsed;quiet_count<=0;end
   if(!mode || transition)begin measuring<=0;confirmed<=0;armed<=0;since_count<=0;end
   out_valid<=0;event_patch<=patch[7:0];scan<=scan+1'b1;
   if(cooldown!=0)cooldown<=cooldown-1'b1;
   if(in_valid)begin
    out_valid<=1;out_data<=in_data;
    if(piano)begin
     if(note_on)begin held[key]<=1;if(mode)out_valid<=0;else normal_notes[key]<=1;end
     if(note_off)begin held[key]<=0;requests[key]<=0;normal_notes[key]<=0;
      if(mode && !normal_notes[key])out_valid<=0;
     end
     if(clear_keys)begin held<=0;requests<=0;normal_notes<=0;end
    end
   end else if(out_ready && cooldown==0 && mode && normal_notes[scan])begin
    out_valid<=1;out_data<=message(1,0,scan,0);normal_notes[scan]<=0;cooldown<=7;
   end else if(out_ready && cooldown==0 && sounding[scan] && (!mode || transition || cleanup[scan] || !held[scan]))begin
    out_valid<=1;out_data<=message(1,1,scan,0);sounding[scan]<=0;requests[scan]<=0;cleanup[scan]<=0;
    cooldown<=7;
   end else if(out_ready && cooldown==0 && mode && !transition && held[scan] && requests[scan])begin
    out_valid<=1;out_data<=message(2,1,scan,velocity);sounding[scan]<=1;requests[scan]<=0;cooldown<=7;
   end
   if(pluck && mode && !transition)begin requests<=held;velocity<=pluck_velocity;end
   if(transition)begin requests<=0;cleanup<=sounding;end
   if(!online)begin held<=0;normal_notes<=0;sounding<=0;requests<=0;cleanup<=0;end
  end
 end
endmodule
`default_nettype wire
