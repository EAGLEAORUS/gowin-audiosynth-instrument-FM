`default_nettype none
// Rational sample timing: floor(n*1789773/(period*48000)), no rounded FCW.
// At most ten shifts per sample, serialized on the SAME system clock.
module nes_osc_noise(
 input wire clk,rst_n,sample_tick,restart,enable,
 input wire [3:0] period_index,input wire short_mode,input wire [3:0] volume,
 output wire [3:0] level,output reg busy,output reg [14:0] lfsr
);
 (* syn_ramstyle = "registers", ram_style = "distributed" *) reg [11:0] periods[0:15];
 initial begin
  periods[0]=4;periods[1]=8;periods[2]=16;periods[3]=32;
  periods[4]=64;periods[5]=96;periods[6]=128;periods[7]=160;
  periods[8]=202;periods[9]=254;periods[10]=380;periods[11]=508;
  periods[12]=762;periods[13]=1016;periods[14]=2034;periods[15]=4068;
 end
 reg [27:0] denominator,residue;
 reg mode;
 wire [27:0] extended_period={16'd0,periods[period_index]};
 // 48000=32768+16384-1024-128. A constant shift/add uses no DSP or RAM.
 wire [27:0] next_denominator=(extended_period<<15)+(extended_period<<14)-(extended_period<<10)-(extended_period<<7);
 wire feedback=lfsr[0]^(mode?lfsr[6]:lfsr[1]);
 assign level=(enable && lfsr[0])?volume:4'd0; // model uses bit0, NOT its inverse
 always @(posedge clk)begin
  if(!rst_n || restart)begin
   denominator<=next_denominator;residue<=0;mode<=short_mode;lfsr<=15'd1;busy<=0;
  end else if(sample_tick && enable)begin residue<=residue+28'd1789773;busy<=1;end
  else if(busy)begin
   if(residue>=denominator)begin residue<=residue-denominator;lfsr<={feedback,lfsr[14:1]};end
   else busy<=0;
  end
 end
endmodule
`default_nettype wire
