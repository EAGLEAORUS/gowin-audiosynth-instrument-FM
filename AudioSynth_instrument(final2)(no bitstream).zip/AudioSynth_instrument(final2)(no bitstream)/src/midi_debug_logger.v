`default_nettype none
// Three independent queues prevent RAW/status traffic from overwriting MIDI records.
// Fixed-width decimal fields (CH=01, NOTE=060). RAW prints original USB payload.
module midi_debug_logger #(parameter CLK_HZ=50000000,parameter BAUD=115200,
 parameter LOG_ADDR_BITS=6,parameter RAW_ADDR_BITS=3,parameter SERVICE_ENABLE=0)(
 input wire clk,input wire rst_n,
 input wire event_push,input wire [39:0] event_data,
 input wire raw_push,input wire [518:0] raw_data,
 input wire status_push,input wire [2:0] status_data,
 output wire tx,
 output wire [31:0] event_log_overflow,raw_log_overflow,status_log_overflow,
 input wire descriptor_push,output wire raw_ready,
 input wire service_lock,service_valid,input wire [7:0] service_data,output wire service_ready
);
 wire ev_valid,raw_valid,status_valid;
 wire [39:0] ev_front;
 wire [519:0] raw_front;
 wire [2:0] status_front;
 wire ev_pop,raw_pop,status_pop;
 midi_sync_fifo_fwft_ram #(40,LOG_ADDR_BITS) ef(clk,rst_n,event_push,event_data,,ev_valid,ev_front,ev_pop,event_log_overflow);
 midi_sync_fifo_packed #(520,RAW_ADDR_BITS) rf(clk,rst_n,raw_push,{descriptor_push,raw_data},raw_ready,raw_valid,raw_front,raw_pop,raw_log_overflow);
 midi_sync_fifo #(3,3) sf(clk,rst_n,status_push,status_data,,status_valid,status_front,status_pop,status_log_overflow);
 reg active,prepared;
 reg [1:0] mode,last_mode;
 reg [39:0] ev;
 (* syn_preserve=1 *) reg [519:0] raw;
 reg [2:0] status;
 reg [8:0] cursor;
 reg [1:0] pick;
 // Round robin at line boundaries so no queue starves permanently.
 always @* begin
  pick=0;
  case(last_mode)
   1:if(raw_valid)pick=2;else if(status_valid)pick=3;else if(ev_valid)pick=1;
   2:if(status_valid)pick=3;else if(ev_valid)pick=1;else if(raw_valid)pick=2;
   default:if(ev_valid)pick=1;else if(raw_valid)pick=2;else if(status_valid)pick=3;
  endcase
 end
 assign ev_pop=!active && pick==1;
 assign raw_pop=!active && pick==2;
 assign status_pop=!active && pick==3;
 function [7:0] hexchar;input [3:0] x;begin hexchar=(x<10)?8'd48+{4'd0,x}:8'd55+{4'd0,x};end endfunction
 function [7:0] digit;input [13:0] x;input [13:0] divisor;begin digit=(x/divisor)%10;end endfunction
 function [15:0] dec2;input [13:0] x;begin dec2={8'd48+digit(x,14'd10),8'd48+digit(x,14'd1)};end endfunction
 function [23:0] dec3;input [13:0] x;begin dec3={8'd48+digit(x,14'd100),dec2(x)};end endfunction
 function [39:0] dec5;input [13:0] x;begin dec5={8'd48+digit(x,14'd10000),8'd48+digit(x,14'd1000),dec3(x)};end endfunction
 wire [13:0] ch={10'd0,ev[27:24]}+14'd1;
 wire [13:0] d1={7'd0,ev[23:17]},d2={7'd0,ev[16:10]};
 wire [13:0] bend={ev[16:10],ev[23:17]};
 wire [13:0] cable={10'd0,ev[39:36]};
 reg [511:0] event_line;
 reg [8:0] event_length;
 always @* begin
  event_line=0;event_length=0;
  case(ev[31:28])
   4'd1:begin event_line={"NOTE_OFF CH=",dec2(ch)," NOTE=",dec3(d1)," VEL=",dec3(d2)," CABLE=",dec2(cable)," CIN=",hexchar(ev[35:32]),{8'h0d,8'h0a}};event_length=9'd48;end
   4'd2:begin event_line={"NOTE_ON CH=",dec2(ch)," NOTE=",dec3(d1)," VEL=",dec3(d2)," CABLE=",dec2(cable)," CIN=",hexchar(ev[35:32]),{8'h0d,8'h0a}};event_length=9'd47;end
   4'd3:begin event_line={"CC CH=",dec2(ch)," CTRL=",dec3(d1)," VALUE=",dec3(d2)," CABLE=",dec2(cable)," CIN=",hexchar(ev[35:32]),{8'h0d,8'h0a}};event_length=9'd44;end
   4'd4:begin event_line={"PROGRAM_CHANGE CH=",dec2(ch)," PROGRAM=",dec3(d1)," CABLE=",dec2(cable)," CIN=",hexchar(ev[35:32]),{8'h0d,8'h0a}};event_length=9'd49;end
   4'd5:begin event_line={"PITCH_BEND CH=",dec2(ch)," VALUE=",dec5(bend)," CABLE=",dec2(cable)," CIN=",hexchar(ev[35:32]),{8'h0d,8'h0a}};event_length=9'd45;end
   4'd6:begin event_line={"POLY_PRESSURE CH=",dec2(ch)," NOTE=",dec3(d1)," VALUE=",dec3(d2)," CABLE=",dec2(cable)," CIN=",hexchar(ev[35:32]),{8'h0d,8'h0a}};event_length=9'd55;end
   4'd7:begin event_line={"CHANNEL_PRESSURE CH=",dec2(ch)," VALUE=",dec3(d1)," CABLE=",dec2(cable)," CIN=",hexchar(ev[35:32]),{8'h0d,8'h0a}};event_length=9'd49;end
   4'd8:begin event_line={"SYSTEM STATUS=",hexchar(ev[7:4]),hexchar(ev[3:0])," DATA1=",dec3(d1)," DATA2=",dec3(d2)," CABLE=",dec2(cable)," CIN=",hexchar(ev[35:32]),{8'h0d,8'h0a}};event_length=9'd53;end
   default:begin event_line={"USB ERROR INVALID_EVENT",8'h0d,8'h0a};event_length=25;end
  endcase
 end
 reg [255:0] status_line;
 reg [8:0] status_length;
 always @* begin
  case(status)
   0:begin status_line={"USB DEVICE CONNECTED",8'h0d,8'h0a};status_length=22;end
   1:begin status_line={"USB RESET",8'h0d,8'h0a};status_length=11;end
   2:begin status_line={"DEVICE DESCRIPTOR",8'h0d,8'h0a};status_length=19;end
   3:begin status_line={"CONFIGURED",8'h0d,8'h0a};status_length=12;end
   4:begin status_line={"MIDI ENDPOINT READY",8'h0d,8'h0a};status_length=21;end
   5:begin status_line={"USB ERROR",8'h0d,8'h0a};status_length=11;end
   default:begin status_line={"USB DISCONNECTED",8'h0d,8'h0a};status_length=18;end
  endcase
 end
 // Header is 17 bytes (136 bits); declared separately below.
 reg [135:0] raw_prefix;
 wire diagnostic=raw[518:512]==127;
 reg [143:0] desc_prefix;
 always @(posedge clk)begin
  raw_prefix<={"RAW LEN=",dec3({7'd0,raw[518:512]})," DATA="};
  desc_prefix<={"DESC LEN=",dec3({7'd0,raw[518:512]})," DATA="};
 end
 wire [111:0] diag_prefix="USB DIAG DATA=";
 wire [6:0] print_bytes=diagnostic?7'd32:raw[518:512];
 wire [8:0] prefix_length=diagnostic?9'd14:raw[519]?9'd18:9'd17;
 reg [8:0] length;
 reg [7:0] char_data;
 reg [7:0] raw_byte;
 // cursor and prefix are 9-bit and the subtraction is nonnegative
 // in the payload branch. Avoid promoting division/modulo to 32-bit int.
 wire [8:0] raw_offset=cursor-prefix_length;
 reg [8:0] pos;
 always @* begin
  char_data=0;raw_byte=0;pos=0;length=0;
  case(mode)
   1:begin length=event_length;char_data=event_line[8*(event_length-1-cursor)+:8];end
   2:begin
    length=prefix_length+9'd2+({2'd0,print_bytes}*9'd3);
    if(cursor<prefix_length)begin
     if(diagnostic)char_data=diag_prefix[8*(13-cursor)+:8];
     else if(raw[519])char_data=desc_prefix[8*(17-cursor)+:8];
     else char_data=raw_prefix[8*(16-cursor)+:8];
    end
    else if(cursor==length-2)char_data=13;
    else if(cursor==length-1)char_data=10;
    else begin
     pos=raw_offset/9'd3;
     raw_byte=raw[pos*8+:8];
     case(raw_offset%9'd3)
      0:char_data=hexchar(raw_byte[7:4]);
      1:char_data=hexchar(raw_byte[3:0]);
      default:char_data=8'd32;
     endcase
    end
   end
   3:begin length=status_length;char_data=status_line[8*(status_length-1-cursor)+:8];end
   default:begin length=0;char_data=0;end
  endcase
 end
 wire uart_ready;
 wire tx_ready;wire service=SERVICE_ENABLE && service_lock;
 reg [7:0] prepared_char;
 reg prepared_last;
 assign uart_ready=tx_ready && !service;
 assign service_ready=tx_ready && service;
 midi_uart_tx #(CLK_HZ,BAUD) uart(clk,rst_n,service?service_valid:(active && prepared),service?service_data:prepared_char,tx_ready,tx);
 always @(posedge clk) begin
  if(!rst_n) begin active<=0;prepared<=0;mode<=0;last_mode<=0;cursor<=0;ev<=0;raw<=0;status<=0;end
  else if(!active) begin
   if(pick!=0) begin
    active<=1;prepared<=0;mode<=pick;last_mode<=pick;cursor<=0;
    case(pick)1:ev<=ev_front;2:raw<=raw_front;3:status<=status_front;endcase
   end
  end else if(!prepared)begin
   prepared_char<=char_data;
   prepared_last<=cursor==length-1;
   prepared<=1;
  end
  else if(uart_ready) begin
   prepared<=0;
   if(prepared_last)begin active<=0;cursor<=0;end
   else cursor<=cursor+1'b1;
  end
 end
endmodule
`default_nettype wire
