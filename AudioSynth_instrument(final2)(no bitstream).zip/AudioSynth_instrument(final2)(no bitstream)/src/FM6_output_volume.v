`default_nettype none
// System output control only. The committed 40-bit MIDI event is already in
// the 50 MHz domain; no PCM scaling and no per-operator/voice state changes.
module FM6_output_volume(
 input wire clk,rst_n,event_valid,input wire [39:0] event_data,input wire online,
 output reg [6:0] value,output wire [7:0] dac_code,output wire mute_request,
 output reg [31:0] accepted
);
 wire selected=event_valid && online && event_data[39:36]==4'd0 &&
  event_data[35:32]==4'hb && event_data[31:28]==4'd3 &&
  event_data[27:24]==4'd0 && event_data[23:17]==7'd76 &&
  event_data[9:8]==2'd3 && event_data[7:0]==8'hb0;
 // ES8156 DS Rev5 p19: code BF=0dB, 0.5dB/code. Preserve existing BD=-1dB
 // at 127; 1=3F=-64dB. Zero reaches the floor and asserts SDP SP_MUTE.
 assign dac_code=value==0?8'h3f:({1'b0,value}+8'd62);
 assign mute_request=value==0;
 always @(posedge clk)begin
  if(!rst_n)begin value<=127;accepted<=0;end
  else if(selected)begin value<=event_data[16:10];if(!(&accepted))accepted<=accepted+1'b1;end
  // Retain the system setting across MIDI disconnect/reconnect.
 end
endmodule
`default_nettype wire
