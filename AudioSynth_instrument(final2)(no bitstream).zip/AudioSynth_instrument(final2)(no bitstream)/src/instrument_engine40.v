`default_nettype none
// Four shared 10-voice/6-OP lanes; no 240-fold oscillator datapath replication.
module instrument_engine40 #(parameter TRACE_ENABLE=0,parameter integer VOICES_PER_CORE=10)(
 input wire clk,rst_n,sample_tick,event_valid,input wire [39:0] event_data,input wire online,input wire [2:0] patch_select,
 output reg signed [23:0] pcm,output reg pcm_valid,
 output wire [4*VOICES_PER_CORE-1:0] busy,gate,releasing,
 output reg [31:0] deadline_miss,clip_count,range_errors,output wire [31:0] event_overflow,
 output reg [15:0] last_cycles,output wire [4*VOICES_PER_CORE*32-1:0] voice_raw,
 input wire [23:0] string_ratio,output wire [23:0] string_bend_ratio,
 input wire [95:0] event_tag,output wire exec_valid,output wire [39:0] exec_data,output wire [95:0] exec_tag
);
 wire queue_valid,queue_ready,pop,fetch;wire [39:0] queue_data;
 reg [39:0] routed_data;reg event_pending;reg [2:0] event_age;
 localparam integer EVENT_WARMUP=VOICES_PER_CORE>8?4:3;
 wire safe_online=online && event_overflow==0;
 wire [4*VOICES_PER_CORE-1:0] on,off;wire [6:0] raw_note,velocity;
 wire [4*VOICES_PER_CORE*7-1:0] assigned_notes;wire [4*VOICES_PER_CORE*4-1:0] channels;
 (* syn_keep=1 *) wire [31:0] accepted_events,steals,retriggers;
 wire [3:0] lane_idle,lane_valid;
 wire [15:0] lane_cycles[0:3];wire [31:0] lane_deadline[0:3],lane_ranges[0:3];
 wire signed [33:0] ep_mix[0:3],cel_mix[0:3];
 midi_sync_fifo_fwft_ram #(.WIDTH(40),.ADDR_BITS(7)) events(clk,rst_n && online,event_valid && online,event_data,
  queue_ready,queue_valid,queue_data,fetch,event_overflow);
 // Supplemental immutable tags use the SAME put/fetch boundaries as the
 // existing event FIFO. Payload and tags cannot be consumed independently.
 generate if(TRACE_ENABLE)begin:trace
  reg [95:0] tags[0:127];reg [6:0] wp,rp;reg [95:0] routed_tag;
  always @(posedge clk)begin
   if(event_valid && online && queue_ready)tags[wp]<=event_tag;
   if(!rst_n || !online)begin wp<=0;rp<=0;routed_tag<=0;end
   else begin
    if(event_valid && queue_ready)wp<=wp+1'b1;
    if(fetch)begin routed_tag<=tags[rp];rp<=rp+1'b1;end
   end
  end
  assign exec_tag=routed_tag;
 end else begin:no_trace assign exec_tag=96'd0;end endgenerate
 assign exec_valid=TRACE_ENABLE && pop && safe_online;
 assign exec_data=routed_data;
 reg working;reg [3:0] completed;reg [15:0] elapsed;reg [3:0] mix_index;
 reg event_window_ready;
 always @(posedge clk)begin
  if(!rst_n)event_window_ready<=0;
  else event_window_ready<=(&lane_idle) && !working;
 end
 // Register lane-idle reduction before the high-fanout event enables.
 // working and sample_tick close the window immediately on a frame boundary.
 wire event_window=event_window_ready && !working && !sample_tick;
 // Break FIFO mux -> 32-way selection -> rank update into registered stages.
 // A fetched record stays stable through group + winner registers.
 // Three warm-up cycles include the new winner stage (+20ns event latency).
 assign fetch=event_window && !event_pending && queue_valid;
 assign pop=event_window && event_pending && event_age==EVENT_WARMUP;
 always @(posedge clk)begin
  if(!rst_n || !online)begin routed_data<=0;event_pending<=0;event_age<=0;end
  else begin
   if(fetch)begin routed_data<=queue_data;event_pending<=1;event_age<=0;end
   else if(event_pending && event_age!=EVENT_WARMUP)event_age<=event_age+1'b1;
   if(pop)event_pending<=0;
  end
 end
 instrument_allocator40 #(.SUSTAIN_ENABLE(1),.VOICES(4*VOICES_PER_CORE)) allocator(clk,rst_n,pop,routed_data,safe_online,
  busy,gate,releasing,on,off,raw_note,velocity,assigned_notes,channels,accepted_events,steals,retriggers,patch_select);
 // Keep the previously confirmed Orca offset; Celesta ROM adds its factory +12.
 wire [2:0] core_patch=routed_data[27:24]==9?3'd5:patch_select;
 wire [6:0] model_note=raw_note+7'd12;
 (* syn_keep=1 *) wire [13:0] pitch_value;
 wire [23:0] pitch_ratio;
 assign string_bend_ratio=pitch_ratio;
 (* syn_keep=1 *) wire [31:0] pitch_events;
 synth_pitch_control pitch(clk,rst_n,pop,routed_data,safe_online,pitch_value,pitch_ratio,pitch_events);
 wire [23:0] flute_ratio;wire [17:0] flute_am_pt;
 instrument_flute_lfo flute_lfo(clk,rst_n,sample_tick,(|on) && core_patch==2'd3,pitch_ratio,flute_ratio,flute_am_pt);
 genvar g;generate for(g=0;g<4;g=g+1)begin:lanes
  wire signed [23:0] unused_pcm;wire [31:0] unused_clips;
  instrument_core10 #(.PITCH_ENABLE(1),.VOICES(VOICES_PER_CORE)) core(clk,rst_n,sample_tick,on[g*VOICES_PER_CORE+:VOICES_PER_CORE],off[g*VOICES_PER_CORE+:VOICES_PER_CORE],model_note,velocity,
   unused_pcm,lane_valid[g],busy[g*VOICES_PER_CORE+:VOICES_PER_CORE],gate[g*VOICES_PER_CORE+:VOICES_PER_CORE],releasing[g*VOICES_PER_CORE+:VOICES_PER_CORE],
   lane_deadline[g],unused_clips,lane_ranges[g],lane_cycles[g],voice_raw[g*VOICES_PER_CORE*32+:VOICES_PER_CORE*32],lane_idle[g],pitch_ratio,core_patch,ep_mix[g],cel_mix[g],flute_ratio,flute_am_pt,string_ratio);
 end endgenerate
 reg signed [35:0] ep_sum,cel_sum;
 reg signed [59:0] dc_y,dc_x1; // PCM24 units with 20 fractional guard bits.
 reg signed [71:0] dc_product;
 reg signed [59:0] dc_next;
 reg signed [36:0] mixed;
 reg [3:0] mix_state;
 // r=0.997375 = 1-126/48000; exact decay is 21/8000. Q20 coefficient
 // round(r*2^20)=1045823. Shift/add constant multiply, no floating point.
 always @(posedge clk)begin
  if(!rst_n)begin
   pcm<=0;pcm_valid<=0;deadline_miss<=0;clip_count<=0;range_errors<=0;last_cycles<=0;
   working<=0;completed<=0;elapsed<=0;mix_index<=0;mix_state<=0;
   ep_sum<=0;cel_sum<=0;dc_y<=0;dc_x1<=0;dc_product<=0;dc_next<=0;mixed<=0;
  end else begin
   pcm_valid<=0;
   if(sample_tick)begin
    if(working)deadline_miss<=deadline_miss+1'b1;
    else begin working<=1;completed<=0;elapsed<=0;mix_state<=0;end
   end
   if(working)begin
    elapsed<=elapsed+1'b1;completed<=completed|lane_valid;
    case(mix_state)
     0:if(&(completed|lane_valid))begin ep_sum<=0;cel_sum<=0;mix_index<=0;mix_state<=1;end
     1:begin
      ep_sum<=ep_sum+ep_mix[mix_index];cel_sum<=cel_sum+cel_mix[mix_index];
      if(lane_deadline[mix_index]!=0 || lane_ranges[mix_index]!=0)range_errors<=range_errors+1'b1;
      if(mix_index==3)mix_state<=2;else mix_index<=mix_index+1'b1;
     end
     2:begin
      // Quantization only in the output DC blocker; six-OP raw remains exact.
      dc_product<=dc_y*21'sd1045823;mix_state<=3;
     end
     3:begin dc_next<=($signed(cel_sum)<<<20)-dc_x1+(dc_product>>>20);mix_state<=4;end
     4:begin
      dc_x1<=$signed(cel_sum)<<<20;dc_y<=dc_next;
      // Fixed /8 headroom for 32 voices; no note-count-dependent gain pumping.
      mixed<=($signed(ep_sum)+(dc_next>>>20))>>>3;mix_state<=5;
     end
     5:begin
      if(mixed>37'sd8388607)begin pcm<=24'sh7fffff;clip_count<=clip_count+1'b1;end
      else if(mixed< -37'sd8388608)begin pcm<=24'sh800000;clip_count<=clip_count+1'b1;end
      else pcm<=mixed[23:0];
      pcm_valid<=1;last_cycles<=elapsed;working<=0;mix_state<=0;
     end
     default:mix_state<=0;
    endcase
   end
  end
 end
endmodule
`default_nettype wire
