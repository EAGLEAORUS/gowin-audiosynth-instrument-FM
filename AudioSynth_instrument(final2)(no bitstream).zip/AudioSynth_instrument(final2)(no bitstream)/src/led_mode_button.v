`timescale 1ns/1ps
// AB13按键：默认上拉、按下为低。两级同步，按下/松开均需稳定20ms。
// 每次有效按下翻转一次；长按不会重复触发，复位后默认频谱模式。
module led_mode_button #(
    parameter integer DEBOUNCE_CYCLES=1000000,
    parameter integer ACTIVE_LOW=1, UI_ENABLE=0
)(input wire clk,rst_n,button_n,output reg lissajous_mode,input wire ui_set,ui_mode);
    (* async_reg="true" *) reg sync1,sync2;
    reg stable_pressed;
    localparam integer COUNT_BITS=(DEBOUNCE_CYCLES>1)?$clog2(DEBOUNCE_CYCLES):1;
    reg [COUNT_BITS-1:0] count;
    wire pressed=ACTIVE_LOW?!sync2:sync2;
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            sync1<=ACTIVE_LOW?1'b1:1'b0; sync2<=ACTIVE_LOW?1'b1:1'b0;
            stable_pressed<=0; count<=0; lissajous_mode<=0;
        end else begin
            sync1<=button_n; sync2<=sync1;
            if(pressed==stable_pressed) count<=0;
            else if(count==DEBOUNCE_CYCLES-1) begin
                count<=0; stable_pressed<=pressed;
                if(pressed) lissajous_mode<=~lissajous_mode;
            end else count<=count+1'b1;
            if(UI_ENABLE && ui_set)lissajous_mode<=ui_mode;
        end
    end
endmodule
