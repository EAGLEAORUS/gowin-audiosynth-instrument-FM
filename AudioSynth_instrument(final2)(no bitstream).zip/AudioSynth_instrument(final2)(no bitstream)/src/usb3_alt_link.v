`default_nettype none
// Frozen ALT1 physical transactions. One command / one 4096B application block.
// RX bank is immutable from request_toggle until release returns through ACK.
module usb3_alt_link(
 input wire clk,rst_n,rx_clk,rx_req,rx_vld,output wire rx_ready,
 inout wire [15:0] hd,output wire tx_clk,tx_req,tx_vld,input wire tx_ready,
 output wire request_valid,input wire release_request,
 output reg [15:0] operation,output reg [31:0] total,token,
 output reg [31:0] trailer_crc_errors,trailer_seq_errors,
 output reg length_bad,padding_bad,
 input wire [8:0] read_addr,output reg [15:0] read_data,
 input wire tx_start,input wire [11:0] tx_length,input wire [31:0] tx_data,
 output wire [8:0] tx_addr,output wire tx_done);
 // An actual divide-by-four TX clock provides a 40ns data half-cycle.
 // The 50MHz application domain stays unchanged. Start/done are mailbox
 // toggles; length and TX bank are immutable until the complete frame ends.
 (* syn_preserve=1 *) reg tx_core_clk;
 reg tx_half_phase;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin tx_half_phase<=0;tx_core_clk<=0;end
  else begin tx_half_phase<=~tx_half_phase;if(tx_half_phase)tx_core_clk<=~tx_core_clk;end
 end
 reg start_toggle;
 // Launch the request on core's falling edge, midway between TX rising
 // edges; every related-clock handshake path retains setup/hold checks.
 always @(negedge clk or negedge rst_n)
  if(!rst_n)start_toggle<=0;else if(tx_start)start_toggle<=~start_toggle;
 (* syn_preserve=1 *) reg start_meta,start_sync;
 reg start_seen,done_toggle;
 wire tx_done_core;wire [8:0] core_tx_addr;reg [8:0] tx_addr_delay;
 // A physical transaction starts at sequence zero on both peers. first_tx
 // stays unchanged throughout the first start/complete mailbox handshake,
 // exactly as tx_length/TX RAM do; it is not an independently sampled bus.
 reg request_seen,first_tx;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin request_seen<=0;first_tx<=1;end
  else begin
   request_seen<=request_valid;
   if(request_valid && !request_seen)first_tx<=1;
   else if(tx_done)first_tx<=0;
  end
 end

 wire tx_rst_n;
 usb3_tx_reset reset_tx(tx_core_clk,rst_n,tx_rst_n);
 // EXM expects a one-TX-cycle RAM read. A 50MHz RAM can otherwise replace
 // the prefetched word halfway through the 12.5MHz cycle and skip word zero.
 always @(posedge tx_core_clk)tx_addr_delay<=core_tx_addr;
 reg [8:0] tx_addr_sample;
 always @(negedge clk)tx_addr_sample<=tx_addr_delay;
 assign tx_addr=tx_addr_sample;
 always @(posedge tx_core_clk or negedge tx_rst_n)begin
  if(!tx_rst_n)begin start_meta<=0;start_sync<=0;start_seen<=0;done_toggle<=0;end
  else begin
   start_meta<=start_toggle;start_sync<=start_meta;start_seen<=start_sync;
   if(tx_done_core)done_toggle<=~done_toggle;
  end
 end
 (* syn_preserve=1 *) reg tx_done_meta,tx_done_sync;reg tx_done_seen;
 always @(negedge clk or negedge rst_n)
  if(!rst_n)tx_done_meta<=0;else tx_done_meta<=done_toggle;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin tx_done_sync<=0;tx_done_seen<=0;end
  else begin tx_done_sync<=tx_done_meta;tx_done_seen<=tx_done_sync;end
 end
 assign tx_done=tx_done_sync!=tx_done_seen;
 wire rx_rst_n;
 usb3_tx_reset reset_rx(rx_clk,rst_n,rx_rst_n);
 wire rx_write,rx_done,crc_error,num_error;wire [31:0] rx_data;
 wire [31:0] td;wire [2:0] oe;wire [15:0] crc_value;wire core_tx_req,core_tx_vld;
 assign tx_req=core_tx_req && tx_rst_n;
 assign tx_vld=core_tx_vld && tx_rst_n;
 // The forwarded clock pin is timed as data from the divider, independently
 // from the ideal sampling reference at its Q. This includes its pad delay.
 // Forwarding is an ordinary timed output from the divider.
 USB3_EXM_HSPI #(.TX_LEN(12'd1023),.HSPI_UDF(26'hffff),.TX_ADDR(9'd0),.RX_ADDR(9'd0)) bus_core(
 .HTCLK(tx_clk),.HTREQ(core_tx_req),.HTRDY(tx_ready),.HTVLD(core_tx_vld),.HTD(td),.HTOE(oe),
 .tx_act(start_sync!=start_seen),.tx_len(tx_length),.HRCLK(rx_clk),.HRACT(rx_req),.HRVLD(rx_vld),.HTACK(),
 .HRD({16'd0,hd}),.rstn(tx_rst_n),.clk(tx_core_clk),.dat_mod(2'b01),.ram_clk(),.ram_csn(),.ram_wen(),
 .ram_addr(),.ram_rdata(tx_data),.ram_wdata(),.rx_write(rx_write),.rx_addr(),.rx_data(rx_data),
 .tx_addr(core_tx_addr),.tx_done(tx_done_core),.rx_done(rx_done),.rx_crc_error(crc_error),
 .rx_num_error(num_error),.rx_crc_value(crc_value),.tx_sequence_reset(first_tx));
 assign hd=(tx_req && oe[1])?td[15:0]:16'hzzzz;

 // One immutable business bank. A one-valid-word skid retains the last
 // received word until a following valid word proves it was payload rather
 // than the CRC trailer. This accepts valid gaps and either legal request
 // deassertion phase (with CRC, or after CRC); no raw pad drives CRC reset.
 reg [15:0] bank[0:511];
 reg request_toggle,ack_toggle,seen;
 (* syn_preserve=1 *) reg done_meta,done_sync,ack_meta,ack_sync;
 wire bank_free=request_toggle==ack_sync;
 assign rx_ready=rst_n && !request_valid;
 assign request_valid=(done_sync!=seen) && !release_request;
 always @(posedge clk)begin
  read_data<=bank[read_addr];
  if(!rst_n)begin done_meta<=0;done_sync<=0;ack_toggle<=0;seen<=0;end
  else begin
   done_meta<=request_toggle;done_sync<=done_meta;
   if(release_request)begin seen<=done_sync;ack_toggle<=done_sync;end
  end
 end
 // Registered pad sampling leaves a full RX cycle for CRC/decoder logic.
 reg [15:0] sampled_data;
 reg sampled_req,sampled_valid;
 always @(posedge rx_clk or negedge rx_rst_n)begin
  if(!rx_rst_n)begin sampled_data<=0;sampled_req<=0;sampled_valid<=0;end
  else begin sampled_data<=hd;sampled_req<=rx_req;sampled_valid<=rx_vld;end
 end
 function automatic [15:0] crc16_word(input [15:0] old,input [15:0] data);
  reg [15:0] value;integer k;
  begin
   value=old;
   for(k=0;k<16;k=k+1)value=(value>>1)^((value[0]^data[k])?16'ha001:16'd0);
   crc16_word=value;
  end
 endfunction
 reg receiving,pending_valid,data_mode,count_overflow;
 reg [1:0] header_words;
 reg [3:0] rx_sequence;
 reg [15:0] pending_data,crc_acc;
 reg [11:0] word_count;
 reg [31:0] command_magic,command_total,command_token;
 reg [15:0] command_version,command_operation;
 wire emit_word=receiving && sampled_valid && header_words==2 && pending_valid;
 wire [15:0] next_crc=crc16_word(crc_acc,sampled_data);
 reg end_pending,end_data_mode,end_overflow;
 reg [11:0] end_count;
 reg [15:0] end_crc;
 reg [3:0] end_sequence;
 wire command_good=end_count==32 && !end_overflow && command_magic==32'h42425348 &&
  command_version==1 && (command_operation==1 || command_operation==2) && command_total==4096;
 always @(posedge rx_clk or negedge rx_rst_n)begin
  if(!rx_rst_n)begin
   ack_meta<=0;ack_sync<=0;request_toggle<=0;
   receiving<=0;pending_valid<=0;data_mode<=0;count_overflow<=0;
   header_words<=0;rx_sequence<=0;pending_data<=0;crc_acc<=16'hffff;word_count<=0;
   command_magic<=0;command_total<=0;command_token<=0;command_version<=0;command_operation<=0;
   end_pending<=0;end_data_mode<=0;end_overflow<=0;end_count<=0;end_crc<=0;end_sequence<=0;
   operation<=0;total<=0;token<=0;trailer_crc_errors<=0;trailer_seq_errors<=0;length_bad<=0;padding_bad<=0;
  end else begin
   ack_meta<=ack_toggle;ack_sync<=ack_meta;end_pending<=0;
   if(!receiving)begin
    if(sampled_req)begin
     receiving<=1;pending_valid<=0;header_words<=0;word_count<=0;count_overflow<=0;crc_acc<=16'hffff;
     if(sampled_valid)begin header_words<=1;crc_acc<=crc16_word(16'hffff,sampled_data);end
    end
   end else begin
    if(sampled_valid)begin
     crc_acc<=next_crc;
     if(header_words<2)begin
      header_words<=header_words+1'b1;
      if(header_words==1)rx_sequence<=sampled_data[13:10];
     end else begin
      pending_data<=sampled_data;pending_valid<=1;
      if(pending_valid)begin
       if(word_count==4095)count_overflow<=1;else word_count<=word_count+1'b1;
       if(bank_free)begin
        // Shadow command fields never mutate published transaction metadata.
        case(word_count)
         0:command_magic[15:0]<=pending_data;1:command_magic[31:16]<=pending_data;
         2:command_version<=pending_data;3:command_operation<=pending_data;
         4:command_total[15:0]<=pending_data;5:command_total[31:16]<=pending_data;
         6:command_token[15:0]<=pending_data;7:command_token[31:16]<=pending_data;
         default:begin end
        endcase
        if(data_mode)begin
         if(word_count<512)bank[word_count[8:0]]<=pending_data;
         else if(pending_data!=0)padding_bad<=1;
        end
       end
      end
     end
    end
    if(!sampled_req)begin
     receiving<=0;pending_valid<=0;end_pending<=1;end_data_mode<=data_mode;
     end_count<=word_count+{11'd0,emit_word};end_overflow<=count_overflow || (word_count==4095 && emit_word);
     end_crc<=sampled_valid?next_crc:crc_acc;end_sequence<=rx_sequence;
    end
   end
   if(end_pending && bank_free)begin
    if(command_good)begin
     operation<=command_operation;total<=command_total;token<=command_token;
     // Fixed ALT1 business transactions contain one command and at most one
     // data frame: each per-transaction diagnostic is bounded by two.
     trailer_crc_errors<={31'd0,end_crc!=16'hb001};
     trailer_seq_errors<={31'd0,end_sequence!=0};
     length_bad<=0;padding_bad<=0;
     if(command_operation==1)data_mode<=1;
     else begin data_mode<=0;request_toggle<=~request_toggle;end
    end else if(end_data_mode && end_count!=0)begin
     trailer_crc_errors<={30'd0,trailer_crc_errors[1:0]+{1'b0,end_crc!=16'hb001}};
     trailer_seq_errors<={30'd0,trailer_seq_errors[1:0]+{1'b0,end_sequence!=1}};
     length_bad<=end_count!=2048 || end_overflow;data_mode<=0;request_toggle<=~request_toggle;
    end
    // Empty request pulses, partial headers and malformed physical commands
    // are drained without inventing an UP transaction from stale metadata.
   end
  end
 end

endmodule
`default_nettype wire

// TX divider stops during system reset. Both reset stages must assert even
// without a clock; release still requires two actual TX rising edges.
module usb3_tx_reset(input wire clk,ready,output wire rst_n);
 (* syn_preserve=1 *) reg meta=0,sync=0;
 always @(posedge clk or negedge ready)begin
  if(!ready)begin meta<=0;sync<=0;end
  else begin meta<=1;sync<=meta;end
 end
 assign rst_n=sync;
endmodule
