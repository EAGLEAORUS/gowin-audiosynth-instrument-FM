`default_nettype none
// Three legacy-labelled 25-key ranges. Local CH1 only, no extra event cycle.
module keyboard_octave #(parameter integer DEBOUNCE_CYCLES=500000,
 parameter integer PROMPT_CYCLES=150000000)(
 input wire clk,rst_n,up_n,down_n,online,event_valid,input wire [39:0] event_data,
 output reg [39:0] mapped_data,output reg [1:0] octave,
 output wire prompt,output reg direction_up);
 (* syn_preserve=1 *) reg [1:0] meta,sync;
 reg [1:0] stable,press;
 localparam integer DB=DEBOUNCE_CYCLES>1?$clog2(DEBOUNCE_CYCLES):1;
 localparam integer PB=PROMPT_CYCLES>1?$clog2(PROMPT_CYCLES+1):1;
 reg [DB-1:0] up_count,down_count;
 reg [PB-1:0] remaining;
 // Capture each key's range on NoteOn, so a range change cannot strand NoteOff.
 reg [1:0] held_range[0:24];reg [24:0] held;
 wire piano=event_data[39:36]==0 && event_data[27:24]==0 &&
  event_data[23:17]>=7'd48 && event_data[23:17]<=7'd72;
 wire on=event_data[31:28]==2 && event_data[16:10]!=0;
 wire off=event_data[31:28]==1 || (event_data[31:28]==2 && event_data[16:10]==0);
 wire [4:0] key_index=event_data[23:17]-7'd48;
 wire [1:0] key_range=held[key_index]?held_range[key_index]:octave;
 assign prompt=remaining!=0;
 always @*begin
  mapped_data=event_data;
  if(piano && (on || off))case(key_range)
   0:mapped_data[23:17]=event_data[23:17]-7'd24;
   2:mapped_data[23:17]=event_data[23:17]+7'd24;
   default:mapped_data[23:17]=event_data[23:17];
  endcase
 end
 integer i;
 always @(posedge clk)begin
  if(!rst_n)begin
   meta<=3;sync<=3;stable<=3;press<=0;up_count<=0;down_count<=0;
   octave<=1;remaining<=0;direction_up<=1;held<=0;
   for(i=0;i<25;i=i+1)held_range[i]<=1;
  end else begin
   meta<={down_n,up_n};sync<=meta;press<=0;
   if(sync[0]==stable[0])up_count<=0;
   else if(up_count==DEBOUNCE_CYCLES-1)begin up_count<=0;stable[0]<=sync[0];press[0]<=!sync[0];end
   else up_count<=up_count+1'b1;
   if(sync[1]==stable[1])down_count<=0;
   else if(down_count==DEBOUNCE_CYCLES-1)begin down_count<=0;stable[1]<=sync[1];press[1]<=!sync[1];end
   else down_count<=down_count+1'b1;
   if(remaining!=0)remaining<=remaining-1'b1;
   // Simultaneous keys cancel; repeated presses at an endpoint keep its label.
   if(press==1)begin if(octave!=2)octave<=octave+1'b1;remaining<=PROMPT_CYCLES;direction_up<=1;end
   if(press==2)begin if(octave!=0)octave<=octave-1'b1;remaining<=PROMPT_CYCLES;direction_up<=0;end
   if(!online)held<=0;
   else if(event_valid && piano)begin
    if(on)begin held[key_index]<=1;held_range[key_index]<=key_range;end
    if(off)held[key_index]<=0;
   end else if(event_valid && event_data[27:24]==0 && event_data[31:28]==3 &&
    (event_data[23:17]==120 || event_data[23:17]==123))held<=0;
  end
 end
endmodule
`default_nettype wire
