`default_nettype none
// ROM1A FLUTE 1: shared 64-sample triangle LFO, sync0, delay23, speed30.
// Local Apache-2.0 MSFA/Dexed lfo.cc and dx7note.cc formulas, no PCM model.
// PM log2 step128 Q24 (<0.00458 cents rounded); AM sensamp step1024.
module instrument_flute_lfo(input wire clk,rst_n,sample_tick,keydown,
 input wire [23:0] bend_ratio,output reg [23:0] ratio,output reg [17:0] am_pt);
 reg [5:0] block_pos;reg [31:0] phase,delay_state;
 reg [24:0] triangle,delay_value;reg [4:0] state;
 reg [23:0] bend;reg [28:0] pmd;reg signed [28:0] senslfo;
 reg signed [58:0] pm_product;reg [29:0] amd;reg [46:0] am_product;
 reg signed [23:0] pm_log;reg [21:0] am_depth;reg [44:0] sensamp;
 reg [9:0] pitch_addr,amp_addr;
 wire [23:0] table_ratio;wire [17:0] table_pt;
 instrument_flute_lfo_tables tables(clk,pitch_addr,amp_addr,table_ratio,table_pt);
 reg [47:0] product;reg [23:0] digits,factor;reg [2:0] iter;
 wire [31:0] phase_next=phase+32'd28486596;
 wire [23:0] triangle_next=phase_next[31]?~phase_next[30:7]:phase_next[30:7];
 wire [32:0] delay_next={1'b0,delay_state}+33'd30093952;
 function [26:0] term;
  input [23:0] x;input [2:0] d;reg [26:0] z;
  begin z={3'd0,x};case(d)
   0:term=0;1:term=z;2:term=z<<1;3:term=(z<<1)+z;
   4:term=z<<2;5:term=(z<<2)+z;6:term=(z<<2)+(z<<1);default:term=(z<<3)-z;
  endcase end
 endfunction
 always @(posedge clk)begin
  if(!rst_n)begin
   block_pos<=0;phase<=0;delay_state<=0;triangle<=0;delay_value<=0;
   state<=0;bend<=24'd4194304;ratio<=24'd4194304;am_pt<=0;
   pmd<=0;senslfo<=0;pm_product<=0;amd<=0;am_product<=0;pm_log<=0;am_depth<=0;sensamp<=0;
   pitch_addr<=0;amp_addr<=0;product<=0;digits<=0;factor<=0;iter<=0;
  end else begin
   if(keydown)begin delay_state<=0;delay_value<=0;end
   if(sample_tick)begin
    block_pos<=block_pos+1'b1;state<=1;
    if(block_pos==0)begin
     phase<=phase_next;triangle<={1'b0,triangle_next};
     if(!keydown)begin
      delay_state<=delay_next[32]?32'hffffffff:delay_next[31:0];
      delay_value<=delay_next[32]?25'd16777216:(delay_next[31]?{1'b0,delay_next[30:7]}:25'd0);
     end
    end
   end else case(state)
    1:begin bend<=bend_ratio;pmd<=delay_value*5'd20;senslfo<=($signed({1'b0,triangle})-29'sd8388608)*29'sd10;amd<=delay_value*6'd33;state<=2;end
    2:begin pm_product<=$signed({1'b0,pmd})*senslfo;am_product<=(amd>>8)*(25'd16777216-triangle);state<=3;end
    3:begin pm_log<=pm_product>>>39;am_depth<=am_product>>24;state<=4;end
    4:begin sensamp<=am_depth*23'd4342338;state<=5;end
    5:begin pitch_addr<=($signed(pm_log)+24'sd64)>>>7;amp_addr<=sensamp[43:34];state<=6;end
    6:state<=7;
    7:begin factor<=table_ratio;digits<=bend;product<=0;am_pt<=table_pt;iter<=0;state<=8;end
    8:begin product<=(product<<3)+{21'd0,term(factor,digits[23:21])};digits<=digits<<3;
     if(iter==7)state<=9;else iter<=iter+1'b1;
    end
    9:begin ratio<=product[45:22]+{23'd0,product[21]};state<=0;end
    default:begin end
   endcase
  end
 end
endmodule
`default_nettype wire
