`default_nettype none
// Exact 240.395 Hz quarter-frame accumulator: 48000*200=9600000.
// Update occurs BEFORE returning the sample, matching nes_env_4bit.m.
module nes_env_4bit(
 input wire clk,rst_n,sample_tick,restart,loop_enable,input wire [3:0] rate,
 output wire [3:0] level
);
 reg [23:0] acc;reg [3:0] divider,cur;
 wire [24:0] advanced={1'b0,acc}+25'd48079;
 wire qframe=advanced>=25'd9600000;
 wire decay=qframe && divider==rate;
 assign level=decay?(cur!=0?cur-1'b1:loop_enable?4'd15:4'd0):cur;
 always @(posedge clk)begin
  if(!rst_n || restart)begin acc<=0;divider<=0;cur<=15;end
  else if(sample_tick)begin
   acc<=qframe?advanced-25'd9600000:advanced[23:0];
   if(qframe)begin divider<=decay?4'd0:divider+1'b1;cur<=level;end
  end
 end
endmodule
`default_nettype wire
