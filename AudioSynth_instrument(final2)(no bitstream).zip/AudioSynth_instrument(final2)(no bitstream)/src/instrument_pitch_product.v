`default_nettype none
// Exact unsigned32x24->56; four-edge latency, one input/result per clock.
// Both native signed DSP operands have four leading zeros.
// Keep independent multiply primitives: no shifted DSP cascade inference.
module instrument_pitch_product(input wire clk,input wire [31:0] fcw,input wire [23:0] ratio,output reg [55:0] product);
 wire [23:0] partial[0:11];
 reg [31:0] words[0:3];reg [39:0] low,high;
 MULT12X12 #(.AREG_CLK("BYPASS"),.BREG_CLK("BYPASS"),.PREG_CLK("BYPASS"),.OREG_CLK("CLK0"),.OREG_CE("CE0"),.MULT_RESET_MODE("SYNC")) m0(
 .DOUT(partial[0]),.A({4'd0,fcw[0+:8]}),.B({4'd0,ratio[0+:8]}),.CLK({1'b0,clk}),.CE(2'b01),.RESET(2'b00));
 MULT12X12 #(.AREG_CLK("BYPASS"),.BREG_CLK("BYPASS"),.PREG_CLK("BYPASS"),.OREG_CLK("CLK0"),.OREG_CE("CE0"),.MULT_RESET_MODE("SYNC")) m1(
 .DOUT(partial[1]),.A({4'd0,fcw[0+:8]}),.B({4'd0,ratio[8+:8]}),.CLK({1'b0,clk}),.CE(2'b01),.RESET(2'b00));
 MULT12X12 #(.AREG_CLK("BYPASS"),.BREG_CLK("BYPASS"),.PREG_CLK("BYPASS"),.OREG_CLK("CLK0"),.OREG_CE("CE0"),.MULT_RESET_MODE("SYNC")) m2(
 .DOUT(partial[2]),.A({4'd0,fcw[0+:8]}),.B({4'd0,ratio[16+:8]}),.CLK({1'b0,clk}),.CE(2'b01),.RESET(2'b00));
 MULT12X12 #(.AREG_CLK("BYPASS"),.BREG_CLK("BYPASS"),.PREG_CLK("BYPASS"),.OREG_CLK("CLK0"),.OREG_CE("CE0"),.MULT_RESET_MODE("SYNC")) m3(
 .DOUT(partial[3]),.A({4'd0,fcw[8+:8]}),.B({4'd0,ratio[0+:8]}),.CLK({1'b0,clk}),.CE(2'b01),.RESET(2'b00));
 MULT12X12 #(.AREG_CLK("BYPASS"),.BREG_CLK("BYPASS"),.PREG_CLK("BYPASS"),.OREG_CLK("CLK0"),.OREG_CE("CE0"),.MULT_RESET_MODE("SYNC")) m4(
 .DOUT(partial[4]),.A({4'd0,fcw[8+:8]}),.B({4'd0,ratio[8+:8]}),.CLK({1'b0,clk}),.CE(2'b01),.RESET(2'b00));
 MULT12X12 #(.AREG_CLK("BYPASS"),.BREG_CLK("BYPASS"),.PREG_CLK("BYPASS"),.OREG_CLK("CLK0"),.OREG_CE("CE0"),.MULT_RESET_MODE("SYNC")) m5(
 .DOUT(partial[5]),.A({4'd0,fcw[8+:8]}),.B({4'd0,ratio[16+:8]}),.CLK({1'b0,clk}),.CE(2'b01),.RESET(2'b00));
 MULT12X12 #(.AREG_CLK("BYPASS"),.BREG_CLK("BYPASS"),.PREG_CLK("BYPASS"),.OREG_CLK("CLK0"),.OREG_CE("CE0"),.MULT_RESET_MODE("SYNC")) m6(
 .DOUT(partial[6]),.A({4'd0,fcw[16+:8]}),.B({4'd0,ratio[0+:8]}),.CLK({1'b0,clk}),.CE(2'b01),.RESET(2'b00));
 MULT12X12 #(.AREG_CLK("BYPASS"),.BREG_CLK("BYPASS"),.PREG_CLK("BYPASS"),.OREG_CLK("CLK0"),.OREG_CE("CE0"),.MULT_RESET_MODE("SYNC")) m7(
 .DOUT(partial[7]),.A({4'd0,fcw[16+:8]}),.B({4'd0,ratio[8+:8]}),.CLK({1'b0,clk}),.CE(2'b01),.RESET(2'b00));
 MULT12X12 #(.AREG_CLK("BYPASS"),.BREG_CLK("BYPASS"),.PREG_CLK("BYPASS"),.OREG_CLK("CLK0"),.OREG_CE("CE0"),.MULT_RESET_MODE("SYNC")) m8(
 .DOUT(partial[8]),.A({4'd0,fcw[16+:8]}),.B({4'd0,ratio[16+:8]}),.CLK({1'b0,clk}),.CE(2'b01),.RESET(2'b00));
 MULT12X12 #(.AREG_CLK("BYPASS"),.BREG_CLK("BYPASS"),.PREG_CLK("BYPASS"),.OREG_CLK("CLK0"),.OREG_CE("CE0"),.MULT_RESET_MODE("SYNC")) m9(
 .DOUT(partial[9]),.A({4'd0,fcw[24+:8]}),.B({4'd0,ratio[0+:8]}),.CLK({1'b0,clk}),.CE(2'b01),.RESET(2'b00));
 MULT12X12 #(.AREG_CLK("BYPASS"),.BREG_CLK("BYPASS"),.PREG_CLK("BYPASS"),.OREG_CLK("CLK0"),.OREG_CE("CE0"),.MULT_RESET_MODE("SYNC")) m10(
 .DOUT(partial[10]),.A({4'd0,fcw[24+:8]}),.B({4'd0,ratio[8+:8]}),.CLK({1'b0,clk}),.CE(2'b01),.RESET(2'b00));
 MULT12X12 #(.AREG_CLK("BYPASS"),.BREG_CLK("BYPASS"),.PREG_CLK("BYPASS"),.OREG_CLK("CLK0"),.OREG_CE("CE0"),.MULT_RESET_MODE("SYNC")) m11(
 .DOUT(partial[11]),.A({4'd0,fcw[24+:8]}),.B({4'd0,ratio[16+:8]}),.CLK({1'b0,clk}),.CE(2'b01),.RESET(2'b00));
 integer i;
 always @(posedge clk)begin
  for(i=0;i<4;i=i+1)words[i]<={16'd0,partial[i*3][15:0]}+{8'd0,partial[i*3+1][15:0],8'd0}+{partial[i*3+2][15:0],16'd0};
  low<={8'd0,words[0]}+{words[1],8'd0};
  high<={8'd0,words[2]}+{words[3],8'd0};
  product<={16'd0,low}+{high,16'd0};
 end
endmodule
`default_nettype wire
