`default_nettype none
// I2S, WS=0 left, one rising edge delay, exactly 24 MSB-first data bits.
// Discard partial words at reset and malformed slots; commit atomic L/R only.
module audio_usb_i2s_rx24 #(parameter integer DATA_WIDTH=24)(
 input wire sck,rst_n,ws,sda, output reg valid,
 output reg signed [23:0] left,right, output reg [31:0] frame_errors
);
 reg ws_old,armed,seen,have_left,have_right;
 reg [5:0] bit_count;
 reg [23:0] shift,left_hold,right_hold;
 wire [23:0] next_word={shift[22:0],sda};
 always @(posedge sck) begin
  if(!rst_n) begin
   ws_old<=0;armed<=0;seen<=0;have_left<=0;have_right<=0;right_hold<=0;bit_count<=0;shift<=0;left_hold<=0;
   valid<=0;left<=0;right<=0;frame_errors<=0;
  end else begin
   valid<=0;
   ws_old<=ws;
   if(!armed)armed<=1;
   else if(ws!=ws_old) begin
    if(seen && bit_count!=31) begin frame_errors<=frame_errors+1'b1;have_left<=0;have_right<=0;end
    else if(!ws && have_left && have_right)begin
     left<=left_hold;right<=right_hold;valid<=1;have_left<=0;have_right<=0;
    end
    seen<=1;bit_count<=0;shift<=0;
   end else if(seen) begin
    if(bit_count<63)bit_count<=bit_count+1'b1;
    // First sample AFTER the boundary edge is the MSB, not the boundary bit.
    if(bit_count<DATA_WIDTH)begin
     shift<=next_word;
     if(bit_count==DATA_WIDTH-1)begin
      if(!ws)begin left_hold<=(DATA_WIDTH==16)?{next_word[15:0],8'd0}:next_word;have_left<=1;end
      else if(have_left)begin right_hold<=(DATA_WIDTH==16)?{next_word[15:0],8'd0}:next_word;have_right<=1;end
     end
    end
   end
  end
 end
endmodule
`default_nettype wire
