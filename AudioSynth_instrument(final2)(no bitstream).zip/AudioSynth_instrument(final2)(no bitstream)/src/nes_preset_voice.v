`default_nettype none
// One arithmetic lane shared by all eight slots. No PS work at audio rate.
module nes_preset_voice(
 input wire clk,rst_n,go,restart,release_note,
 input wire [3:0] key,input wire [6:0] velocity,
 input wire [189:0] context_in,output wire [189:0] context_out,
 output reg [5:0] addr,input wire [31:0] word,
 output reg done,active,output reg signed [15:0] pcm
);
 localparam IDLE=0,HEADER=1,NODES=2,EXTRA=3,CONTROL=4,DIVIDE=5,
           CURVE=6,LEVELS=7,CARRIER=8,MIX=9,GAIN=10,OUTPUT=11,
           PRECURVE=12,ENV=13,LINEAR=14;
 reg [3:0] state;
 reg [5:0] index;
 reg [15:0] flags;
 reg [17:0] attack,rel,hold,period,sweep;
 reg [23:0] phase,residue;
 reg [14:0] lfsr;
 reg [16:0] previous;
 reg signed [26:0] highpass;
 reg [18:0] age;
 reg [17:0] release_age;
 reg [17:0] tail,pitch_clock;
 reg releasing;
 reg [4:0] pitch_index;
 reg [11:0] t0,t1;
 reg [15:0] l0,l1,levels;
 reg [23:0] seq_fcw,sweep_base;
 reg signed [24:0] sweep_delta;
 reg [23:0] final_fcw;
 reg [3:0] key_q;
 reg [6:0] velocity_q;
 reg release_q;
 reg [4:0] count;
 reg [17:0] rem_attack,rem_release,rem_level,rem_sweep;
 reg [16:0] qa,qr,ql;
 reg [24:0] qs;
 reg [17:0] den_attack,den_release,den_level,den_sweep;
 reg [16:0] env, blend, attack_curve, release_curve;
 reg [33:0] release_square;
 reg [17:0] level_elapsed,level_span;
 reg [23:0] numerator1,numerator2,numerator_n;
 reg [3:0] linear1,linear2,linear_n;
 reg [1:0] linear_bit;
 reg signed [25:0] sweep_integer;
 reg [23:0] sweep_fraction;
 reg signed [50:0] sweep_upper;
 reg [47:0] sweep_lower;
 reg signed [50:0] sweep_product;
 reg signed [45:0] sample_product;
 reg [23:0] gain;
 reg [3:0] triangle;
 wire [6:0] unused;
 wire [23:0] mapped;
 nes_note_map pitch(key_q,unused,mapped);
 wire [17:0] node_time=({6'd0,word[27:16]}<<5)+({6'd0,word[27:16]}<<4);
 wire [17:0] lo_time=({6'd0,t0}<<5)+({6'd0,t0}<<4);
 wire [17:0] hi_time=({6'd0,t1}<<5)+({6'd0,t1}<<4);
 wire [18:0] a_pos=releasing ? release_age : age;
 wire [17:0] played_attack=a_pos>=attack?attack:a_pos[17:0];
 wire [17:0] s_pos=age<sweep?sweep-age:18'd0;
 wire [33:0] env_product=attack_curve*(flags[1] && hold!=0 ? release_square[32:16]:release_curve);
 wire [23:0] trial={6'd0,level_span}<<linear_bit;
 wire [23:0] noise_step=residue+24'd1789773;
 wire [16:0] mixed;
 wire [3:0] p1=phase[23:21]>=6?levels[15:12]:4'd0;
 wire [3:0] p2=phase[23:21]==7?levels[11:8]:4'd0;
 wire [3:0] n=lfsr[0]?levels[3:0]:4'd0;
 wire [3:0] raw_triangle=phase[23]?phase[22:19]:4'd15-phase[22:19];
 wire [7:0] triangle_product=raw_triangle*levels[7:4]+8'd7;
 // Floor division by 15, exact over 0..232.
 wire [3:0] triangle_scaled=(triangle_product+8'd1+(triangle_product>>4))>>4;
 nes_mixer_lut mixer(p1,p2,triangle,n,mixed);
 wire signed [27:0] delta=$signed({1'b0,mixed,8'd0})-$signed({1'b0,previous,8'd0});
 wire signed [27:0] dc=delta+$signed(highpass)-($signed(highpass)>>>9);
 wire signed [26:0] scaled=(sample_product+46'sd4194304)>>>23;
 assign context_out={phase,residue,lfsr,previous,highpass,age,tail,pitch_clock,releasing,pitch_index,release_age,4'd0};

 function [16:0] smooth;
  input [16:0] t;
  reg [33:0] t2;
  reg [35:0] result;
  begin t2=t*t;result=t2[32:16]*(19'd196608-({2'd0,t}<<1));smooth=result[32:16];end
 endfunction
 function [34:0] divide;
  input [17:0] rem_in,den;
  input [16:0] quotient;
  reg [18:0] twice;
  reg [17:0] rest;
  begin
   twice={rem_in,1'b0};
   rest=twice>=den ? twice-den:twice[17:0];
   divide=quotient[16]?{rem_in,quotient}:{rest,quotient[15:0],twice>=den};
  end
 endfunction
 function [42:0] divide_sweep;
  input [17:0] rem_in,den;
  input [24:0] quotient;
  reg [18:0] twice;
  reg [17:0] rest;
  begin
   twice={rem_in,1'b0};
   rest=twice>=den ? twice-den:twice[17:0];
   divide_sweep=quotient[24]?{rem_in,quotient}:{rest,quotient[23:0],twice>=den};
  end
 endfunction
 function [3:0] lerp;
  input [3:0] a,b;
  input [16:0] weight;
  reg [21:0] total;
  begin total=a*(17'd65536-weight)+b*weight+22'd32768;lerp=total[19:16];end
 endfunction


 always @(posedge clk)begin
  if(!rst_n)begin state<=IDLE;done<=0;active<=0;pcm<=0;addr<=0;end
  else begin
   done<=0;
   case(state)
    IDLE:if(go)begin
     if(restart)begin
      phase<=0;residue<=0;lfsr<=1;previous<=0;highpass<=0;
      age<=0;tail<=0;pitch_clock<=0;releasing<=0;pitch_index<=0;release_age<=0;
     end else {phase,residue,lfsr,previous,highpass,age,tail,pitch_clock,releasing,pitch_index,release_age}<=context_in[189:4];
     key_q<=key;velocity_q<=velocity;release_q<=release_note;
     addr<=1;index<=0;state<=HEADER;
    end
    // The controller presents word 0 at go, with a synchronous BSRAM read.
    HEADER:begin
     addr<=addr+1'b1;index<=index+1'b1;
     case(index)
      0:flags<=word[15:0];
      1:attack<=word[17:0];
      2:rel<=word[17:0];
      3:hold<=word[17:0];
      4:period<=word[17:0];
      5:begin
       sweep<=word[17:0];addr<=8;index<=0;count<=0;
       t0<=0;t1<=0;l0<=0;l1<=0;state<=NODES;
      end
      default:begin end
     endcase
    end
    NODES:begin
     if(index==0)begin index<=1;addr<=9;end
     else begin
      if(count==0 || node_time<=age)begin t0<=word[27:16];l0<=word[15:0];end
      t1<=word[27:16];l1<=word[15:0];
      if((count!=0 && node_time>age) || count+1'b1==flags[10:6])begin
       addr<=flags[5]?{1'b1,key_q,1'b0}:6'd24+{1'b0,pitch_index};
       index<=0;state<=EXTRA;
      end else begin count<=count+1'b1;addr<=addr+1'b1;end
     end
    end
    EXTRA:begin
     addr<=addr+1'b1;index<=index+1'b1;
     if(index==1)begin seq_fcw<=word[23:0];sweep_base<=word[23:0];end
     if(index==2)begin
      sweep_delta<=word[24:0];
      if(!releasing && (hold!=0 ? age>=hold:release_q))begin releasing<=1;tail<=0;release_age<=age>=attack?attack:age[17:0];end
      state<=CONTROL;
     end
    end
    CONTROL:begin
     den_attack<=attack;den_release<=rel-1'b1;den_level<=hi_time-lo_time;den_sweep<=sweep;
     rem_attack<=played_attack;rem_release<=tail;rem_level<=age-lo_time;rem_sweep<=s_pos;
     qa<=a_pos>=attack?17'd65536:17'd0;
     qr<=tail>=rel-1'b1 ? 17'd65536:17'd0;
     ql<=age>=hi_time?17'd65536:17'd0;
     qs<=s_pos>=sweep?25'd16777216:25'd0;
     count<=0;state<=DIVIDE;
    end
    DIVIDE:begin
     if(count<16)begin
     {rem_attack,qa}<=divide(rem_attack,den_attack,qa);
     {rem_release,qr}<=divide(rem_release,den_release,qr);
     {rem_level,ql}<=divide(rem_level,den_level,ql);
     end
     {rem_sweep,qs}<=divide_sweep(rem_sweep,den_sweep,qs);
     count<=count+1'b1;
     if(count==(flags[5]?23:15))state<=PRECURVE;
    end
    PRECURVE:begin
     attack_curve<=smooth(qa);release_curve<=17'd65536-smooth(qr);
     blend<=smooth(ql);
     level_elapsed<=(age>=hi_time?hi_time:age)-lo_time;
     level_span<=hi_time-lo_time;
     sweep_product<=sweep_delta*$signed({1'b0,qs});
     state<=CURVE;
    end
    CURVE:begin
     release_square<=release_curve*release_curve;
     sweep_integer<=sweep_product[49:24];
     sweep_fraction<=sweep_product[23:0];
     numerator1<=l0[15:12]*(level_span-level_elapsed)+l1[15:12]*level_elapsed+(level_span>>1);
     numerator2<=l0[11:8]*(level_span-level_elapsed)+l1[11:8]*level_elapsed+(level_span>>1);
     numerator_n<=l0[3:0]*(level_span-level_elapsed)+l1[3:0]*level_elapsed+(level_span>>1);
     linear1<=0;linear2<=0;linear_n<=0;linear_bit<=3;
     state<=flags[1] || level_span==0?ENV:LINEAR;
    end
    LINEAR:begin
     if(numerator1>=trial)begin numerator1<=numerator1-trial;linear1[linear_bit]<=1;end
     if(numerator2>=trial)begin numerator2<=numerator2-trial;linear2[linear_bit]<=1;end
     if(numerator_n>=trial)begin numerator_n<=numerator_n-trial;linear_n[linear_bit]<=1;end
     if(linear_bit==0)state<=ENV;
     else linear_bit<=linear_bit-1'b1;
    end
    ENV:begin
     sweep_upper<=sweep_integer*$signed({1'b0,qs});
     sweep_lower<=sweep_fraction*qs;
     env<=env_product[32:16];
     if(flags[1])levels<={lerp(l0[15:12],l1[15:12],blend),lerp(l0[11:8],l1[11:8],blend),
                         lerp(l0[7:4],l1[7:4],blend),lerp(l0[3:0],l1[3:0],blend)};
     else levels<=level_span==0?l0:{linear1,linear2,l0[7:4],linear_n};
     state<=LEVELS;
    end
    LEVELS:begin
     gain<=env*velocity_q;
     sweep_product<=sweep_upper+$signed({27'd0,sweep_lower[47:24]});
     state<=CARRIER;
    end
    CARRIER:begin
     final_fcw<=flags[5]?sweep_base+($signed(sweep_product)>>>24):
                flags[15:11]!=0?seq_fcw:mapped>>flags[3:2];
     triangle<=triangle_scaled;
     state<=MIX;
    end
    MIX:begin
     previous<=mixed;highpass<=dc[26:0];
     phase<=phase+final_fcw;
     if(noise_step>=24'd12192000)begin
      residue<=noise_step-24'd12192000;
      lfsr<={lfsr[0]^lfsr[1],lfsr[14:1]};
     end else residue<=noise_step;
     if(age!=19'h7ffff)age<=age+1'b1;
     if(releasing)tail<=tail+1'b1;
     if(flags[15:11]!=0)begin
      if(pitch_clock+1'b1>=period)begin
       pitch_clock<=0;
       if(pitch_index+1'b1<flags[15:11])pitch_index<=pitch_index+1'b1;
       else if(flags[4])pitch_index<=0;
      end else pitch_clock<=pitch_clock+1'b1;
     end
     state<=GAIN;
    end
    GAIN:begin
     // Natural level scale is shared with the historical 8-bit lane; stock
     // retains its separate PCM scaling and bit-exact path.
     sample_product<=$signed(highpass[26:8])*$signed({1'b0,gain});
     state<=OUTPUT;
    end
    OUTPUT:begin
     pcm<=scaled>32767?16'sh7fff:scaled< -32768?16'sh8000:scaled[15:0];
     active<=!releasing || tail<rel;done<=1;state<=IDLE;
    end
    default:state<=IDLE;
   endcase
  end
 end
endmodule
`default_nettype wire
