`default_nettype none
// Serial control port ahead of four existing arithmetic lanes. The musical
// owner supplies slot_safe after stopping a stolen slot at a frame boundary.
// Accepted writes are token-checked BEFORE the actual config RAM write pulse.
// Commit is held until the owner can start the note at a safe frame boundary.
module sd_tdm_config_port #(parameter integer ABORT_ENABLE=0,parameter integer VOICES=40)(input wire clk,rst_n,
 input wire req_valid,output wire req_ready,input wire[2:0] req_kind,
 input wire[5:0] req_slot,input wire[31:0] req_token,input wire[2:0] req_op,
 input wire[107:0] req_data,input wire[7:0] req_meta,input wire[6:0] req_note,req_velocity,
 input wire[VOICES-1:0] slot_safe,input wire commit_ready,
 output reg resp_valid,resp_ok,output reg[31:0] resp_token,
 output wire cfg_we,meta_we,output wire[5:0] cfg_slot,output wire[2:0] cfg_op,
 output wire[107:0] cfg_data,output wire[7:0] meta_data,
 output wire commit_valid,output wire[5:0] commit_slot,output wire[6:0] commit_note,commit_velocity,
 output wire[VOICES-1:0] reserved,input wire abort);
 reg[1:0] state;reg request;reg[2:0] kind,op;reg[5:0] slot;reg[31:0] token;
 reg[107:0] data;reg[7:0] metadata;reg[6:0] note,velocity;
 wire lease_ready,lease_valid,lease_ok,lease_commit,lease_op,lease_meta;wire[31:0] lease_token;wire[VOICES-1:0] lease_reserved;
 wire aborting=ABORT_ENABLE && abort;
 sd_voice_lease #(.CANCEL_ALL_ENABLE(1),.VOICES(VOICES)) guard(clk,rst_n,request,kind,slot,token,op,lease_ready,lease_valid,lease_ok,lease_token,lease_op,lease_meta,lease_commit,cfg_slot,lease_reserved,aborting);
 assign cfg_we=lease_op && !aborting;assign meta_we=lease_meta && !aborting;
 assign req_ready=state==0 && lease_ready && !aborting;
 assign cfg_op=op;assign cfg_data=data;assign meta_data=metadata;
 assign commit_valid=state==2 && !aborting;assign commit_slot=slot;assign commit_note=note;assign commit_velocity=velocity;
 assign reserved=lease_reserved | (state==2?({{(VOICES-1){1'b0}},1'b1}<<slot):{VOICES{1'b0}});
 always @(posedge clk)begin
  if(!rst_n)begin state<=0;request<=0;kind<=0;op<=0;slot<=0;token<=0;data<=0;metadata<=0;note<=0;velocity<=0;resp_valid<=0;resp_ok<=0;resp_token<=0;end
  else if(aborting)begin state<=0;request<=0;resp_valid<=0;resp_ok<=0;end
  else begin
   request<=0;resp_valid<=0;
   case(state)
    0:if(req_valid && req_ready)begin
     if(req_kind==0 && req_slot<VOICES && !slot_safe[req_slot])begin resp_valid<=1;resp_ok<=0;resp_token<=req_token;end
     else begin kind<=req_kind;op<=req_op;slot<=req_slot;token<=req_token;data<=req_data;metadata<=req_meta;note<=req_note;velocity<=req_velocity;request<=1;state<=1;end
    end
    1:if(lease_valid)begin
     resp_ok<=lease_ok;resp_token<=lease_token;
     if(lease_commit)state<=2;else begin resp_valid<=1;state<=0;end
    end
    2:if(commit_ready)begin resp_valid<=1;resp_ok<=1;state<=0;end
    default:state<=0;
   endcase
  end
 end
endmodule
`default_nettype wire
