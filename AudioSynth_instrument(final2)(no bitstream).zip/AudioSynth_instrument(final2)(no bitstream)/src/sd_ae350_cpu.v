`default_nettype none
// Official AE350 hard macro wrapper. 200MHz core + synchronous 50MHz AHB/APB,
// 10MHz RTC; dedicated CORE clock uses PLL_R[0]/CLKOUT1. No DDR or Flash IP.
module sd_ae350_cpu(input wire clk,rst_n,input wire [31:0] prdata,input wire pready,
 output wire psel,penable,pwrite,output wire [31:0] paddr,pwdata,output wire [3:0] pstrb);
 wire cpuclk,rtcclk,locked;
 sd_ae350_pll50 pll(.clkin(clk),.clkout1(cpuclk),.clkout4(rtcclk),.locked(locked),
  .enclk0(1'b1),.enclk1(1'b1),.enclk2(1'b1),.enclk3(1'b1),.enclk4(1'b1));
 reg [19:0] warmup=0;
 always @(posedge clk)if(!rst_n || !locked)warmup<=0;else if(!(&warmup))warmup<=warmup+1'b1;
 wire assert_n=rst_n && locked;
 (* ASYNC_REG="TRUE",syn_preserve=1 *)reg [1:0] reset_core=0;
 // The official AE350 SDK drives POR_RSTN/HW_RSTN from a 50MHz
 // reset controller. CLKOUT1 is reserved for the dedicated hard CPU pin.
 always @(posedge clk or negedge assert_n)if(!assert_n)reset_core<=0;else reset_core<={reset_core[0],warmup[19]};
 wire [31:0] rom_addr,rom_data;wire rom_clk;
 RiscV_AE350_SOC_Top soc(.CORE_CLK(cpuclk),.DDR_CLK(clk),.AHB_CLK(clk),.APB_CLK(clk),.RTC_CLK(rtcclk),
  .POR_RSTN(reset_core[1]),.HW_RSTN(reset_core[1]),.TCK_IN(1'b0),.TMS_IN(1'b1),.TRST_IN(1'b1),.TDI_IN(1'b0),
  .ROM_HRDATA(rom_data),.ROM_HREADY(1'b1),.ROM_HRESP(1'b0),.ROM_HADDR(rom_addr),.ROM_HCLK(rom_clk),
  .DDR_HRDATA(64'd0),.DDR_HREADY(1'b1),.DDR_HRESP(1'b0),
  .APB_PRDATA(prdata),.APB_PREADY(pready),.APB_PSLVERR(1'b0),.APB_PADDR(paddr),.APB_PWDATA(pwdata),
  .APB_PSEL(psel),.APB_PENABLE(penable),.APB_PWRITE(pwrite),.APB_PSTRB(pstrb));
 sd_ae350_boot_rom rom(rom_clk,rom_addr,rom_data);
endmodule
`default_nettype wire
