`default_nettype none
// DAC boundaries generate a slow toggle, synchronized into 50MHz. PCM returns
// through a WHOLE stereo frame FIFO. No PCM bus uses two-flop synchronization.
module instrument_audio_adapter #(parameter TRACE_ENABLE=0)(
 input wire clk_50m,common_ready,event_valid,input wire [39:0] event_data,
 input wire online,fault,input wire [2:0] patch_select,input wire bclk,tx_rst_n,ws,
 output wire sdout,output wire [31:0] underrun,
 input wire signed [15:0] nes_pcm,output wire nes_rst_n,nes_sample_tick,
 input wire [23:0] string_ratio,output wire [23:0] string_bend_ratio,
 input wire [95:0] event_tag,output wire capture_valid,output wire [47:0] capture_pcm,
 output reg [31:0] capture_index,output wire exec_valid,output wire [39:0] exec_data,output wire [95:0] exec_tag,
 output wire [575:0] actual_state
);
 wire core_rst_n,read_rst_n;
 audio_usb_reset reset_core(clk_50m,common_ready,core_rst_n);
 audio_usb_reset reset_read(bclk,common_ready,read_rst_n);
 wire tx_ready;
 (* syn_preserve=1 *) reg frame_toggle;
 always @(posedge bclk or negedge read_rst_n)
  if(!read_rst_n)frame_toggle<=0;else if(tx_ready)frame_toggle<=~frame_toggle;
 (* syn_preserve=1 *) reg tick_meta,tick_sync;
 reg tick_old;
 always @(posedge clk_50m)begin
  if(!core_rst_n)begin tick_meta<=0;tick_sync<=0;tick_old<=0;end
  else begin tick_meta<=frame_toggle;tick_sync<=tick_meta;tick_old<=tick_sync;end
 end
 // Register the domain-local edge pulse before the high-fanout audio enables.
 (* syn_preserve=1 *) reg sample_tick /* synthesis syn_maxfan=16 */;
 always @(posedge clk_50m)if(!core_rst_n)sample_tick<=0;else sample_tick<=tick_sync!=tick_old;
 wire signed [23:0] pcm;wire pcm_valid,wr_ready,rd_valid;
 wire [47:0] frame;
 (* syn_keep=1 *) wire [39:0] busy,gate,releasing;
 (* syn_keep=1 *) wire [31:0] deadline_miss,clips,range_errors,event_overflow,pcm_overflow;
 (* syn_keep=1 *) wire [15:0] last_cycles;
 wire [1279:0] voice_raw;
 instrument_engine40 #(.TRACE_ENABLE(TRACE_ENABLE),.VOICES_PER_CORE(10)) engine(clk_50m,core_rst_n,sample_tick,event_valid,event_data,online && !fault,patch_select,
  pcm,pcm_valid,busy,gate,releasing,deadline_miss,clips,range_errors,event_overflow,last_cycles,voice_raw,string_ratio,string_bend_ratio,event_tag,exec_valid,exec_data,exec_tag);
 // The board top owns the CH10 APU. Export the exact same reset and tick;
 // its signed PCM returns on this 50MHz domain before engine pcm_valid.
 assign nes_rst_n=core_rst_n;
 assign nes_sample_tick=sample_tick;
 // NES-only level trim 11/128 (-21.32dB), matched to existing four timbres.
 // PCM16 -> PCM24 is 256 * 11/128 = 22, exact with no rounding or DSP.
 wire signed [23:0] nes_extended={{8{nes_pcm[15]}},nes_pcm};
 wire signed [23:0] nes_balanced=(nes_extended<<<4)+(nes_extended<<<2)+(nes_extended<<<1);
 wire signed [24:0] combined=$signed({pcm[23],pcm})+$signed({nes_balanced[23],nes_balanced});
 wire signed [23:0] mixed_pcm=(combined > 25'sd8388607) ? 24'sh7fffff :
  (combined < -25'sd8388608) ? 24'sh800000 : combined[23:0];
 wire signed [23:0] effects_pcm;wire effects_valid;wire [351:0] effects_state;
 instrument_effects effects(clk_50m,core_rst_n,sample_tick,event_valid,event_data,online && !fault,
  pcm_valid,mixed_pcm,effects_valid,effects_pcm,effects_state);
 assign capture_valid=effects_valid && wr_ready;
 assign capture_pcm={effects_pcm,effects_pcm};
 always @(posedge clk_50m)if(!core_rst_n)capture_index<=0;else if(sample_tick)capture_index<=capture_index+1'b1;
 assign actual_state={last_cycles,gate[39:32],busy[39:32],pcm_overflow,clips,deadline_miss,event_overflow,gate[31:0],busy[31:0],effects_state};
 usb_packet_async_fifo #(.WIDTH(48),.ADDR_BITS(2)) pcm_fifo(
  clk_50m,core_rst_n,effects_valid,{effects_pcm,effects_pcm},wr_ready,pcm_overflow,
  bclk,read_rst_n,rd_valid,frame,tx_ready);
 audio_usb_i2s_tx24 tx(bclk,tx_rst_n,ws,rd_valid && read_rst_n,frame,tx_ready,sdout,underrun);
endmodule
`default_nettype wire
