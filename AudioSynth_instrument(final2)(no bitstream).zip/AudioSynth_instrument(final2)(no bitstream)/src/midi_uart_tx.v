`default_nettype none
// Adapted from the supplied boards/common/uart_tx_V2.v four-state 8N1 TX.
// Changes: explicit synchronous reset, latched input, complete stop bit,
// start-aligned divider, declared widths, ready/valid instead of wr_en/busy.
module midi_uart_tx #(parameter CLK_HZ=50000000,parameter BAUD=115200)(
 input wire clk,input wire rst_n,input wire valid,input wire [7:0] data,
 output wire ready,output reg tx
);
 localparam DIV=(CLK_HZ+BAUD/2)/BAUD;
 // synthesis translate_off
 initial begin
  if(CLK_HZ<1 || BAUD<1 || DIV<1) $fatal(1,"invalid UART clock/baud parameters");
 end
 // synthesis translate_on
 localparam IDLE=2'd0,START=2'd1,DATA=2'd2,STOP=2'd3;
 reg [1:0] state;
 reg [31:0] timer;
 reg [7:0] held;
 reg [2:0] bitpos;
 assign ready=(state==IDLE);
 always @(posedge clk) begin
  if(!rst_n) begin tx<=1;state<=IDLE;timer<=0;held<=0;bitpos<=0;end
  else if(state==IDLE) begin
   tx<=1;
   if(valid) begin held<=data;bitpos<=0;tx<=0;timer<=DIV-1;state<=START;end
  end else if(timer!=0) timer<=timer-1'b1;
  else begin
   timer<=DIV-1;
   case(state)
    START:begin tx<=held[0];state<=DATA;end
    DATA:begin
     if(bitpos==7) begin tx<=1;state<=STOP;end
     else begin bitpos<=bitpos+1'b1;tx<=held[bitpos+1'b1];end
    end
    STOP:begin tx<=1;state<=IDLE;end
    default:begin tx<=1;state<=IDLE;end
   endcase
  end
 end
endmodule
`default_nettype wire
