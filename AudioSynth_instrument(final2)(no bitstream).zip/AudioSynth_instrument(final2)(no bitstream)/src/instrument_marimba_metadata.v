`default_nettype none
// Metadata decoded from ROM1A slot22; OP order: OP6..OP1.
module instrument_marimba_metadata(input wire [2:0] op,
 output reg [3:0] sensitivity,output reg [11:0] offset0,offset1);
 always @* begin
  sensitivity=0;offset0=0;offset1=0;
  case(op)
   3'd0:begin sensitivity=4'd2;offset0=12'd864;offset1=12'd864;end
   3'd1:begin sensitivity=4'd2;offset0=12'd736;offset1=12'd1824;end
   3'd2:begin sensitivity=4'd2;offset0=12'd736;offset1=12'd1824;end
   3'd3:begin sensitivity=4'd1;offset0=12'd224;offset1=12'd416;end
   3'd4:begin sensitivity=4'd2;offset0=12'd736;offset1=12'd1824;end
   3'd5:begin sensitivity=4'd0;offset0=12'd224;offset1=12'd416;end
   default:begin end
  endcase
 end
endmodule
`default_nettype wire
