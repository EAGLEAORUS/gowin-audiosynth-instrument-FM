`default_nettype none
// Human-readable boundary markers; never claims successful USB enumeration.
module midi_board_message_tx #(parameter CLK_HZ=50000000,parameter BAUD=115200)(
 input wire clk,input wire rst_n,input wire start,input wire [1:0] message_id,
 input wire dp,input wire dm,output wire tx,output reg done
);
 reg [767:0] line,next_line;
 reg [6:0] length,next_length,cursor;
 reg active,tail;
 wire ready;
 wire [7:0] ch=line[8*(length-1-cursor)+:8];
 always @* begin
  next_line=0;next_length=0;
  case(message_id)
   0:begin next_line={"SELFTEST BEGIN - SYNTHETIC MIDI; USB HOST NOT IMPLEMENTED",8'h0d,8'h0a};next_length=59;end
   1:begin next_line={"SELFTEST END - WAITING; USB HOST NOT IMPLEMENTED",8'h0d,8'h0a};next_length=50;end
   default:begin
    next_line={"USB STATIC LINE DP=",(dp?8'h31:8'h30)," DM=",(dm?8'h31:8'h30),"; HOST NOT IMPLEMENTED",8'h0d,8'h0a};
    next_length=49;
   end
  endcase
 end
 midi_uart_tx #(CLK_HZ,BAUD) uart(clk,rst_n,active,ch,ready,tx);
 always @(posedge clk) begin
  if(!rst_n)begin line<=0;length<=0;cursor<=0;active<=0;tail<=0;done<=0;end
  else begin
   done<=0;
   if(start && !active && !tail)begin line<=next_line;length<=next_length;cursor<=0;active<=1;end
   else if(active && ready)begin
    if(cursor==length-1)begin active<=0;tail<=1;end
    else cursor<=cursor+1'b1;
   end else if(tail && ready)begin tail<=0;done<=1;end
  end
 end
endmodule
`default_nettype wire
