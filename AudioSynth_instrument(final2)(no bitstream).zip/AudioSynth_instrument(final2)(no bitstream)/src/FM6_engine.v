`default_nettype none
module FM6_engine(
 input wire clk,rst_n,sample_tick,event_valid,input wire [39:0] event_data,input wire online,
 output wire signed [23:0] pcm,output wire pcm_valid,
 output wire [3:0] busy,gate,releasing,
 output wire [31:0] deadline_miss,clip_count,range_errors,event_overflow,
 output wire [15:0] last_cycles,output wire [111:0] voice_raw
);
 wire queue_valid,queue_ready,pop,idle;wire [39:0] queue_data;
 wire safe_online=online && event_overflow==0;
 wire [3:0] on,off;wire [6:0] raw_note,velocity;
 wire [27:0] assigned_notes;wire [15:0] channels;
 (* syn_keep=1 *) wire [31:0] accepted_events,steals,retriggers;
 // USB/allocator/core all run at 50MHz. Buffer events while the datapath runs.
 midi_sync_fifo #(.WIDTH(40),.ADDR_BITS(5)) events(clk,rst_n && online,event_valid && online,event_data,
  queue_ready,queue_valid,queue_data,pop,event_overflow);
 assign pop=idle && !sample_tick;
 voice_allocator allocator(clk,rst_n,queue_valid && pop,queue_data,safe_online,
  busy,gate,releasing,on,off,raw_note,velocity,assigned_notes,channels,accepted_events,steals,retriggers);
 // Preserve the existing Orca convention: raw48..72 plays scientific MIDI60..84.
 wire [6:0] model_note=raw_note+7'd12;
 (* syn_keep=1 *) wire [13:0] pitch_value;
 wire [23:0] pitch_ratio;
 (* syn_keep=1 *) wire [31:0] pitch_events;
 synth_pitch_control pitch(clk,rst_n,queue_valid && pop,queue_data,safe_online,pitch_value,pitch_ratio,pitch_events);
 FM6_core4 #(.PITCH_ENABLE(1)) core(clk,rst_n,sample_tick,on,off,model_note,velocity,pcm,pcm_valid,busy,gate,releasing,
  deadline_miss,clip_count,range_errors,last_cycles,voice_raw,idle,pitch_ratio);
endmodule
`default_nettype wire
