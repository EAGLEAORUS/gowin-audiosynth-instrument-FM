`default_nettype none
// FPGA-owned patch, bank, gain and bend state. The CPU writes menu selections
// and can snapshot state when creating a MIDI recording.
module sd_performance(
 input wire clk,rst_n,dispatch,apply_control,
 input wire [39:0] event_data,
 input wire [8:0] patch_count,input wire [15:0] pedal_snapshot,
 input wire cpu_write,input wire [11:0] cpu_address,input wire [31:0] cpu_data,
 output reg [31:0] cpu_read,
 output wire [15:0] active_mask,
 output wire [7:0] patch,output wire [6:0] key,
 output wire control_busy,control_we,output reg [3:0] control_channel,
 output wire [34:0] control_data,output wire [8:0] piano_patch
);
 // Generated lookup constants from the integer model.
function [23:0] bend_q22;
 input [7:0] index;
 begin
  case(index)
   8'd0: bend_q22=24'd3736700;
   8'd1: bend_q22=24'd3740076;
   8'd2: bend_q22=24'd3743452;
   8'd3: bend_q22=24'd3746832;
   8'd4: bend_q22=24'd3750216;
   8'd5: bend_q22=24'd3753600;
   8'd6: bend_q22=24'd3756988;
   8'd7: bend_q22=24'd3760384;
   8'd8: bend_q22=24'd3763776;
   8'd9: bend_q22=24'd3767176;
   8'd10: bend_q22=24'd3770576;
   8'd11: bend_q22=24'd3773984;
   8'd12: bend_q22=24'd3777392;
   8'd13: bend_q22=24'd3780800;
   8'd14: bend_q22=24'd3784216;
   8'd15: bend_q22=24'd3787632;
   8'd16: bend_q22=24'd3791052;
   8'd17: bend_q22=24'd3794476;
   8'd18: bend_q22=24'd3797900;
   8'd19: bend_q22=24'd3801332;
   8'd20: bend_q22=24'd3804764;
   8'd21: bend_q22=24'd3808200;
   8'd22: bend_q22=24'd3811636;
   8'd23: bend_q22=24'd3815080;
   8'd24: bend_q22=24'd3818524;
   8'd25: bend_q22=24'd3821972;
   8'd26: bend_q22=24'd3825424;
   8'd27: bend_q22=24'd3828876;
   8'd28: bend_q22=24'd3832332;
   8'd29: bend_q22=24'd3835792;
   8'd30: bend_q22=24'd3839256;
   8'd31: bend_q22=24'd3842724;
   8'd32: bend_q22=24'd3846192;
   8'd33: bend_q22=24'd3849668;
   8'd34: bend_q22=24'd3853144;
   8'd35: bend_q22=24'd3856620;
   8'd36: bend_q22=24'd3860104;
   8'd37: bend_q22=24'd3863588;
   8'd38: bend_q22=24'd3867080;
   8'd39: bend_q22=24'd3870568;
   8'd40: bend_q22=24'd3874064;
   8'd41: bend_q22=24'd3877564;
   8'd42: bend_q22=24'd3881064;
   8'd43: bend_q22=24'd3884568;
   8'd44: bend_q22=24'd3888076;
   8'd45: bend_q22=24'd3891588;
   8'd46: bend_q22=24'd3895100;
   8'd47: bend_q22=24'd3898616;
   8'd48: bend_q22=24'd3902136;
   8'd49: bend_q22=24'd3905660;
   8'd50: bend_q22=24'd3909188;
   8'd51: bend_q22=24'd3912716;
   8'd52: bend_q22=24'd3916252;
   8'd53: bend_q22=24'd3919788;
   8'd54: bend_q22=24'd3923328;
   8'd55: bend_q22=24'd3926868;
   8'd56: bend_q22=24'd3930416;
   8'd57: bend_q22=24'd3933964;
   8'd58: bend_q22=24'd3937516;
   8'd59: bend_q22=24'd3941072;
   8'd60: bend_q22=24'd3944628;
   8'd61: bend_q22=24'd3948192;
   8'd62: bend_q22=24'd3951756;
   8'd63: bend_q22=24'd3955324;
   8'd64: bend_q22=24'd3958896;
   8'd65: bend_q22=24'd3962472;
   8'd66: bend_q22=24'd3966048;
   8'd67: bend_q22=24'd3969628;
   8'd68: bend_q22=24'd3973212;
   8'd69: bend_q22=24'd3976800;
   8'd70: bend_q22=24'd3980392;
   8'd71: bend_q22=24'd3983988;
   8'd72: bend_q22=24'd3987584;
   8'd73: bend_q22=24'd3991184;
   8'd74: bend_q22=24'd3994788;
   8'd75: bend_q22=24'd3998396;
   8'd76: bend_q22=24'd4002004;
   8'd77: bend_q22=24'd4005620;
   8'd78: bend_q22=24'd4009236;
   8'd79: bend_q22=24'd4012856;
   8'd80: bend_q22=24'd4016480;
   8'd81: bend_q22=24'd4020104;
   8'd82: bend_q22=24'd4023736;
   8'd83: bend_q22=24'd4027368;
   8'd84: bend_q22=24'd4031004;
   8'd85: bend_q22=24'd4034644;
   8'd86: bend_q22=24'd4038288;
   8'd87: bend_q22=24'd4041936;
   8'd88: bend_q22=24'd4045584;
   8'd89: bend_q22=24'd4049236;
   8'd90: bend_q22=24'd4052892;
   8'd91: bend_q22=24'd4056552;
   8'd92: bend_q22=24'd4060216;
   8'd93: bend_q22=24'd4063884;
   8'd94: bend_q22=24'd4067552;
   8'd95: bend_q22=24'd4071224;
   8'd96: bend_q22=24'd4074900;
   8'd97: bend_q22=24'd4078580;
   8'd98: bend_q22=24'd4082264;
   8'd99: bend_q22=24'd4085948;
   8'd100: bend_q22=24'd4089636;
   8'd101: bend_q22=24'd4093332;
   8'd102: bend_q22=24'd4097028;
   8'd103: bend_q22=24'd4100724;
   8'd104: bend_q22=24'd4104428;
   8'd105: bend_q22=24'd4108136;
   8'd106: bend_q22=24'd4111844;
   8'd107: bend_q22=24'd4115556;
   8'd108: bend_q22=24'd4119272;
   8'd109: bend_q22=24'd4122992;
   8'd110: bend_q22=24'd4126716;
   8'd111: bend_q22=24'd4130440;
   8'd112: bend_q22=24'd4134172;
   8'd113: bend_q22=24'd4137904;
   8'd114: bend_q22=24'd4141640;
   8'd115: bend_q22=24'd4145380;
   8'd116: bend_q22=24'd4149124;
   8'd117: bend_q22=24'd4152868;
   8'd118: bend_q22=24'd4156620;
   8'd119: bend_q22=24'd4160372;
   8'd120: bend_q22=24'd4164128;
   8'd121: bend_q22=24'd4167888;
   8'd122: bend_q22=24'd4171652;
   8'd123: bend_q22=24'd4175420;
   8'd124: bend_q22=24'd4179188;
   8'd125: bend_q22=24'd4182964;
   8'd126: bend_q22=24'd4186740;
   8'd127: bend_q22=24'd4190520;
   8'd128: bend_q22=24'd4194304;
   8'd129: bend_q22=24'd4198092;
   8'd130: bend_q22=24'd4201880;
   8'd131: bend_q22=24'd4205676;
   8'd132: bend_q22=24'd4209472;
   8'd133: bend_q22=24'd4213276;
   8'd134: bend_q22=24'd4217080;
   8'd135: bend_q22=24'd4220888;
   8'd136: bend_q22=24'd4224696;
   8'd137: bend_q22=24'd4228512;
   8'd138: bend_q22=24'd4232332;
   8'd139: bend_q22=24'd4236152;
   8'd140: bend_q22=24'd4239976;
   8'd141: bend_q22=24'd4243804;
   8'd142: bend_q22=24'd4247636;
   8'd143: bend_q22=24'd4251472;
   8'd144: bend_q22=24'd4255312;
   8'd145: bend_q22=24'd4259152;
   8'd146: bend_q22=24'd4263000;
   8'd147: bend_q22=24'd4266848;
   8'd148: bend_q22=24'd4270700;
   8'd149: bend_q22=24'd4274556;
   8'd150: bend_q22=24'd4278416;
   8'd151: bend_q22=24'd4282280;
   8'd152: bend_q22=24'd4286148;
   8'd153: bend_q22=24'd4290016;
   8'd154: bend_q22=24'd4293892;
   8'd155: bend_q22=24'd4297768;
   8'd156: bend_q22=24'd4301648;
   8'd157: bend_q22=24'd4305532;
   8'd158: bend_q22=24'd4309420;
   8'd159: bend_q22=24'd4313312;
   8'd160: bend_q22=24'd4317208;
   8'd161: bend_q22=24'd4321104;
   8'd162: bend_q22=24'd4325008;
   8'd163: bend_q22=24'd4328912;
   8'd164: bend_q22=24'd4332820;
   8'd165: bend_q22=24'd4336732;
   8'd166: bend_q22=24'd4340648;
   8'd167: bend_q22=24'd4344568;
   8'd168: bend_q22=24'd4348492;
   8'd169: bend_q22=24'd4352416;
   8'd170: bend_q22=24'd4356348;
   8'd171: bend_q22=24'd4360280;
   8'd172: bend_q22=24'd4364216;
   8'd173: bend_q22=24'd4368160;
   8'd174: bend_q22=24'd4372104;
   8'd175: bend_q22=24'd4376052;
   8'd176: bend_q22=24'd4380000;
   8'd177: bend_q22=24'd4383956;
   8'd178: bend_q22=24'd4387916;
   8'd179: bend_q22=24'd4391876;
   8'd180: bend_q22=24'd4395844;
   8'd181: bend_q22=24'd4399812;
   8'd182: bend_q22=24'd4403784;
   8'd183: bend_q22=24'd4407760;
   8'd184: bend_q22=24'd4411740;
   8'd185: bend_q22=24'd4415724;
   8'd186: bend_q22=24'd4419712;
   8'd187: bend_q22=24'd4423704;
   8'd188: bend_q22=24'd4427696;
   8'd189: bend_q22=24'd4431696;
   8'd190: bend_q22=24'd4435696;
   8'd191: bend_q22=24'd4439700;
   8'd192: bend_q22=24'd4443712;
   8'd193: bend_q22=24'd4447724;
   8'd194: bend_q22=24'd4451740;
   8'd195: bend_q22=24'd4455760;
   8'd196: bend_q22=24'd4459780;
   8'd197: bend_q22=24'd4463808;
   8'd198: bend_q22=24'd4467840;
   8'd199: bend_q22=24'd4471872;
   8'd200: bend_q22=24'd4475912;
   8'd201: bend_q22=24'd4479952;
   8'd202: bend_q22=24'd4483996;
   8'd203: bend_q22=24'd4488048;
   8'd204: bend_q22=24'd4492100;
   8'd205: bend_q22=24'd4496156;
   8'd206: bend_q22=24'd4500216;
   8'd207: bend_q22=24'd4504280;
   8'd208: bend_q22=24'd4508344;
   8'd209: bend_q22=24'd4512416;
   8'd210: bend_q22=24'd4516492;
   8'd211: bend_q22=24'd4520568;
   8'd212: bend_q22=24'd4524652;
   8'd213: bend_q22=24'd4528736;
   8'd214: bend_q22=24'd4532824;
   8'd215: bend_q22=24'd4536920;
   8'd216: bend_q22=24'd4541016;
   8'd217: bend_q22=24'd4545116;
   8'd218: bend_q22=24'd4549220;
   8'd219: bend_q22=24'd4553328;
   8'd220: bend_q22=24'd4557440;
   8'd221: bend_q22=24'd4561552;
   8'd222: bend_q22=24'd4565672;
   8'd223: bend_q22=24'd4569796;
   8'd224: bend_q22=24'd4573920;
   8'd225: bend_q22=24'd4578052;
   8'd226: bend_q22=24'd4582184;
   8'd227: bend_q22=24'd4586324;
   8'd228: bend_q22=24'd4590464;
   8'd229: bend_q22=24'd4594608;
   8'd230: bend_q22=24'd4598756;
   8'd231: bend_q22=24'd4602908;
   8'd232: bend_q22=24'd4607064;
   8'd233: bend_q22=24'd4611224;
   8'd234: bend_q22=24'd4615388;
   8'd235: bend_q22=24'd4619556;
   8'd236: bend_q22=24'd4623728;
   8'd237: bend_q22=24'd4627904;
   8'd238: bend_q22=24'd4632080;
   8'd239: bend_q22=24'd4636264;
   8'd240: bend_q22=24'd4640452;
   8'd241: bend_q22=24'd4644640;
   8'd242: bend_q22=24'd4648836;
   8'd243: bend_q22=24'd4653032;
   8'd244: bend_q22=24'd4657232;
   8'd245: bend_q22=24'd4661440;
   8'd246: bend_q22=24'd4665648;
   8'd247: bend_q22=24'd4669860;
   8'd248: bend_q22=24'd4674076;
   8'd249: bend_q22=24'd4678296;
   8'd250: bend_q22=24'd4682520;
   8'd251: bend_q22=24'd4686748;
   8'd252: bend_q22=24'd4690980;
   8'd253: bend_q22=24'd4695216;
   8'd254: bend_q22=24'd4699456;
   8'd255: bend_q22=24'd4703700;
   default: bend_q22=0;
  endcase
 end
endfunction
 reg [15:0] active,banks;
 reg [7:0] patches[0:15];
 reg [6:0] volumes[0:15],expressions[0:15];
 reg [13:0] bends[0:15];
 reg [8:0] curated_patch[0:15];
 reg curated;
 wire [3:0] ch=event_data[27:24],kind=event_data[31:28];
 wire [6:0] note=event_data[23:17],value=event_data[16:10];
 wire is_pad=ch==9 && note>=36 && note<=51;
 wire [3:0] pad=note[3:0]-4'd4;
 wire [6:0] natural_note;
 nes_note_map natural_keys(pad,natural_note,);
 function [6:0] drum_note;
  input [3:0] index;
  begin
   case(index)
    0,2:drum_note=36;
    1:drum_note=84;
    7:drum_note=72;
    default:drum_note=60;
   endcase
  end
 endfunction
 assign active_mask=patch_count==0 ? 16'd0:active;
 assign piano_patch={active_mask[0],patches[0]};
 assign patch=is_pad && curated && curated_patch[pad][8] ? curated_patch[pad][7:0]:patches[ch];
 assign key=is_pad ? (curated ? drum_note(pad):natural_note):note>115 ? 7'd127:note+7'd12;
 wire [8:0] program_id={1'b0,banks[ch],note};
 wire [3:0] selected=cpu_address[5:2];
 always @*begin
  case(cpu_address[11:6])
   6'h0e:cpu_read={8'd0,(selected==9 && curated),expressions[selected],volumes[selected],active_mask[selected],patches[selected]};
   6'h0f:cpu_read={17'd0,pedal_snapshot[selected],bends[selected]};
   default:cpu_read=0;
  endcase
 end
 wire vol_event=kind==3 && note==7;
 wire expr_event=kind==3 && note==11;
 wire bend_event=kind==5;
 reg [1:0] control_step;
 reg [13:0] gain_product;
 reg [33:0] gain_scaled;
 reg [10:0] gain;
 reg [23:0] ratio;
 assign control_busy=control_step!=0;
 assign control_we=control_step==3 && apply_control;
 assign control_data={gain,ratio};
 integer i;
 always @(posedge clk)begin
  if(!rst_n)begin
   active<=0;banks<=0;curated<=0;control_step<=0;
   for(i=0;i<16;i=i+1)begin
    patches[i]<=0;volumes[i]<=127;expressions[i]<=127;bends[i]<=8192;curated_patch[i]<=0;
   end
  end else begin
   // Equivalent to round(product*1024/16129) for every product 0..16129.
   if(control_step==1)begin gain_scaled<=gain_product*20'd532577+34'd4194304;control_step<=2;end
   else if(control_step==2)begin gain<=gain_scaled[33:23];control_step<=3;end
   else if(control_we)control_step<=0;
   if(dispatch)begin
    if(kind==3 && note==0)banks[ch]<=value[0];
    if(kind==3 && note==20 && ch==9)begin
     curated<=value==127;
     if(value==64)active[9]<=0; // Recorded selector for the built-in 8bit pads.
    end
    if(kind==4 && program_id<patch_count)begin
     patches[ch]<=program_id[7:0];active[ch]<=1;
     if(ch==9)curated<=0;
    end
    if(vol_event || expr_event || bend_event)begin
     if(vol_event)volumes[ch]<=value;
     if(expr_event)expressions[ch]<=value;
     if(bend_event)bends[ch]<={value,note};
     control_channel<=ch;
     ratio<=bend_q22(bend_event ? {value,note[6]}:bends[ch][13:6]);
     gain_product<=(vol_event ? value:volumes[ch])*(expr_event ? value:expressions[ch]);
     control_step<=1;
    end
   end
   // A menu action is applied atomically on its APB write.
   if(cpu_write)case(cpu_address)
    12'h330:begin
     active[cpu_data[19:16]]<=cpu_data[8] && {1'b0,cpu_data[7:0]}<patch_count;
     patches[cpu_data[19:16]]<=cpu_data[7:0];
     if(cpu_data[19:16]==9)curated<=0;
    end
    12'h334:curated<=cpu_data[0];
    12'h338:curated_patch[cpu_data[19:16]]<=cpu_data[8:0];
    12'h33c:begin active<=0;banks<=0;curated<=0;end
    default:begin end
   endcase
  end
 end
endmodule
`default_nettype wire
