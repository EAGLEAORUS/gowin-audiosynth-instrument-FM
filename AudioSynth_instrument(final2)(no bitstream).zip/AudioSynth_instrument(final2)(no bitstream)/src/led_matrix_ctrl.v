//============================================================================
//  led_matrix_ctrl.v
//
//  Sequencer for a 128 x 64, 1/64-scan RGB LED panel using FM6363B column
//  drivers and a DP32020A (or compatible 74HC595-style) row shift register.
//
//  Panel assumptions (see docs/PANEL_ASSUMPTIONS.md):
//    - 128 columns (x, long edge) x 64 rows (y, short edge)
//    - 64 scan lines, one row active at a time
//    - two half-width data lanes of 64 columns each:
//         RGB1 = R1/G1/B1  -> one horizontal half
//         RGB2 = R2/G2/B2  -> the other horizontal half
//    - each lane is 4 x FM6363B in series (4 x 16 outputs = 64 columns)
//    - HUB75 "A" = DP32020A DCK (row shift clock)
//      HUB75 "B" = DP32020A RCK (row register/config latch, held low here)
//      HUB75 "C" = DP32020A DIN (row data, one-hot)
//      HUB75 "CLK" = FM6363B DCLK
//      HUB75 "LAT" = FM6363B LE
//      HUB75 "OE"  = FM6363B GCLK (grayscale clock)
//
//  Static mode uses independent lane colour words. Diagnostic mode cycles
//  full-screen interpolated rainbow, white hold, and fade back to red.
//  Two-row upload packets alternate with complete high-refresh scans.
//  GCLK is stopped during SRAM writes; no long full-image black interval.
//
//  Protocol references:
//    - FM6363 "Control and Programming Guide" (LE pulse length commands)
//    - FM6363B datasheet (16-bit shift register, 16 channels, 33..64 scan)
//    - DP32020A datasheet (DIN/DCK/RCK serial row driver)
//    - kingdo9/rpi-rgb-led-matrix_pwm_experiment SPWM implementation
//
//  Timing: every module input/output changes on "tick", which is one DCLK
//  period (160 ns at 6.25 MHz from a 50 MHz clock). The top-level registers
//  CLK/OE from clk_en/gclk_en so the pins are clean.
//============================================================================
`timescale 1ns / 1ps

module led_matrix_ctrl #(
    parameter integer SCAN_ROWS       = 64,
    parameter integer CHANNELS_PER_CHIP = 16,
    parameter integer CHIPS_PER_LANE  = 4,
    parameter integer WORDS_PER_LATCH = 8,   // 8 x 16-bit = 128 bits per channel
    parameter integer WORD_BITS       = 16,
    parameter integer GCLK_PER_ROW    = 74,
    parameter integer POWER_ON_TICKS  = 125000, // 10 ms at 12.5 MHz
    parameter [15:0]  RED_WORD        = 16'hFFFF,
    parameter [15:0]  GREEN_WORD      = 16'h0000,
    parameter [15:0]  BLUE_WORD       = 16'h0000,
    // Independent lane-2 words; default is the same all-red image.
    parameter [15:0]  RED_WORD2       = 16'hFFFF,
    parameter [15:0]  GREEN_WORD2     = 16'h0000,
    parameter [15:0]  BLUE_WORD2      = 16'h0000,
    parameter integer COLOR_CYCLE_ENABLE = 0,
    parameter integer COLOR_HOLD_TICKS = 25000000, // white: 2 s
    parameter integer GRADIENT_HOLD_TICKS = 292969, // 256 steps: ~6 s/segment
    parameter integer GRADIENT_STEPS = 256,
    parameter [15:0] ORANGE_GREEN_WORD = 16'h1999, // ~10% green, less yellow
    parameter [15:0] YELLOW_GREEN_WORD = 16'h6000,
    parameter integer BAND_DISPLAY_ENABLE = 0,
    parameter integer SCAN_ROW0_AT_BOTTOM = 0,
    parameter integer ROW_BLANK_TICKS = 4, // 640 ns at 6.25 MHz
    parameter integer VERTICAL_BANDS = 0,
    parameter integer RGB1_ON_RIGHT = 1,
    parameter integer LANE_CHIP_REVERSE = 0,
    parameter integer MUSIC_DISPLAY_ENABLE = 0, WRITE_ROWS_PER_PACKET = 2
) (
    input  wire       clk,
    input  wire       rst_n,
    input  wire       tick,        // one-cycle enable, one per DCLK period
    input  wire       music_frame_ready,
    input  wire [47:0] music_pixel1, music_pixel2,
    output reg        music_accept,
    output reg        music_commit,
    output wire [6:0] image_x1,image_x2,
    output wire [5:0] image_y,

    output reg  [2:0] rgb1,        // {R1,G1,B1}
    output reg  [2:0] rgb2,        // {R2,G2,B2}
    output wire       row_a,       // DP32020A DCK
    output wire       row_b,       // DP32020A RCK (held low)
    output wire       row_c,       // DP32020A DIN
    output reg        clk_en,      // DCLK enable
    output reg        lat,         // FM6363B LE
    output wire       gclk_en,     // FM6363B GCLK enable (OE pin)
    output reg        busy,
    output wire       frame_pulse,
    output wire [5:0] row_index
);

    // ------------------------------------------------------------------
    // Constants
    // ------------------------------------------------------------------
    localparam [3:0] S_PWR    = 4'd0;
    localparam [3:0] S_CLEAR  = 4'd1;
    localparam [3:0] S_INSERT = 4'd2;
    localparam [3:0] S_INIT   = 4'd3;
    localparam [3:0] S_LOAD   = 4'd4;
    localparam [3:0] S_VSYNC  = 4'd5;
    localparam [3:0] S_BLANK = 4'd6;
    localparam [3:0] S_BLANK_GAP = 4'd7;
    localparam [3:0] S_REACT = 4'd8;
    localparam [3:0] S_LGAP   = 4'd9;
    localparam [3:0] S_RUN = 4'd11;
    localparam [3:0] S_ENABLE = 4'd10;
    localparam [3:0] S_ENABLE_GAP = 4'd12;
    localparam [3:0] S_RESTART = 4'd13;
    localparam [3:0] S_VSYNC_GAP = 4'd14;
    localparam [3:0] S_PACKET_SCAN = 4'd15;
    localparam [4:0] S_WAIT_IMAGE = 5'd16;

    localparam [1:0] I_SHIFT  = 2'd0;
    localparam [1:0] I_LE     = 2'd1;
    localparam [1:0] I_IDLE   = 2'd2;

    localparam [1:0] L_SHIFT  = 2'd0;
    localparam [1:0] L_LE     = 2'd1;

    // Number of 16-bit words shifted per channel, including the LE tail.
    //
    // The physical chain is either 4 x 16-bit chips per half-width lane, or
    // 8 x 16-bit chips on a single full-width serial path (some 128x64
    // panels wire the two halves as one chain).  Sending 8 words is safe for
    // both cases: extra words simply shift out of the SDO end of a shorter
    // chain. This broadcast test sends identical words to every chip.
    // Broadcast identical words to cover either documented chain length.
    // Config and image uploads MUST cover the same complete serial chain.
    localparam integer CHAIN_WORDS = (WORDS_PER_LATCH > CHIPS_PER_LANE) ?
                                    WORDS_PER_LATCH : CHIPS_PER_LANE;
    localparam integer LOAD_BITS = CHAIN_WORDS * WORD_BITS;
    localparam integer BIT_COUNT_WIDTH = $clog2(LOAD_BITS + 1);
    // A packet contains at most two upload rows. In between packets issue
    // a WHOLE display scan, without VSYNC or its four-GCLK startup prefix.
    localparam integer PACKET_COUNT = (SCAN_ROWS+WRITE_ROWS_PER_PACKET-1)/WRITE_ROWS_PER_PACKET;
    localparam integer UPDATE_TICKS = SCAN_ROWS*CHANNELS_PER_CHIP*(LOAD_BITS+1)+47+
                                      (PACKET_COUNT-1)*(SCAN_ROWS*GCLK_PER_ROW+44);

    // FM6363 configuration registers (proven values from the SPWM project).
    // CFG1 bits [13:8] = SCAN_ROWS-1; all other bits keep the known-good
    // 32-scan baseline (OPEN_DET=0, GCLK_N=0, OPT=10, TEST=11).
    localparam [5:0]  SCAN_CODE = SCAN_ROWS - 1;
    localparam [15:0] CFG1_VAL  = {2'b00, SCAN_CODE, 2'b10, 2'b11, 1'b0, 3'b000};
    localparam [15:0] CFG2_VAL  = 16'hF39C; // 1..64 scan mode, blanking, IGAIN
    localparam [15:0] CFG3_VAL  = 16'h20B6; // VDS / PWM / low-gray compensation
    localparam [15:0] CFG4_VAL  = 16'h1A00; // blanking / clamp / timing
    localparam [15:0] CFG5_VAL  = 16'h7E08; // debug register (LE = 2)

    // ------------------------------------------------------------------
    // Registers
    // ------------------------------------------------------------------
    reg [4:0]  state;
    reg [31:0] pwr_cnt;
    reg [6:0]  clear_cnt;
    reg        clear_phase;
    reg [1:0]  insert_phase;
    reg [7:0] row_init_count;

    reg [3:0]  init_idx;
    reg [1:0]  init_phase;
    reg [BIT_COUNT_WIDTH-1:0] init_bit;
    reg [4:0]  init_cnt;
    reg [15:0] init_data;
    reg [4:0]  init_len;
    reg [3:0]  init_idle;
    reg        init_has_data;

    // 正面坐标：“上”y=63 对应 load_line=0；“下”y=0 对应 load_line=63。
    // load_line 是 SRAM 扫描行序号，不是自下向上的 y 坐标。
    reg [5:0]  load_line;
    reg [3:0]  load_ch;
    reg [BIT_COUNT_WIDTH-1:0] load_bit;
    reg [1:0]  load_phase;

    reg [2:0]  vsync_cnt;
    reg [4:0] op_count;
    reg [3:0]  test_color; // 0..6 rainbow, 7 fade to white, 8 white, 9 fade to red
    reg [$clog2(GRADIENT_STEPS)-1:0] gradient_step;
    reg [31:0] hold_ticks;
    reg [31:0] frame_hold_ticks;
    reg        display_active;
    reg        have_frame;
    reg        packet_resume;
    reg        scan_prefix;
    reg init_a, init_c;
    wire scan_a, scan_c, scan_boundary;

    // Pause at a physical row wrap and DIS_OP before touching display SRAM.
    // Restore outputs only after the entire image and VSYNC have completed.
    led_matrix_scan #(.SCAN_ROWS(SCAN_ROWS), .GCLK_PER_ROW(GCLK_PER_ROW)) u_scan (
        .clk(clk), .rst_n(rst_n), .tick(tick), .enable(display_active),
        .initial_prefix(scan_prefix),
        .row_a(scan_a), .row_c(scan_c), .gclk_en(gclk_en),
        .frame_pulse(frame_pulse), .row_index(row_index), .boundary(scan_boundary)
    );
    assign row_a = display_active ? scan_a : init_a;
    assign row_c = display_active ? scan_c : init_c;
    assign row_b = 1'b0;

    // Linear interpolation over each segment; division is by a compile-time
    // power of two in the default configuration (256 steps).
    function [15:0] mix_level;
        input [15:0] first_level, last_level;
        input integer step;
        reg [31:0] weighted;
        reg [31:0] scaled;
        begin
            weighted = first_level * (GRADIENT_STEPS-step) + last_level * step;
            scaled = weighted / GRADIENT_STEPS;
            // Convex interpolation remains in 0..65535; select explicitly.
            mix_level = scaled[15:0];
        end
    endfunction

    // Make yellow -> green visibly change: reduce red quadratically while
    // green rises from a calibrated yellow level, instead of keeping green
    // saturated throughout the entire segment.
    function [15:0] yellow_red_level;
        input integer step;
        reg [31:0] remaining_squared;
        reg [63:0] weighted;
        reg [63:0] scaled;
        begin
            remaining_squared = (GRADIENT_STEPS-step)*(GRADIENT_STEPS-step);
            weighted = 64'd65535 * remaining_squared;
            scaled = weighted / (GRADIENT_STEPS*GRADIENT_STEPS);
            yellow_red_level = scaled[15:0];
        end
    endfunction

    // 16-bit grayscale words. Intermediate intensities mix orange/violet;
    // white drives R, G and B together at full scale.
    reg [47:0] palette_rgb;
    always @* begin
        case (test_color)
            4'd0: palette_rgb = {16'hFFFF,mix_level(0,ORANGE_GREEN_WORD,gradient_step),16'h0000};
            4'd1: palette_rgb = {16'hFFFF,mix_level(ORANGE_GREEN_WORD,YELLOW_GREEN_WORD,gradient_step),16'h0000};
            4'd2: palette_rgb = {yellow_red_level(gradient_step),mix_level(YELLOW_GREEN_WORD,16'hFFFF,gradient_step),16'h0000};
            4'd3: palette_rgb = {16'h0000,16'hFFFF,mix_level(0,16'hFFFF,gradient_step)};
            4'd4: palette_rgb = {16'h0000,mix_level(16'hFFFF,0,gradient_step),16'hFFFF};
            4'd5: palette_rgb = {mix_level(0,16'hAAAA,gradient_step),16'h0000,16'hFFFF};
            4'd6: palette_rgb = {mix_level(16'hAAAA,16'hFFFF,gradient_step),16'h0000,mix_level(16'hFFFF,0,gradient_step)};
            4'd7: palette_rgb = {16'hFFFF,mix_level(0,16'hFFFF,gradient_step),mix_level(0,16'hFFFF,gradient_step)};
            4'd9: palette_rgb = {16'hFFFF,mix_level(16'hFFFF,0,gradient_step),mix_level(16'hFFFF,0,gradient_step)};
            default: palette_rgb = {16'hFFFF,16'hFFFF,16'hFFFF};
        endcase
    end
    // 长边为底边：左 x=0 -> 右 x=127；下 y=0 -> 上 y=63。
    // 当前实机扫描方向从上到下；这里只变换图案坐标，保留正确扫描时序。
    wire [5:0] band_y = SCAN_ROW0_AT_BOTTOM ? load_line : (6'd63-load_line);
    // Each 16-bit grayscale word addresses one cascaded driver's current
    // channel. Four retained words cover 64 columns; eight transmitted words
    // repeat that four-chip pattern. First retained word goes to the far chip,
    // last word to the near chip. Never broadcast one colour to both halves
    // in vertical-band mode: RGB2=left 64 columns, RGB1=right 64 columns.
    // 左右半屏及16列组顺序已经实机确认；保留 LANE_CHIP_REVERSE=0。
    wire [1:0] serial_group = load_bit[5:4];
    wire [1:0] lane_group = LANE_CHIP_REVERSE ? (2'd3-serial_group) : serial_group;
    wire [2:0] band_x1 = (RGB1_ON_RIGHT ? 3'd4 : 3'd0) + {1'b0,lane_group};
    wire [2:0] band_x2 = (RGB1_ON_RIGHT ? 3'd0 : 3'd4) + {1'b0,lane_group};
    // 实机已确认：RGB1右半屏、RGB2左半屏，组内级联从左向右。
    // 通道装载次序 load_ch=0..15 对应一个16列芯片块内的 x 次序。
    assign image_x1={(RGB1_ON_RIGHT ? 1'b1:1'b0),lane_group,load_ch};
    assign image_x2={(RGB1_ON_RIGHT ? 1'b0:1'b1),lane_group,load_ch};
    assign image_y=band_y;
    function [47:0] band_colour;
        input [2:0] index;
        begin
            case(index)
                0: band_colour={16'hFFFF,16'h0000,16'h0000}; // leftmost red
                1: band_colour={16'hFFFF,YELLOW_GREEN_WORD,16'h0000};
                2: band_colour={16'h0000,16'hFFFF,16'h0000};
                3: band_colour={16'h0000,16'hFFFF,16'hFFFF};
                4: band_colour={16'h0000,16'h0000,16'hFFFF};
                5: band_colour={16'hAAAA,16'h0000,16'hFFFF};
                6: band_colour={16'hFFFF,16'hFFFF,16'hFFFF};
                default: band_colour=48'd0; // rightmost off
            endcase
        end
    endfunction
    wire [47:0] band_rgb1 = band_colour(VERTICAL_BANDS ? band_x1 : band_y[5:3]);
    wire [47:0] band_rgb2 = band_colour(VERTICAL_BANDS ? band_x2 : band_y[5:3]);
    wire [15:0] image_r1 = MUSIC_DISPLAY_ENABLE ? music_pixel1[47:32] : BAND_DISPLAY_ENABLE ? band_rgb1[47:32] :
                          (COLOR_CYCLE_ENABLE ? palette_rgb[47:32] : RED_WORD);
    wire [15:0] image_g1 = MUSIC_DISPLAY_ENABLE ? music_pixel1[31:16] : BAND_DISPLAY_ENABLE ? band_rgb1[31:16] :
                          (COLOR_CYCLE_ENABLE ? palette_rgb[31:16] : GREEN_WORD);
    wire [15:0] image_b1 = MUSIC_DISPLAY_ENABLE ? music_pixel1[15:0] : BAND_DISPLAY_ENABLE ? band_rgb1[15:0] :
                          (COLOR_CYCLE_ENABLE ? palette_rgb[15:0] : BLUE_WORD);
    wire [15:0] image_r2 = MUSIC_DISPLAY_ENABLE ? music_pixel2[47:32] : BAND_DISPLAY_ENABLE ? band_rgb2[47:32] : (COLOR_CYCLE_ENABLE ? image_r1 : RED_WORD2);
    wire [15:0] image_g2 = MUSIC_DISPLAY_ENABLE ? music_pixel2[31:16] : BAND_DISPLAY_ENABLE ? band_rgb2[31:16] : (COLOR_CYCLE_ENABLE ? image_g1 : GREEN_WORD2);
    wire [15:0] image_b2 = MUSIC_DISPLAY_ENABLE ? music_pixel2[15:0] : BAND_DISPLAY_ENABLE ? band_rgb2[15:0] : (COLOR_CYCLE_ENABLE ? image_b1 : BLUE_WORD2);

    // ------------------------------------------------------------------
    // Init sequence decode.
    //
    // The command is identified by the number of DCLK rising edges while
    // LE is high (FM6363 guide):
    //   1 = DATA_LATCH, 2 = WR_DBG(CFG5), 3 = VSYNC, 4 = WR_CFG1,
    //   6 = WR_CFG2, 8 = WR_CFG3, 10 = WR_CFG4, 12 = EN_OP, 14 = PRE_ACT
    //
    // Sequence (same as the working SPWM FM6363 init):
    //   PRE_ACT(14), EN_OP(12), VSYNC(3), PRE_ACT(14),
    //   CFG1(4), PRE_ACT(14), CFG2(6), PRE_ACT(14),
    //   CFG3(8), PRE_ACT(14), CFG4(10), PRE_ACT(14), CFG5(2)
    // ------------------------------------------------------------------
    always @* begin
        init_len      = 5'd0;
        init_data     = 16'h0000;
        init_has_data = 1'b0;
        init_idle     = 4'd0;
        case (init_idx)
            4'd0:  init_len = 5'd14;
            4'd1:  init_len = 5'd12;
            4'd2:  init_len = 5'd3;
            4'd3:  init_len = 5'd14;
            4'd4:  begin init_has_data = 1'b1; init_data = CFG1_VAL; init_len = 5'd4;  init_idle = 4'd7; end
            4'd5:  init_len = 5'd14;
            4'd6:  begin init_has_data = 1'b1; init_data = CFG2_VAL; init_len = 5'd6;  init_idle = 4'd7; end
            4'd7:  init_len = 5'd14;
            4'd8:  begin init_has_data = 1'b1; init_data = CFG3_VAL; init_len = 5'd8;  init_idle = 4'd7; end
            4'd9:  init_len = 5'd14;
            4'd10: begin init_has_data = 1'b1; init_data = CFG4_VAL; init_len = 5'd10; init_idle = 4'd7; end
            4'd11: init_len = 5'd14;
            4'd12: begin init_has_data = 1'b1; init_data = CFG5_VAL; init_len = 5'd2;  init_idle = 4'd0; end
            default: init_len = 5'd0;
        endcase
    end

    // ------------------------------------------------------------------
    // Main sequencer
    // ------------------------------------------------------------------
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            state        <= S_PWR;
            music_accept <= 0;
            music_commit <= 0;
            pwr_cnt      <= 32'd0;
            clear_cnt    <= 7'd0;
            clear_phase  <= 1'b0;
            insert_phase <= 2'd0;
            row_init_count <= 0;
            init_idx     <= 4'd0;
            init_phase   <= I_SHIFT;
            init_bit     <= 5'd0;
            init_cnt     <= 5'd0;
            load_line    <= 6'd0;
            load_ch      <= 4'd0;
            load_bit     <= 7'd0;
            load_phase   <= L_SHIFT;
            vsync_cnt    <= 3'd0;
            op_count     <= 0;
            test_color   <= 4'd0;
            gradient_step <= 0;
            frame_hold_ticks <= GRADIENT_HOLD_TICKS;
            hold_ticks   <= 32'd0;
            display_active <= 1'b0;
            have_frame <= 1'b0;
            packet_resume <= 1'b0;
            scan_prefix <= 1'b1;

            rgb1         <= 3'b000;
            rgb2         <= 3'b000;
            init_a        <= 1'b0;
            init_c        <= 1'b0;
            clk_en       <= 1'b0;
            lat          <= 1'b0;
            busy         <= 1'b1;
        end else if (tick) begin
            music_accept <= 0;
            music_commit <= 0;
            // Defaults: every DCLK period starts with idle controls.
            rgb1        <= 3'b000;
            rgb2        <= 3'b000;
            init_a       <= 1'b0;
            init_c       <= 1'b0;
            clk_en      <= display_active;
            lat         <= 1'b0;
            busy        <= 1'b0;
            if (display_active && hold_ticks < frame_hold_ticks)
                hold_ticks <= hold_ticks + 1'b1;

            case (state)
                // ------------------------------------------------------
                // Wait for the panel supply to settle.
                // ------------------------------------------------------
                S_PWR: begin
                    busy <= 1'b1;
                    if (pwr_cnt == (POWER_ON_TICKS - 1)) begin
                        pwr_cnt     <= 32'd0;
                        clear_cnt   <= 7'd0;
                        clear_phase <= 1'b0;
                        state       <= S_CLEAR;
                    end else begin
                        pwr_cnt <= pwr_cnt + 32'd1;
                    end
                end

                // ------------------------------------------------------
                // Clear the 64-bit row shift register: 64 A pulses, C=0.
                // ------------------------------------------------------
                S_CLEAR: begin
                    busy <= 1'b1;
                    if (clear_phase == 1'b0) begin
                        init_a       <= 1'b1;
                        init_c       <= 1'b0;
                        clear_phase <= 1'b1;
                        row_init_count <= 1;
                    end else if(row_init_count < ROW_BLANK_TICKS) begin
                        init_a <= 1'b1;
                        row_init_count <= row_init_count + 1'b1;
                    end else begin
                        init_a       <= 1'b0;
                        init_c       <= 1'b0;
                        clear_phase <= 1'b0;
                        if (clear_cnt == (SCAN_ROWS - 1)) begin
                            clear_cnt    <= 7'd0;
                            insert_phase <= 2'd0;
                            state        <= S_INSERT;
                        end else begin
                            clear_cnt <= clear_cnt + 7'd1;
                        end
                    end
                end

                // ------------------------------------------------------
                // Insert the one-hot bit: one A pulse with C=1.
                // ------------------------------------------------------
                S_INSERT: begin
                    busy <= 1'b1;
                    if (insert_phase == 2'd0) begin
                        // DIN setup: one full tick before the DCK edge.
                        init_c        <= 1'b1;
                        insert_phase <= 2'd1;
                    end else if (insert_phase == 2'd1) begin
                        init_a        <= 1'b1;
                        init_c        <= 1'b1;
                        insert_phase <= 2'd2;
                        row_init_count <= 1;
                    end else if(row_init_count < ROW_BLANK_TICKS) begin
                        init_a <= 1'b1;
                        init_c <= 1'b1;
                        row_init_count <= row_init_count + 1'b1;
                    end else begin
                        init_a        <= 1'b0;
                        init_c        <= 1'b1; // DIN hold after DCK
                        insert_phase <= 2'd0;
                        init_idx     <= 4'd0;
                        init_phase   <= I_SHIFT;
                        init_bit     <= 5'd0;
                        init_cnt     <= 5'd0;
                        state        <= S_INIT;
                    end
                end

                // ------------------------------------------------------
                // FM6363B configuration sequence.
                // ------------------------------------------------------
                S_INIT: begin
                    busy   <= 1'b1;
                    clk_en <= 1'b1;
                    case (init_phase)
                        I_SHIFT: begin
                            lat <= 1'b0;
                            if (init_has_data) begin
                                rgb1 <= {3{init_data[15 - init_bit[3:0]]}};
                                rgb2 <= {3{init_data[15 - init_bit[3:0]]}};
                                // LE overlaps the last N DATA clocks, rather
                                // than adding zero bits after the payload.
                                lat <= (init_bit >= (LOAD_BITS - init_len));
                                if (init_bit == (LOAD_BITS - 1)) begin
                                    init_bit   <= 5'd0;
                                    init_phase <= I_IDLE;
                                    init_cnt   <= 5'd0;
                                end else begin
                                    init_bit <= init_bit + 5'd1;
                                end
                            end else begin
                                init_bit   <= 5'd0;
                                init_phase <= I_LE;
                                init_cnt   <= 5'd0;
                            end
                        end
                        I_LE: begin
                            lat      <= 1'b1;
                            init_cnt <= init_cnt + 5'd1;
                            if (init_cnt == (init_len - 5'd1)) begin
                                init_cnt <= 5'd0;
                                if (init_idle == 4'd0) begin
                                    if (init_idx == 4'd12) begin
                                        load_line  <= 6'd0;
                                        load_ch    <= 4'd0;
                                        load_bit   <= 7'd0;
                                        load_phase <= L_SHIFT;
                                        state      <= MUSIC_DISPLAY_ENABLE ? S_WAIT_IMAGE : S_LOAD;
                                    end else begin
                                        init_idx   <= init_idx + 4'd1;
                                        init_phase <= I_SHIFT;
                                        init_bit   <= 5'd0;
                                    end
                                end else begin
                                    init_phase <= I_IDLE;
                                end
                            end
                        end
                        I_IDLE: begin
                            lat      <= 1'b0;
                            init_cnt <= init_cnt + 5'd1;
                            // Also give CFG5 a low-LE separator before SRAM.
                            if (init_cnt == ((init_idle == 0) ? 0 : init_idle - 1)) begin
                                init_cnt <= 5'd0;
                                if (init_idx == 4'd12) begin
                                    load_line  <= 6'd0;
                                    load_ch    <= 4'd0;
                                    load_bit   <= 7'd0;
                                    load_phase <= L_SHIFT;
                                    state      <= MUSIC_DISPLAY_ENABLE ? S_WAIT_IMAGE : S_LOAD;
                                end else begin
                                    init_idx   <= init_idx + 4'd1;
                                    init_phase <= I_SHIFT;
                                    init_bit   <= 5'd0;
                                end
                            end
                        end
                        default: init_phase <= I_SHIFT;
                    endcase
                end

                // ------------------------------------------------------
                // Load the full SRAM: 64 lines x 16 channels per chip.
                // Shift CHAIN_WORDS x 16 bits; LE overlaps the final bit.
                // ------------------------------------------------------
                S_LOAD: begin
                    busy   <= 1'b1;
                    clk_en <= 1'b1;
                    case (load_phase)
                        L_SHIFT: begin
                            lat  <= (load_bit == (LOAD_BITS - 1));
                            rgb1 <= {image_r1[15 - load_bit[3:0]],
                                     image_g1[15 - load_bit[3:0]],
                                     image_b1[15 - load_bit[3:0]]};
                            rgb2 <= {image_r2[15 - load_bit[3:0]],
                                     image_g2[15 - load_bit[3:0]],
                                     image_b2[15 - load_bit[3:0]]};
                            if (load_bit == (LOAD_BITS - 1)) begin
                                load_bit   <= 7'd0;
                                load_phase <= L_LE;
                            end else begin
                                load_bit <= load_bit + 7'd1;
                            end
                        end
                        L_LE: begin
                            // LE falls here; no extra shift clock is needed.
                            lat  <= 1'b0;
                            clk_en <= 1'b0;
                            load_phase <= L_SHIFT;
                            if (load_ch == (CHANNELS_PER_CHIP - 1)) begin
                                load_ch <= 4'd0;
                                if (load_line == (SCAN_ROWS - 1)) begin
                                    load_line <= 6'd0;
                                    packet_resume <= 1'b0;
                                    state     <= S_LGAP;
                                end else begin
                                    load_line <= load_line + 6'd1;
                                    if(have_frame && (load_line % WRITE_ROWS_PER_PACKET == WRITE_ROWS_PER_PACKET-1)) begin
                                        // Complete SRAM rows written. The
                                        // write pointer is left intact here.
                                        packet_resume <= 1'b1;
                                        scan_prefix <= 1'b0;
                                        op_count <= 0;
                                        state <= S_REACT;
                                    end
                                end
                            end else begin
                                load_ch <= load_ch + 4'd1;
                            end
                        end
                        default: load_phase <= L_SHIFT;
                    endcase
                end

                // ------------------------------------------------------
                // One LE-low DCLK between the last DATA_LATCH and VSYNC.
                // Without this gap the two commands merge into a single
                // 4-clock LE pulse and the last word is not latched.
                // ------------------------------------------------------
                S_LGAP: begin
                    busy      <= 1'b1;
                    clk_en    <= 1'b1;
                    lat       <= 1'b0;
                    vsync_cnt <= 3'd0;
                    state     <= S_VSYNC;
                end

                // ------------------------------------------------------
                // VSYNC: LE high for 3 DCLKs, updates the display frame.
                // ------------------------------------------------------
                S_VSYNC: begin
                    busy   <= 1'b1;
                    clk_en <= 1'b1;
                    lat    <= 1'b1;
                    if (vsync_cnt == 3'd2) begin
                        vsync_cnt <= 3'd0;
                        hold_ticks <= 32'd0;
                        display_active <= 1'b0;
                        packet_resume <= 1'b0;
                        scan_prefix <= 1'b1;
                        frame_hold_ticks <= (test_color == 8) ? COLOR_HOLD_TICKS : GRADIENT_HOLD_TICKS;
                        op_count <= 0;
                        state     <= S_VSYNC_GAP;
                    end else begin
                        vsync_cnt <= vsync_cnt + 3'd1;
                    end
                end

                // ------------------------------------------------------
                // Show each colour until just before its scheduled replacement.
                // No writes occur while the current image is being scanned.
                S_RUN: begin
                    if(MUSIC_DISPLAY_ENABLE && music_frame_ready && scan_boundary) begin
                        music_accept<=1;
                        load_line<=0; load_ch<=0; load_bit<=0; load_phase<=L_SHIFT;
                        display_active<=0; packet_resume<=0; op_count<=0;
                        state<=S_BLANK;
                    end else if (!MUSIC_DISPLAY_ENABLE && COLOR_CYCLE_ENABLE && !BAND_DISPLAY_ENABLE && scan_boundary &&
                        hold_ticks >= ((frame_hold_ticks > UPDATE_TICKS) ?
                                       frame_hold_ticks-UPDATE_TICKS : 0)) begin
                        if (test_color == 4'd8) begin
                            test_color <= 4'd9;
                            gradient_step <= 0;
                        end else if (gradient_step == (GRADIENT_STEPS-1)) begin
                            gradient_step <= 0;
                            test_color <= (test_color == 4'd9) ? 4'd0 : test_color + 4'd1;
                        end else begin
                            gradient_step <= gradient_step + 1'b1;
                        end
                        load_line <= 0;
                        load_ch <= 0;
                        load_bit <= 0;
                        load_phase <= L_SHIFT;
                        display_active <= 1'b0;
                        packet_resume <= 1'b0;
                        op_count <= 0;
                        state <= S_BLANK;
                    end
                end
                S_WAIT_IMAGE: begin // wait for complete feature cache before first upload
                    busy<=1;
                    if(music_frame_ready) begin music_accept<=1; state<=S_LOAD; end
                end

                S_BLANK: begin
                    busy <= 1'b1;
                    clk_en <= 1'b1;
                    lat <= 1'b1;
                    if(op_count==12) begin op_count<=0; state<=S_BLANK_GAP; end
                    else op_count<=op_count+1'b1;
                end
                S_BLANK_GAP: begin
                    clk_en<=1'b1;
                    state<=S_LOAD;
                end
                S_VSYNC_GAP: begin
                    clk_en<=1'b1;
                    state<=S_REACT;
                end
                S_REACT: begin
                    clk_en<=1'b1; lat<=1'b1;
                    if(op_count==13) begin op_count<=0; state<=S_ENABLE_GAP; end
                    else op_count<=op_count+1'b1;
                end
                S_ENABLE_GAP: begin
                    clk_en<=1'b1;
                    state<=S_ENABLE;
                end
                S_ENABLE: begin
                    clk_en<=1'b1; lat<=1'b1;
                    if(op_count==11) begin op_count<=0; state<=S_RESTART; end
                    else op_count<=op_count+1'b1;
                end
                S_RESTART: begin
                    clk_en<=1'b1;
                    display_active<=1'b1;
                    if(packet_resume) begin
                        state<=S_PACKET_SCAN;
                    end else begin
                        have_frame<=1'b1;
                        if(MUSIC_DISPLAY_ENABLE) music_commit<=1;
                        hold_ticks<=0;
                        state<=S_RUN;
                    end
                end
                S_PACKET_SCAN: begin
                    // Complete the 64-row scan before the next short write.
                    // Keep the physical/internal row counters aligned.
                    if(scan_boundary) begin
                        display_active<=1'b0;
                        op_count<=0;
                        state<=S_BLANK;
                    end
                end

                default: state <= S_PWR;
            endcase
        end
    end

endmodule

// Independent display timing: runs during LOAD and while waiting to swap.
module led_matrix_scan #(
    parameter integer SCAN_ROWS = 64,
    parameter integer GCLK_PER_ROW = 74
)(
    input wire clk, rst_n, tick, enable, initial_prefix,
    output reg row_a, row_c, gclk_en, frame_pulse,
    output reg [5:0] row_index,
    output wire boundary
);
    localparam [2:0] PRE=0, VISIBLE=1, ADVANCE=2, FRAME=4;
    reg [2:0] phase;
    reg [6:0] count;
    reg [5:0] row;
    assign boundary = enable && (phase == FRAME);

    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            phase<=PRE; count<=0; row<=0; row_index<=0;
            row_a<=0; row_c<=0; gclk_en<=0; frame_pulse<=0;
        end else if(tick) begin
            row_a<=0; row_c<=0; gclk_en<=0; frame_pulse<=0;
            if(!enable) begin
                phase<=initial_prefix ? PRE : VISIBLE;
                count<=0; row<=0; row_index<=0;
            end else case(phase)
                PRE: begin
                    gclk_en<=1;
                    if(count==3) begin count<=0; phase<=VISIBLE; end
                    else count<=count+1'b1;
                end
                VISIBLE: begin
                    gclk_en<=1;
                    if(count==GCLK_PER_ROW-5) begin
                        row_c<=(row==SCAN_ROWS-1); // DIN setup before A
                        count<=0; phase<=ADVANCE;
                    end else count<=count+1'b1;
                end
                ADVANCE: begin
                    // Four continuous GCLKs, DCK high throughout. At 160 ns
                    // per tick this gives 640 ns without holding a PWM state
                    // for extra clockless dwell periods.
                    gclk_en<=1;
                    row_a<=1;
                    row_c<=(row==SCAN_ROWS-1);
                    if(count==3) begin
                        count<=0;
                        if(row==SCAN_ROWS-1) phase<=FRAME;
                        else begin row<=row+1'b1; row_index<=row+1'b1; phase<=VISIBLE; end
                    end else count<=count+1'b1;
                end
                FRAME: begin
                    frame_pulse<=1; row<=0; row_index<=0; phase<=VISIBLE;
                end
                default: phase<=PRE;
            endcase
        end
    end
endmodule
