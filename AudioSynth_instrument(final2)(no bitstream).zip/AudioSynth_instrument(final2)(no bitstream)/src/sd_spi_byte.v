`default_nettype none
// Mode0, MSB first. 390625Hz init / 3.125MHz transfer. No generated logic clock.
module sd_spi_byte(input wire clk,rst_n,start,fast,input wire [7:0] tx,
 input wire miso,output reg sck,mosi,output reg busy,output reg [7:0] rx);
 (* syn_preserve=1 *) reg miso_meta,miso_sync;
 reg [6:0] count;reg [2:0] bitpos;reg [7:0] shift;
 reg fast_held;
 always @(posedge clk)begin
  miso_meta<=miso;miso_sync<=miso_meta;
  if(!rst_n)begin sck<=0;mosi<=1;busy<=0;rx<=255;shift<=255;count<=0;bitpos<=0;fast_held<=0;end
  else if(!busy)begin
   sck<=0;
   if(start)begin busy<=1;fast_held<=fast;count<=fast?7:63;bitpos<=0;shift<=tx;mosi<=tx[7];rx<=0;end
  end else if(count!=0)count<=count-1'b1;
  else begin
   count<=fast_held?7:63;
   if(!sck)begin sck<=1;rx<={rx[6:0],miso_sync};end
   else begin
    sck<=0;
    if(bitpos==7)begin busy<=0;mosi<=1;end
    else begin bitpos<=bitpos+1'b1;shift<={shift[6:0],1'b1};mosi<=shift[6];end
   end
  end
 end
endmodule
`default_nettype wire
