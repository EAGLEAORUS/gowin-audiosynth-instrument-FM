create_clock -name clk_50m -period 20.000 [get_ports {clk_50m}]
create_generated_clock -name clk_usb -source [get_ports {clk_50m}] -multiply_by 48 -divide_by 25 [get_pins {usb/clock_usb/PLL_inst/CLKOUT0}]
// PHY pins are asynchronous; cut only pad -> first synchronizer stage.
set_false_path -from [get_ports {usb_dp usb_dm}] -to [get_pins {*dp_meta_s0/D *dm_meta_s0/D}]
// Gray FIFO/memory paths cross domains under pointer synchronization.
// Bound propagation instead of cutting whole clock domains. Core captures a
// committed word only after two pointer synchronizer stages (>40ns).
set_max_delay -from [get_clocks {clk_usb}] -to [get_clocks {clk_50m}] 20.000
set_min_delay -from [get_clocks {clk_usb}] -to [get_clocks {clk_50m}] 0.000
set_max_delay -from [get_clocks {clk_50m}] -to [get_clocks {clk_usb}] 10.000
set_min_delay -from [get_clocks {clk_50m}] -to [get_clocks {clk_usb}] 0.000
// First Gray synchronizer stages intentionally sample asynchronously. Only
// their HOLD checks are excepted; bounded setup propagation above remains.
set_false_path -hold -to [get_regs {*records/rg_meta*_s0 *records/wg_meta*_s0 *usb/cdc_fault_meta_s0}]
// POR/PLL reset is asynchronous to USB. The first reset synchronizer may
// release near an edge; stage 2 synchronizes release before protocol use.
// The broad cross-domain min_delay otherwise treats its async CLEAR as a
// synchronous data capture. Exempt only this first-stage CLEAR hold check;
// stage-1 Q -> stage-2 D and every stage-2 check remain timed.
set_false_path -hold -to [get_pins {usb/reset_usb_0_s*/CLEAR}]
// USB write pointer can change every 10.417ns: also bound its Gray bits to
// <one source period; the wider payload remains under the 20ns bound above.
set_max_delay -to [get_regs {*records/wg_meta*_s0}] 10.000
// UART external receiver does not capture on an FPGA clock.
set_false_path -to [get_ports {uart_tx}]

// Audio PLL: USB PLL96 -> 768MHz VCO /62.5 =12.288MHz. No fabric divider.
create_generated_clock -name audio_mclk -source [get_pins {usb/clock_usb/PLL_inst/CLKOUT0}] -multiply_by 16 -divide_by 125 [get_pins {audio/clock_audio/PLL_inst/CLKOUT0}]
// Each codec is a separate master, /4 BCLK, /256 LRCK. No phase assumption.
create_clock -name adc_bclk -period 325.520834 -waveform {0 162.760417} [get_ports {es0_dsclk}]
create_clock -name dac_bclk -period 325.520834 -waveform {0 162.760417} [get_ports {es1_dsclk}]
// ES7243E p12: data <=16ns, LRCK <=10ns after falling BCLK at 3.3V.
// 4ns board budget (assumption to measure), min=0 conservative.
set_input_delay -clock adc_bclk -clock_fall -max 20.000 [get_ports {es0_sdin}]
set_input_delay -clock adc_bclk -clock_fall -min 0.000 [get_ports {es0_sdin}]
set_input_delay -clock adc_bclk -clock_fall -max 14.000 [get_ports {es0_alrck}]
set_input_delay -clock adc_bclk -clock_fall -min 0.000 [get_ports {es0_alrck}]
set_input_delay -clock dac_bclk -clock_fall -max 14.000 [get_ports {es1_dlrc}]
set_input_delay -clock dac_bclk -clock_fall -min 0.000 [get_ports {es1_dlrc}]
// ES8156 p13: setup/hold=10ns. Include a 4ns output/clock skew budget.
set_output_delay -clock dac_bclk -max 14.000 [get_ports {es1_sdout}]
set_output_delay -clock dac_bclk -min -14.000 [get_ports {es1_sdout}]
// Frame FIFO: bound payload and Gray-pointer crossings, never clock groups.
set_max_delay -from [get_clocks {adc_bclk}] -to [get_clocks {dac_bclk}] 160.000
set_min_delay -from [get_clocks {adc_bclk}] -to [get_clocks {dac_bclk}] 0.000
set_max_delay -from [get_clocks {dac_bclk}] -to [get_clocks {adc_bclk}] 160.000
set_min_delay -from [get_clocks {dac_bclk}] -to [get_clocks {adc_bclk}] 0.000
set_false_path -hold -to [get_regs {*audio/frame_fifo/wg_meta*_s0 *audio/frame_fifo/rg_meta*_s0}]
// Only first-stage asynchronous reset assertion/release controls are excepted.
// Stage 1 Q -> stage 2 D and consumers remain timed in their clock domains.
set_false_path -to [get_pins {*audio/reset_rx/meta_s*/CLEAR *audio/reset_tx/meta_s*/CLEAR *audio/reset_core/meta_s*/CLEAR}]
// Slow asynchronous I2C ACK enters only two explicitly named first samplers.
set_false_path -from [get_ports {es7243_sda}] -to [get_regs {*audio/adc_config/u_i2c_com/sda_meta_s0}]
set_false_path -from [get_ports {es8156_sda}] -to [get_regs {*audio/dac_config/u_i2c_com/sda_meta_s0}]
// LED and I2C are externally observed asynchronous outputs; no FPGA-clock receiver.
set_false_path -to [get_ports {lin_led es7243_scl es8156_scl es7243_sda es8156_sda}]
// Only the FIFO committed-memory HOLD relation has no clock phase meaning.
// A read is qualified by TWO synchronized Gray-pointer stages. A bank cannot
// be rewritten until the read pointer returns through TWO write-domain stages.
// Thus each captured payload is immutable around the read edge; the explicit
// 160ns SETUP/max propagation bound above still applies to all 48 payload bits.

// DX7 PCM FIFO core50 <-> DAC BCLK, bounded committed payload/Gray crossings.
set_max_delay -from [get_clocks {clk_50m}] -to [get_clocks {dac_bclk}] 160.000
set_min_delay -from [get_clocks {clk_50m}] -to [get_clocks {dac_bclk}] 0.000
set_max_delay -from [get_clocks {dac_bclk}] -to [get_clocks {clk_50m}] 20.000
set_min_delay -from [get_clocks {dac_bclk}] -to [get_clocks {clk_50m}] 0.000
set_max_delay -to [get_regs {*audio/synth/pcm_fifo/wg_meta*_s0}] 20.000
set_false_path -hold -to [get_regs {*audio/synth/pcm_fifo/wg_meta*_s0 *audio/synth/pcm_fifo/rg_meta*_s0 *audio/synth/tick_meta_s0 *usb/midi_online_meta_s0}]
// Immutable committed banks are qualified by two Gray synchronizer stages.
set_false_path -hold -from [get_regs {*audio/synth/pcm_fifo/mem_mem_RAMREG*}] -to [get_regs {*audio/synth/pcm_fifo/rd_data_reg*_s0}]
set_false_path -to [get_pins {*audio/synth/reset_core/meta_s*/CLEAR *audio/synth/reset_read/meta_s*/CLEAR}]
// PLL lock is asynchronous: only first domain-reset CLEAR is excepted above.
// Independent codec clock-health samplers; only external pad -> first stage.
set_false_path -from [get_ports {es0_dsclk}] -to [get_regs {*audio/adc_health/bclk_meta_s0}]
set_false_path -from [get_ports {es0_alrck}] -to [get_regs {*audio/adc_health/ws_meta_s0}]
set_false_path -from [get_ports {es1_dsclk}] -to [get_regs {*audio/dac_health/bclk_meta_s0}]
set_false_path -from [get_ports {es1_dlrc}] -to [get_regs {*audio/dac_health/ws_meta_s0}]
set_false_path -to [get_pins {*audio/reset_frame_rd/meta_s0/CLEAR}]
// WS2812 receiver has no FPGA clock input. Pulse timing is generated at 50MHz.
set_false_path -to [get_ports {ws2812}]

// Gowin models a clock port used as D as a clock-launched self endpoint;
// the -from pad exception above does not suppress that generated HOLD check.
// Only the two asynchronous first samplers are exempted. Their Q -> second
// sampler D paths and all consumers remain timed at 50MHz.
set_false_path -hold -to [get_regs {*audio/adc_health/bclk_meta_s0 *audio/dac_health/bclk_meta_s0}]

// PLL clock output feeds codec MCLK pins; no external FPGA-clock capture.
set_false_path -to [get_ports {es0_mclk es1_mclk}]

// K1 octave: asynchronous pad -> first sampler only. meta -> sync is timed.
set_false_path -from [get_ports {k1_n}] -to [get_regs {*keyboard_keys/meta_0_s0}]

// ADC analysis FIFO now crosses into 50MHz, independent of DAC startup.
set_max_delay -from [get_clocks {adc_bclk}] -to [get_clocks {clk_50m}] 20.000
set_min_delay -from [get_clocks {adc_bclk}] -to [get_clocks {clk_50m}] 0.000
set_max_delay -from [get_clocks {clk_50m}] -to [get_clocks {adc_bclk}] 160.000
set_min_delay -from [get_clocks {clk_50m}] -to [get_clocks {adc_bclk}] 0.000
set_max_delay -to [get_regs {*audio/frame_fifo/rg_meta*_s0}] 20.000
set_false_path -hold -from [get_regs {*audio/frame_fifo/mem_mem_RAMREG*}] -to [get_regs {*audio/frame_fifo/rd_data_reg*_s0}]
// K2 octave: asynchronous pad -> first sampler only. meta -> sync is timed.
set_false_path -from [get_ports {k2_n}] -to [get_regs {*keyboard_keys/meta_1_s0}]
// The panel has its own serial receiver; phase/setup/hold checked by pin-level TB.
set_false_path -to [get_ports {hub_r1 hub_g1 hub_b1 hub_r2 hub_g2 hub_b2 hub_a hub_b hub_c hub_clk hub_lat hub_oe}]

// Only asynchronous EC11 pads to first-stage D; inter-stage paths timed.
set_false_path -from [get_ports {ec11_a}] -to [get_regs {*ui/encoder/a_meta*_s0}]
set_false_path -from [get_ports {ec11_b}] -to [get_regs {*ui/encoder/b_meta*_s0}]
set_false_path -from [get_ports {ec11_push_n}] -to [get_regs {*ui/encoder/p_meta*_s0}]
// ST7789 serial timing checked at pins in simulation; it has no FPGA capture clock.
set_false_path -to [get_ports {tft_blk tft_cs_n tft_dc tft_res_n tft_sda tft_scl}]

// Only the asynchronous Home pad to first-stage D; following stages stay timed.
set_false_path -from [get_ports {home_n}] -to [get_regs {*ui/home_meta*_s0}]

// Frozen ALT1 CH569 TX: 120MHz normal-mode source synchronous HSPI.
// Data changes at falling clock; max 3ns/min0 I/O+board budget is an explicit
// design assumption to validate on hardware, not a measured CH569 timing spec.
create_clock -name pc_rx -period 8.333333 -waveform {0 4.166667} [get_ports {pc_hspi_rx_clk}]
set_input_delay -clock pc_rx -clock_fall -max 3.000 [get_ports {pc_hspi_hd[*] pc_hspi_rx_req pc_hspi_rx_vld}]
set_input_delay -clock pc_rx -clock_fall -min 0.000 [get_ports {pc_hspi_hd[*] pc_hspi_rx_req pc_hspi_rx_vld}]
// TX really runs at 12.5MHz, generated synchronously from core50 (no PLL).
// Its data RAM remains clocked at 50MHz: an address is held for 80ns and
// the bank is immutable until the start/done mailbox completes. These
// phase-related address/data paths remain timed, with no false path.
create_generated_clock -name pc_tx_core -source [get_ports {clk_50m}] -divide_by 4 [get_pins {pc/link/tx_core_clk_s0/Q}]
// External receiver setup5ns/hold1ns budget, pending physical characterization.
// Forwarding is separately timed as an ordinary output from the 50MHz
// divider FF: max0 below gives a 20ns pad-arrival bound, min0 ensures no
// advance. Setup uses zero extra forwarding latency; hold includes the
// full 20ns bound plus 1ns receiver hold. The negative-control model
// sets max19.9 and MUST fail this exact output path.
set_output_delay -clock pc_tx_core -clock_fall -max 5.000 [get_ports {pc_hspi_hd[*] pc_hspi_tx_req pc_hspi_tx_vld}]
set_output_delay -clock pc_tx_core -clock_fall -min -21.000 [get_ports {pc_hspi_hd[*] pc_hspi_tx_req pc_hspi_tx_vld}]
// Frozen immutable RX bank is published by toggle then acknowledged only after
// the entire response. Two destination synchronizer clocks qualify its read.
set_max_delay -from [get_clocks {pc_rx}] -to [get_clocks {clk_50m}] 20.000
set_min_delay -from [get_clocks {pc_rx}] -to [get_clocks {clk_50m}] 0.000
set_max_delay -from [get_clocks {clk_50m}] -to [get_clocks {pc_rx}] 8.000
set_min_delay -from [get_clocks {clk_50m}] -to [get_clocks {pc_rx}] 0.000
set_false_path -to [get_regs {*pc/link/done_meta*_s0 *pc/link/ack_meta*_s0}]
// Published transaction metadata cannot change until core releases ACK.
// The request crosses two core synchronizer stages before this capture;
// these immutable buses have no phase-related HOLD requirement. Keep the
// explicit 20ns SETUP propagation bound above, including every metadata bit.
set_false_path -hold -from [get_clocks {pc_rx}] -to [get_regs {*pc/transaction_*}]
// HTRDY is asynchronous; EXM samples it before granting any data transmission.
set_false_path -from [get_ports {pc_hspi_tx_ready}] -to [get_regs {*pc/link/bus_core/reg_tx_rdy_meta*_s0}]
// Only the FIRST request synchronizer stage is excluded; its second stage
// gates TX arbitration. Actual RX request/data capture remains source timed.
set_false_path -to [get_regs {*pc/link/bus_core/reg_rx_active_meta*_s0}]
set_false_path -to [get_pins {*pc/link/reset_rx/meta_s*/CLEAR *pc/link/reset_rx/sync_s*/CLEAR *pc/link/reset_tx/meta_s*/CLEAR *pc/link/reset_tx/sync_s*/CLEAR}]
// Private EXM RX outputs are unused; the registered parser owns RX/reset.
// Receiver grant has no continuous-clock capture contract; it gates frame start.
set_false_path -to [get_ports {pc_hspi_rx_ready}]
// KEY0 async assertion, 10ms filtered release, then per-domain synchronizers.
set_false_path -from [get_ports {key0_n}] -to [get_pins {*system_reset/key_meta*/CLEAR *system_reset/count*/CLEAR *system_reset/released*/CLEAR}]
set_false_path -from [get_ports {key0_n}] -to [get_regs {*system_reset/key_meta*_s0}]

// Codec counter telemetry uses two whole-bank mailboxes. Only first handshake
// samplers and asynchronous reset controls are excepted; bank propagation is
// bounded by the existing ADC/DAC <-> core max constraints above (20ns).
// bank and bank_valid update with ack at a source edge, then remain held until
// the NEXT request (~1ms). ack_meta -> ack_sync -> consumer gives >=40ns to
// settle before the actual capture. No same-edge source/destination HOLD
// relation exists for these two qualified mailboxes. Keep SETUP/max timing,
// handshake stage2 paths, and every unrelated data/clock path timed.
// Verified: status-mailbox1 actual RTL, asynchronous phases/stopped clocks,
// reset/restart and an instrumented worst-bound 20ns data transport.
set_false_path -hold -from [get_regs {*audio/adc_stats/bank*_s0}] -to [get_regs {*audio/adc_stats/data*_s0 *audio/adc_stats/valid_s1}]
set_false_path -hold -from [get_regs {*audio/dac_stats/bank*_s0}] -to [get_regs {*audio/dac_stats/data*_s0 *audio/dac_stats/valid_s1}]
set_false_path -to [get_regs {*audio/adc_stats/request_meta*_s0 *audio/adc_stats/ack_meta*_s0 *audio/dac_stats/request_meta*_s0 *audio/dac_stats/ack_meta*_s0}]
set_false_path -to [get_pins {*audio/adc_stats/reset_source/meta_s*/CLEAR *audio/dac_stats/reset_source/meta_s*/CLEAR}]
// Clock forwarding pad has an ordinary data path from the divider Q;
// do not declare a generated clock at that port (it aliases the D feedback).
set_output_delay -clock clk_50m -max 0.000 [get_ports {pc_hspi_tx_clk}]
set_output_delay -clock clk_50m -min 0.000 [get_ports {pc_hspi_tx_clk}]
// Only the generated-clock-as-data HOLD artifact at the divider's own D.
// Physically Q and D belong to the same 50MHz FF (D=~Q), with zero clock
// skew. Its real 50MHz setup remains timed. The model's measured minimum
// feedback data delay is >2ns versus <0.05ns hold; no CDC or other FF is cut.
set_false_path -hold -from [get_clocks {pc_tx_core}] -to [get_pins {pc/link/tx_core_clk_s0/D}]

// ESP32 link, 2026-10-31. bt_bclk/bt_ws are forwarded copies of the ES8156
// master clocks and bt_din is the es1_sdout pad itself; the ESP32 samples with
// its own forwarded BCLK, so only the pad-to-pad forward delay and the DAC data
// arrival need a bound. 14ns matches the existing ES8156 output budget.
// Absolute pad-to-pad latency is irrelevant at 3.072 MHz (one bit = 325.5ns):
// the ESP32 re-times with the forwarded BCLK, so only intra-pair skew against
// bt_din matters and both forwards use identical IBUF/OBUF paths. 30ns keeps
// the skew below 10% of a bit period and still bounds generic clock routing.
set_max_delay -from [get_ports {es1_dsclk}] -to [get_ports {bt_bclk}] 30.000
set_max_delay -from [get_ports {es1_dlrc}] -to [get_ports {bt_ws}] 30.000
set_output_delay -clock dac_bclk -max 14.000 [get_ports {bt_din}]
set_output_delay -clock dac_bclk -min -14.000 [get_ports {bt_din}]
// The private UART is a pad-level byte stream; the ESP32 has no FPGA clock and
// the FPGA RX side samples only after its two-flop synchronizer.
set_false_path -from [get_ports {bt_uart_rx}] -to [get_regs {*bt_link/rx/meta_s0}]
set_false_path -to [get_ports {bt_uart_tx}]

// New asynchronous inputs: only first sampler is excluded. SPI runs at
// 3.125MHz max; the two-cycle MISO sampler has >120ns half-period margin.
set_false_path -from [get_ports {uart_rx}] -to [get_regs {*sd/rx/rx_d0*_s0}]
set_false_path -from [get_ports {sd_miso}] -to [get_regs {*sd/spi/miso_meta*_s0}]
set_output_delay -clock clk_50m -max 0.000 [get_ports {sd_sck sd_mosi sd_cs_n}]
set_output_delay -clock clk_50m -min 0.000 [get_ports {sd_sck sd_mosi sd_cs_n}]

create_generated_clock -name ae350_core200 -source [get_ports {clk_50m}] -multiply_by 4 [get_pins {sd_cpu/pll/PLL_inst/CLKOUT1}]
create_generated_clock -name ae350_rtc10 -source [get_ports {clk_50m}] -divide_by 5 [get_pins {sd_cpu/pll/PLL_inst/CLKOUT4}]

// A16 asynchronous input. Keep timing from the first stage onward.
set_false_path -from [get_ports {display_button_n}] -to [get_regs {*display_source/button_meta*}]
set_false_path -from [get_ports {ir_rx}] -to [get_regs {*single_string/rx_meta*}]
