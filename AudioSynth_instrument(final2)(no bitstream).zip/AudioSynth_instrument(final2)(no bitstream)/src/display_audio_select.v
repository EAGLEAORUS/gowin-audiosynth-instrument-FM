`default_nettype none
// A16 selects the analysis stream. Post-effects PCM gain is display-only.
module display_audio_select #(parameter integer PCM_GAIN=50, US_CYCLES=50,
 DB_US=10000, SHORT_US=400000, DOUBLE_US=400000, PROMPT_US=3000000)(
 input wire clk,rst_n,button_n,adc_valid,adc_ready,pcm_valid,pcm_ready,
 input wire [31:0] adc_data,input wire [47:0] pcm_data,
 output reg pcm_selected,output wire prompt,output reg changed,
 output wire sample_valid,output wire [31:0] sample_data,output wire stream_ok,
 output reg pcm_active,output wire button_debounced_n);
 reg [5:0] us_div;wire utick=us_div==US_CYCLES-1;
 (* syn_preserve=1 *) reg button_meta,button_sync;
 reg stable_button;
 assign button_debounced_n=stable_button;
 reg [$clog2(DB_US+1)-1:0] debounce_age;
 reg previous_button,pressed,waiting;
 reg [19:0] press_age,gap_age;reg [21:0] prompt_age;
 assign prompt=prompt_age!=0;
 // Multiply PCM24 before discarding low 8 bits. Signed 56-bit products
 // retain full precision for a positive signed-32-bit integer gain.
 localparam signed [31:0] GAIN=PCM_GAIN;
 function signed [55:0] display_product;
  input signed [23:0] sample;
  reg signed [55:0] extended;
  begin
   extended={{32{sample[23]}},sample};
   if(PCM_GAIN==32)display_product=extended<<<5;
   else if(PCM_GAIN==50)display_product=(extended<<<5)+(extended<<<4)+(extended<<<1);
   else display_product=extended*GAIN;
  end
 endfunction
 reg signed [55:0] left_product,right_product;reg scaled_valid;
 function [15:0] clip16;
 input signed [55:0] v;
 begin
  if(v>56'sd8388607)clip16=16'h7fff;
  else if(v< -56'sd8388608)clip16=16'h8000;
  else clip16=v[23:8]; // arithmetic floor /256; no wrap at either rail
 end endfunction
 // Preserve the startup ADC display while the DAC is still coming up.
 wire desired_source=pcm_selected && (pcm_ready || !adc_ready);
 assign sample_valid=!changed && (pcm_active?(scaled_valid && pcm_ready):(adc_valid && adc_ready));
 assign sample_data=pcm_active?{clip16(left_product),clip16(right_product)}:adc_data;
 assign stream_ok=pcm_active?pcm_ready:adc_ready;
 always @(posedge clk)begin
  if(!rst_n)begin
   pcm_selected<=1;pcm_active<=1;changed<=0;us_div<=0;previous_button<=1;
   button_meta<=1;button_sync<=1;stable_button<=1;debounce_age<=0;
   pressed<=0;waiting<=0;press_age<=0;gap_age<=0;prompt_age<=0;
   scaled_valid<=0;left_product<=0;right_product<=0;
  end else begin
   button_meta<=button_n;button_sync<=button_meta;
   scaled_valid<=pcm_valid && pcm_ready;
   if(pcm_valid && pcm_ready)begin
    left_product<=display_product(pcm_data[47:24]);
    right_product<=display_product(pcm_data[23:0]);
   end
   changed<=pcm_active!=desired_source;
   pcm_active<=desired_source;
   us_div<=utick?0:us_div+1'b1;
   if(utick)begin
    if(button_sync==stable_button)debounce_age<=0;
    else if(debounce_age==DB_US-1)begin stable_button<=button_sync;debounce_age<=0;end
    else debounce_age<=debounce_age+1'b1;
    previous_button<=stable_button;
    if(prompt_age!=0)prompt_age<=prompt_age-1'b1;
    if(waiting)begin
     if(gap_age>=DOUBLE_US-1)begin waiting<=0;gap_age<=0;end
     else gap_age<=gap_age+1'b1;
    end
    if(previous_button && !stable_button)begin pressed<=1;press_age<=0;end
    else if(pressed && !stable_button)begin
     if(press_age<SHORT_US)press_age<=press_age+1'b1;
     else begin waiting<=0;gap_age<=0;end
    end
    if(!previous_button && stable_button && pressed)begin
     pressed<=0;
     if(press_age<SHORT_US)begin
      if(waiting && gap_age<DOUBLE_US-1)begin
       pcm_selected<=!pcm_selected;prompt_age<=PROMPT_US;waiting<=0;
      end else begin waiting<=1;gap_age<=0;end
     end else begin waiting<=0;gap_age<=0;end
    end
   end
  end
 end
endmodule
`default_nettype wire
