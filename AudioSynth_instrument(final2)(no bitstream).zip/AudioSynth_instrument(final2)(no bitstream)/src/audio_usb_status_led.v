// Compatibility placeholder for already-open Gowin file lists.
// audio_usb_status_led is now defined in audio_usb_loop24.v.
