# USB-01：全速 USB MIDI -> Debugger UART

当前真实 USB 入口为 **usb_midi_fs_top**，工程为 `fpga/usb_midi_fs/usb_midi_fs.gprj`，构建脚本为 `scripts/usb_midi/build_fs.tcl`。实现全速收发、单设备枚举、描述符选择 MIDI 1.0 Bulk IN、整包 CDC，再接入本目录原有 MIDI/UART。没有启动时合成事件。

可烧录文件：`build/usb01/fs-pnr/impl/pnr/usb_midi_fs.fs`。旧 `AudioSynth_instrument/impl/pnr/AudioSynth_instrument.fs` 和 SELFTEST 工程未被覆盖，不能用旧文件验收本次功能。当前仅模型验证，Orca 实板仍待人工验证；结果、限制和步骤见 [全速交付报告](../../docs/usb-midi/USB-01-FULL-SPEED.md)。

V22=用户确认50MHz有源晶振；H13/G13=USB D+/D-；U15=Debugger TX；LVCMOS33。USB 为双向端口，UART 为115200/8N1。`usb_midi_fs_top.RAW_ENABLE=1` 可打开有效端点payload的十六进制日志；默认0。仅修改此参数后须重新综合/PnR，当前 `.fs` 默认关闭RAW。

## 以下为此前 payload/SELFTEST 交付说明

2026-10-12。用户选择“仅使用当前例程，先交付可验证部分”。**usb_midi_debug 没有 USB Host、PHY 或枚举器，不能直接接收 Orca 的 D+/D- 数据。** 原例程仍是低速 Host，键盘说明书写全速；此次没有替换、改写或绕过 USB 层。随后按用户要求新增独立上板串口自检顶层与引脚/PnR工程，生成的 bitstream 仅供 SELFTEST，不能读取真实键盘按键。

## 模块关系

`packet_valid + packet_length + packet_data` -> packet FIFO -> usb_midi_payload_decode -> 两个独立 FIFO（未来事件接口 / UART事件日志）。原始payload另进RAW FIFO，USB状态另进status FIFO；midi_debug_logger按行轮询三路日志 -> midi_uart_tx -> uart_tx。

| 文件 | 功能 |
|---|---|
| usb_midi_debug.v | 仅内部集成边界、各FIFO及错误计数输出 |
| usb_midi_payload_decode.v | 四字节USB-MIDI1.0事件解析、CIN/状态/数据位校验、零力度规范化 |
| midi_sync_fifo.v | 同域FIFO、满时丢新记录并饱和计数，支持满时同时pop/push |
| midi_debug_logger.v | 独立event/raw/status队列，逐行轮询，十进制/十六进制文本 |
| midi_uart_tx.v | 参考现有uart_tx_V2的四状态8N1发送器；显式复位/完整停止位/锁存输入与起始对齐分频 |
| usb_midi_board_top.v | 四物理端口包装、同步上电复位、6个合成MIDI事件、USB静态电平采样；无Host |
| midi_board_message_tx.v | 明确标记SELFTEST/未实现Host的启动、结束及静态电平文本 |

上板入口：`fpga/usb_midi_board/usb_midi_board_selftest.gprj`，顶层 `usb_midi_board_top`；CST/SDC与RTL同目录。V22=用户确认的50MHz，U15=Debugger TX，H13/G13=USB D+/D-输入，统一LVCMOS33；V14 RX不使用。完整报告与人工步骤见 `docs/usb-midi/USB-01-BOARD-PNR.md`。原 `AudioSynth_instrument.gprj` 仍只有内部模块，不能直接应用这份物理端口CST，需打开独立工程。

UART来源：用户补充例程boards/common/uart_tx_V2.v，原作者模块无外部复位；本副本为适配后实现，参考许可见USB_HOST_REFERENCE_LICENSE.txt。未修改参考文件。

## 输入契约与复位

所有端口处在同一个clk域；rst_n为同步低有效复位，外部异步复位须先按本域同步释放。复位清FIFO/输出状态/计数，TX回高。没有CDC实现；异域Host必须在前面使用帧异步FIFO。
每个packet_valid高的周期提交一个完整USB端点有效payload，最大64字节；packet_length为有效长度（0..64），packet_data[7:0]为第一字节，其后每8位一字节。输入没有ready，突发超过packet FIFO容量会丢包并计数。默认8包。Host必须在提交前完成CRC/PID/长度校验、DATA toggle去重、去除PID/CRC，且只提交已选中MIDI端点的数据；本模块不能补做USB事务验证。长度>64或非4倍数整包拒绝并记malformed。0长度不产事件。
RAW开关只决定当拍payload是否进日志队列，**不控制解码**；RAW可记录<=64字节的非法MIDI长度以诊断。未声明字节不打印。Host物理CRC错误须由上游报告USB ERROR，不能把CRC错误payload当有效输入。

支持CIN8..E的NoteOff/NoteOn/PolyPressure/CC/Program/ChannelPressure/PitchBend，保留16个Cable与16通道；CIN2/3/5/F支持相应System Common/Realtime。NoteOn velocity0输出type=NoteOff，保留原status与CIN用于诊断。Program/ChannelPressure按2个有效MIDI字节处理，第三个填充字节忽略；单字节System未用data1/data2清零。SysEx CIN4/6/7及F7结束暂仅RAW记录并增加unsupported，不组装长SysEx；保留CIN0全零填充忽略，其它保留CIN记unsupported或malformed。实际Orca消息格式仍待采集。

## 统一事件接口（本地debug-v1，未冻结全局音频接口）

只有evt_valid && evt_ready时消费；背压保持evt_data与valid。默认未来事件FIFO64项，日志FIFO另64项，互不阻塞。未来接口不用时必须将evt_ready接1，否则约64个事件后未来事件队列会溢出，UART日志仍独立运行。FIFO溢出计数饱和到32'hffffffff；packet/event丢失令recovery_required持续为1直到复位，未来合成器必须响应此信号恢复/释放全部音符。本轮无AllNotesOff注入、无音频frame_id、无声部管理。断连时上游负责先停止新包，并同步复位/清理本通路；复位会中断当前UART字符，PC应在恢复后从完整行重新同步。

| evt_data 位 | 字段 |
|---|---|
| 39:36 | Cable 0..15 |
| 35:32 | 原始CIN |
| 31:28 | type：1 Off、2 On、3 CC、4 Program、5 Bend、6 PolyPressure、7 ChannelPressure、8 System |
| 27:24 | channel 0..15；System清零 |
| 23:17 | data1 |
| 16:10 | data2；Bend={data2,data1}，中心8192 |
| 9:8 | 有效MIDI字节数1/2/3（不包括Cable/CIN头） |
| 7:0 | 原始status |

packet_overflow/event_overflow为数据通路丢失；event_log_overflow/raw_log_overflow/status_log_overflow只表示相应日志记录丢失。各日志按整条记录入队或丢弃，不会因溢出产生半行拼接；跨日志类型按轮询输出，不承诺USB状态与MIDI跨类型的严格时间顺序，各自队列内部保序。

## 输出示例（仿真数据，不是真实键盘收包）

```text
NOTE_ON CH=01 NOTE=060 VEL=100 CABLE=00 CIN=9
NOTE_OFF CH=01 NOTE=064 VEL=000 CABLE=00 CIN=9
CC CH=01 CTRL=001 VALUE=064 CABLE=00 CIN=B
PROGRAM_CHANGE CH=01 PROGRAM=127 CABLE=00 CIN=C
PITCH_BEND CH=01 VALUE=08192 CABLE=00 CIN=E
RAW LEN=008 DATA=09 90 3C 64 08 80 3C 00 
```

行末显式0D 0A，数值固定宽度零填充，通道显示1..16，Cable显示0..15。RAW每字节后一个空格。status_valid与status_code由Host上游产生（本模块不伪造已连接/已枚举）：0 USB DEVICE CONNECTED，1 USB RESET，2 DEVICE DESCRIPTOR，3 CONFIGURED，4 MIDI ENDPOINT READY，5 USB ERROR，6/7 USB DISCONNECTED。错误细分由上游计数/接口扩展；当前状态日志无自带错误原因字段。
默认CLK_HZ=50_000_000、BAUD=115200，四舍五入DIV=434、8N1，条件实际50MHz时baud=115207.37（+0.0064%）。RAW高流量受11520字节/秒左右吞吐限制，可观测丢日志是预期行为；不能用加大FIFO消除持续超速。

## 复现和当前验证

在工作区根运行（内置Python可用，不安装依赖）：

```powershell
& 'C:/Users/EAGLEAORUS/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/python.exe' scripts/usb_midi/run_modelsim.py
New-Item -ItemType Directory -Force build/usb01/payload-syn
Set-Location build/usb01/payload-syn
& 'C:/Gowin/Gowin_V1.9.12.03_x64/IDE/bin/gw_sh.exe' ../../../scripts/usb_midi/synth_payload.tcl
```

实际结果见根目录docs/usb-midi/USB-01-PAYLOAD-RESULTS.md。仿真只验证已提交payload与UART，不包含USB D+/D-协议或Orca设备模型。综合仅内部模块，795个逻辑边界I/O不能当作板级顶层引脚；没有PnR/板级时序或.fs。默认BSRAM利用偏高（519位浅FIFO被映射成较多宽度分片），尚未针对资源优化。

Rev1.4文档核对的USB D+/D-=H13/G13，Debugger TX/RX=U15/V14、UART LVCMOS33；实板修订/电压/时钟未测。本轮未生成物理CST，不碰AD/DA引脚。将来具备可用全速Host后才连接内部packet端口并建立可烧录USB顶层；当前拨SW4/插键盘不会让本模块自行枚举。

终检观察到工作区原gprj另有变化（包含新RTL，器件AC1/I0），来源尚未确认，保留现状；独立小模块综合脚本使用AC2/I1。不能将该gprj视为已验证板级工程，详见本轮结果报告。
