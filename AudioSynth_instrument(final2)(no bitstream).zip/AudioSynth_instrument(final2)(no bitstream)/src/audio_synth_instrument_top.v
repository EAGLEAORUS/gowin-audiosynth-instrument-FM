`default_nettype none
// 64 independent shared NES/SD voices + selectable PCM/ADC visualization. K1=AB13 octave up; K2=Y12 octave down.
module audio_synth_instrument_top #(parameter integer RESET_RELEASE_CYCLES=500000, FAST_PANEL=1)(
 input wire clk_50m,k1_n,k2_n,inout wire usb_dp,usb_dm,output wire uart_tx,
 output wire es0_mclk,es1_mclk,es7243_scl,inout wire es7243_sda,
 output wire es8156_scl,inout wire es8156_sda,
 input wire es0_dsclk,es0_alrck,es0_sdin,es1_dsclk,es1_dlrc,
 output wire es1_sdout,lin_led,ws2812,midi_key_trigger,
 input wire bt_uart_rx,output wire bt_uart_tx,output wire bt_bclk,bt_ws,bt_din,
 output wire hub_r1,hub_g1,hub_b1,hub_r2,hub_g2,hub_b2,hub_a,hub_b,hub_c,hub_clk,hub_lat,hub_oe,
 input wire ec11_a,ec11_b,ec11_push_n,
 output wire tft_blk,tft_cs_n,tft_dc,tft_res_n,tft_sda,tft_scl,
 input wire home_n,input wire key0_n,input wire display_button_n,ir_rx,output wire ir_tx,
 inout wire [15:0] pc_hspi_hd,
 input wire pc_hspi_rx_clk,pc_hspi_rx_req,pc_hspi_rx_vld,pc_hspi_tx_ready,
 output wire pc_hspi_rx_ready,pc_hspi_tx_clk,pc_hspi_tx_req,pc_hspi_tx_vld,
 input wire uart_rx,sd_miso,output wire sd_sck,sd_mosi,sd_cs_n
);
 wire evt_valid,online,fault,usb_core_rst_n,ref_clk,ref_locked;

 wire [39:0] evt_data;
 wire system_rst_n;
 usb3_system_reset #(.RELEASE_CYCLES(RESET_RELEASE_CYCLES)) system_reset(clk_50m,key0_n,system_rst_n);
 wire local_evt_valid,local_online,local_fault;wire [39:0] local_evt_data;
 wire pc_evt_valid,pc_evt_ready,pc_release,pc_patch_set;wire [2:0] pc_patch;
 wire [39:0] pc_evt_data;wire [95:0] pc_evt_tag,event_tag;
 wire adc_analysis_valid,adc_analysis_ready,analysis_reset_n;wire [31:0] adc_analysis_data;
 wire analysis_valid,analysis_stream_ok,display_pcm,display_selected_pcm,display_prompt,display_changed;wire [31:0] analysis_data;
 wire capture_valid,exec_valid;wire [47:0] capture_pcm;wire [31:0] capture_index;
 wire [39:0] exec_data;wire [95:0] exec_tag;wire [767:0] actual_state;wire [15:0] upper_busy,nes_status;
 wire [31:0] cycles,local_overflow,dispatched,suppressed,recoveries;
 wire backend_fault;
 wire [2:0] current_patch,ui_patch;wire [6:0] current_volume;
 wire current_mode,ui_patch_set,ui_mode_set,ui_mode;
 wire [2:0] wave_color,spectrum_color,overload_color,xy_color;
 // Legacy external NES inputs are tied off; the shared engine renders CH10.
 wire signed [15:0] nes_pcm;
 wire nes_rst_n,nes_sample_tick,nes_pcm_valid,nes_active;
 reg local_good_d;
 wire local_good_now=local_online && !local_fault;
 always @(posedge clk_50m)if(!usb_core_rst_n)local_good_d<=0;else local_good_d<=local_good_now;
 wire [3:0] nes_volume;
 wire [23:0] nes_fcw;
 wire [15:0] nes_levels;
 wire [23:0] string_bend_ratio,string_ratio;
 wire [15:0] dynamic_mask,requested_mask,release_channels;wire [3:0] release_sources;wire cpu_enabled;
 wire [3:0] voice_release_sources=release_sources | {2'b0,pc_release,(local_good_d && !local_good_now)};
 wire control_valid,control_ready;wire [3:0] control_channel;wire [34:0] control_data;
 wire cpu_event_valid,cpu_event_ready,cpu_ack_valid;wire [39:0] cpu_event_data;wire [95:0] cpu_event_tag,cpu_ack_tag;
 wire allocation_valid;wire [5:0] allocation_slot;wire [31:0] allocation_token;
 wire config_valid,config_ready,config_resp_valid,config_resp_ok;wire [2:0] config_kind,config_op;
 wire [5:0] config_slot;wire [31:0] config_token,config_resp_token,config_faults;wire [107:0] config_data;wire [7:0] config_meta;
 wire sd_valid,sd_ready;wire [39:0] sd_data;wire [95:0] sd_tag;wire [31:0] sd_status,sd_overflow;wire sd_trapped;
 wire uart_lock,service_valid,service_ready;wire [7:0] service_data;
 wire apb_sel,apb_enable,apb_write,apb_ready,sd_apb_ready;wire [31:0] apb_address,apb_wdata,apb_rdata,sd_apb_rdata,fft_rdata,tft_rdata;
 wire fft_selected=apb_address[11:4]==8'h40;
 wire tft_selected=apb_address[11:4]==8'h41;
 wire ui_apb_access=apb_sel && apb_enable && (fft_selected || tft_selected);
 assign apb_ready=(fft_selected || tft_selected)?ui_apb_access:sd_apb_ready;
 assign apb_rdata=fft_selected?fft_rdata:tft_selected?tft_rdata:sd_apb_rdata;wire [3:0] apb_strb;
 wire sd_ui_valid;wire [3:0] sd_ui_action;wire menu_begin,menu_commit,menu_home,glyph_we,cell_we,menu_ready;
 wire [10:0] glyph_address;wire [15:0] glyph_data;wire [6:0] cell_address;wire [7:0] cell_data;wire [2:0] menu_selected;
 reg mounted_previous;
 always @(posedge clk_50m)if(!usb_core_rst_n)mounted_previous<=0;else mounted_previous<=sd_status[0];
 wire [8:0] library_count;
 wire library_read,hw_write;
 wire [10:0] library_address;
 wire [127:0] library_data;
 wire [11:0] hw_address;
 wire [31:0] hw_data,hw_read;
 wire [15:0] hw_active;
 wire [255:0] string_catalog;
 wire [8:0] piano_patch;
 wire [8:0] string_patch={piano_patch[8] && string_catalog[piano_patch[7:0]],piano_patch[7:0]};
 wire string_enabled,string_prompt,string_mode,display_button_debounced,string_valid,local_ready;
 wire [39:0] string_data;
 wire [7:0] string_event_patch;
 assign dynamic_mask=hw_active;
 sd_ae350_cpu sd_cpu(clk_50m,usb_core_rst_n,apb_rdata,apb_ready,apb_sel,apb_enable,apb_write,apb_address,apb_wdata,apb_strb);
 sd_instrument_apb #(.PATCH_STORE_ENABLE(1),.HW_PATCH(1)) sd(.clk(clk_50m),.rst_n(usb_core_rst_n),.tick(nes_sample_tick),.sample_index(capture_index),.cycles(cycles),
 .event_valid(cpu_event_valid),.event_data(cpu_event_data),.event_tag(cpu_event_tag),.event_ready(cpu_event_ready),
 .pc_release(pc_release),.local_good(local_online && !local_fault),.builtin_select(pc_patch_set),.legacy_patch_request(pc_patch),
 .uart_rx(uart_rx),.uart_lock(uart_lock),.uart_valid(service_valid),.uart_data(service_data),.uart_ready(service_ready),
 .sd_miso(sd_miso),.sd_sck(sd_sck),.sd_mosi(sd_mosi),.sd_cs_n(sd_cs_n),.dynamic_mask(requested_mask),.cpu_enabled(cpu_enabled),.cpu_ack_valid(cpu_ack_valid),.cpu_ack_tag(cpu_ack_tag),
 .sd_valid(sd_valid),.sd_data(sd_data),.sd_tag(sd_tag),.sd_ready(sd_ready),.ui_valid(sd_ui_valid),.ui_action(sd_ui_action),.ui_status(sd_status),.trapped(sd_trapped),.event_overflow(sd_overflow),
 .dynamic_busy({upper_busy,actual_state[595:588],actual_state[551:544],actual_state[383:352]}),.dynamic_gate({actual_state[767:762],actual_state[631:625],actual_state[606:604],actual_state[603:596],actual_state[559:552],actual_state[415:384]}),.deadline_misses(actual_state[479:448]),
 .psel(apb_sel && !fft_selected && !tft_selected),.penable(apb_enable),.pwrite(apb_write),.mem_addr(apb_address),.mem_wdata(apb_wdata),.pstrb(apb_strb),.mem_ready(sd_apb_ready),.mem_rdata(sd_apb_rdata),
 .allocation_valid(allocation_valid),.allocation_slot(allocation_slot),.allocation_token(allocation_token),.config_faults(config_faults),
 .config_valid(config_valid),.config_ready(config_ready),.config_kind(config_kind),.config_slot(config_slot),.config_token(config_token),.config_op(config_op),.config_data(config_data),.config_meta(config_meta),
 .config_resp_valid(config_resp_valid),.config_resp_ok(config_resp_ok),.config_resp_token(config_resp_token),.release_channels(release_channels),.release_sources(release_sources),
 .menu_begin(menu_begin),.menu_commit(menu_commit),.glyph_we(glyph_we),.cell_we(cell_we),.menu_home(menu_home),.glyph_address(glyph_address),.glyph_data(glyph_data),.cell_address(cell_address),.cell_data(cell_data),.menu_selected(menu_selected),.menu_ready(menu_ready),.control_valid(control_valid),.control_ready(control_ready),.control_channel(control_channel),.control_data(control_data),
 .library_read(library_read),.library_address(library_address),.library_data(library_data),.library_count(library_count),
 .hw_write(hw_write),.hw_address(hw_address),.hw_data(hw_data),.hw_read(hw_read),.hw_active(hw_active),.string_catalog(string_catalog));
 wire [39:0] octave_evt_data;wire [1:0] keyboard_range;wire octave_visible,octave_up;
 keyboard_octave keyboard_keys(clk_50m,usb_core_rst_n,k1_n,k2_n,local_online && !local_fault,
  local_evt_valid,local_evt_data,octave_evt_data,keyboard_range,octave_visible,octave_up);
 ir_string_control single_string(.clk(clk_50m),.rst_n(usb_core_rst_n),
  .button_n(display_button_debounced),.ir_rx(ir_rx),.online(local_good_now && nes_rst_n),
  .in_valid(local_evt_valid),.in_data(octave_evt_data),.out_ready(local_ready),.patch(string_patch),
  .out_valid(string_valid),.out_data(string_data),.event_patch(string_event_patch),
  .enabled(string_enabled),.prompt(string_prompt),.ir_tx(ir_tx),.playing_mode(string_mode));
 assign fault=1'b0;
 usb3_midi_arbiter #(.SD_ENABLE(1),.HW_PATCH(1)) arbiter(clk_50m,usb_core_rst_n,nes_rst_n,local_online,local_fault,
  string_valid,string_data,pc_evt_valid,pc_evt_data,pc_evt_tag,pc_evt_ready,
  pc_release,backend_fault,cycles,evt_valid,evt_data,event_tag,online,local_overflow,dispatched,suppressed,recoveries,sd_valid,sd_data,sd_tag,sd_ready,mounted_previous && !sd_status[0],dynamic_mask,string_event_patch,local_ready);
 // ESP32 link: merges its parsed MIDI into the committed event stream without
 // adding a pipeline stage for the existing sources (combinational 2:1 select).

 wire bt_evt_valid;wire [39:0] bt_evt_data;wire [95:0] bt_event_tag;
 // Audio liveness for the ESP32 telemetry: does the effects output actually
 // carry a non-trivial sample? capture_pcm is the exact DAC/serial frame.
 reg aud_hot,aud_loud;
 always @(posedge clk_50m)begin
  if(!usb_core_rst_n)begin aud_hot<=0;aud_loud<=0;end
  else if(capture_valid)begin
   if(|capture_pcm[22:8])aud_hot<=1;
   if(|capture_pcm[22:12])aud_loud<=1;
  end
 end
 bt_midi_bridge bt_link(.clk(clk_50m),.rst_n(usb_core_rst_n),
  .uart_rx(bt_uart_rx),.uart_tx(bt_uart_tx),.cycles(cycles),
  .dbg_in({aud_loud,aud_hot,capture_valid,nes_rst_n,analysis_stream_ok,1'b0}),
  .arb_valid(evt_valid),.arb_data(evt_data),.arb_tag(event_tag),
  .evt_valid(bt_evt_valid),.evt_data(bt_evt_data),.evt_tag(bt_event_tag));
 // I2S tap for the ESP32 encoder: same clocks and the same serial data as the
 // ES8156 DAC. No register is inserted in the local DAC path.
 assign bt_bclk=es1_dsclk;
 assign bt_ws=es1_dlrc;
 assign bt_din=es1_sdout;
 usb3_instrument_bridge #(.SD_ENABLE(1),.HW_PATCH(1)) pc(.clk(clk_50m),.rst_n(usb_core_rst_n),.audio_ok(nes_rst_n),
  .rx_clk(pc_hspi_rx_clk),.rx_req(pc_hspi_rx_req),.rx_vld(pc_hspi_rx_vld),.rx_ready(pc_hspi_rx_ready),.hd(pc_hspi_hd),
  .tx_clk(pc_hspi_tx_clk),.tx_req(pc_hspi_tx_req),.tx_vld(pc_hspi_tx_vld),.tx_ready(pc_hspi_tx_ready),
  .capture_valid(capture_valid),.capture_pcm(capture_pcm),.capture_index(capture_index),
  .exec_valid(exec_valid),.exec_data(exec_data),.exec_tag(exec_tag),.actual_state(actual_state),.local_online(local_online),.local_fault(local_fault),
  .display_mode(current_mode),.colors({xy_color,overload_color,spectrum_color,wave_color}),
  .local_overflow(local_overflow),.dispatched(dispatched),.suppressed(suppressed),.recoveries(recoveries),
  .pc_valid(pc_evt_valid),.pc_data(pc_evt_data),.pc_tag(pc_evt_tag),.pc_ready(pc_evt_ready),.pc_release(pc_release),
  .patch_set(pc_patch_set),.patch_value(pc_patch),.patch_ready(!ui_patch_set),.cycles(cycles),.backend_fault(backend_fault),.dynamic_channels(dynamic_mask),.upper_busy(upper_busy),.nes_status(nes_status));

 assign string_ratio=24'd4194304; // SD channels carry their own bend; no fixed Strings engine.
 assign nes_pcm=16'sd0;assign nes_pcm_valid=1'b0;assign nes_active=1'b0;
 assign nes_volume=4'd0;assign nes_fcw=24'd0;assign nes_levels=16'd0;

 tft_ui #(.SD_ONLY(1)) ui(.clk(clk_50m),.rst_n(analysis_reset_n),.effects_rst_n(nes_rst_n),
  .a(ec11_a),.b(ec11_b),.push_n(ec11_push_n),.patch(current_patch),.mode(current_mode),.volume(current_volume),
  .event_valid(bt_evt_valid),.event_data(bt_evt_data),.online(online && !fault),
  .patch_set(ui_patch_set),.patch_value(ui_patch),.mode_set(ui_mode_set),.mode_value(ui_mode),
  .wave_color(wave_color),.spectrum_color(spectrum_color),.overload_color(overload_color),.xy_color(xy_color),
  .cs_n(tft_cs_n),.sclk(tft_scl),.mosi(tft_sda),.dc(tft_dc),.res_n(tft_res_n),.blk(tft_blk),.home_n(home_n),.sd_action_valid(sd_ui_valid),.sd_action(sd_ui_action),
 .menu_begin(menu_begin),.menu_commit(menu_commit),.glyph_we(glyph_we),.cell_we(cell_we),.menu_home(menu_home),.glyph_address(glyph_address),.glyph_data(glyph_data),.cell_address(cell_address),.cell_data(cell_data), .menu_selected(menu_selected),.menu_ready(menu_ready),.source_status(sd_status),
 .ui_read(ui_apb_access && tft_selected && !apb_write),
 .ui_write(ui_apb_access && tft_selected && apb_write && (&apb_strb)),
 .ui_address(apb_address[3:0]),.ui_wdata(apb_wdata),.ui_rdata(tft_rdata));
 usb_midi_fs_top #(.EXTERNAL_RESET(1),.SERVICE_ENABLE(1)) usb(.clk_50m(clk_50m),.usb_dp(usb_dp),.usb_dm(usb_dm),.uart_tx(uart_tx),
 .audio_evt_valid(local_evt_valid),.audio_evt_data(local_evt_data),.audio_online(local_online),
 .audio_fault(local_fault),.system_rst_n(system_rst_n),.audio_core_rst_n(usb_core_rst_n),.audio_ref_clk(ref_clk),.audio_ref_locked(ref_locked),.service_lock(uart_lock),.service_valid(service_valid),.service_data(service_data),.service_ready(service_ready),.midi_trigger(midi_key_trigger));
 audio_synth_instrument_loop #(.UI_ENABLE(1),.PC_ENABLE(1),.SD_ONLY(1),.HW_PATCH(1),.VOICES_PER_CORE(16),.EXTERNAL_DISPLAY_SELECT(1)) audio(clk_50m,es0_mclk,es1_mclk,es7243_scl,es7243_sda,
 es8156_scl,es8156_sda,es0_dsclk,es0_alrck,es0_sdin,es1_dsclk,es1_dlrc,es1_sdout,lin_led,bt_evt_valid,bt_evt_data,online,fault,usb_core_rst_n,ws2812,ref_clk,ref_locked,1'b1,adc_analysis_valid,adc_analysis_data,adc_analysis_ready,analysis_reset_n,nes_pcm,nes_rst_n,nes_sample_tick,1'b0,3'd0,current_patch,current_volume,string_ratio,string_bend_ratio,
 system_rst_n,bt_event_tag,capture_valid,capture_pcm,capture_index,exec_valid,exec_data,exec_tag,actual_state,dynamic_mask,cpu_enabled,cpu_event_valid,cpu_event_data,cpu_event_tag,cpu_event_ready,cpu_ack_valid,cpu_ack_tag,
 allocation_valid,allocation_slot,allocation_token,config_valid,config_ready,config_kind,config_slot,config_token,config_op,config_data,config_meta,
 config_resp_valid,config_resp_ok,config_resp_token,config_faults,release_channels,voice_release_sources,control_valid,control_ready,control_channel,control_data,
  library_count,library_read,library_address,library_data,
  hw_write,hw_address,hw_data,hw_read,hw_active,upper_busy,string_mode,piano_patch,nes_status);
 display_audio_select #(.PCM_GAIN(32)) display_source(
  .clk(clk_50m),.rst_n(analysis_reset_n),.button_n(display_button_n),
  .adc_valid(adc_analysis_valid),.adc_ready(adc_analysis_ready),
  .pcm_valid(capture_valid),.pcm_ready(nes_rst_n),.adc_data(adc_analysis_data),.pcm_data(capture_pcm),
  .pcm_selected(display_selected_pcm),.pcm_active(display_pcm),.prompt(display_prompt),.changed(display_changed),
  .sample_valid(analysis_valid),.sample_data(analysis_data),.stream_ok(analysis_stream_ok),.button_debounced_n(display_button_debounced));
 audio_live_display #(.UI_ENABLE(1),.BOOT_FRAME(1),.DCLK_DIV(FAST_PANEL?4:8),
  .WRITE_ROWS_PER_PACKET(FAST_PANEL?8:2)) visual(.clk(clk_50m),.rst_n(analysis_reset_n),.stream_ok(analysis_stream_ok),
 .sample_valid(analysis_valid),.sample_data(analysis_data),.mode_button_n(1'b1),
 .hub_r1(hub_r1),.hub_g1(hub_g1),.hub_b1(hub_b1),.hub_r2(hub_r2),.hub_g2(hub_g2),.hub_b2(hub_b2),
 .hub_a(hub_a),.hub_b(hub_b),.hub_c(hub_c),.hub_clk(hub_clk),.hub_lat(hub_lat),.hub_oe(hub_oe),
 .ui_mode_set(ui_mode_set),.ui_mode(ui_mode),.current_mode(current_mode),
 .wave_color(wave_color),.spectrum_color(spectrum_color),.overload_color(overload_color),.xy_color(xy_color),.octave_prompt_enable(octave_visible),.octave_range(keyboard_range),.octave_direction_up(octave_up),
 .source_prompt_enable(display_prompt),.source_selected_pcm(display_selected_pcm),.source_pcm(display_pcm),.source_changed(display_changed),
  .string_prompt_enable(string_prompt),.string_enabled(string_enabled),
 .fft_read(ui_apb_access && fft_selected && !apb_write),
 .fft_write(ui_apb_access && fft_selected && apb_write && (&apb_strb)),
 .fft_address(apb_address[3:0]),.fft_wdata(apb_wdata),.fft_rdata(fft_rdata));
endmodule
`default_nettype wire
