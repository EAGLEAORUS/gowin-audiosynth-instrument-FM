`default_nettype none
module tft_spi_byte #(parameter integer HALF_PERIOD=4)(
 input wire clk,rst_n,start,dc_in,input wire [7:0] data,
 output reg busy,done,cs_n,sclk,mosi,dc);
 localparam integer CB=HALF_PERIOD>1?$clog2(HALF_PERIOD):1;
 reg [CB-1:0] div;reg [2:0] bit_index;reg [7:0] shift;
 always @(posedge clk)begin
  if(!rst_n)begin busy<=0;done<=0;cs_n<=1;sclk<=0;mosi<=0;dc<=0;div<=0;bit_index<=0;shift<=0;end
  else begin
   done<=0;
   if(!busy)begin
    if(start)begin busy<=1;cs_n<=0;sclk<=0;dc<=dc_in;shift<=data;mosi<=data[7];div<=0;bit_index<=0;end
   end else if(div==HALF_PERIOD-1)begin
    div<=0;sclk<=~sclk;
    if(sclk)begin
     if(bit_index==7)begin busy<=0;done<=1;cs_n<=1;sclk<=0;end
     else begin bit_index<=bit_index+1'b1;shift<={shift[6:0],1'b0};mosi<=shift[6];end
    end
   end else div<=div+1'b1;
  end
 end
endmodule
`default_nettype wire
