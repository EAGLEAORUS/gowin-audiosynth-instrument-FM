`default_nettype none
// 50MHz control plane. CPU is optional to the legacy instrument: traps, card
// faults or FIFO overflow cannot stop the codec, old synth, USB or PCM capture.
module sd_instrument_apb #(parameter PATCH_STORE_ENABLE=0,parameter HW_PATCH=0)(
 input wire clk,rst_n,tick,input wire [31:0] sample_index,cycles,
 input wire event_valid,input wire [39:0] event_data,input wire [95:0] event_tag,output wire event_ready,
 input wire pc_release,local_good,builtin_select,
 input wire uart_rx,output reg uart_lock,output reg uart_valid,output reg [7:0] uart_data,input wire uart_ready,
 input wire sd_miso,output wire sd_sck,sd_mosi,output reg sd_cs_n,
 output reg [15:0] dynamic_mask,output wire cpu_enabled,
 output wire cpu_ack_valid,output wire [95:0] cpu_ack_tag,
 output reg sd_valid,output reg [39:0] sd_data,output reg [95:0] sd_tag,input wire sd_ready,
 input wire ui_valid,input wire [3:0] ui_action,output reg [31:0] ui_status,output wire trapped,
 output wire [31:0] event_overflow,input wire [63:0] dynamic_busy,dynamic_gate,input wire [31:0] deadline_misses,
 input wire psel,penable,pwrite,input wire [31:0] mem_addr,mem_wdata,input wire [3:0] pstrb,
 output reg mem_ready,output reg [31:0] mem_rdata,
 input wire allocation_valid,input wire [5:0] allocation_slot,input wire [31:0] allocation_token,config_faults,
 output wire config_valid,input wire config_ready,output wire [2:0] config_kind,
 output wire [5:0] config_slot,output wire [31:0] config_token,output wire [2:0] config_op,
 output wire [107:0] config_data,output wire [7:0] config_meta,
 input wire config_resp_valid,config_resp_ok,input wire [31:0] config_resp_token,
 output reg [15:0] release_channels,output reg [3:0] release_sources,
 output reg menu_begin,menu_commit,glyph_we,cell_we,menu_home,
 output reg [10:0] glyph_address,output reg [15:0] glyph_data,
 output reg [6:0] cell_address,output reg [7:0] cell_data,output reg [2:0] menu_selected,input wire menu_ready,
 output wire control_valid,input wire control_ready,output reg [3:0] control_channel,output reg [34:0] control_data,input wire [2:0] legacy_patch_request,
 input wire library_read,input wire [10:0] library_address,
 output wire [127:0] library_data,output wire [8:0] library_count,
 output wire hw_write,output wire [11:0] hw_address,output wire [31:0] hw_data,
 input wire [31:0] hw_read,input wire [15:0] hw_active,output wire [255:0] string_catalog);
 wire [3:0] mem_wstrb=pwrite?pstrb:4'd0;
 reg library_read_delayed;
 always @(posedge clk)if(!rst_n)library_read_delayed<=0;else library_read_delayed<=library_read;
 wire library_wait=HW_PATCH && !pwrite && mem_addr[11:0]==12'h324 &&
  (library_read || library_read_delayed);
 wire request=psel && penable && !mem_ready && !library_wait;
 wire write=request && (|mem_wstrb);
 wire [31:0] patch_word,patch_status;
 generate if(PATCH_STORE_ENABLE)begin:patch_library
  sd_patch_store #(.HW_PATCH(HW_PATCH)) presets(clk,rst_n,
   write && mem_addr[11:0]==12'h320,write && mem_addr[11:0]==12'h324,
   request && !pwrite && mem_addr[11:0]==12'h324,write && mem_addr[11:0]==12'h328,
   mem_wdata,patch_word,patch_status,library_read,library_address,library_data,string_catalog);
 end else begin:no_patch_library
  assign patch_word=0;assign patch_status=0;assign library_data=0;assign string_catalog=0;
 end endgenerate
 assign library_count=patch_status[8:0];
 assign hw_write=HW_PATCH && write;
 assign hw_address=mem_addr[11:0];
 assign hw_data=mem_wdata;
 reg [31:0] trap_status;reg trap_present;assign trapped=trap_present;
 always @(posedge clk)begin
  if(!rst_n)trap_present<=0;
  else if(write && mem_addr[11:0]==12'h098)trap_present<=|mem_wdata;
 end
 reg [31:0] fw_status;
 reg firmware_ready;
 always @(posedge clk)begin
  if(!rst_n)firmware_ready<=0;
  else if(write && mem_addr[11:0]==12'h090)firmware_ready<=mem_wdata==32'h00010001;
 end
 reg [25:0] heartbeat_age;
 reg heartbeat_alive;
 reg control_pending,control_error;
 assign control_valid=control_pending && cpu_enabled;
 always @(posedge clk)begin
  if(!rst_n)begin heartbeat_age<=26'd50000000;heartbeat_alive<=1'b0;end
  else if(write && mem_addr[11:0]==12'h090)begin heartbeat_age<=0;heartbeat_alive<=1'b1;end
  else begin
   if(heartbeat_age<26'd50000000)heartbeat_age<=heartbeat_age+1'b1;
   // Look ahead to the incremented/saturated value: exactly equivalent to
   // heartbeat_age<50000000 after this edge, with no extra watchdog cycle.
   heartbeat_alive<=heartbeat_age<26'd49999999;
  end
 end
 wire [31:0] config_read;
 sd_tdm_registers params(clk,rst_n,cpu_enabled,write,mem_addr[11:0],mem_wdata,config_read,
  allocation_valid,allocation_slot,allocation_token,config_faults,
  config_valid,config_ready,config_kind,config_slot,config_token,config_op,config_data,config_meta,
  config_resp_valid,config_resp_ok,config_resp_token);
 wire rx_valid,rx_ready;wire [7:0] rx_data;wire [31:0] rx_overflow;
 wire serial_valid;wire [7:0] serial_data;
 sd_sipeed_uart_rx #(.CLK_FRE(50),.BAUD_RATE(115200)) rx(clk,rst_n,serial_data,serial_valid,1'b1,uart_rx);
 reg rx_pop;
 midi_sync_fifo_fwft_ram #(8,10) rx_fifo(clk,rst_n,serial_valid,serial_data,rx_ready,rx_valid,rx_data,rx_pop,rx_overflow);
 reg spi_start,spi_fast;reg [7:0] spi_tx;wire spi_busy;wire [7:0] spi_rx;
 sd_spi_byte spi(clk,rst_n,spi_start,spi_fast,spi_tx,sd_miso,sd_sck,sd_mosi,spi_busy,spi_rx);
 reg clear_events,builtin_pending;reg [2:0] legacy_patch;
 wire ev_valid,ev_ready;wire [135:0] ev_data;reg ev_pop;
 midi_sync_fifo_fwft_ram #(136,7) ev_fifo(clk,rst_n && !clear_events,(HW_PATCH?(event_valid && ui_status[3] && event_tag[95:88]!=3):(event_valid && event_ready)),{event_tag,event_data},ev_ready,ev_valid,ev_data,ev_pop,event_overflow);
 assign event_ready=ev_ready && !clear_events;
 wire safe=(event_overflow==0) && !trapped;
 assign cpu_enabled=safe && firmware_ready && ui_status[31] && heartbeat_alive;
 assign cpu_ack_valid=ev_pop && ev_valid;
 assign cpu_ack_tag=ev_data[135:40];
 reg [3:0] ui_pending;reg ui_has;reg [1:0] release_pending;reg old_local;
 always @(posedge clk)begin
  if(!rst_n)begin
   mem_ready<=0;mem_rdata<=0;trap_status<=0;rx_pop<=0;spi_start<=0;spi_fast<=0;spi_tx<=255;sd_cs_n<=1;
   uart_lock<=0;uart_valid<=0;uart_data<=0;dynamic_mask<=0;release_channels<=0;release_sources<=0;menu_begin<=0;menu_commit<=0;glyph_we<=0;cell_we<=0;menu_home<=0;glyph_address<=0;glyph_data<=0;cell_address<=0;cell_data<=0;menu_selected<=0;
   ev_pop<=0;sd_valid<=0;sd_data<=0;sd_tag<=0;ui_pending<=0;ui_has<=0;release_pending<=0;old_local<=0;
   clear_events<=0;builtin_pending<=0;legacy_patch<=0;ui_status<=0;fw_status<=0;
   control_pending<=0;control_error<=0;control_channel<=0;control_data<={11'd1024,24'd4194304};
  end else begin
   clear_events<=0;if(builtin_select)begin builtin_pending<=1;legacy_patch<=legacy_patch_request;end
   mem_ready<=0;rx_pop<=0;spi_start<=0;uart_valid<=0;ev_pop<=0;release_channels<=0;release_sources<=0;menu_begin<=0;menu_commit<=0;glyph_we<=0;cell_we<=0;menu_home<=0;old_local<=local_good;
   if(sd_valid && sd_ready)sd_valid<=0;
   if(!cpu_enabled)begin control_pending<=0;control_error<=0;end
   else if(control_valid && control_ready)control_pending<=0;
   if(ui_valid)begin ui_has<=1;ui_pending<=ui_action;end
   if(pc_release)release_pending[1]<=1;
   if(old_local && !local_good)release_pending[0]<=1;
   if(!safe)begin dynamic_mask<=0;uart_lock<=0;sd_cs_n<=1;end
   if(request)begin
     mem_ready<=1;mem_rdata<=0;
     if(mem_wstrb!=0)case(mem_addr[11:0])
      12'h014:begin uart_data<=mem_wdata[7:0];uart_valid<=1;end
      12'h018:uart_lock<=mem_wdata[0];
      12'h020:begin spi_tx<=mem_wdata[7:0];spi_fast<=mem_wdata[8];spi_start<=1;end
      12'h024:sd_cs_n<=mem_wdata[0];
      12'h044:ev_pop<=ev_valid;
      12'h048:dynamic_mask<=safe?mem_wdata[15:0]:16'd0;
      12'h074:ui_status<=mem_wdata;
      12'h080:begin sd_valid<=1;sd_data<={4'd0,mem_wdata[7:4],mem_wdata[31:0]};sd_tag<={8'd3,56'd0,cycles};end
      12'h090:fw_status<=mem_wdata;
      12'h098:trap_status<=mem_wdata;
      12'h094:clear_events<=1;
      12'h230:release_channels<=mem_wdata[15:0];
      12'h238:release_sources<=mem_wdata[3:0];
      12'h240:if(!control_pending)control_channel<=mem_wdata[3:0];else control_error<=1;
      12'h244:if(!control_pending)control_data[23:0]<=mem_wdata[23:0];else control_error<=1;
      12'h248:if(!control_pending)control_data[34:24]<=mem_wdata[10:0];else control_error<=1;
      12'h24c:begin
       if(mem_wdata[1])control_error<=0;
       if(mem_wdata[0])begin if(!control_pending)control_pending<=1;else control_error<=1;end
      end
      12'h300:begin menu_begin<=mem_wdata[0];menu_commit<=mem_wdata[1];menu_selected<=mem_wdata[6:4];end
      12'h304:glyph_address<=mem_wdata[10:0];
      12'h308:begin glyph_data<=mem_wdata[15:0];glyph_we<=1;end
      12'h30c:cell_address<=mem_wdata[6:0];
      12'h310:begin cell_data<=mem_wdata[7:0];cell_we<=1;end
      12'h318:menu_home<=mem_wdata[0];
      default:begin end
     endcase
     else case(mem_addr[11:0])
      12'h000:mem_rdata<=32'h53444932;
      12'h004:mem_rdata<=cycles;
      12'h008:mem_rdata<=sample_index;
      12'h00c:mem_rdata<={29'd0,rx_overflow!=0,uart_ready,rx_valid};
      12'h010:begin mem_rdata<={24'd0,rx_data};rx_pop<=rx_valid;end
      12'h01c:mem_rdata<={16'd0,spi_rx,7'd0,spi_busy};
      12'h028:mem_rdata<={28'd0,1'b1,event_overflow!=0,config_ready,ev_valid};
      12'h02c:mem_rdata<=ev_data[31:0];
      12'h030:mem_rdata<=ev_data[63:32];
      12'h034:mem_rdata<=ev_data[95:64];
      12'h038:mem_rdata<=ev_data[127:96];
      12'h03c:mem_rdata<={ev_data[63:40],ev_data[135:128]};
      12'h040:mem_rdata<={24'd0,ev_data[71:64]};
      12'h048:mem_rdata<={16'd0,(HW_PATCH?hw_active:dynamic_mask)};
      12'h064:mem_rdata<=dynamic_gate[31:0];
      12'h068:mem_rdata<=dynamic_busy[31:0];
      12'h06c:mem_rdata<=deadline_misses;
      12'h070:begin mem_rdata<={27'd0,ui_has,ui_pending};ui_has<=0;end
      12'h084:mem_rdata<={31'd0,!sd_valid};
      12'h088:begin mem_rdata<={30'd0,release_pending};release_pending<=0;end
      12'h08c:begin mem_rdata<={28'd0,(PATCH_STORE_ENABLE?legacy_patch:3'd0),builtin_pending};builtin_pending<=0;end
      12'h324:mem_rdata<=patch_word;
      12'h328:mem_rdata<=patch_status;
      12'h428:mem_rdata<=hw_read;
      12'h090:mem_rdata<=fw_status;
      12'h234:mem_rdata<={dynamic_gate[47:40],dynamic_busy[47:40],dynamic_gate[39:32],dynamic_busy[39:32]};
      12'h23c:mem_rdata<={dynamic_gate[63:48],dynamic_busy[63:48]};
      12'h24c:mem_rdata<={26'd0,cpu_enabled,2'd0,control_error,control_pending,(!control_pending && cpu_enabled)};
      12'h300:mem_rdata<={24'd0,1'b0,menu_selected,3'd0,menu_ready};
      default:mem_rdata<=(HW_PATCH && mem_addr[11:7]==5'h07)?hw_read:config_read;
     endcase
    end
   end
 end
endmodule
`default_nettype wire
