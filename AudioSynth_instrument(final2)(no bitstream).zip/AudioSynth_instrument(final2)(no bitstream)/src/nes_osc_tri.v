`default_nettype none
module nes_osc_tri(
 input wire clk,rst_n,sample_tick,restart,enable,input wire [23:0] fcw,
 output wire [3:0] level,output reg [23:0] phase
);
 (* syn_ramstyle = "registers", ram_style = "distributed" *) reg [3:0] triangle[0:31];
 integer k;
 initial begin
  for(k=0;k<16;k=k+1)begin triangle[k]=15-k;triangle[k+16]=k;end
 end
 assign level=enable?triangle[phase[23:19]]:4'd0;
 always @(posedge clk)begin
  if(!rst_n || restart)phase<=24'd0;
  else if(sample_tick && enable)phase<=phase+fcw;
 end
endmodule
`default_nettype wire
