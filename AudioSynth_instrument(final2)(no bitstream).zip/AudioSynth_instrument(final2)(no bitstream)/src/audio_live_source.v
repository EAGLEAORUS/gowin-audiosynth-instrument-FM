`default_nettype none
// ADC PCM16 snapshots, normalized Hann FFT and a frozen panel feature frame.
// All arithmetic/display logic is in clk_50m. Samples arrive through a whole-frame CDC FIFO.
// Analysis deliberately skips samples during processing/upload; every acquired window is 1024 contiguous frames.
module audio_live_source(
 input wire clk,rst_n,stream_ok,sample_valid,input wire [31:0] sample_data,
 input wire [6:0] x1,x2,input wire [5:0] y,input wire accept_frame,commit_frame,
 output wire frame_ready,output wire [47:0] spectrum1,spectrum2,liss1,liss2,
 output reg [31:0] completed_frames,skipped_samples,fft_timeouts,
 input wire unity_gain,input wire [1:0] octave,
 input wire features_ready,input wire [23:0] features,
 output wire [4:0] feature_address,output wire feature_taken,feature_busy
);
 localparam [4:0] CAPTURE=0,PRE_ISSUE=1,PRE_WAIT=2,PRE_MUL=3,PRE_STORE=4,
  FFT_START=5,FFT_RUN=6,BAND_INIT=7,BAND_WAIT=8,BAND_EVAL=9,LEVEL=10,
  CLEAR=11,LINE_FIRST=12,LINE_FIRST_WAIT=13,LINE_NEXT=14,LINE_WAIT=15,
  LINE_SETUP=16,DRAW=17,READY=18,IN_FLIGHT=19,RECOVER=20,LIMIT_START=21,LIMIT_WAIT=22,PRE_SCALE=23,FIRST_COORD=24,WAVE_ISSUE=25,WAVE_WAIT=26,WAVE_SCALE=27,WAVE_POINT=28;
 reg [4:0] state;
 reg [10:0] capture_count,address;
 reg [1:0] scope_range;
 wire [10:0] capture_last=scope_range==0?11'd2047:11'd1023;
 (* syn_ramstyle="block_ram" *) reg [31:0] samples[0:2047];
 reg [31:0] sample_q;
 always @(posedge clk)begin
  if(state==CAPTURE && stream_ok && sample_valid)samples[capture_count]<=sample_data;
  sample_q<=samples[address];
 end
 // Fixed display sensitivity and a linked look-ahead peak limiter.
 // Quiet windows are never muted; no gain-recovery delay is imposed.
 function [15:0] magnitude16;
  input [15:0] v;
  begin magnitude16=v[15]?(~v+16'd1):v;end
 endfunction
 wire [15:0] capture_left_peak=magnitude16(sample_data[31:16]);
 wire [15:0] capture_right_peak=magnitude16(sample_data[15:0]);
 wire [15:0] capture_peak=(capture_left_peak>capture_right_peak)?capture_left_peak:capture_right_peak;
 reg [15:0] raw_peak;
 wire [15:0] next_raw_peak=(capture_peak>raw_peak)?capture_peak:raw_peak;
 wire [16:0] display_gain_q8;wire limit_done;
 display_level_limiter #(.BASE_GAIN(128),.LIMIT_LEVEL(30000)) limiter(
  clk,rst_n,state==LIMIT_START,raw_peak,limit_done,display_gain_q8,unity_gain);
 function signed [15:0] display_scale;
  input signed [15:0] value;input [16:0] gain_q8;
  reg signed [33:0] product;reg signed [34:0] extended,rounded;
  begin
   product=$signed(value)*$signed({1'b0,gain_q8});extended={product[33],product};
   if(product<0)rounded=-(((-extended)+35'sd128)>>>8);
   else rounded=(extended+35'sd128)>>>8;
   if(rounded>35'sd32767)display_scale=16'sh7fff;
   else if(rounded< -35'sd32768)display_scale=16'sh8000;
   else display_scale=rounded[15:0];
  end
 endfunction
 wire signed [15:0] display_left=display_scale($signed(sample_q[31:16]),display_gain_q8);
 wire signed [15:0] display_right=display_scale($signed(sample_q[15:0]),display_gain_q8);
 (* syn_preserve=1 *) reg signed [15:0] scaled_left,scaled_right;
 always @(posedge clk)begin scaled_left<=display_left;scaled_right<=display_right;end
 wire signed [16:0] stereo_sum=$signed({scaled_left[15],scaled_left})+$signed({scaled_right[15],scaled_right});
 wire signed [15:0] mono=stereo_sum[16:1]; // signed average, floor toward -infinity
 reg [4:0] wave_y[0:127];reg [5:0] height[0:127];
 // Display-only scope: first armed rising zero crossing,32 pretrigger samples.
 // 256 samples /128 columns (old1024), nominal5.33333ms at48kHz (actual rate requires board measurement).
 reg [10:0] wave_start;
 reg [6:0] wave_column,feature_column;
 reg [3:0] scope_group;
 reg signed [15:0] window_sample;
 wire [3:0] group_last=scope_range==0?4'd15:scope_range==1?4'd3:4'd1;
 wire [10:0] trigger_last=scope_range==1?11'd544:11'd800;
 wire [4:0] feature_bit={3'd0,feature_column[1:0]}*5'd6;
 wire [5:0] feature_height=features[feature_bit+:6];
 assign feature_address=state!=FFT_RUN?5'd0:
  feature_column[6:2]+{4'd0,(&feature_column[1:0])};
 assign feature_busy=state==FFT_RUN || (state==FFT_START && features_ready);
 assign feature_taken=state==FFT_RUN && feature_column==127;
 reg trigger_armed,trigger_found;reg signed [15:0] previous_wave;
 reg signed [15:0] wave_peak;
 wire [15:0] mono_abs=window_sample[15]?(~window_sample+16'd1):window_sample;
 wire [15:0] peak_abs=wave_peak[15]?(~wave_peak+16'd1):wave_peak;
 wire signed [15:0] chosen_peak=(scope_group==0 || mono_abs>peak_abs)?window_sample:wave_peak;
 function [4:0] wave_coordinate;
  input signed [15:0] v;reg signed [22:0] e,t;
  begin e={{7{v[15]}},v};t=(e<<<5)-e+23'sd1048576;wave_coordinate=t[20:16];end
 endfunction
 function [5:0] xy_coordinate;
  input signed [15:0] v;reg signed [22:0] e,t;
  begin e={{7{v[15]}},v};t=(e<<<6)-e+23'sd2097152;xy_coordinate=t[21:16];end
 endfunction
 // Two identical simple-dual-port bitmaps: one registered pixel read per lane,
 // one write per clock. No whole-track ROM and no 4096-bit variable FF write mux.
 (* syn_ramstyle="block_ram" *) reg raster1[0:4095];
 (* syn_ramstyle="block_ram" *) reg raster2[0:4095];
 reg [11:0] clear_address;
 reg [5:0] cx,cy,tx,ty,px,py;
 reg x_positive,y_positive;
 reg signed [8:0] dx,negative_dy;
 reg signed [9:0] error;
 wire [5:0] next_x=xy_coordinate(scaled_left);
 wire [5:0] next_y=xy_coordinate(scaled_right);
 wire [6:0] delta_x=(next_x>=px)?{1'b0,next_x}-{1'b0,px}:{1'b0,px}-{1'b0,next_x};
 wire [6:0] delta_y=(next_y>=py)?{1'b0,next_y}-{1'b0,py}:{1'b0,py}-{1'b0,next_y};
 wire signed [10:0] twice_error=$signed({error[9],error})<<<1;
 wire step_x=twice_error>=negative_dy,step_y=twice_error<=dx;
 wire signed [9:0] next_error=error+(step_x?negative_dy:9'sd0)+(step_y?dx:9'sd0);
 wire raster_write=state==CLEAR || state==DRAW;
 wire [11:0] raster_address=(state==CLEAR)?clear_address:{cy,cx};
 reg raster_q1,raster_q2,inside1,inside2;
 wire [5:0] local_x1=x1[5:0]-6'd32,local_x2=x2[5:0]-6'd32;
 always @(posedge clk)begin
  if(raster_write)begin raster1[raster_address]<=state==DRAW;raster2[raster_address]<=state==DRAW;end
  raster_q1<=raster1[{y,local_x1}];raster_q2<=raster2[{y,local_x2}];
  inside1<=x1>=32 && x1<96;inside2<=x2>=32 && x2<96;
 end
 assign liss1=(inside1 && raster_q1)?48'h0000ffff0000:48'd0;
 assign liss2=(inside2 && raster_q2)?48'h0000ffff0000:48'd0;
 function [47:0] render;
  input [5:0] h;input [4:0] w,p;input [5:0] yy;
  reg [4:0] lo,hi;
  begin
   lo=(w<p)?w:p;hi=(w>p)?w:p;render=0;
   if(yy<32)begin if(yy<h)render=(yy<24)?48'h0000ffffffff:48'hffffffffffff;end
   else if((yy-32)>=lo && (yy-32)<=hi)render=48'haaaa0000ffff;
  end
 endfunction
 reg [47:0] spectrum_q1,spectrum_q2;
 always @(posedge clk)begin
  spectrum_q1<=render(height[x1],wave_y[x1],wave_y[x1==0?7'd0:x1-7'd1],y);
  spectrum_q2<=render(height[x2],wave_y[x2],wave_y[x2==0?7'd0:x2-7'd1],y);
 end
 assign spectrum1=spectrum_q1;assign spectrum2=spectrum_q2;
 assign frame_ready=state==READY;
 integer i;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   wave_start<=0;wave_column<=0;scope_group<=0;trigger_armed<=0;trigger_found<=0;previous_wave<=0;raw_peak<=0;
   state<=CAPTURE;capture_count<=0;address<=0;window_sample<=0;wave_peak<=0;feature_column<=0;scope_range<=1;
   completed_frames<=0;skipped_samples<=0;fft_timeouts<=0;clear_address<=0;
   cx<=0;cy<=0;tx<=0;ty<=0;px<=0;py<=0;x_positive<=0;y_positive<=0;dx<=0;negative_dy<=0;error<=0;
   for(i=0;i<128;i=i+1)begin height[i]<=0;wave_y[i]<=16;end
  end else begin
   if(sample_valid && stream_ok && state!=CAPTURE)skipped_samples<=skipped_samples+1'b1;
   case(state)
    CAPTURE:if(!stream_ok)begin capture_count<=0;raw_peak<=0;end
     else if(sample_valid)begin
      raw_peak<=next_raw_peak;
      if(capture_count==0)scope_range<=octave;
      if(capture_count==capture_last)begin
       wave_start<=0;wave_column<=0;scope_group<=0;trigger_armed<=0;trigger_found<=0;previous_wave<=0;address<=0;state<=LIMIT_START;
      end
      else capture_count<=capture_count+1'b1;
     end
    LIMIT_START:state<=LIMIT_WAIT;
    LIMIT_WAIT:if(limit_done)state<=scope_range==0?WAVE_ISSUE:PRE_ISSUE;
    PRE_ISSUE:state<=PRE_WAIT;
    PRE_WAIT:state<=PRE_SCALE;
    PRE_SCALE:begin window_sample<=mono;state<=PRE_MUL;end
    PRE_MUL:begin
     previous_wave<=window_sample;
     if(!trigger_found && address<=trigger_last)begin
      if(window_sample<=-16'sd64)trigger_armed<=1;
      if(trigger_armed && previous_wave<0 && window_sample>=0 && address>=32)begin
       trigger_found<=1;wave_start<=address-11'd32;
      end
     end
     if(address==capture_last)state<=PRE_STORE;
     else begin address<=address+1'b1;state<=PRE_ISSUE;end
    end
    PRE_STORE:begin address<=wave_start;state<=WAVE_ISSUE;end
    WAVE_ISSUE:state<=WAVE_WAIT;
    WAVE_WAIT:state<=WAVE_SCALE;
    WAVE_SCALE:begin window_sample<=mono;state<=WAVE_POINT;end
    WAVE_POINT:begin
     wave_peak<=chosen_peak;
     if(scope_group==group_last)begin
      wave_y[wave_column]<=wave_coordinate(chosen_peak);
      scope_group<=0;
      if(wave_column==127)state<=FFT_START;
      else begin wave_column<=wave_column+1'b1;address<=address+1'b1;state<=WAVE_ISSUE;end
     end else begin scope_group<=scope_group+1'b1;address<=address+1'b1;state<=WAVE_ISSUE;end
    end
    FFT_START:begin
     feature_column<=0;
     if(features_ready)state<=FFT_RUN;
     else begin clear_address<=0;state<=CLEAR;end
    end
    FFT_RUN:begin
     if(height[feature_column]>feature_height+6'd3)
      height[feature_column]<=height[feature_column]-6'd3;
     else height[feature_column]<=feature_height;
     if(feature_column==127)begin clear_address<=0;state<=CLEAR;end
     else feature_column<=feature_column+1'b1;
    end
    CLEAR:if(clear_address==4095)begin address<=0;state<=LINE_FIRST;end
     else clear_address<=clear_address+1'b1;
    LINE_FIRST:state<=LINE_FIRST_WAIT;
    LINE_FIRST_WAIT:state<=FIRST_COORD;
    FIRST_COORD:begin px<=next_x;py<=next_y;address<=1;state<=LINE_NEXT;end
    LINE_NEXT:state<=LINE_WAIT;
    LINE_WAIT:state<=LINE_SETUP;
    LINE_SETUP:begin
     cx<=px;cy<=py;tx<=next_x;ty<=next_y;px<=next_x;py<=next_y;
     dx<=$signed({2'b00,delta_x});negative_dy<=-$signed({2'b00,delta_y});
     error<=$signed({3'b000,delta_x})-$signed({3'b000,delta_y});
     x_positive<=next_x>=px;y_positive<=next_y>=py;state<=DRAW;
    end
    DRAW:if(cx==tx && cy==ty)begin
     if(address==1023)begin completed_frames<=completed_frames+1'b1;state<=READY;end
     else begin address<=address+1'b1;state<=LINE_NEXT;end
    end else begin error<=next_error;if(step_x)cx<=x_positive?cx+1'b1:cx-1'b1;if(step_y)cy<=y_positive?cy+1'b1:cy-1'b1;end
    READY:if(accept_frame)state<=IN_FLIGHT;
    IN_FLIGHT:if(commit_frame)begin capture_count<=0;raw_peak<=0;state<=CAPTURE;end
    default:state<=CAPTURE;
   endcase
  end
 end
endmodule
`default_nettype wire
`default_nettype none
// BASE_GAIN=1..256; LIMIT_LEVEL=1..32767. One coefficient serves both channels.
// gain_q8=min(BASE_GAIN*256,floor(LIMIT_LEVEL*256/peak)); no division by zero.
module display_level_limiter #(
 parameter integer BASE_GAIN=256,LIMIT_LEVEL=30000
)(input wire clk,rst_n,start,input wire [15:0] peak,output reg done,output reg [16:0] gain_q8,input wire unity_gain);
 reg busy;reg [4:0] count;reg [23:0] dividend,quotient;
 reg [15:0] divisor;reg [16:0] remainder;
 wire [16:0] trial={remainder[15:0],dividend[23]};
 wire subtract=trial>={1'b0,divisor};
 wire [16:0] next_remainder=subtract?trial-{1'b0,divisor}:trial;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   busy<=0;count<=0;dividend<=0;quotient<=0;divisor<=1;remainder<=0;done<=0;gain_q8<=BASE_GAIN*256;
  end else begin
   done<=0;
   if(!busy)begin
    if(start)begin
     // PCM has already received its requested display gain upstream. ADC
     // retains the established BASE_GAIN. Both paths share peak limiting.
     if((unity_gain===1'b1)?peak<=LIMIT_LEVEL:peak<=LIMIT_LEVEL/BASE_GAIN)begin gain_q8<=(unity_gain===1'b1)?17'd256:BASE_GAIN*256;done<=1;end
     else begin
      divisor<=peak;dividend<=LIMIT_LEVEL*256;quotient<=0;remainder<=0;count<=0;busy<=1;
     end
    end
   end else begin
    remainder<=next_remainder;dividend<={dividend[22:0],1'b0};quotient<={quotient[22:0],subtract};
    if(count==23)begin gain_q8<={quotient[15:0],subtract};done<=1;busy<=0;end
    else count<=count+1'b1;
   end
  end
 end
endmodule
`default_nettype wire
