`default_nettype none
// Mono post-mix effect bus, copied to L/R by the existing whole-frame FIFO.
// Raw zero gates each stage immediately; all-zero uses the original PCM bits
// and original valid edge. No sample delay or Q4.20 conversion on that path.
module instrument_effects(
 input wire clk,rst_n,sample_tick,event_valid,input wire [39:0] event_data,input wire online,
 input wire input_valid,input wire signed [23:0] input_pcm,
 output wire output_valid,output wire signed [23:0] output_pcm,output wire [351:0] actual_state
);
 wire [6:0] delay_value,chorus_value,reverb_value;
 reg [6:0] phaser_depth;
 wire phaser_selected=event_valid && online && event_data[39:36]==0 && event_data[35:32]==4'hb &&
  event_data[31:28]==3 && event_data[27:24]==0 && event_data[9:8]==3 &&
  event_data[7:0]==8'hb0 && event_data[23:17]==7'd75;
 always @(posedge clk)begin
  if(!rst_n)phaser_depth<=0;
  else if(phaser_selected)phaser_depth<=event_data[16:10];
 end
 wire phaser_valid;
 wire signed [23:0] phaser_pcm;
 wire [31:0] phaser_overruns;
 instrument_phaser phaser(clk,rst_n,input_valid,phaser_depth,input_pcm,phaser_valid,phaser_pcm,phaser_overruns);

 wire [17:0] dm,dg,cm,rm,g0,g1,g2,g3;wire [23:0] depth;
 (* syn_keep=1 *) wire [31:0] accepted,updates;
 wire [20:0] smd,smc,smr;
 instrument_effects_control controls(clk,rst_n,sample_tick,event_valid,event_data,online,
  delay_value,chorus_value,reverb_value,dm,dg,cm,rm,depth,g0,g1,g2,g3,accepted,updates,smd,smc,smr);
 wire [2:0] enable={reverb_value!=0 && rm!=0,chorus_value!=0 && cm!=0,delay_value!=0 && dm!=0};
 (* syn_keep=1 *) wire ready,busy;
 (* syn_keep=1 *) wire [15:0] last_cycles;
 (* syn_keep=1 *) wire [31:0] overruns,state_saturations,wet_saturations,output_clips;
 instrument_effects_dsp dsp(clk,rst_n,phaser_valid,phaser_pcm,enable,1'b0,
  dm,dg,18'd59761,cm,rm,depth,g0,g1,g2,g3,18'd124518,18'd65536,18'd0,
  output_valid,output_pcm,ready,busy,last_cycles,overruns,state_saturations,wet_saturations,output_clips);
 wire [32:0] total_overruns={1'b0,overruns}+{1'b0,phaser_overruns};
 wire [31:0] effect_overruns=total_overruns[32] ? 32'hffffffff : total_overruns[31:0];
 assign actual_state={1'b0,enable,output_clips,effect_overruns,updates,
  g3,g2,g1,g0,depth,dg,rm,cm,dm,smr,smc,smd,reverb_value,chorus_value,delay_value};
endmodule

// Mono phaser before the original delay, chorus and reverb.
module instrument_phaser (
 input wire clk,rst_n,input_valid,
 input wire [6:0] depth,
 input wire signed [23:0] input_pcm,
 output wire output_valid,
 output wire signed [23:0] output_pcm,
 output reg [31:0] overruns
);
 localparam [3:0] IDLE=0, MODULATE=1, SET_COEFFICIENT=2,
                  MUL_INPUT=3, WAIT_INPUT=4, MUL_OUTPUT=5, WAIT_OUTPUT=6,
                  MUL_MIX=7, WAIT_MIX=8, STORE_OUTPUT=9,
                  STORE_STATE=10, STORE_MIX=11;
 // 0.35 Hz at the configured 48,000 Hz (12.288 MHz / 256) audio frame rate.
 localparam [31:0] PHASE_STEP=32'd31317;
 localparam signed [17:0] CENTER=-18'sd91750;
 reg [3:0] state;
 reg [2:0] stage;
 reg [31:0] phase;
 reg [13:0] smooth_depth;
 reg signed [17:0] coefficient, mix;
 reg signed [25:0] history[0:5];
 reg signed [25:0] current, filtered;
 reg signed [23:0] dry, processed;
 reg signed [26:0] operand_a;
 reg signed [17:0] operand_b;
 reg signed [44:0] product;
 reg processed_valid;
 integer i;

 // Folding phase gives an amplitude of almost one in signed Q1.16.
 wire [16:0] folded=phase[31] ? ~phase[30:14] : phase[30:14];
 wire signed [16:0] triangle=$signed({~folded[16],folded[15:0]});
 wire [13:0] target_depth={depth,7'd0};
 wire [13:0] distance=target_depth>smooth_depth ?
                         target_depth-smooth_depth : smooth_depth-target_depth;
 wire [14:0] step_numerator={1'b0,distance}+15'd255;
 wire [13:0] step={7'd0,step_numerator[14:8]};
 wire signed [27:0] floor_product=product[44:17];
 wire round_up=product[16] && (!product[44] || (|product[15:0]));
 wire signed [27:0] rounded=floor_product+$signed({27'd0,round_up});
 wire idle_bypass=state==IDLE && depth==0;
 assign output_valid=processed_valid || (input_valid && idle_bypass);
 assign output_pcm=processed_valid ? processed : input_pcm;

 function signed [23:0] sat24;
  input signed [27:0] value;
  begin
   if(value>28'sd8388607)sat24=24'sh7fffff;
   else if(value< -28'sd8388608)sat24=24'sh800000;
   else sat24=value[23:0];
  end
 endfunction

 function signed [25:0] sat26;
  input signed [27:0] value;
  begin
   if(value>28'sd33554431)sat26=26'sh1ffffff;
   else if(value< -28'sd33554432)sat26=26'sh2000000;
   else sat26=value[25:0];
  end
 endfunction

 // A single fully registered multiplier is shared by modulation, the six
 // transposed first-order allpasses, and the dry/wet mix.
 always @(posedge clk) begin
  product<=operand_a*operand_b;
  if(!rst_n)begin
   state<=IDLE;stage<=0;phase<=0;smooth_depth<=0;processed_valid<=0;overruns<=0;
   for(i=0;i<6;i=i+1)history[i]<=0;
  end else begin
   processed_valid<=0;
   if(input_valid)begin
    phase<=phase+PHASE_STEP;
    if(state!=IDLE && !(&overruns))overruns<=overruns+1'b1;
   end
   case(state)
    IDLE:if(input_valid)begin
     if(idle_bypass)begin
      smooth_depth<=0;
      for(i=0;i<6;i=i+1)history[i]<=0;
     end else begin
      smooth_depth<=target_depth>smooth_depth ? smooth_depth+step : smooth_depth-step;
      mix<=$signed({2'b00,smooth_depth,2'b00});
      dry<=input_pcm;current<={{2{input_pcm[23]}},input_pcm};stage<=0;
      operand_a<={{10{triangle[16]}},triangle};
      operand_b<=$signed({4'd0,smooth_depth});
      state<=MODULATE;
     end
    end
    MODULATE:state<=SET_COEFFICIENT;
    SET_COEFFICIENT:begin
     coefficient<=CENTER+$signed(product[32:15]);
     state<=MUL_INPUT;
    end
    MUL_INPUT:begin
     operand_a<={current[25],current};operand_b<=coefficient;
     state<=WAIT_INPUT;
    end
    WAIT_INPUT:state<=STORE_OUTPUT;
    STORE_OUTPUT:begin
     // H(z)=(a+z^-1)/(1+a*z^-1), y=a*x+s, s'=x-a*y.
     filtered<=sat26(rounded+$signed({{2{history[stage][25]}},history[stage]}));
     state<=MUL_OUTPUT;
    end
    MUL_OUTPUT:begin
     operand_a<={filtered[25],filtered};operand_b<=coefficient;
     state<=WAIT_OUTPUT;
    end
    WAIT_OUTPUT:state<=STORE_STATE;
    STORE_STATE:begin
     history[stage]<=sat26($signed({{2{current[25]}},current})-rounded);
     current<=filtered;
     if(stage==5)state<=MUL_MIX;
     else begin stage<=stage+1'b1;state<=MUL_INPUT;end
    end
    MUL_MIX:begin
     operand_a<=$signed({current[25],current})-$signed({{3{dry[23]}},dry});
     operand_b<=mix;
     state<=WAIT_MIX;
    end
    WAIT_MIX:state<=STORE_MIX;
    STORE_MIX:begin
     processed<=sat24(rounded+$signed({{4{dry[23]}},dry}));
     processed_valid<=1;state<=IDLE;
    end
    default:state<=IDLE;
   endcase
  end
 end
endmodule
`default_nettype wire
