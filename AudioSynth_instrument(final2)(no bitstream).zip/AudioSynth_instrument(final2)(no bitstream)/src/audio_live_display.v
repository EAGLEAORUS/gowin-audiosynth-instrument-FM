`default_nettype none
// Existing FM6363B/DP32020A protocol; realtime pixels replace offline track ROMs.
module audio_live_display #(
 parameter integer POWER_ON_TICKS=62500,
 parameter integer BUTTON_DEBOUNCE_CYCLES=1000000, UI_ENABLE=0, OCTAVE_ENABLE=1,
 parameter integer BOOT_FRAME=0, DCLK_DIV=8, WRITE_ROWS_PER_PACKET=2
)(
 input wire clk,rst_n,stream_ok,sample_valid,input wire [31:0] sample_data,input wire mode_button_n,
 output wire hub_r1,hub_g1,hub_b1,hub_r2,hub_g2,hub_b2,hub_a,hub_b,hub_c,hub_clk,hub_lat,hub_oe,
 input wire ui_mode_set,ui_mode,output wire current_mode,
 input wire [2:0] wave_color,spectrum_color,overload_color,xy_color,
 input wire octave_prompt_enable,input wire [1:0] octave_range,input wire octave_direction_up,
 input wire source_prompt_enable,source_selected_pcm,source_pcm,source_changed,
 input wire string_prompt_enable,string_enabled,
 input wire fft_read,fft_write,input wire [3:0] fft_address,input wire [31:0] fft_wdata,
 output wire [31:0] fft_rdata
);
 reg [2:0] div_cnt;wire tick=div_cnt==DCLK_DIV-1;
 always @(posedge clk or negedge rst_n)if(!rst_n || tick)div_cnt<=0;else div_cnt<=div_cnt+1'b1;
 wire [2:0] rgb1,rgb2;wire clk_en,gclk_en,ready,accept_frame,commit_frame;
 reg boot_pending,boot_active;
 reg accept_d,commit_d,live_upload,restart_pending,analysis_reset;
 reg notice_pending,source_prompt_d,source_selected_d,string_prompt_d,string_enabled_d,stream_ok_d;
 // The scanner holds its strobes for a full display tick.
 wire frame_start=accept_frame && !accept_d;
 wire frame_done=commit_frame && !commit_d;
 wire stream_lost=stream_ok_d && !stream_ok;
 wire restart_request=source_changed || stream_lost;
 // Keep the completed pixel cache intact until an in-progress upload commits.
 wire restart=(restart_request || restart_pending) && !live_upload;
 wire live_ready=ready && !restart_request && !restart_pending && !analysis_reset;
 wire live_accept=frame_start && !boot_pending && live_ready;
 wire notice_accept=frame_start && !boot_pending && !live_ready;
 wire live_commit=frame_done && live_upload;
 always @(posedge clk)begin
  if(!rst_n)begin
   accept_d<=0;commit_d<=0;live_upload<=0;restart_pending<=0;analysis_reset<=0;
   notice_pending<=0;source_prompt_d<=0;source_selected_d<=1;
   string_prompt_d<=0;string_enabled_d<=0;stream_ok_d<=0;
  end
  else begin
   accept_d<=accept_frame;commit_d<=commit_frame;
   source_prompt_d<=source_prompt_enable;source_selected_d<=source_selected_pcm;
   string_prompt_d<=string_prompt_enable;string_enabled_d<=string_enabled;
   stream_ok_d<=stream_ok;
   analysis_reset<=restart;
   if(frame_start)live_upload<=live_accept;
   else if(frame_done)live_upload<=0;
   if(restart)restart_pending<=0;
   else if(restart_request)restart_pending<=1;
   if(live_accept || notice_accept)notice_pending<=0;
   // A source selection and the end of its prompt both need a panel update.
   if(restart_request || source_prompt_enable!=source_prompt_d ||
      (source_prompt_enable && source_selected_pcm!=source_selected_d) ||
      string_prompt_enable!=string_prompt_d ||
      (string_prompt_enable && string_enabled!=string_enabled_d))notice_pending<=1;
  end
 end
 always @(posedge clk)begin
  if(!rst_n)begin boot_pending<=BOOT_FRAME!=0;boot_active<=0;end
  else if(boot_pending && frame_start)begin boot_pending<=0;boot_active<=1;end
  else if(frame_done)boot_active<=0;
 end
 wire [6:0] x1,x2;wire [5:0] y;
 wire [47:0] spectrum1,spectrum2,liss1,liss2;
 wire requested_mode;reg active_mode;
 led_mode_button #(.DEBOUNCE_CYCLES(BUTTON_DEBOUNCE_CYCLES),.UI_ENABLE(UI_ENABLE)) u_button(.clk(clk),.rst_n(rst_n),.button_n(mode_button_n),.lissajous_mode(requested_mode),.ui_set(ui_mode_set),.ui_mode(ui_mode));
 assign current_mode=requested_mode;
 always @(posedge clk or negedge rst_n)if(!rst_n)active_mode<=0;else if(live_accept)active_mode<=requested_mode;

 reg [2:0] wc,sc,oc,xc;
 always @(posedge clk)begin
  if(!rst_n)begin wc<=5;sc<=3;oc<=6;xc<=2;end
  else if(live_accept)begin wc<=wave_color;sc<=spectrum_color;oc<=overload_color;xc<=xy_color;end
 end
 function [47:0] recolor;
 input [47:0] raw;input [2:0] color;
 reg [2:0] channels;
 begin
  case(color)
   0:channels=3'b100;1:channels=3'b110;2:channels=3'b010;3:channels=3'b011;
   4:channels=3'b001;5:channels=3'b101;default:channels=3'b111;
  endcase
  recolor=raw==0?48'd0:(color==5?48'haaaa0000ffff:{{16{channels[2]}},{16{channels[1]}},{16{channels[0]}}});
 end endfunction
 wire [47:0] color_spec1=recolor(spectrum1,spectrum1==48'haaaa0000ffff ? wc:(spectrum1==48'hffffffffffff ? oc:sc));
 wire [47:0] color_spec2=recolor(spectrum2,spectrum2==48'haaaa0000ffff ? wc:(spectrum2==48'hffffffffffff ? oc:sc));
 wire [47:0] base_pixel1=UI_ENABLE?(active_mode?recolor(liss1,xc):color_spec1):(active_mode?liss1:spectrum1);
 wire [47:0] base_pixel2=UI_ENABLE?(active_mode?recolor(liss2,xc):color_spec2):(active_mode?liss2:spectrum2);
 reg source_active,source_is_pcm,string_active,string_on;
 reg prompt_active,prompt_up;reg [1:0] prompt_range;
 always @(posedge clk)begin
  if(!rst_n)begin source_active<=0;source_is_pcm<=1;string_active<=0;string_on<=0;prompt_active<=0;prompt_up<=1;prompt_range<=1;end
  else if(notice_accept || live_accept)begin
   source_active<=source_prompt_enable;source_is_pcm<=source_selected_pcm;
   string_active<=string_prompt_enable;string_on<=string_enabled;
   prompt_active<=live_accept && OCTAVE_ENABLE && octave_prompt_enable;
   prompt_up<=octave_direction_up;prompt_range<=octave_range;
  end
 end
 wire ink1,ink2;
 octave_prompt label1(x1,y,prompt_range,prompt_up,ink1);
 octave_prompt label2(x2,y,prompt_range,prompt_up,ink2);
 wire source_ink1,source_ink2,string_ink1,string_ink2;
 string_prompt string_label1(x1,y,string_on,string_ink1);
 string_prompt string_label2(x2,y,string_on,string_ink2);
 source_prompt source_label1(x1,y,source_is_pcm,source_ink1);
 source_prompt source_label2(x2,y,source_is_pcm,source_ink2);
 wire [47:0] startup_pixel=y==48?48'h111100003333:48'd0;
 wire [47:0] pixel1=boot_active?startup_pixel:string_active?(string_ink1?48'hffffffffffff:48'd0):source_active?(source_ink1?48'hffffffffffff:48'd0):prompt_active?(ink1?48'hffffffffffff:48'd0):live_upload?base_pixel1:48'd0;
 wire [47:0] pixel2=boot_active?startup_pixel:string_active?(string_ink2?48'hffffffffffff:48'd0):source_active?(source_ink2?48'hffffffffffff:48'd0):prompt_active?(ink2?48'hffffffffffff:48'd0):live_upload?base_pixel2:48'd0;
 wire [31:0] completed_frames,skipped_samples,fft_timeouts;
 wire source_rst_n=rst_n && !analysis_reset;
 wire [4:0] feature_address;wire [23:0] features;
 wire features_ready,feature_taken,feature_busy;
 ps_fft_mailbox fft_service(clk,rst_n,restart_request,stream_ok,sample_valid,source_pcm,sample_data,
  fft_read,fft_write,fft_address,fft_wdata,fft_rdata,
  feature_address,features,features_ready,feature_taken,feature_busy);
 audio_live_source source(clk,source_rst_n,stream_ok,sample_valid,sample_data,x1,x2,y,live_accept,live_commit,
  ready,spectrum1,spectrum2,liss1,liss2,completed_frames,skipped_samples,fft_timeouts,source_pcm,octave_range,
  features_ready,features,feature_address,feature_taken,feature_busy);
 led_matrix_ctrl #(.POWER_ON_TICKS(POWER_ON_TICKS),.MUSIC_DISPLAY_ENABLE(1),.RGB1_ON_RIGHT(1),
  .SCAN_ROW0_AT_BOTTOM(0),.ROW_BLANK_TICKS(32/DCLK_DIV),.LANE_CHIP_REVERSE(0),
  .WRITE_ROWS_PER_PACKET(WRITE_ROWS_PER_PACKET)) u_ctrl(
  .clk(clk),.rst_n(rst_n),.tick(tick),.music_frame_ready(boot_pending || live_ready || notice_pending),
  .music_pixel1(pixel1),.music_pixel2(pixel2),
  .music_accept(accept_frame),.music_commit(commit_frame),.image_x1(x1),.image_x2(x2),.image_y(y),
  .rgb1(rgb1),.rgb2(rgb2),.row_a(hub_a),.row_b(hub_b),.row_c(hub_c),
  .clk_en(clk_en),.lat(hub_lat),.gclk_en(gclk_en),.busy(),.frame_pulse(),.row_index());
 reg hub_clk_r,hub_oe_r;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin hub_clk_r<=0;hub_oe_r<=0;end
  else if(div_cnt==DCLK_DIV/2-1)begin hub_clk_r<=clk_en;hub_oe_r<=gclk_en;end
  else if(tick)begin hub_clk_r<=0;hub_oe_r<=0;end
 end
 assign {hub_r1,hub_g1,hub_b1}=rgb1;assign {hub_r2,hub_g2,hub_b2}=rgb2;
 assign hub_clk=hub_clk_r;assign hub_oe=hub_oe_r;
endmodule
`default_nettype wire
