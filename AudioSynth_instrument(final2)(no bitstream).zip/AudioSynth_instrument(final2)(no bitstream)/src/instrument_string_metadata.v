`default_nettype none
module instrument_string_metadata(input wire [2:0] op,output reg [3:0] sensitivity,output reg [12:0] offset0,offset1,offset2);
 always @* begin sensitivity=0;offset0=4256;offset1=4256;offset2=4256;case(op)
 0:begin sensitivity=4'd2;offset0=13'd224;offset1=13'd416;offset2=13'd608;end
 1:begin sensitivity=4'd2;offset0=13'd608;offset1=13'd416;offset2=13'd608;end
 2:begin sensitivity=4'd2;offset0=13'd224;offset1=13'd416;offset2=13'd608;end
 3:begin sensitivity=4'd7;offset0=13'd224;offset1=13'd672;offset2=13'd736;end
 4:begin sensitivity=4'd0;offset0=13'd736;offset1=13'd416;offset2=13'd1376;end
 5:begin sensitivity=4'd3;offset0=13'd224;offset1=13'd672;offset2=13'd1120;end
 default:begin end
 endcase end
endmodule
`default_nettype wire
