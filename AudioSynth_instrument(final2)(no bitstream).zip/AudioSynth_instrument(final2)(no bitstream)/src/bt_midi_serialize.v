`default_nettype none
// Committed 40-bit event -> raw MIDI bytes for the ESP32 UART. 3-byte channel
// messages, 2-byte Program/ChannelPressure, 1-byte system realtime. No running
// status compression: the receiver always sees an explicit status byte.
module bt_midi_serialize(
 input wire clk,rst_n,evt_valid,input wire [39:0] evt_data,
 output wire evt_ready,
 output reg byte_valid,output reg [7:0] byte_data,input wire byte_ready
);
 reg busy;
 reg [1:0] idx,n;
 reg [6:0] d1,d2;
 reg [7:0] st;
 assign evt_ready=!busy;
 always @(posedge clk)begin
  if(!rst_n)begin
   busy<=0;idx<=2'd0;n<=2'd0;d1<=7'd0;d2<=7'd0;st<=8'd0;
   byte_valid<=0;byte_data<=8'd0;
  end else if(!busy)begin
   if(evt_valid)begin
    busy<=1;idx<=2'd0;
    n<=evt_data[9:8];
    st<=evt_data[7:0];
    d1<=evt_data[23:17];
    d2<=evt_data[16:10];
    byte_valid<=1;byte_data<=evt_data[7:0];
   end else byte_valid<=0;
  end else if(byte_valid && byte_ready)begin
   if(idx+2'd1>=n)begin busy<=0;byte_valid<=0;end
   else begin
    idx<=idx+2'd1;
    byte_valid<=1;
    byte_data<=(idx==2'd0)?{1'b0,d1}:{1'b0,d2};
   end
  end
 end
endmodule
`default_nettype wire
