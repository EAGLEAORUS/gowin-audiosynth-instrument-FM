`default_nettype none
// Whole-record Gray-pointer CDC FIFO. Both resets assert together on PLL loss.
module usb_packet_async_fifo #(parameter WIDTH=523,parameter ADDR_BITS=2)(
 input wire wr_clk,wr_rst_n,wr_valid,input wire [WIDTH-1:0] wr_data,
 output wire wr_ready,output reg [31:0] overflow,
 input wire rd_clk,rd_rst_n,output wire rd_valid,output wire [WIDTH-1:0] rd_data,
 input wire rd_ready
);
 reg [WIDTH-1:0] mem[0:(1<<ADDR_BITS)-1];
 reg [ADDR_BITS:0] wb,wg,rb,rg;
 // One staged write, included in capacity accounting. The Gray pointer is
 // committed ONLY on the clock that writes memory, never before the payload.
 reg [(1<<ADDR_BITS)-1:0] bank_enable;
 reg [WIDTH-1:0] staged_data;
 wire pending=|bank_enable;
 wire [ADDR_BITS:0] allocated=wb+pending;
 wire [ADDR_BITS:0] allocated_gray=(allocated>>1)^allocated;
 integer bank;
 (* syn_preserve=1 *) reg [ADDR_BITS:0] rg_meta,rg_sync,wg_meta,wg_sync;
 wire [ADDR_BITS:0] full_compare={~rg_sync[ADDR_BITS:ADDR_BITS-1],rg_sync[ADDR_BITS-2:0]};
 assign wr_ready=allocated_gray!=full_compare;
 // Prefetch the asynchronously-written word into the read clock domain before
 // exposing it.  The synchronized Gray pointer guarantees that the selected
 // memory word has been stable for at least two read clocks.  Keeping this
 // register here also prevents the 523-bit CDC payload from directly driving
 // every downstream FIFO write-enable.
 reg rd_valid_reg;
 reg [WIDTH-1:0] rd_data_reg;
 wire stored_available=rg!=wg_sync;
 assign rd_valid=rd_valid_reg;
 assign rd_data=rd_data_reg;
 wire [ADDR_BITS:0] wn=wb+1'b1,rn=rb+1'b1;
 always @(posedge wr_clk or negedge wr_rst_n)begin
  if(!wr_rst_n)begin wb<=0;wg<=0;rg_meta<=0;rg_sync<=0;overflow<=0;bank_enable<=0;staged_data<=0;end
  else begin
   rg_meta<=rg;rg_sync<=rg_meta;
   // Registered per-bank enables remove full/Gray/address logic from the
   // high-fanout 523-bit memory CE path at 96MHz.
   for(bank=0;bank<(1<<ADDR_BITS);bank=bank+1)begin
    if(bank_enable[bank])mem[bank]<=staged_data;
    bank_enable[bank]<=wr_valid && wr_ready && allocated[ADDR_BITS-1:0]==bank;
   end
   if(pending)begin wb<=wn;wg<=(wn>>1)^wn;end
   if(wr_valid)begin
    if(wr_ready)staged_data<=wr_data;
    else overflow<=overflow+1'b1;
   end
  end
 end
 always @(posedge rd_clk or negedge rd_rst_n)begin
  if(!rd_rst_n)begin
   rb<=0;rg<=0;wg_meta<=0;wg_sync<=0;rd_valid_reg<=0;rd_data_reg<=0;
  end
  else begin
   wg_meta<=wg;wg_sync<=wg_meta;
   if((!rd_valid_reg || rd_ready) && stored_available)begin
    rd_data_reg<=mem[rb[ADDR_BITS-1:0]];
    rd_valid_reg<=1;
    rb<=rn;rg<=(rn>>1)^rn;
   end else if(rd_valid_reg && rd_ready)rd_valid_reg<=0;
  end
 end
endmodule
`default_nettype wire
