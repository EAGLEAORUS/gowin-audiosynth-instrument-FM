# DDS / ADSR reference attribution

The new sample-enabled phase accumulator, note LUT, and envelope design were
reviewed against nishadsuresh/fpga-verilog-synth. The MIT notice is retained
below. Our implementation uses the actual 48828.125 Hz codec frame rate,
Orca +12 calibration, exact-duration integer ramps and safe event CDC.

gundy/tiny-synth was studied for voice modularity and main-clock/sample-clock
differences. Its CERN OHL v1.2 code was not incorporated into production RTL;
reference snapshots and original licence are kept under the task's references.
See docs/dds-adsr/REFERENCE_SHA256.json for actual reviewed files and hashes.

MIT License

Copyright (c) 2026 Nishad Suresh

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
