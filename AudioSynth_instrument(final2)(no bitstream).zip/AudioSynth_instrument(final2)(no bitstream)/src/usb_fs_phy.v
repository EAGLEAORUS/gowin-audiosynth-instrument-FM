`default_nettype none
// Full-speed derivative of the local nand2mario/hi631 UKP bit engine.
// Retains 8 clocks/bit, edge phase correction, NRZI and six-one stuffing.
// Apache-2.0; see USB_HOST_REFERENCE_LICENSE.txt. No HID fixed data window.
// clk MUST be 96MHz. Packet ports include PID/CRC, exclude SYNC/EOP.
module usb_fs_phy(
 input wire clk,rst_n,input wire bus_reset,
 inout wire usb_dp,usb_dm,
 input wire tx_start,input wire [3:0] tx_length,input wire [87:0] tx_packet,
 output wire tx_ready,output reg tx_done,
 output reg rx_done,output reg rx_error,output reg rx_crc_ok,
 output reg [6:0] rx_length,output reg [535:0] rx_packet,
 output wire line_j,line_se0,output wire driving,
 output reg [7:0] rx_faults,output wire rx_active
);
 (* syn_preserve=1 *) reg dp_meta,dm_meta,dp_sync,dm_sync;
 always @(posedge clk) begin
  if(!rst_n)begin dp_meta<=0;dm_meta<=0;dp_sync<=0;dm_sync<=0;end
  else begin dp_meta<=usb_dp;dm_meta<=usb_dm;dp_sync<=dp_meta;dm_sync<=dm_meta;end
 end
 assign line_j=dp_sync && !dm_sync;
 assign line_se0=!dp_sync && !dm_sync;
 wire line_k=!dp_sync && dm_sync;
 reg oe,tx_j,tx_se0;
 reg [2:0] tx_state,tx_phase,tx_bit,tx_ones;
 reg [3:0] tx_index,tx_len;
 reg [87:0] tx_buf;
 localparam T_IDLE=0,T_SYNC=1,T_DATA=2,T_SE0A=3,T_SE0B=4,T_J=5,T_STUFF=6,T_RELEASE=7;
 assign driving=oe || bus_reset;
 assign usb_dp=bus_reset?1'b0:oe?(tx_se0?1'b0:tx_j):1'bz;
 assign usb_dm=bus_reset?1'b0:oe?(tx_se0?1'b0:!tx_j):1'bz;
 assign tx_ready=tx_state==T_IDLE && !bus_reset;
 wire tx_value=(tx_state==T_SYNC)?(tx_bit==7):tx_buf[{tx_index,3'b000}+tx_bit];
 always @(posedge clk) begin
  if(!rst_n || bus_reset)begin
   oe<=0;tx_state<=T_IDLE;tx_phase<=0;tx_bit<=0;tx_index<=0;tx_len<=0;
   tx_ones<=0;tx_j<=1;tx_se0<=0;tx_done<=0;tx_buf<=0;
  end else begin
   tx_done<=0;
   if(tx_state==T_IDLE)begin
    if(tx_start && tx_length!=0 && tx_length<=11)begin
     tx_buf<=tx_packet;tx_len<=tx_length;tx_index<=0;tx_bit<=0;
     tx_phase<=0;tx_ones<=0;tx_j<=1;tx_state<=T_SYNC;
    end
   end else begin
    tx_phase<=tx_phase+1'b1;
    if(tx_phase==0)begin
     oe<=1;
     if(tx_state==T_SYNC || tx_state==T_DATA)begin
      if(tx_ones==6)begin tx_j<=!tx_j;tx_ones<=0;end
      else begin
       tx_j<=tx_value?tx_j:!tx_j;
       tx_ones<=tx_value?tx_ones+1'b1:3'd0;
       if(tx_bit==7)begin
        tx_bit<=0;
        if(tx_state==T_SYNC)tx_state<=T_DATA;
        else if(tx_index==tx_len-1'b1)tx_state<=(tx_value && tx_ones==5)?T_STUFF:T_SE0A;
        else tx_index<=tx_index+1'b1;
       end else tx_bit<=tx_bit+1'b1;
      end
     end else if(tx_state==T_STUFF)begin tx_j<=!tx_j;tx_ones<=0;tx_state<=T_SE0A;end
     else if(tx_state==T_SE0A)begin tx_se0<=1;tx_state<=T_SE0B;end
     else if(tx_state==T_SE0B)tx_state<=T_J;
     else if(tx_state==T_J)begin tx_se0<=0;tx_j<=1;tx_state<=T_RELEASE;end
     else if(tx_state==T_RELEASE)begin tx_state<=T_IDLE;oe<=0;tx_done<=1;end
    end
   end
  end
 end
 function [15:0] crc_byte;
  input [15:0] c;input [7:0] b;reg [15:0] v;integer k;
  begin v=c;for(k=0;k<8;k=k+1)v=(v>>1)^((v[0]^b[k])?16'ha001:16'd0);crc_byte=v;end
 endfunction
 reg receiving,last_line,prev_j,sync_seen,bad;
 assign rx_active=receiving;
 reg [2:0] phase,bit_index,ones;
 reg [7:0] shift;
 reg [6:0] count;
 reg [15:0] crc;
 reg [1:0] eop_count;
 reg [12:0] rx_watchdog;
 wire nrz=last_line ~^ dp_sync;
 wire [7:0] next_byte={nrz,shift[7:1]};
 always @(posedge clk)begin
  if(!rst_n || bus_reset || oe)begin
   receiving<=0;prev_j<=1;last_line<=1;sync_seen<=0;bad<=0;
   phase<=0;bit_index<=0;ones<=0;shift<=0;count<=0;crc<=16'hffff;
   eop_count<=0;rx_watchdog<=0;rx_done<=0;rx_error<=0;rx_crc_ok<=0;
   rx_length<=0;rx_packet<=0;rx_faults<=0;
  end else begin
   rx_done<=0;
   // Preserve the last VALID differential line state. Separate D+/D-
   // synchronizers can briefly report SE0/SE1 on a real J<->K edge.
   // Updating history from D+ alone loses the first K of SYNC when D-
   // arrives one sampling clock later (e.g. a 2ns pad skew).
   if(line_j || line_k)prev_j<=line_j;
   if(!receiving)begin
    if(prev_j && line_k)begin
     receiving<=1;rx_faults<=0;phase<=0;last_line<=1;sync_seen<=0;bad<=0;bit_index<=0;
     ones<=0;shift<=0;count<=0;crc<=16'hffff;eop_count<=0;rx_watchdog<=0;
    end
   end else begin
    rx_watchdog<=rx_watchdog+1'b1;
    if(rx_watchdog==8191)begin receiving<=0;rx_done<=1;rx_error<=1;rx_length<=0;rx_crc_ok<=0;rx_faults[6]<=1;end
    // Same UKP phase recovery principle; sample near the middle after an edge.
    if((line_j || line_k) && dp_sync!=prev_j)phase<=0;
    else phase<=phase+1'b1;
    if(phase==3)begin
     if(line_se0)begin
      if(eop_count!=3)eop_count<=eop_count+1'b1;
     end else if(eop_count!=0)begin
      receiving<=0;rx_done<=1;rx_length<=count;
      rx_error<=bad || !line_j || eop_count!=2 || bit_index!=0 || !sync_seen || count==0 || ones==6;
      rx_crc_ok<=crc==16'hb001;
      rx_faults[3]<=!line_j || eop_count!=2;
      rx_faults[4]<=bit_index!=0 || !sync_seen || count==0 || ones==6;
     end else if(!(line_j || line_k))begin bad<=1;rx_faults[7]<=1;end
     else begin
      last_line<=dp_sync;
      if(ones==6)begin
       if(nrz)begin bad<=1;rx_faults[2]<=1;end
       ones<=0;
      end else begin
       ones<=nrz?ones+1'b1:3'd0;
       shift<=next_byte;
       bit_index<=bit_index+1'b1;
       if(bit_index==7)begin
        if(!sync_seen)begin sync_seen<=1;if(next_byte!=8'h80)begin bad<=1;rx_faults[1]<=1;end end
        else if(count<67)begin
         rx_packet[count*8+:8]<=next_byte;count<=count+1'b1;
         if(count!=0)crc<=crc_byte(crc,next_byte);
         else if(next_byte[7:4]!=(~next_byte[3:0]))begin bad<=1;rx_faults[0]<=1;end
        end else begin bad<=1;rx_faults[5]<=1;end
       end
      end
     end
    end
   end
  end
 end
endmodule
`default_nettype wire
