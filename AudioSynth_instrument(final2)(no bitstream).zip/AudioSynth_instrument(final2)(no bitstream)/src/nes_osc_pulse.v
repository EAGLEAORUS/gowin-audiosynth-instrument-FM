`default_nettype none
// MATLAB phase zero is the FIRST sample, not FCW. Duty step order is literal.
module nes_osc_pulse(
 input wire clk,rst_n,sample_tick,restart,enable,
 input wire [23:0] fcw,input wire [1:0] duty,input wire [3:0] volume,
 output wire [3:0] level,output reg [23:0] phase
);
 reg high_step;
 always @* begin
  case(duty)
   2'd0:high_step=phase[23:21]==3'd7;
   2'd1:high_step=phase[23:21]>=3'd6;
   2'd2:high_step=phase[23];
   default:high_step=!phase[23]; // literal fourth nes_spec row
  endcase
 end
 assign level=(enable && high_step)?volume:4'd0;
 always @(posedge clk)begin
  if(!rst_n || restart)phase<=24'd0;
  else if(sample_tick && enable)phase<=phase+fcw;
 end
endmodule
`default_nettype wire
