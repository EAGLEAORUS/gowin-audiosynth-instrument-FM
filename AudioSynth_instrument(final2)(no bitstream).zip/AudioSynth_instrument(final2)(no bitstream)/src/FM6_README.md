# DX7 E.PIANO 1 candidate

2026-10-17 CC76 source update: Cable00/CH01/CC76 now controls ES8156 system output volume (0=mute, 127=original maximum), with 0.5dB I2C steps and disconnect retention. RTL, small synthesized control-path netlist, and 4095-sample I2S golden integration pass. See `../../docs/midi-volume/CC76.md`. Rebuild the current project (48 CLI/standalone sources; GUI keeps the unrelated parallel rollback top disabled): the existing fix-logicpitch-pnr2 bitstream predates this feature; full PnR/hardware for this update has not been run.

Top: `FM6_audio_usb_top`, four independent six-operator voices, nominal 48kHz signed PCM24. Algorithm5, OP6 feedback, factory four-stage EG and key/velocity scaling; no PCM playback ROM.

Full evidence, clock rationale, limitations, rollback and manual validation: `../../docs/dx7/DX7-01.md`.
Current final build identity: `../../scripts/dx7/candidate-build.json`.

Current follow-up: `../../docs/dx7/DX7-SOUND-FIX.md`. The initial build has a reproduced synthesized exp-interpolation error. Corrected candidate fix-logicpitch-pnr2 passes RTL, synthesized-core, full USB/I2S synthesized/routed pin-only golden, and STA/static checks. Source/bitstream identity is in candidate-build.json and build/dx7-fix-v1/final-evidence.json. Setup margin is only +0.001 ns. New hardware audio remains unverified. SDF is intentionally not run.

CH01 raw48..72 maps to model MIDI60..84 as in the prior keyboard test. The correction restores channel-wide +/-2-semitone Pitch Bend for all six operators, preserving phase/EG and using a frame snapshot. Sustain is not connected. Original DDS/Pitch projects remain for rollback. Numerical sources/notices: `../../assets/dx7/NOTICE.md` and source-sha256.json.
