`default_nettype none
// Whole counter snapshot mailbox. Never synchronize counter bits separately.
// A stopped codec clock yields unavailable/stale telemetry, never an invented
// valid zero. Source holds the entire bank until the next request returns.
module usb3_status_cdc #(parameter W=64)(
 input wire clk,rst_n,source_clk,source_valid,input wire [W-1:0] source_data,
 output reg [W-1:0] data,output reg valid);
 wire source_rst_n;
 audio_usb_reset reset_source(source_clk,rst_n,source_rst_n);
 reg request,ack,ack_seen,request_seen;
 (* syn_preserve=1 *) reg request_meta,request_sync,ack_meta,ack_sync;
 reg [W-1:0] bank;reg bank_valid;
 reg [15:0] poll_count;reg [19:0] age;
 always @(posedge source_clk or negedge source_rst_n)begin
  if(!source_rst_n)begin request_meta<=0;request_sync<=0;request_seen<=0;ack<=0;bank<=0;bank_valid<=0;end
  else begin
   request_meta<=request;request_sync<=request_meta;
   if(request_sync!=request_seen)begin
    bank<=source_valid?source_data:{W{1'b0}};bank_valid<=source_valid;
    request_seen<=request_sync;ack<=request_sync;
   end
  end
 end
 always @(posedge clk)begin
  if(!rst_n)begin request<=0;ack_meta<=0;ack_sync<=0;ack_seen<=0;data<=0;valid<=0;poll_count<=0;age<=0;end
  else begin
   ack_meta<=ack;ack_sync<=ack_meta;
   if(request!=ack_sync)poll_count<=0;
   else if(poll_count==49999)begin request<=~request;poll_count<=0;end
   else poll_count<=poll_count+1'b1;
   if(age<500000)age<=age+1'b1;else valid<=0;
   if(ack_sync!=ack_seen)begin data<=bank;valid<=bank_valid;age<=0;ack_seen<=ack_sync;end
  end
 end
endmodule
`default_nettype wire
