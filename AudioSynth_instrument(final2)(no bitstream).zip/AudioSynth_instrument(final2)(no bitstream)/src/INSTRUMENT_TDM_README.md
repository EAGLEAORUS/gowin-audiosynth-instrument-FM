# AudioSynth instrument: 50 MHz, 64 voices, 4×16 SYX TDM

The production top is `audio_synth_instrument_top`. Both Gowin projects use
four 16-voice lanes through `audio.synth.engine.bank.lanes[0–3].core`.
The active RTL files are `instrument_tdm64_engine.v`,
`instrument_tdm64_core.v`, `instrument_tdm64_allocator.v`,
`instrument_tdm64_bank.v` and `sd_instrument_apb.v`.

Open [AudioSynth_instrument.gprj](../AudioSynth_instrument.gprj) and run
Synthesis before Place & Route for a manual build. The existing `impl`
artifacts are historical. The isolated validated run used Place 3 / Route 2.

[4×16 build and resources](../../docs/sd-adapt/TDM64_20261108.md) ·
[64-voice soak and onset measurements](../../docs/sd-adapt/TDM64_SOAK_20261108.md)

## Historical 40-voice, 4×10 TDM release
This release used instrument_engine40, instrument_core10 and instrument_allocator40.
CH1 FM and CH10 NES-style8bit pads share ALL40 slots; no fixed quotas.
Repeated pad hits allocate separate slots, including40 overlapping hits on one pad.
Total40 held/releasing notes; exhaustion steals a releasing/oldest voice using the shared LRU.
CH1 same-key retrigger and sustain policy remain; CH10 NoteOff releases all matching held hits.
Four shared NES arithmetic lanes store183bit per-note contexts inside existing188bit OP RAM.
The16 pads select16 pitches, not a16-voice hardware limit.
Production no longer instantiates the legacy single-note nes_apu; it remains a numerical reference.
Single-note NES gain/shape and FM arithmetic remain; mixed-sum saturation is explicit.
See docs/nes-poly/REPORT_20261031.md for current implementation/validation and resource results.
See INSTRUMENT40_NOTICES.md for original attribution.

## Historical release notes below (superseded by current report)

# DX7 instrument: 32 voices, EP1 + Celesta + MARIMBA, 4 x 8 TDM

Current accepted lossless effects storage optimization (2026-10-21):
[report and current release](../../docs/effects/MEMORY_OPTIMIZATION.md),
[tested bitstream](../../build/effects-memory-20261021/pnr1/workspace/AudioSynth_instrument/impl/pnr/audio_synth_instrument.fs),
[delivery check](../../build/effects-memory-20261021/final/delivery-check.json).
Physical BSRAM 235 -> 215 of 340 (69.12% -> 63.24%); Logic -25,
FF +5, CLS +62, DSP unchanged. Only three verified effects RTL files changed.
Audio remains bit exact, with zero added 50MHz cycles or sample frames.
Both original projects keep 64 sources, current CST/SDC, 19 pins and K2 AB13.
The 32 voices, three patches, MIDI controls, pitch and USB PHY fix remain.
Native synthesis/PnR passed, Setup/Hold=0, +0.049/+0.210ns (small setup margin).
Full routed-netlist USB -> I2S simulation passed. Hardware/SDF/analog sound
and physical end-to-end latency remain unverified; no flashing performed.
Use only a NEW isolated build copy, synthesis before PnR; old impl is historical.

Previous accepted three-knob effects release (2026-10-20):
[contract, validation and limitations](../../docs/effects/EFFECTS.md),
[tested bitstream](../../build/effects-20261020/pnr1/workspace/AudioSynth_instrument/impl/pnr/audio_synth_instrument.fs),
[delivery check](../../build/effects-20261020/final/delivery-check.json).
CC77=Delay, CC93=Chorus, CC73=Reverb on Cable00/CH01, VALUE0..127.
Delay -> Chorus -> Reverb may operate together. All-zero uses the original
PCM24 bits and valid edge, with no extra sample frame. The 32 voices, three
patches, K2/C3..C5 mapping, pitch, CC76 and accepted USB PHY fix remain.
Native basic synthesis/PnR passed, Setup/Hold=0, +0.209/+0.212ns.
The full routed board passed real USB knob on/off and external stereo I2S,
including 1103 exact dry frames after zero bypass and 1031 changed wet frames.
Current CST/SDC/19 pins/K2 AB13/flow settings are preserved.
Both original GPRJ source entries are maintained; run tools ONLY in a new
isolated copy, Synthesis before PnR. Original impl outputs remain historical.
Hardware, SDF, analog sound/RT60 and actual sample precision are unverified.

Previous accepted USB RX correction (2026-10-20):
[cause, commands and validation](../../docs/usb-midi/USB_RX_FIX.md),
[tested bitstream](../../build/usb-rx-fix-20261020/pnr1/workspace/AudioSynth_instrument/impl/pnr/audio_synth_instrument.fs),
[delivery check](../../build/usb-rx-fix-20261020/final/delivery-check.json).
Only usb_fs_phy.v changed: retain the last valid J/K across differential
synchronizer skew. Native basic GPRJ synthesis/PnR passed with Setup/Hold=0
and +0.250/+0.203ns worst slack. The exact routed netlist passed 7153 external
USB/K2/I2S samples with 2ns device D- skew. Current CST/SDC, both projects,
flow settings, pitch mapping and all 19 pins are unchanged. Original impl
outputs are historical: reopen the basic GPRJ and run Synthesis before PnR,
or use the tested bitstream above. Hardware and SDF remain unverified.

Previous accepted three-patch release (2026-10-19):
[closure report and commands](../../docs/marimba/CLOSURE.md),
[tested bitstream](../../build/marimba-closure-20261019/pnr1/impl/pnr/audio_synth_instrument.fs),
[current source status](../../build/marimba-closure-20261019/final/source-status.json).
Full synthesis/PnR/STA and the native GPRJ rebuild passed with zero Setup/Hold
violations (+0.032/+0.191ns). The exact routed netlist passed 7153 external
USB/K2/stereo-I2S golden samples across EP, MARIMBA and Celesta. The GPRJ rebuild
produced identical programming bits. Hardware and SDF remain unverified.
The small 32ps setup margin applies only to this frozen version.
The earlier candidate pointers below are historical two-patch builds without MARIMBA.

Both GPRJ entry points now have the same 64 HDL files, instrument CST/SDC,
explicit `audio_synth_instrument_top`, output `audio_synth_instrument`, and
the accepted source order and Place/Route=2/1 settings. Current CST/SDC bytes and
all 19 pins (K2=AB13) were preserved. Close the old IDE project without saving
stale project state, then open an isolated copy of the basic GPRJ and run
Synthesis before Place & Route. Original impl outputs were retained and are older than this code.
The preserved [two-patch recovery](../../build/marimba-route-recovery-20261019/two-patch-recovery/AudioSynth_instrument/AudioSynth_basic_instrument.gprj)
remains available; [PA2024 history](../../docs/marimba/PROJECT_ENTRY_FIX.md) is separate.
Read-only configuration check: `python scripts/marimba/project_config.py`;
after closing the IDE, `--repair` backs up and restores the canonical config.

Current production architecture: four physical lanes at 50MHz, each processing
eight independent six-operator voices. `instrument_core8` uses a tagged EG/Pitch
preparation pipeline followed by one shared FM/PM rendering datapath per lane.
`instrument_core4` remains as the previous numerical regression reference.

Historical two-patch results, bitstream, latency definitions, limitations and
commands: [4 x 8 report](../../docs/instrument32-tdm/TDM4X8.md) and
[command index](../../docs/instrument32-tdm/COMMANDS.md).
The historical two-patch pointer is `scripts/instrument32_tdm/candidate-build.json`;
earlier pnr8/storage-only pointers also remain rollback evidence. None of these
is the current three-patch source fingerprint.

The source entry is `AudioSynth_basic_instrument.gprj` in the parent directory. Close an old
Gowin project without saving stale file selections before reopening. Run
**Synthesis before Place & Route**: the old `impl/gwsynthesis` netlist is not the
delivered candidate. Current top: `audio_synth_instrument_top`; output base:
`audio_synth_instrument`, with 64 enabled HDL files. Build only an isolated copy. Only `audio_synth_instrument.cst` and
`audio_synth_instrument.sdc` should be active. Do not edit the old USB SDC to
hide hierarchy errors.

All 18 old pin assignments are preserved; K2 adds EX_KEY.1 / AB13, active low,
with internal pull-up and the original 10ms stable debounce. Power-on EP1,
press for Celesta, press again for MARIMBA, press a third time for EP1.
The internal selector is two bits (EP1=0, Celesta=1, MARIMBA=2). Held voices
retain their own patch; new NoteOn/retrigger captures the selected patch.

The existing C3..C5 keyboard mapping remains raw CH01 MIDI48..72 -> played
MIDI60..84. MARIMBA preserves factory transpose0 and its frequency ratios,
including half-frequency carriers; no extra octave normalization is applied.
Celesta retains its own factory +12.

MARIMBA comes directly from ROM1A slot22, algorithm7, feedback0, key-sync1.
Six OP rates/levels/scaling/velocity/ratios are decoded from the supplied SYX.
The existing EP parameter compiler and envelope/sine arithmetic are reused
with algorithm7 routing added. No recording fit, new sound model or sampled
PCM ROM is introduced. This does not establish Yamaha-chip/Dexed bit identity.
MARIMBA follows EP output scaling: raw/16 per voice, then fixed /8 headroom.

The 32 independent voices retain original phase, EG, feedback, velocity,
NoteOn/Off, quantization and saturation rules. EP algorithm5 and Celesta
algorithm31 retain separate frozen numerical kernels and tables. The lossless
EP dictionary still reconstructs 173 bits in one clock edge. No sampled-audio
ROM is played. MIDI mapping, Pitch Bend, CC76, USB, PLL, codec, complete-frame
CDC and I2S interfaces are unchanged. The fixed additional /8 output headroom
is unchanged from the previous 32-voice design; it is not normalized by lane
count or active note count.

The report distinguishes digital NoteOn latency, CC76 DAC smoothing, K2
debounce and unmeasured controller/DAC analog latency. Digital simulation and
STA do not replace board testing. Board/analog and SDF validation remain
unverified unless the current report explicitly records otherwise.

After legacy model/integration generation, run
`python scripts/instrument32_storage/install.py`, followed by
`python scripts/instrument32_tdm/install.py`, then apply
`python scripts/marimba/preset.py` and `python scripts/marimba/integrate.py`
before rerunning numerical/timing
acceptance. The TDM generator uses the preserved core4 and the frozen baseline
engine source in `tests/instrument32_tdm/baseline_engine32.v`; it does not
depend on a temporary build snapshot.

Use `python scripts/marimba/check_delivery.py` for this extension. Legacy TDM
finalizers and GUI `--repair` helpers restore/compare against the old two-patch
snapshot and must not be used to restore this three-patch project.
That initial MARIMBA bring-up's unverified synthesis/PnR note is historical;
use the accepted release reports above. Board playback, analog measurements
and SDF remain unverified.

Historical references: [storage stage](../../docs/instrument32-storage/STORAGE_OPTIMIZATION.md),
[initial 32-voice stage](../../docs/instrument32/INSTRUMENT32.md),
[licenses and provenance](INSTRUMENT32_NOTICES.md).
