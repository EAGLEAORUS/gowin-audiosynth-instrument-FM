`default_nettype none
// One independent note/phase/envelope/velocity state. All sequential logic is
// in clk (DAC BCLK); sample_tick is a one-cycle enable once per stereo frame.
module voice_core #(
 parameter integer ATTACK_SAMPLES=146, DECAY_SAMPLES=3906, RELEASE_SAMPLES=5859,
 parameter [15:0] SUSTAIN_LEVEL=16'd49151
)(input wire clk,rst_n,sample_tick,event_valid,input wire [39:0] event_data,
 input wire online, output wire signed [23:0] pcm,
 output wire [15:0] envelope,output wire [2:0] env_state,
 output reg [6:0] active_note,output reg gate,
 output reg [31:0] accepted_events);
 wire [3:0] kind=event_data[31:28],channel=event_data[27:24];
 wire [6:0] note=event_data[23:17],velocity=event_data[16:10];
 wire selected=channel==0 && note>=48 && note<=72;
 wire note_on=event_valid && selected && kind==2 && velocity!=0;
 wire note_off=event_valid && selected && (kind==1 || (kind==2 && velocity==0));
 wire all_off=event_valid && channel==0 && kind==3 && (note==120 || note==123);
 wire trigger=online && note_on;
 wire stop=(!online && gate) || (online && ((note_off && note==active_note && gate) || (all_off && gate)));
 reg [15:0] velocity_target,velocity_gain;
 wire [31:0] increment;
 reg [31:0] phase;
 wire signed [15:0] sine;
 synth_note_lut tuning(active_note,increment);
 synth_sine_rom waveform(clk,phase[31:22],sine);
 synth_adsr #(.ATTACK_SAMPLES(ATTACK_SAMPLES),.DECAY_SAMPLES(DECAY_SAMPLES),
 .RELEASE_SAMPLES(RELEASE_SAMPLES),.SUSTAIN_LEVEL(SUSTAIN_LEVEL)) adsr(
 clk,rst_n,sample_tick,trigger,stop,envelope,env_state);
 always @(posedge clk)begin
  if(!rst_n)begin active_note<=48;gate<=0;velocity_target<=0;velocity_gain<=0;phase<=0;accepted_events<=0;end
  else begin
   if(trigger)begin
    active_note<=note;gate<=1;
    // 127*516=65532, unsigned Q0.16; the gain slew prevents a velocity step.
    velocity_target<={9'd0,velocity}*16'd516;accepted_events<=accepted_events+1'b1;
   end else if(stop)begin gate<=0;accepted_events<=accepted_events+1'b1;end
   if(sample_tick)begin
    // Never reset phase on retrigger: frequency changes retain phase continuity.
    if(env_state!=0 || gate)phase<=phase+increment;
    if(velocity_gain<velocity_target)begin
     if({1'b0,velocity_target}-{1'b0,velocity_gain}<=17'd449)velocity_gain<=velocity_target;
     else velocity_gain<=velocity_gain+16'd449;
    end else if(velocity_gain>velocity_target)begin
     if({1'b0,velocity_gain}-{1'b0,velocity_target}<=17'd449)velocity_gain<=velocity_target;
     else velocity_gain<=velocity_gain-16'd449;
    end
   end
  end
 end
 // Explicit signed 16x17 -> 33, then 33x17 -> 50 bit products. Pipeline runs
 // every BCLK and settles well before the next 64-BCLK frame boundary.
 reg signed [32:0] env_product;
 reg signed [49:0] gain_product;
 reg signed [49:0] rounded;
 reg signed [23:0] pcm_reg;
 always @* begin
  if(gain_product>=0)rounded=(gain_product+50'sd67108864)>>>27;
  else rounded=-(((-gain_product)+50'sd67108864)>>>27);
 end
 always @(posedge clk)begin
  if(!rst_n)begin env_product<=0;gain_product<=0;pcm_reg<=0;end
  else begin
   env_product<=$signed(sine)*$signed({1'b0,envelope});
   gain_product<=env_product*$signed({1'b0,velocity_gain});
   // Conservative 1/8 peak gain (-18.06 dB), symmetric nearest rounding.
   if(rounded>50'sd8388607)pcm_reg<=24'sh7fffff;
   else if(rounded< -50'sd8388608)pcm_reg<=24'sh800000;
   else pcm_reg<=rounded[23:0];
  end
 end
 assign pcm=pcm_reg;
endmodule
`default_nettype wire
