# Numerical source notices

MARIMBA integration (2026-10-19) decodes user-supplied ROM1A slot22 directly.
It reuses the existing EP parameter compiler and integer datapath; no new
audio model or fitted recording is introduced. Algorithm7 routing was checked
against read-only `src_msfa_orig/fm_core.cc` (Copyright 2012 Google Inc., Apache
License 2.0) in the existing DX7_CELESTA reference cache. Its exact source hash,
packed preset hash and source-bank hash are recorded in `assets/marimba/config.json`
at the workspace root. Existing EP numerical limitations continue to apply.
Verification-only Python fixtures reuse the existing read-only EP oracle with
algorithm7 bus wiring selected; production never consumes those fixtures.

The Celesta integer path implements the supplied mathematical release
`celesta-math-v3-20261017`, which follows Dexed's Mark I engine and msfa.
Reference originals remain under
`F:/generation_FPGA_audiosynth_models_ds/DX7_CELESTA/src_dexed/` and
`src_msfa_orig/`. The existing EP notices are in `assets/dx7/NOTICE.md`.

Preserved notice from `src_dexed/source_engine_EngineMkI.cpp`:

Copyright (C) 2015-2017 Pascal Gauthier.

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software Foundation,
Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.

The code is based on ppplay https://github.com/stohrendorf/ppplay and opl3
math documentation:
https://github.com/gtaylormb/opl3_fpga/blob/master/docs/opl3math/opl3math.pdf

Preserved msfa envelope notice:

Copyright 2012 Google Inc.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
