`default_nettype none
// Built-in MIDI pattern generator. Only runs when no external MIDI has been
// seen for the idle threshold, so it never competes with a real controller or
// the PC application. It drives the same event path, therefore its notes reach
// the synth, the DAC and the ESP32 MIDI uplink alike.
module bt_midi_autoplay #(
 parameter integer HOLD_CYCLES=12500000,
 parameter integer GAP_CYCLES=12500000
)(
 input wire clk,rst_n,
 input wire idle,
 input wire accept,
 output reg valid,output reg [39:0] data
);
 localparam [6:0] N0=7'd72,N1=7'd76,N2=7'd79,N3=7'd84;
 reg [1:0] step;
 reg [31:0] timer;
 reg [3:0] index;
 reg [6:0] note;
 always @(*)begin
  case(index[1:0])
   2'd0:note=N0;
   2'd1:note=N1;
   2'd2:note=N2;
   default:note=N3;
  endcase
 end
 always @(posedge clk)begin
  if(!rst_n)begin
   step<=2'd0;timer<=32'd0;index<=4'd0;valid<=0;data<=40'd0;
  end else begin
   valid<=0;
   case(step)
    2'd0:if(idle && accept)begin
     valid<=1;data<={4'd0,4'h9,4'd2,4'd0,note,7'd100,2'd3,8'h90};
     step<=2'd1;timer<=32'd0;
    end
    2'd1:begin
     timer<=timer+1'b1;
     if((!idle || timer>=HOLD_CYCLES) && accept)begin
      valid<=1;data<={4'd0,4'h8,4'd1,4'd0,note,7'd0,2'd3,8'h80};
      step<=2'd2;timer<=32'd0;
     end
    end
    default:if(timer>=GAP_CYCLES)begin
     step<=2'd0;timer<=32'd0;index<=index+1'b1;
    end else timer<=timer+1'b1;
   endcase
  end
 end
endmodule
`default_nettype wire
