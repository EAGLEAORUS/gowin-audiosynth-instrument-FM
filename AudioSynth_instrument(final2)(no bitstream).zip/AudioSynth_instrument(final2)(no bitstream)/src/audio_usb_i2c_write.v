`default_nettype none
module audio_usb_i2c_write (
    input wire clk_50m, input wire ce, //   // I2C control clock, ~417 kHz
    input  wire        rstn,
    output wire        ack,         // OR of the three slave acknowledge bits
    input  wire [23:0] i2c_data,    // {device addr[7:0], reg addr[7:0], data[7:0]}
    input  wire        start,
    output reg         tr_end,      // one-cycle transfer-complete flag
    output wire        i2c_sclk,
    inout  wire        i2c_sdat
);

    (* syn_preserve=1 *) reg sda_meta=1,sda_sync=1;
    always @(posedge clk_50m)begin sda_meta<=i2c_sdat;sda_sync<=sda_meta;end
    reg [6:0] cyc_count;
    reg        reg_sdat;
    reg        sclk;
    reg        ack1, ack2, ack3;
    reg        clock_i2c_test;

    assign ack = ack1 | ack2 | ack3;

    // SCL is held high outside the transfer window, otherwise it follows the
    // divided control clock so that a full bit period spans two ticks.
    assign i2c_sclk = sclk | (((cyc_count >= 7'd8) && (cyc_count <= 7'd117)) ? clock_i2c_test : 1'b0);

    // open-drain SDA: drive low, release (high-Z) for a logic one
    assign i2c_sdat = reg_sdat ? 1'bz : 1'b0;

//------------------------------------------------------------------------------
// Bit counter: 0 while idle, counts up to 127 during a transfer
//------------------------------------------------------------------------------
    always @(posedge clk_50m) begin
      if (ce) begin
        if (!rstn)
            cyc_count <= 7'b111_1111;
        else begin
            if (start == 1'b0)
                cyc_count <= 7'd0;
            else if (cyc_count < 7'b111_1111)
                cyc_count <= cyc_count + 1'b1;
        end
      end
    end

//------------------------------------------------------------------------------
// SCL source: toggles every other tick so each bit lasts two ticks
//------------------------------------------------------------------------------
    always @(posedge clk_50m) begin
      if (ce) begin
        if (!rstn || cyc_count == 7'd0)
            clock_i2c_test <= 1'b0;
        else if ((cyc_count > 7'd0) && (cyc_count[0] == 1'b0))
            clock_i2c_test <= ~clock_i2c_test;
      end
    end

//------------------------------------------------------------------------------
// Transfer state machine
//------------------------------------------------------------------------------
    always @(posedge clk_50m) begin
      if (ce) begin
        if (!rstn) begin
            tr_end   <= 1'b0;
            ack1     <= 1'b1;
            ack2     <= 1'b1;
            ack3     <= 1'b1;
            sclk     <= 1'b1;
            reg_sdat <= 1'b1;
        end
        else begin
            case (cyc_count)
                7'd0  : begin ack1 <= 1'b1; ack2 <= 1'b1; ack3 <= 1'b1;
                              tr_end <= 1'b0; sclk <= 1'b1; reg_sdat <= 1'b1; end
                7'd4  : reg_sdat <= 1'b0;                  // START
                7'd8  : sclk     <= 1'b0;
                7'd9  : reg_sdat <= i2c_data[23];          // device address
                7'd13 : reg_sdat <= i2c_data[22];
                7'd17 : reg_sdat <= i2c_data[21];
                7'd21 : reg_sdat <= i2c_data[20];
                7'd25 : reg_sdat <= i2c_data[19];
                7'd29 : reg_sdat <= i2c_data[18];
                7'd33 : reg_sdat <= i2c_data[17];
                7'd37 : reg_sdat <= i2c_data[16];
                7'd41 : reg_sdat <= 1'b1;                  // ACK slot
                7'd43 : ack1 <= sda_sync;                  // sample ACK while SCL is HIGH
                7'd45 : reg_sdat <= i2c_data[15];          // next byte, first bit
                7'd49 : reg_sdat <= i2c_data[14];          // register address
                7'd53 : reg_sdat <= i2c_data[13];
                7'd57 : reg_sdat <= i2c_data[12];
                7'd61 : reg_sdat <= i2c_data[11];
                7'd65 : reg_sdat <= i2c_data[10];
                7'd69 : reg_sdat <= i2c_data[9];
                7'd73 : reg_sdat <= i2c_data[8];
                7'd77 : reg_sdat <= 1'b1;                  // ACK slot
                7'd79 : ack2 <= sda_sync;                  // sample ACK while SCL is HIGH
                7'd81 : reg_sdat <= i2c_data[7];           // register data
                7'd85 : reg_sdat <= i2c_data[6];
                7'd89 : reg_sdat <= i2c_data[5];
                7'd93 : reg_sdat <= i2c_data[4];
                7'd97 : reg_sdat <= i2c_data[3];
                7'd101: reg_sdat <= i2c_data[2];
                7'd105: reg_sdat <= i2c_data[1];
                7'd109: reg_sdat <= i2c_data[0];
                7'd113: reg_sdat <= 1'b1;                  // ACK slot
                7'd115: ack3 <= sda_sync;                  // sample ACK while SCL is HIGH
                7'd117: begin sclk <= 1'b0; reg_sdat <= 1'b0; end
                7'd121: sclk     <= 1'b1;                  // STOP
                7'd125: begin reg_sdat <= 1'b1; tr_end <= 1'b1; end
                default: ;                                 // hold
            endcase
        end
      end
    end

endmodule

`default_nettype wire
