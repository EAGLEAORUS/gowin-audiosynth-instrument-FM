`default_nettype none
module audio_usb_loop24 #(parameter SYNTH_ENABLE=0, parameter integer VOICE_COUNT=1)(
 input wire clk_50m,output wire es0_mclk,es1_mclk,
 output wire es7243_scl,inout wire es7243_sda,
 output wire es8156_scl,inout wire es8156_sda,
 input wire es0_dsclk,es0_alrck,es0_sdin,es1_dsclk,es1_dlrc,
 output wire es1_sdout,lin_led,
 input wire midi_evt_valid,input wire [39:0] midi_evt_data,
 input wire midi_online,midi_fault,midi_core_rst_n,
 output wire ws2812
);
 reg [15:0] por=0;
 always @(posedge clk_50m)if(!(&por))por<=por+1'b1;
 wire mclk,locked,core_rst_n;
 audio_usb_pll125 clock_audio(mclk,locked,clk_50m,!(&por));
 assign es0_mclk=mclk;assign es1_mclk=mclk;
 audio_usb_reset reset_core(clk_50m,(&por)&&locked,core_rst_n);
 // 0x50000 MCLK cycles = 1,310,720 core cycles = 26.2144 ms.
 reg [20:0] startup=0;
 always @(posedge clk_50m)if(!core_rst_n)startup<=0;
 else if(startup!=21'd1310720)startup<=startup+1'b1;
 wire config_rst_n=core_rst_n && startup==21'd1310720;
 reg [7:0] ce_count=0;
 wire ce=ce_count==8'd247;
 always @(posedge clk_50m)if(ce)ce_count<=0;else ce_count<=ce_count+1'b1;
 wire adc_done,dac_done,adc_ack,dac_ack;
 (* syn_keep=1 *) wire adc_healthy,dac_healthy;
 wire adc_retry,dac_retry;
 wire adc_config_rst_n=config_rst_n && !adc_retry;
 wire dac_config_rst_n=config_rst_n && !dac_retry;
 audio_usb_codec_health adc_health(clk_50m,config_rst_n,adc_done,es0_dsclk,es0_alrck,adc_healthy,adc_retry);
 audio_usb_codec_health dac_health(clk_50m,config_rst_n,dac_done,es1_dsclk,es1_dlrc,dac_healthy,dac_retry);
 audio_usb_es7243e_config adc_config(clk_50m,ce,adc_config_rst_n,es7243_scl,es7243_sda,adc_done,adc_ack);
 audio_usb_es8156_config dac_config(.clk_50m(clk_50m),.ce(ce),.rstn(dac_config_rst_n),
  .i2c_sclk(es8156_scl),.i2c_sdat(es8156_sda),.reg_conf_done(dac_done),.i2c_ack(dac_ack),
  .volume_code(8'hbd),.mute_request(1'b0));
 // DAC/DDS startup never waits for ADC configuration or ADC clock activity.
 wire audio_ready=dac_config_rst_n && dac_done;
 wire frame_ready=audio_ready && adc_config_rst_n && adc_done && adc_healthy;
 audio_usb_ws2812_status rgb_status(clk_50m,(&por),dac_healthy,adc_healthy,ws2812);
 audio_usb_status_led status_led(clk_50m,core_rst_n,(dac_healthy && adc_healthy),lin_led);
 wire rx_rst_n,tx_rst_n,frame_rd_rst_n;
 audio_usb_reset reset_rx(es0_dsclk,frame_ready,rx_rst_n);
 audio_usb_reset reset_tx(es1_dsclk,audio_ready,tx_rst_n);
 audio_usb_reset reset_frame_rd(es1_dsclk,frame_ready,frame_rd_rst_n);
 wire frame_valid,fifo_ready,out_valid,out_ready;
 wire signed [23:0] pcm_l,pcm_r;
 wire [47:0] out_frame;
 (* syn_keep=1 *) wire [31:0] overflow,underrun,frame_errors;
 audio_usb_i2s_rx24 rx(es0_dsclk,rx_rst_n,es0_alrck,es0_sdin,frame_valid,pcm_l,pcm_r,frame_errors);
 // Reuse the proven whole-record Gray FIFO without changing USB production RTL.
 usb_packet_async_fifo #(.WIDTH(48),.ADDR_BITS(3)) frame_fifo(
  es0_dsclk,rx_rst_n,frame_valid,{pcm_l,pcm_r},fifo_ready,overflow,
  es1_dsclk,frame_rd_rst_n,out_valid,out_frame,out_ready);
 wire tx_ready;
 // Keep ADC CDC draining even in synth mode, making loopback rollback explicit.
 assign out_ready=tx_ready;
 generate if(SYNTH_ENABLE)begin:synth
  wire voice_rst_n,ev,online;
  wire [39:0] event_word;
  (* syn_keep=1 *) wire [31:0] event_overflow,accepted_events;
  (* syn_keep=1 *) wire fault,gate;
  (* syn_keep=1 *) wire [6:0] active_note;
  (* syn_keep=1 *) wire [15:0] envelope;
  (* syn_keep=1 *) wire [2:0] env_state;
  wire signed [23:0] pcm;
  synth_midi_cdc bridge(clk_50m,audio_ready && midi_core_rst_n,midi_evt_valid,midi_evt_data,
   midi_online,midi_fault,es1_dsclk,voice_rst_n,ev,event_word,online,event_overflow,fault);
  if(VOICE_COUNT==1)begin:mono_path
   // Exact legacy algorithm remains selectable for hardware regression.
   voice_core voice(es1_dsclk,voice_rst_n,tx_ready,ev,event_word,online,pcm,
    envelope,env_state,active_note,gate,accepted_events);
  end else begin:poly_path
   wire [3:0] busy,gates,releasing;
   wire [27:0] notes;wire [63:0] envelopes;wire [11:0] states;
   wire [95:0] samples;wire [127:0] phases,increments;
   (* syn_keep=1 *) wire [31:0] steals,retriggers,clips;
   poly_synth_engine engine(es1_dsclk,voice_rst_n,tx_ready,ev,event_word,online,
    1'b0,2'd0,32'd0,pcm,busy,gates,releasing,notes,envelopes,states,
    samples,phases,increments,accepted_events,steals,retriggers,clips);
   assign gate=|gates;
   // Compatibility telemetry: voice 0 envelope/note, aggregate gate/event count.
   assign envelope=envelopes[15:0];assign env_state=states[2:0];assign active_note=notes[6:0];
  end
  // The unmodified transmitter captures settled PCM from the preceding frame.
  audio_usb_i2s_tx24 tx(es1_dsclk,tx_rst_n,es1_dlrc,1'b1,{pcm,pcm},tx_ready,es1_sdout,underrun);
 end else begin:loopback
  audio_usb_i2s_tx24 tx(es1_dsclk,tx_rst_n,es1_dlrc,(out_valid && frame_rd_rst_n),out_frame,tx_ready,es1_sdout,underrun);
 end endgenerate
endmodule
`default_nettype wire

// Keep the small status module in this already-compiled source unit so
// existing open Gowin projects cannot miss a newly added source file.
`default_nettype none
// D3: active-high LED_TEST/P19. Reference normal pattern: four 100ms
// flashes at 250ms intervals, repeated every 2 seconds (eight slots).
// Configuration pending is solid on, as in the original voice_loop.
module audio_usb_status_led #(parameter integer CLK_HZ=50000000)(
 input wire clk,rst_n,config_ok,output wire led
);
 localparam integer SLOT_CYCLES=CLK_HZ/4;
 localparam integer ON_CYCLES=CLK_HZ/10;
 reg [23:0] slot_count;
 reg [2:0] slot_index;
 always @(posedge clk)begin
  if(!rst_n || !config_ok)begin slot_count<=24'd0;slot_index<=3'd0;end
  else if(slot_count==SLOT_CYCLES-1)begin
   slot_count<=24'd0;slot_index<=slot_index+3'd1;
  end else slot_count<=slot_count+24'd1;
 end
 assign led=rst_n && (!config_ok || ((slot_index<3'd4) && (slot_count<ON_CYCLES)));
endmodule
`default_nettype wire
