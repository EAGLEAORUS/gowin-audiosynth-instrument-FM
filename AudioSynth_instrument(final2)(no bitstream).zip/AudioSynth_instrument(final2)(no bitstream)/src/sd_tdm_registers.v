`default_nettype none
// Control-register slice at0x200..0x22c in the existing AE350 APB aperture.
// Parent supplies one write pulse per completed APB transaction. All50MHz.
// Payload is immutable from START until response ACK; no duplicate wide queue.
module sd_tdm_registers(input wire clk,rst_n,enabled,write,
 input wire[11:0] address,input wire[31:0] write_data,output reg[31:0] read_data,
 input wire allocation_valid,input wire[5:0] allocation_slot,input wire[31:0] allocation_token,input wire[31:0] faults,
 output wire config_valid,input wire config_ready,output wire[2:0] config_kind,
 output wire[5:0] config_slot,output wire[31:0] config_token,output wire[2:0] config_op,
 output wire[107:0] config_data,output wire[7:0] config_meta,
 input wire response_valid,response_ok,input wire[31:0] response_token);
 reg[107:0] stage;reg[31:0] descriptor,token;
 reg pending,inflight,have_response,ok,protocol_error;reg[31:0] reply_token;
 wire lease_match=allocation_valid && token==allocation_token && descriptor[5:0]==allocation_slot;
 // A complete note fits in 25 words: 6 x 4 operator words and one meta word.
 // CPU fills this buffer, then the existing checked port publishes each
 // operator and commits the note. The CPU observes only the final response.
 reg [31:0] batch_ram[0:31];
 reg [31:0] batch_word;
 reg [4:0] batch_written,batch_read;
 reg [2:0] batch_item;
 reg batch_active,batch_fetch,batch_wait;
 wire idle=!pending && !inflight && !have_response;
 wire writable=idle && !batch_active;
 always @(posedge clk)begin
  if(write && enabled && writable && address==12'h250 && batch_written<25)
   batch_ram[batch_written]<=write_data;
  batch_word<=batch_ram[batch_read];
 end
 assign config_valid=pending && lease_match && enabled;
 assign config_kind=batch_active?(batch_item<6?3'd1:batch_item==6?3'd2:3'd3):descriptor[11:9];
 assign config_slot=descriptor[5:0];assign config_op=batch_active?batch_item:descriptor[8:6];
 assign config_meta=descriptor[23:16];assign config_data=stage;assign config_token=token;
 always @*begin
  read_data=0;
  case(address)
   12'h200:read_data={10'd0,allocation_slot,10'd0,enabled,protocol_error,allocation_valid,ok,have_response,(writable && config_ready && enabled)};
   12'h204:read_data=allocation_token;
   12'h208:read_data=token;12'h20c:read_data=descriptor;
   12'h210:read_data=stage[31:0];12'h214:read_data=stage[63:32];12'h218:read_data=stage[95:64];12'h21c:read_data={20'd0,stage[107:96]};
   12'h228:read_data=reply_token;12'h22c:read_data=faults;
   12'h258:read_data=32'h42544331;
   default:read_data=0;
  endcase
 end
 always @(posedge clk)begin
  if(!rst_n)begin batch_active<=0;batch_fetch<=0;batch_wait<=0;batch_written<=0;batch_read<=0;batch_item<=0;stage<=0;descriptor<=0;token<=0;pending<=0;inflight<=0;have_response<=0;ok<=0;protocol_error<=0;reply_token<=0;end
  else if(!enabled)begin batch_active<=0;batch_fetch<=0;batch_wait<=0;batch_written<=0;pending<=0;inflight<=0;have_response<=0;ok<=0;protocol_error<=0;end
  else begin
   if(pending && !lease_match)begin pending<=0;have_response<=1;ok<=0;reply_token<=token;batch_active<=0;end
   else if(config_valid && config_ready)begin pending<=0;inflight<=1;end
   if(response_valid && inflight)begin
    inflight<=0;
    if(batch_active && response_ok && response_token==token && batch_item!=7)begin
     batch_item<=batch_item+1'b1;
     if(batch_item==6)pending<=1;
     else begin batch_read<=batch_read+1'b1;batch_wait<=1;batch_fetch<=1;end
    end else begin
     have_response<=1;ok<=response_ok && (!batch_active || response_token==token);
     reply_token<=response_token;batch_active<=0;
    end
   end
   if(batch_fetch)begin
    if(batch_wait)batch_wait<=0;
    else if(batch_item==6)begin
     stage<={76'd0,batch_word};batch_fetch<=0;pending<=1;
    end else begin
     case(batch_read[1:0])
      0:stage[31:0]<=batch_word;
      1:stage[63:32]<=batch_word;
      2:stage[95:64]<=batch_word;
      3:stage[107:96]<=batch_word[11:0];
     endcase
     if(batch_read[1:0]==3)begin batch_fetch<=0;pending<=1;end
     else begin batch_read<=batch_read+1'b1;batch_wait<=1;end
    end
   end
   if(write)begin
    if(address==12'h224)begin if(write_data[0])have_response<=0;if(write_data[1])protocol_error<=0;end
    else if(address==12'h250)begin
     if(writable && batch_written<25)batch_written<=batch_written+1'b1;
     else protocol_error<=1;
    end else if(address==12'h254)begin
     if(!writable)protocol_error<=1;
     else if(write_data[1])batch_written<=0;
     else if(write_data[0])begin
      batch_written<=0;
      if(batch_written!=25 || !lease_match)begin have_response<=1;ok<=0;reply_token<=token;end
      else begin batch_active<=1;batch_item<=0;batch_read<=0;batch_wait<=1;batch_fetch<=1;ok<=0;end
     end
    end else if(address>=12'h208 && address<=12'h220)begin
     if(!writable)protocol_error<=1;
     else case(address)
      12'h208:token<=write_data;12'h20c:descriptor<=write_data;
      12'h210:stage[31:0]<=write_data;12'h214:stage[63:32]<=write_data;12'h218:stage[95:64]<=write_data;12'h21c:stage[107:96]<=write_data[11:0];
      12'h220:if(write_data[0])begin pending<=1;ok<=0;end
      default:begin end
     endcase
    end
   end
  end
 end
endmodule
`default_nettype wire
