`default_nettype none
// Explicit registered output, BSRAM-friendly. Capacity includes the output word.
module usb3_buffered_fifo #(parameter W=88,A=9,STYLE="block_ram")(
 input wire clk,rst_n,push,input wire [W-1:0] din,output wire ready,
 output reg valid,output reg [W-1:0] dout,input wire pop,output wire [A:0] level);
 (* syn_ramstyle=STYLE *) reg [W-1:0] mem[0:(1<<A)-1];reg [A-1:0] wp,rp;reg [A:0] stored;
 wire load=(!valid || pop) && stored!=0;
 assign level=stored+valid;
 assign ready=level<(1<<A);
 always @(posedge clk)begin
  if(push && ready)mem[wp]<=din;
  if(!rst_n)begin wp<=0;rp<=0;stored<=0;valid<=0;dout<=0;end
  else begin
   if(push && ready)wp<=wp+1'b1;
   if(load)begin dout<=mem[rp];rp<=rp+1'b1;valid<=1;end
   else if(pop)valid<=0;
   case({push && ready,load})2'b10:stored<=stored+1'b1;2'b01:stored<=stored-1'b1;default:begin end endcase
  end
 end
endmodule
`default_nettype wire
