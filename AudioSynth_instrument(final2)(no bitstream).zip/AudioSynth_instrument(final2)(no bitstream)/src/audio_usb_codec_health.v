`default_nettype none
// Status-only observation of single-bit codec clocks into the 50 MHz domain.
// No PCM or MIDI payload is transferred through these synchronizers.
module audio_usb_codec_health #(
 parameter integer FRAME_MIN=900, FRAME_MAX=1150,
 parameter integer BCLK_TIMEOUT=250, FRAME_TIMEOUT=5000,
 parameter integer CONFIG_GRACE=250000, RETRY_CYCLES=2048
)(input wire clk,rst_n,configured,bclk,ws,
 output wire healthy,output reg retry_reset);
 (* syn_preserve=1 *) reg bclk_meta,bclk_sync,ws_meta,ws_sync;
 reg bclk_old,ws_old,seen_frame;
 reg [15:0] bit_age,frame_age,bit_edges;
 reg [1:0] good_frames;
 reg [31:0] grace_count,retry_count;
 reg had_good;
 wire b_rise=bclk_sync && !bclk_old;
 wire w_rise=ws_sync && !ws_old;
 // LRCK rising-to-rising is one stereo frame; 64 BCLK periods are expected.
 wire frame_good=seen_frame && frame_age>=FRAME_MIN && frame_age<=FRAME_MAX &&
  bit_edges>=16'd63 && bit_edges<=16'd65;
 wire clock_good=good_frames==3 && bit_age<BCLK_TIMEOUT && frame_age<FRAME_TIMEOUT;
 assign healthy=rst_n && configured && clock_good && !retry_reset;
 always @(posedge clk)begin
  if(!rst_n)begin
   bclk_meta<=0;bclk_sync<=0;ws_meta<=0;ws_sync<=0;bclk_old<=0;ws_old<=0;
   seen_frame<=0;bit_age<=0;frame_age<=0;bit_edges<=0;good_frames<=0;
  end else begin
   bclk_meta<=bclk;bclk_sync<=bclk_meta;ws_meta<=ws;ws_sync<=ws_meta;
   bclk_old<=bclk_sync;ws_old<=ws_sync;
   if(b_rise)bit_age<=0;else if(bit_age<BCLK_TIMEOUT)bit_age<=bit_age+16'd1;
   if(frame_age<FRAME_TIMEOUT)frame_age<=frame_age+16'd1;
   if(b_rise && bit_edges<16'd1023)bit_edges<=bit_edges+16'd1;
   if(w_rise)begin
    seen_frame<=1;frame_age<=0;bit_edges<=0;
    if(frame_good)begin if(good_frames!=3)good_frames<=good_frames+2'd1;end
    else good_frames<=0;
   end else if(bit_age>=BCLK_TIMEOUT || frame_age>=FRAME_TIMEOUT)good_frames<=0;
  end
 end
 // Existing configuration engines remain intact. Reset only the failed side
 // to retry its full table after disconnect / missing clocks. Hold >=2 CE ticks.
 always @(posedge clk)begin
  if(!rst_n)begin retry_reset<=0;retry_count<=0;grace_count<=0;had_good<=0;end
  else if(retry_reset)begin
   if(retry_count==RETRY_CYCLES-1)begin retry_reset<=0;retry_count<=0;end
   else retry_count<=retry_count+32'd1;
   grace_count<=0;had_good<=0;
  end else if(!configured)begin grace_count<=0;had_good<=0;end
  else if(clock_good)begin grace_count<=0;had_good<=1;end
  else if(had_good || grace_count==CONFIG_GRACE-1)begin
   retry_reset<=1;retry_count<=0;grace_count<=0;had_good<=0;
  end else grace_count<=grace_count+32'd1;
 end
endmodule
`default_nettype wire
