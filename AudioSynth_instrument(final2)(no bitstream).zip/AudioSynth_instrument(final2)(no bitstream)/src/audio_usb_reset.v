`default_nettype none
// Async assertion only at stage 1; stage 2 and all consumers release in-domain.
module audio_usb_reset #(parameter RELEASE_FALLING=0)(input wire clk, input wire ready, output wire rst_n);
 (* syn_preserve=1 *) reg meta=0;
 (* syn_preserve=1 *) reg sync=0;
 always @(posedge clk or negedge ready) if(!ready) meta<=0; else meta<=1;
 generate if(RELEASE_FALLING)begin:opposite_edge
  // Keep release away from the active edge of the ADC FIFO and counters.
  always @(negedge clk) sync<=meta;
 end else begin:same_edge
  always @(posedge clk) sync<=meta;
 end endgenerate
 assign rst_n=sync;
endmodule
`default_nettype wire
