`default_nettype none
// Algorithm 5 only. One shared multi-cycle datapath, 24 independent OP states.
// State arrays are deliberately registers: one indexed read/write, no ambiguous
// BRAM read-during-write behavior. ROM pairs use one synchronous read port each.
// MIX_SHIFT=2: supplied solo /8; production four-voice MIX_SHIFT=4: fixed /32.
module FM6_core4 #(parameter integer MIX_SHIFT=4,parameter integer PITCH_ENABLE=0)(
 input wire clk,rst_n,sample_tick,input wire [3:0] note_on,note_off,
 input wire [6:0] note,velocity,
 output reg signed [23:0] pcm,output reg pcm_valid,
 output reg [3:0] busy,gate,output wire [3:0] releasing,
 output reg [31:0] deadline_miss,clip_count,range_errors,
 output reg [15:0] last_cycles,output reg [111:0] voice_raw,output wire idle,
 input wire [23:0] pitch_ratio
);
 reg [5:0] state;
 assign idle=state==0;
 reg [1:0] v;reg [2:0] op;
 wire [4:0] ix=({3'd0,v}<<2)+({3'd0,v}<<1)+{2'd0,op};
 reg [3:0] pending_on,pending_off,start_on,down;
 reg [6:0] pending_note[0:3],pending_vel[0:3],run_note[0:3],run_vel[0:3];
 reg [5:0] block_pos[0:3];reg [3:0] run_off;
 reg [31:0] phase[0:23],fcw[0:23];
 // Base FCW includes the factory ratio/detune. Bend changes only its step;
 // one ratio snapshot serves every OP/voice in the current audio frame.
 reg [23:0] frame_ratio;
 // Radix-8 shift/add avoids Gowin's multi-DSP wide-product packing. Eight
 // registered iterations, shared by all 24 OPs; no truncated DSP cascade.
 reg [55:0] pitch_one,pitch_three,pitch_five,pitch_seven,pitch_product;
 reg [23:0] pitch_digits;
 reg [2:0] pitch_digit_index;
 reg [32:0] pitch_rounded;
 reg pitch_overflow;
 reg [55:0] pitch_term;
 reg [31:0] pitch_step;
 always @*case(pitch_digits[2:0])
  0:pitch_term=0;1:pitch_term=pitch_one;2:pitch_term=pitch_one<<1;
  3:pitch_term=pitch_three;4:pitch_term=pitch_one<<2;
  5:pitch_term=pitch_five;6:pitch_term=pitch_three<<1;default:pitch_term=pitch_seven;
 endcase
 reg signed [31:0] level[0:23],target0[0:23],target1[0:23];
 reg [31:0] inc0[0:23],inc1[0:23],inc2[0:23],inc3[0:23];
 reg [2:0] stage[0:23];
 reg [23:0] endpoint[0:23];reg signed [31:0] current_gain[0:23],delta_gain[0:23];
 reg silent_block[0:23];
 reg signed [25:0] fb0[0:3],fb1[0:3];
 reg signed [25:0] branch;
 reg signed [32:0] mix;reg signed [27:0] raw;
 reg [15:0] cycles;
 assign releasing=busy & ~gate;
 wire [172:0] config_q;
 FM6_config_rom config_rom(clk,{run_note[v],op},config_q);
 wire [7:0] vel_value;
 FM6_velocity_lut velocity_rom(run_vel[v][6:1],vel_value);
 reg signed [15:0] velocity_adjust;
 reg signed [31:0] outlevel;
 reg [3:0] sensitivity;
 always @* case(op)
  0,2:sensitivity=6;4:sensitivity=7;3,5:sensitivity=2;default:sensitivity=0;
 endcase
 reg signed [31:0] eg_target,eg_base;
 reg [31:0] eg_inc;
 reg [2:0] eg_stage;
 reg signed [39:0] eg_product;
 reg signed [40:0] eg_candidate;
 reg signed [31:0] eg_next;
 reg [2:0] stage_next;
 reg signed [5:0] eg_factor;
 wire [47:0] exp_q;
 FM6_exp_pairs exp_rom(clk,eg_next[23:14],exp_q);
 // exp2[i+1]-exp2[i] is positive and <=5677 in this immutable ROM.
 // Register the 13-bit difference before multiplication. In Gowin 1.9.12.03
 // the former (upper-lower)*fraction expression mapped to a DSP subtract/
 // multiply with a spurious bit24 carry, despite matching in RTL simulation.
 reg [12:0] exp_diff;
 reg [26:0] exp_product;
 reg [24:0] mantissa;
 reg [23:0] new_gain;
 reg signed [31:0] dg;
 reg [31:0] pm;
 wire [35:0] sine_q;
 FM6_sine_pairs sine_rom(clk,pm[31:20],sine_q);
 reg signed [18:0] sine_diff;
 reg signed [39:0] sine_product;
 reg signed [18:0] wave;
 reg signed [24:0] op_gain;
 reg signed [43:0] op_product;
 reg signed [25:0] result;
 reg signed [26:0] feedback_sum;
 reg signed [32:0] scaled_mix;
 integer i;
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=0;v<=0;op<=0;pcm<=0;pcm_valid<=0;busy<=0;gate<=0;down<=0;
   pending_on<=0;pending_off<=0;start_on<=0;run_off<=0;
   frame_ratio<=24'd4194304;pitch_one<=0;pitch_three<=0;pitch_five<=0;pitch_seven<=0;
   pitch_product<=0;pitch_digits<=0;pitch_digit_index<=0;pitch_rounded<=0;pitch_overflow<=0;pitch_step<=0;
   deadline_miss<=0;clip_count<=0;range_errors<=0;cycles<=0;last_cycles<=0;voice_raw<=0;mix<=0;raw<=0;branch<=0;
   for(i=0;i<4;i=i+1)begin block_pos[i]<=0;pending_note[i]<=0;pending_vel[i]<=0;run_note[i]<=0;run_vel[i]<=0;fb0[i]<=0;fb1[i]<=0;end
   for(i=0;i<24;i=i+1)begin
    phase[i]<=0;fcw[i]<=0;level[i]<=0;stage[i]<=0;endpoint[i]<=0;current_gain[i]<=0;delta_gain[i]<=0;silent_block[i]<=1;
    target0[i]<=0;target1[i]<=0;inc0[i]<=0;inc1[i]<=0;inc2[i]<=0;inc3[i]<=0;
   end
  end else begin
   pcm_valid<=0;
   if(state!=0)cycles<=cycles+1'b1;
   if(sample_tick && state!=0)deadline_miss<=deadline_miss+1'b1;
   case(state)
    0:if(sample_tick)begin
     frame_ratio<=pitch_ratio;
     start_on<=pending_on;run_off<=pending_off;pending_on<=0;pending_off<=0;
     for(i=0;i<4;i=i+1)begin
      if(pending_on[i])begin
       run_note[i]<=pending_note[i];run_vel[i]<=pending_vel[i];block_pos[i]<=0;fb0[i]<=0;fb1[i]<=0;down[i]<=!pending_off[i];
      end
     end
     v<=0;op<=0;mix<=0;raw<=0;cycles<=0;state<=1;
    end
    1:begin // Voice boundary: only local block boundary applies queued Note Off.
     if(!busy[v] && !start_on[v])begin
      voice_raw[v*28+:28]<=0;
      if(v==3)state<=30;else begin v<=v+1'b1;state<=1;end
     end else begin
      if(run_off[v])down[v]<=0;
      raw<=0;op<=0;state<=2;
     end
    end
    2:state<=3; // Configuration ROM read (synchronous).
    3:if(start_on[v])begin
     velocity_adjust<=($signed({1'b0,sensitivity})*($signed({1'b0,vel_value})-16'sd239)+16'sd7)>>>3;
     state<=4;
    end else state<=PITCH_ENABLE?33:6;
    4:begin
     outlevel<=$signed({1'b0,config_q[172:160]})+($signed(velocity_adjust)<<<4);
     fcw[ix]<=config_q[31:0];inc3[ix]<=config_q[63:32];inc2[ix]<=config_q[95:64];inc1[ix]<=config_q[127:96];inc0[ix]<=config_q[159:128];
     phase[ix]<=0;level[ix]<=0;stage[ix]<=0;endpoint[ix]<=0;current_gain[ix]<=0;delta_gain[ix]<=0;silent_block[ix]<=1;
     state<=5;
    end
    5:begin
     // This patch's L1=99, L2=95 (OP2/1=75), L3=L4=0.
     target0[ix]<=((outlevel<0?32'sd0:outlevel)-32'sd224)<<<16;
     target1[ix]<=((outlevel<0?32'sd0:outlevel)-(op>=4?32'sd992:32'sd352))<<<16;
     // Clamp the logarithmic floor, including very soft velocity settings.
     if(outlevel-32'sd224<16)target0[ix]<=32'sd1048576;
     if(outlevel-(op>=4?32'sd992:32'sd352)<16)target1[ix]<=32'sd1048576;
     state<=PITCH_ENABLE?33:6;
    end
    33:begin
     if(frame_ratio==24'd4194304)begin pitch_step<=fcw[ix];state<=6;end
     else begin
      pitch_one<={24'd0,fcw[ix]};
      pitch_three<=({24'd0,fcw[ix]}<<1)+{24'd0,fcw[ix]};
      pitch_five<=({24'd0,fcw[ix]}<<2)+{24'd0,fcw[ix]};
      pitch_seven<=({24'd0,fcw[ix]}<<3)-{24'd0,fcw[ix]};
      pitch_digits<=frame_ratio;pitch_product<=0;pitch_digit_index<=0;state<=34;
     end
    end
    34:begin
     pitch_product<=pitch_product+pitch_term;
     pitch_one<=pitch_one<<3;pitch_three<=pitch_three<<3;pitch_five<=pitch_five<<3;pitch_seven<=pitch_seven<<3;
     pitch_digits<=pitch_digits>>3;pitch_digit_index<=pitch_digit_index+1'b1;
     if(pitch_digit_index==7)state<=35;
    end
    35:begin
     pitch_rounded<={1'b0,pitch_product[53:22]}+{32'd0,pitch_product[21]};
     pitch_overflow<=|pitch_product[55:54];state<=37;
    end
    37:begin
     pitch_step<=pitch_overflow || pitch_rounded[32]?32'hffffffff:pitch_rounded[31:0];state<=6;
    end
    6:begin
     if(block_pos[v]==0)begin
      eg_stage<=(!down[v]?3'd3:stage[ix]);
      if(stage[ix]==4 && !start_on[v])eg_stage<=4;
      state<=7;
     end else begin
      current_gain[ix]<=current_gain[ix]+delta_gain[ix];state<=18;
     end
    end
    7:begin
     eg_base<=level[ix];eg_target<=32'sd1048576;eg_inc<=inc3[ix];
     case(eg_stage)
      0:begin eg_target<=target0[ix];eg_inc<=inc0[ix];end
      1:begin eg_target<=target1[ix];eg_inc<=inc1[ix];end
      2:begin eg_target<=32'sd1048576;eg_inc<=inc2[ix];end
      default:begin end
     endcase
     state<=8;
    end
    8:begin
     if(eg_target>eg_base && eg_base<32'sd112459776)eg_base<=32'sd112459776;
     state<=9;
    end
    9:begin eg_factor<=(32'sd285212672-eg_base)>>>24;state<=10;end
    10:begin eg_product<=eg_factor*$signed({1'b0,eg_inc});state<=11;end
    11:begin
     if(eg_target>level[ix])eg_candidate<=$signed(eg_base)+eg_product;
     else eg_candidate<=$signed(eg_base)-$signed({1'b0,eg_inc});
     state<=12;
    end
    12:begin
     eg_next<=eg_candidate[31:0];stage_next<=eg_stage;
     if(eg_stage==4)eg_next<=level[ix];
     else if((eg_target>level[ix] && eg_candidate>=eg_target) || (eg_target<=level[ix] && eg_candidate<=eg_target))begin
      eg_next<=eg_target;
      if(eg_stage<2 || eg_stage==3)stage_next<=eg_stage+1'b1;
     end
     state<=13;
    end
    13:begin level[ix]<=eg_next;stage[ix]<=stage_next;state<=14;end // exp ROM read
    14:begin exp_diff<=exp_q[47:24]-exp_q[23:0];state<=36;end
    36:begin exp_product<=exp_diff*eg_next[13:0];state<=15;end
    15:begin mantissa<={1'b0,exp_q[23:0]}+(exp_product>>14);state<=16;end
    16:begin
     if(eg_next[31:24]>=14)new_gain<=mantissa<<(eg_next[31:24]-8'd14);
     else new_gain<=mantissa>>(8'd14-eg_next[31:24]);
     state<=17;
    end
    17:begin
     dg<=($signed({1'b0,new_gain})-$signed({1'b0,endpoint[ix]})+32'sd32)>>>6;
     silent_block[ix]<=new_gain<280 && endpoint[ix]<280;state<=31;
    end
    31:begin
     delta_gain[ix]<=dg;current_gain[ix]<=$signed({1'b0,endpoint[ix]})+dg;endpoint[ix]<=new_gain;state<=18;
    end
    18:begin
     feedback_sum<=$signed({fb0[v][25],fb0[v]})+$signed({fb1[v][25],fb1[v]});state<=19;
    end
    19:begin
     if(op==0)pm<=phase[ix]+((feedback_sum>>>3)<<<10);
     else if(op[0])pm<=phase[ix]+(branch<<<10);
     else pm<=phase[ix];
     op_gain<=silent_block[ix]?25'sd0:$signed({1'b0,current_gain[ix][23:0]});
     state<=20;
    end
    20:state<=21; // sine ROM read
    21:begin sine_diff<=$signed({sine_q[35],sine_q[35:18]})-$signed({sine_q[17],sine_q[17:0]});state<=22;end
    22:begin sine_product<=sine_diff*$signed({1'b0,pm[19:0]});state<=23;end
    23:begin wave<=$signed({sine_q[17],sine_q[17:0]})+(sine_product>>>20);state<=24;end
    24:begin op_product<=wave*op_gain;state<=25;end
    25:begin
     result<=op_product>>>17;
     if((op_product>>>17)>44'sd33554431 || (op_product>>>17)<-44'sd33554432)range_errors<=range_errors+1'b1;
     state<=26;
    end
    26:begin
     phase[ix]<=phase[ix]+(PITCH_ENABLE?pitch_step:fcw[ix]);
     if(!op[0])branch<=result;
     else begin raw<=raw+$signed(result);mix<=mix+$signed(result);end
     if(op==0)begin fb0[v]<=fb1[v];fb1[v]<=result;end
     if(op==5)state<=27;else begin op<=op+1'b1;state<=2;end
    end
    27:begin
     voice_raw[v*28+:28]<=raw;block_pos[v]<=block_pos[v]+1'b1;
     // Every OP has reached R4/L4 before recycling the slot.
     if(!gate[v] && stage[ix]==4 && stage[ix-1]==4 && stage[ix-2]==4 && stage[ix-3]==4 && stage[ix-4]==4 && stage[ix-5]==4)busy[v]<=0;
     if(v==3)state<=30;else begin v<=v+1'b1;state<=1;end
    end
    30:begin scaled_mix<=mix>>>MIX_SHIFT;state<=32;end
    32:begin
     if(scaled_mix>33'sd8388607)begin pcm<=24'sh7fffff;clip_count<=clip_count+1'b1;end
     else if(scaled_mix< -33'sd8388608)begin pcm<=24'sh800000;clip_count<=clip_count+1'b1;end
     else pcm<=scaled_mix[23:0];
     pcm_valid<=1;last_cycles<=cycles;state<=0;
    end
    default:state<=0;
   endcase
   // Event capture wins a simultaneous boundary; events apply next sample.
   for(i=0;i<4;i=i+1)begin
    if(note_on[i])begin
     pending_on[i]<=1;pending_off[i]<=0;pending_note[i]<=note;pending_vel[i]<=velocity;busy[i]<=1;gate[i]<=1;
    end else if(note_off[i])begin pending_off[i]<=1;gate[i]<=0;end
   end
   // A release waits for this voice's next local block. Retain it until then.
   for(i=0;i<4;i=i+1)begin
    if(state==0 && sample_tick && pending_off[i] && !pending_on[i] && block_pos[i]!=0)pending_off[i]<=1;
   end
  end
 end
endmodule
`default_nettype wire
