`default_nettype none
// MARIMBA algorithm7 integration; algorithms5/31 keep their previous arithmetic. One shared multi-cycle datapath, 60 independent OP states; tagged EG/pitch preparation pipeline.
// 4x10: prefetch next OP during writeback; first OP at voice boundary.
// Dynamic state uses synchronous RAM, read and write on different states.
// ROM pairs use one synchronous read port each.
// MIX_SHIFT=2: supplied solo /8; production ten-voice MIX_SHIFT=4: fixed /32.
module instrument_core10 #(parameter integer VOICES=10,parameter integer MIX_SHIFT=4,parameter integer PITCH_ENABLE=0)(
 input wire clk,rst_n,sample_tick,input wire [VOICES-1:0] note_on,note_off,
 input wire [6:0] note,velocity,
 output reg signed [23:0] pcm,output reg pcm_valid,
 output reg [VOICES-1:0] busy,gate,output wire [VOICES-1:0] releasing,
 output reg [31:0] deadline_miss,clip_count,range_errors,
 output reg [15:0] last_cycles,output reg [VOICES*32-1:0] voice_raw,output wire idle,
 input wire [23:0] pitch_ratio,input wire [2:0] patch_select,output wire signed [33:0] ep_mix,cel_mix,
 input wire [23:0] flute_pitch_ratio,input wire [17:0] flute_am_pt,input wire [23:0] string_ratio
);
 localparam integer VB=$clog2(VOICES), AB=VB+3;
 reg [6:0] state;
 wire [VOICES-1:0] nes_voice;
 reg [VOICES-1:0] nes_cold;
 wire [182:0] nes_result;wire nes_done,nes_active;wire signed [15:0] nes_pcm;
 reg [VB-1:0] issue_v,read_v;reg [2:0] issue_op,read_op;
 reg read_valid;
 wire preparing=(state==50 || state==51);
 assign idle=state==0;
 reg [VB-1:0] v;reg [2:0] op;
 wire [AB-1:0] ix={v,op};
 wire [AB-1:0] read_addr=preparing?{issue_v,issue_op}:
  state==1?{v,3'd0}:(state==26 && op!=5)?{v,(op+3'd1)}:ix;
 reg [VOICES-1:0] pending_on,pending_off,start_on,down;
 reg [VOICES-1:0] initialized,cold_on;
 reg [2:0] pending_patch[0:VOICES-1],run_patch[0:VOICES-1];
 wire [VOICES-1:0] celesta_voice,marimba_voice,flute_voice,string_voice;
 genvar patch_v;
 generate for(patch_v=0;patch_v<VOICES;patch_v=patch_v+1)begin:patch_flags
  assign nes_voice[patch_v]=run_patch[patch_v]==3'd5;
  assign string_voice[patch_v]=run_patch[patch_v]==3'd4;
  assign celesta_voice[patch_v]=run_patch[patch_v]==2'd1;
  assign flute_voice[patch_v]=run_patch[patch_v]==2'd3;
  assign marimba_voice[patch_v]=run_patch[patch_v]==2'd2;
 end endgenerate
 reg [5:0] finished[0:VOICES-1];
 // 24 records, one synchronous read and one write. Uninitialized records are
 // never consumed: cold_on initializes all fields on the first note.
 reg [187:0] op_mem[0:(1<<AB)-1] /* synthesis syn_ramstyle="block_ram" */;
 reg [187:0] op_q;
 wire [182:0] nes_context=op_q[182:0];

 reg [6:0] pending_note[0:VOICES-1],pending_vel[0:VOICES-1],run_note[0:VOICES-1],run_vel[0:VOICES-1];
 reg [5:0] block_pos[0:VOICES-1];reg [VOICES-1:0] run_off;
 wire [6:0] nes_key_offset=run_note[v]-7'd48;
 nes_context_voice nes_lane(clk,rst_n,state==62,nes_cold[v],start_on[v],run_off[v],nes_context,nes_key_offset[3:0],run_vel[v],nes_result,nes_done,nes_pcm,nes_active);
 wire signed [33:0] nes_pcm_wide={{18{nes_pcm[15]}},nes_pcm};
 wire signed [33:0] nes_scaled=(nes_pcm_wide<<<7)+(nes_pcm_wide<<<5)+(nes_pcm_wide<<<4);

 reg [31:0] phase,fcw;
 // Base FCW includes the factory ratio/detune. Bend changes only its step;
 // one ratio snapshot serves every OP/voice in the current audio frame.
 reg [23:0] frame_ratio;
 // Radix-8 shift/add avoids Gowin's multi-DSP wide-product packing. Eight
 // registered iterations, shared by all 24 OPs; no truncated DSP cascade.
 reg [55:0] pitch_one,pitch_three,pitch_five,pitch_seven,pitch_product;
 reg [23:0] pitch_digits;
 reg [2:0] pitch_digit_index;
 reg [32:0] pitch_rounded;
 reg pitch_overflow;
 reg [55:0] pitch_term;
 reg [31:0] pitch_step;
 always @*case(pitch_digits[2:0])
  0:pitch_term=0;1:pitch_term=pitch_one;2:pitch_term=pitch_one<<1;
  3:pitch_term=pitch_three;4:pitch_term=pitch_one<<2;
  5:pitch_term=pitch_five;6:pitch_term=pitch_three<<1;default:pitch_term=pitch_seven;
 endcase
 reg signed [31:0] level,target0,target1;
 reg [31:0] inc0,inc1,inc2,inc3;
 reg [2:0] stage;
 reg [23:0] endpoint;reg signed [31:0] current_gain,delta_gain;
 reg silent_block;
 reg signed [27:0] fb0[0:VOICES-1],fb1[0:VOICES-1];
 reg signed [27:0] branch;
 reg signed [33:0] mix,mix_ep,mix_cel;reg signed [31:0] raw;
 // Fixed per-note output trim, Q6. Calibrated against the geometric
 // mean of the unchanged EPiano1/Celesta short-term RMS (34 RTL cases).
 // Same 64 velocity bins as FM6_velocity_lut; no audio-dependent AGC.
 function [19:0] volume_trim_q6;
  input [5:0] velocity_bin;
  begin case(velocity_bin)
   6'd0:volume_trim_q6={10'd876,10'd71};
   6'd1:volume_trim_q6={10'd469,10'd70};
   6'd2:volume_trim_q6={10'd409,10'd70};
   6'd3:volume_trim_q6={10'd379,10'd71};
   6'd4:volume_trim_q6={10'd349,10'd71};
   6'd5:volume_trim_q6={10'd329,10'd72};
   6'd6:volume_trim_q6={10'd308,10'd72};
   6'd7:volume_trim_q6={10'd295,10'd73};
   6'd8:volume_trim_q6={10'd283,10'd74};
   6'd9:volume_trim_q6={10'd274,10'd75};
   6'd10:volume_trim_q6={10'd266,10'd75};
   6'd11:volume_trim_q6={10'd257,10'd76};
   6'd12:volume_trim_q6={10'd249,10'd77};
   6'd13:volume_trim_q6={10'd245,10'd78};
   6'd14:volume_trim_q6={10'd241,10'd78};
   6'd15:volume_trim_q6={10'd237,10'd79};
   6'd16:volume_trim_q6={10'd233,10'd79};
   6'd17:volume_trim_q6={10'd229,10'd80};
   6'd18:volume_trim_q6={10'd225,10'd81};
   6'd19:volume_trim_q6={10'd221,10'd82};
   6'd20:volume_trim_q6={10'd217,10'd82};
   6'd21:volume_trim_q6={10'd213,10'd83};
   6'd22:volume_trim_q6={10'd209,10'd84};
   6'd23:volume_trim_q6={10'd205,10'd85};
   6'd24:volume_trim_q6={10'd201,10'd85};
   6'd25:volume_trim_q6={10'd197,10'd85};
   6'd26:volume_trim_q6={10'd194,10'd85};
   6'd27:volume_trim_q6={10'd190,10'd85};
   6'd28:volume_trim_q6={10'd187,10'd84};
   6'd29:volume_trim_q6={10'd183,10'd84};
   6'd30:volume_trim_q6={10'd180,10'd84};
   6'd31:volume_trim_q6={10'd177,10'd83};
   6'd32:volume_trim_q6={10'd173,10'd83};
   6'd33:volume_trim_q6={10'd169,10'd83};
   6'd34:volume_trim_q6={10'd165,10'd82};
   6'd35:volume_trim_q6={10'd161,10'd82};
   6'd36:volume_trim_q6={10'd157,10'd82};
   6'd37:volume_trim_q6={10'd153,10'd81};
   6'd38:volume_trim_q6={10'd149,10'd81};
   6'd39:volume_trim_q6={10'd145,10'd81};
   6'd40:volume_trim_q6={10'd141,10'd80};
   6'd41:volume_trim_q6={10'd141,10'd82};
   6'd42:volume_trim_q6={10'd140,10'd84};
   6'd43:volume_trim_q6={10'd140,10'd86};
   6'd44:volume_trim_q6={10'd140,10'd88};
   6'd45:volume_trim_q6={10'd140,10'd89};
   6'd46:volume_trim_q6={10'd139,10'd91};
   6'd47:volume_trim_q6={10'd139,10'd93};
   6'd48:volume_trim_q6={10'd139,10'd95};
   6'd49:volume_trim_q6={10'd140,10'd97};
   6'd50:volume_trim_q6={10'd142,10'd98};
   6'd51:volume_trim_q6={10'd144,10'd100};
   6'd52:volume_trim_q6={10'd145,10'd102};
   6'd53:volume_trim_q6={10'd147,10'd104};
   6'd54:volume_trim_q6={10'd148,10'd105};
   6'd55:volume_trim_q6={10'd150,10'd107};
   6'd56:volume_trim_q6={10'd152,10'd109};
   6'd57:volume_trim_q6={10'd151,10'd109};
   6'd58:volume_trim_q6={10'd151,10'd109};
   6'd59:volume_trim_q6={10'd150,10'd108};
   6'd60:volume_trim_q6={10'd150,10'd108};
   6'd61:volume_trim_q6={10'd149,10'd108};
   6'd62:volume_trim_q6={10'd149,10'd108};
   6'd63:volume_trim_q6={10'd148,10'd108};
   default:volume_trim_q6={10'd64,10'd64};
  endcase end
 endfunction
 wire [19:0] trim_pair=volume_trim_q6(run_vel[v][6:1]);
 wire [9:0] trim_gain=flute_voice[v]?trim_pair[19:10]:(marimba_voice[v]?trim_pair[9:0]:10'd64);
 reg signed [42:0] trim_product;
 wire signed [33:0] trimmed_raw=trim_product>>>(MIX_SHIFT+6);
 assign ep_mix=mix_ep;assign cel_mix=mix_cel;
 reg [15:0] cycles;
 assign releasing=busy & ~gate;
 wire [172:0] config_q,ep_config_q,cel_config_q,mar_config_q,flute_config_q,string_config_q;
 wire [6:0] cel_note=run_note[issue_v]+7'd12;
 instrument_ep_config config_rom(clk,{run_note[issue_v],issue_op},ep_config_q);
 instrument_celesta_config cel_config(clk,{cel_note,issue_op},cel_config_q);
 instrument_marimba_config mar_config(clk,{run_note[issue_v],issue_op},mar_config_q);
 instrument_flute_config flute_config(clk,{run_note[issue_v],issue_op},flute_config_q);
 instrument_string_config string_config(clk,{run_note[issue_v],issue_op},string_config_q);
 assign config_q=string_voice[read_v]?string_config_q:flute_voice[read_v]?flute_config_q:celesta_voice[read_v]?cel_config_q:(marimba_voice[read_v]?mar_config_q:ep_config_q);
 wire [3:0] mar_sensitivity,unused_sensitivity;
 wire [11:0] unused_offset0,unused_offset1,mar_offset0,mar_offset1;
 instrument_marimba_metadata mar_velocity(read_op,mar_sensitivity,unused_offset0,unused_offset1);
 wire [7:0] vel_value;
 FM6_velocity_lut velocity_rom(run_vel[read_v][6:1],vel_value);
 reg [AB-1:0] p_tag[0:17];
 wire [3:0] flute_sensitivity,flute_unused;
 wire [12:0] flute_off0,flute_off1,flute_off2,f_unused0,f_unused1,f_unused2;
 instrument_flute_metadata flute_velocity(read_op,flute_sensitivity,f_unused0,f_unused1,f_unused2);
 instrument_flute_metadata flute_levels(p_tag[1][2:0],flute_unused,flute_off0,flute_off1,flute_off2);
 reg p_string[0:17];
 wire [3:0] string_sensitivity,string_unused;
 wire [12:0] string_off0,string_off1,string_off2,s_unused0,s_unused1,s_unused2;
 instrument_string_metadata string_velocity(read_op,string_sensitivity,s_unused0,s_unused1,s_unused2);
 instrument_string_metadata string_levels(p_tag[1][2:0],string_unused,string_off0,string_off1,string_off2);
 wire [12:0] full_off0=p_string[1]?string_off0:flute_off0;
 wire [12:0] full_off1=p_string[1]?string_off1:flute_off1;
 wire [12:0] full_off2=p_string[1]?string_off2:flute_off2;
 reg signed [15:0] velocity_adjust;
 reg signed [31:0] outlevel;
 reg [3:0] sensitivity;
 always @* if(string_voice[read_v])sensitivity=string_sensitivity;
 else if(flute_voice[read_v])sensitivity=flute_sensitivity;
 else if(marimba_voice[read_v])sensitivity=mar_sensitivity;
 else if(celesta_voice[read_v])case(read_op)
  0,1:sensitivity=7;2:sensitivity=0;default:sensitivity=3;
 endcase
 else case(read_op)
  0,2:sensitivity=6;4:sensitivity=7;3,5:sensitivity=2;default:sensitivity=0;
 endcase
 reg signed [31:0] eg_target,eg_base;
 reg [31:0] eg_inc;
 reg [2:0] eg_stage;
 reg signed [39:0] eg_product;
 reg signed [40:0] eg_candidate;
 reg signed [31:0] eg_next;
 reg [2:0] stage_next;
 reg signed [5:0] eg_factor;
 wire [47:0] exp_q;
 // EG lookup belongs to preparation stage 8 below.
 // exp2[i+1]-exp2[i] is positive and <=5677 in this immutable ROM.
 // Register the 13-bit difference before multiplication. In Gowin 1.9.12.03
 // the former (upper-lower)*fraction expression mapped to a DSP subtract/
 // multiply with a spurious bit24 carry, despite matching in RTL simulation.
 reg [12:0] exp_diff;
 reg [26:0] exp_product;
 reg [24:0] mantissa;
 reg [23:0] new_gain;
 reg signed [31:0] dg;
 reg [31:0] pm;
 wire [35:0] sine_q;
 FM6_sine_pairs sine_rom(clk,pm[31:20],sine_q);
 reg signed [18:0] sine_diff;
 reg signed [39:0] sine_product;
 reg signed [18:0] wave;
 reg signed [24:0] op_gain;
 reg signed [43:0] op_product;
 reg signed [27:0] result;
 reg signed [28:0] feedback_sum;
 reg signed [33:0] scaled_mix;
 wire [13:0] sin_log;
 wire [9:0] log_index=pm[22]?~pm[21:12]:pm[21:12];
 instrument_sin_log log_rom(clk,log_index,sin_log);
 reg [15:0] log_env;
 wire [11:0] sin_exp;
 instrument_sin_exp anti_log_rom(clk,~log_env[9:0],sin_exp);
 reg [12:0] exp_magnitude;
 wire [23:0] cel_g1=endpoint==0?24'd16383:endpoint;
 // PCM16 saturation occurs per voice, before mixing, exactly as MATLAB.
 reg signed [15:0] cel_pcm16;


 // Pipelined preparation: all 60 contexts, identical integer operations.
 reg [17:0] pvld;
 
 instrument_marimba_metadata mar_levels(p_tag[1][2:0],unused_sensitivity,mar_offset0,mar_offset1);
 reg [0:0] p_active[0:17];
 reg [0:0] p_patch[0:17];
 reg [1:0] p_marimba;
 reg p_flute[0:17];reg [23:0] p_ratio[0:17];
 reg signed [31:0] p_target2[0:17];
 reg [13:0] lut_fraction[0:17];reg [7:0] lut_exponent[0:17];reg [49:0] am_product;reg signed [31:0] lut_level;
 reg [23:0] frame_string_ratio;reg [23:0] frame_flute_ratio;reg [17:0] frame_am_pt;reg [4:0] prepare_wait;
 reg signed [27:0] flute_bus2;
 reg [0:0] p_boundary[0:17];
 reg [0:0] p_down[0:17];
 reg [0:0] p_start[0:17];
 reg [31:0] p_phase[0:17];
 reg signed [31:0] p_level[0:17];
 reg [2:0] p_stage[0:17];
 reg [23:0] p_endpoint[0:17];
 reg signed [31:0] p_gain[0:17];
 reg signed [31:0] p_delta[0:17];
 reg [0:0] p_silent[0:17];
 reg [12:0] p_base[0:17];
 reg signed [15:0] p_vadj[0:17];
 reg signed [31:0] p_outlevel[0:17];
 reg signed [31:0] p_target0[0:17];
 reg signed [31:0] p_target1[0:17];
 reg [31:0] p_inc0[0:17];
 reg [31:0] p_inc1[0:17];
 reg [31:0] p_inc2[0:17];
 reg [31:0] p_inc3[0:17];
 reg [2:0] p_egstage[0:17];
 reg signed [31:0] p_egbase[0:17];
 reg signed [31:0] p_egtarget[0:17];
 reg [31:0] p_eginc[0:17];
 reg signed [5:0] p_factor[0:17];
 reg signed [39:0] p_egprod[0:17];
 reg signed [40:0] p_candidate[0:17];
 reg signed [31:0] p_egnext[0:17];
 reg [2:0] p_nextstage[0:17];
 reg [23:0] p_explow[0:17];
 reg [12:0] p_expdiff[0:17];
 reg [26:0] p_expprod[0:17];
 reg [24:0] p_mantissa[0:17];
 reg [23:0] p_newgain[0:17];
 reg signed [31:0] p_dg[0:17];
 reg [31:0] p_fcw[0:17];
 wire [55:0] pitch_product_q;
 instrument_pitch_product pitch_multiplier(clk,p_fcw[5],p_ratio[5],pitch_product_q);
 reg p_pitch_identity[0:10];
 reg [32:0] p_pitchround[0:17];
 reg [0:0] p_pitchover[0:17];
 reg [31:0] p_pitch[0:17];
 integer ps;
 wire eg_hold=p_egstage[7]==4 || ((p_patch[7] || p_flute[7]) && p_egstage[7]==3 && p_down[7]);
 wire eg_hit=(p_egtarget[7]>p_level[7] && p_candidate[7]>=p_egtarget[7]) || (p_egtarget[7]<=p_level[7] && p_candidate[7]<=p_egtarget[7]);
 wire signed [31:0] chosen_level=eg_hold?p_level[7]:(eg_hit?p_egtarget[7]:p_candidate[7][31:0]);
 wire [23:0] pipe_g1=p_endpoint[14]==0?24'd16383:p_endpoint[14];
 FM6_exp_pairs prep_exp(clk,lut_level[23:14],exp_q);
 // Single read port and single write port. Preparation reads/writes overlap;
 // rendering starts only after all preparation writes have committed.
 always @(posedge clk)begin
  op_q<=op_mem[read_addr];
  if(rst_n && pvld[17] && p_active[17])
   op_mem[p_tag[17]]<={p_phase[17],p_level[17],p_stage[17],p_endpoint[17],p_gain[17],p_delta[17],p_silent[17],p_pitch[17]};
  else if(rst_n && state==64)op_mem[{v,3'd0}]<={5'd0,nes_result};
  else if(rst_n && state==26)
   op_mem[ix]<={(celesta_voice[v]?{8'd0,phase[23:0]+pitch_step[23:0]}:phase+pitch_step),level,stage,endpoint,current_gain,delta_gain,silent_block,pitch_step};
 end
 always @(posedge clk)begin
  if(!rst_n)begin p_marimba<=0;pvld<=0;read_valid<=0;read_v<=0;read_op<=0;end
  else begin
   read_valid<=state==50;read_v<=issue_v;read_op<=issue_op;
   pvld<={pvld[16:0],read_valid};
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])begin p_string[ps]<=p_string[ps-1];p_flute[ps]<=p_flute[ps-1];p_ratio[ps]<=p_ratio[ps-1];p_target2[ps]<=p_target2[ps-1];end
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_tag[ps]<=p_tag[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_active[ps]<=p_active[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_patch[ps]<=p_patch[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_boundary[ps]<=p_boundary[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_down[ps]<=p_down[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_start[ps]<=p_start[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_phase[ps]<=p_phase[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_level[ps]<=p_level[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_stage[ps]<=p_stage[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_endpoint[ps]<=p_endpoint[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_gain[ps]<=p_gain[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_delta[ps]<=p_delta[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_silent[ps]<=p_silent[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_base[ps]<=p_base[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_vadj[ps]<=p_vadj[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_outlevel[ps]<=p_outlevel[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_target0[ps]<=p_target0[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_target1[ps]<=p_target1[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_inc0[ps]<=p_inc0[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_inc1[ps]<=p_inc1[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_inc2[ps]<=p_inc2[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_inc3[ps]<=p_inc3[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_egstage[ps]<=p_egstage[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_egbase[ps]<=p_egbase[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_egtarget[ps]<=p_egtarget[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_eginc[ps]<=p_eginc[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_factor[ps]<=p_factor[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_egprod[ps]<=p_egprod[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_candidate[ps]<=p_candidate[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_egnext[ps]<=p_egnext[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_nextstage[ps]<=p_nextstage[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_explow[ps]<=p_explow[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_expdiff[ps]<=p_expdiff[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_expprod[ps]<=p_expprod[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_mantissa[ps]<=p_mantissa[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_newgain[ps]<=p_newgain[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_dg[ps]<=p_dg[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_fcw[ps]<=p_fcw[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_pitchround[ps]<=p_pitchround[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_pitchover[ps]<=p_pitchover[ps-1];
   for(ps=1;ps<18;ps=ps+1)if(pvld[ps-1])p_pitch[ps]<=p_pitch[ps-1];

   p_tag[0]<=6'd0;
   p_active[0]<=1'd0;
   p_patch[0]<=1'd0;
   p_boundary[0]<=1'd0;
   p_down[0]<=1'd0;
   p_start[0]<=1'd0;
   p_phase[0]<=32'd0;
   p_level[0]<=32'd0;
   p_stage[0]<=3'd0;
   p_endpoint[0]<=24'd0;
   p_gain[0]<=32'd0;
   p_delta[0]<=32'd0;
   p_silent[0]<=1'd0;
   p_base[0]<=13'd0;
   p_vadj[0]<=16'd0;
   p_outlevel[0]<=32'd0;
   p_target0[0]<=32'd0;
   p_target1[0]<=32'd0;
   p_inc0[0]<=32'd0;
   p_inc1[0]<=32'd0;
   p_inc2[0]<=32'd0;
   p_inc3[0]<=32'd0;
   p_egstage[0]<=3'd0;
   p_egbase[0]<=32'd0;
   p_egtarget[0]<=32'd0;
   p_eginc[0]<=32'd0;
   p_factor[0]<=6'd0;
   p_egprod[0]<=40'd0;
   p_candidate[0]<=41'd0;
   p_egnext[0]<=32'd0;
   p_nextstage[0]<=3'd0;
   p_explow[0]<=24'd0;
   p_expdiff[0]<=13'd0;
   p_expprod[0]<=27'd0;
   p_mantissa[0]<=25'd0;
   p_newgain[0]<=24'd0;
   p_dg[0]<=32'd0;
   p_fcw[0]<=32'd0;
   p_pitchround[0]<=33'd0;
   p_pitchover[0]<=1'd0;
   p_pitch[0]<=32'd0;
   p_string[0]<=string_voice[read_v];p_flute[0]<=flute_voice[read_v] || string_voice[read_v];p_ratio[0]<=string_voice[read_v]?frame_string_ratio:flute_voice[read_v]?frame_flute_ratio:frame_ratio;
   p_marimba<={p_marimba[0],marimba_voice[read_v]};
   p_tag[0]<={read_v,read_op};p_active[0]<=(busy[read_v] || start_on[read_v]) && !nes_voice[read_v];
   p_patch[0]<=celesta_voice[read_v];p_boundary[0]<=block_pos[read_v]==0;
   p_down[0]<=down[read_v];p_start[0]<=start_on[read_v];
   {p_phase[0],p_level[0],p_stage[0],p_endpoint[0],p_gain[0],p_delta[0],p_silent[0]}<=op_q[187:32];
   if(start_on[read_v])begin
    p_level[0]<=0;p_stage[0]<=0;
    if(cold_on[read_v])begin p_phase[0]<=0;p_endpoint[0]<=0;p_gain[0]<=0;p_delta[0]<=0;p_silent[0]<=1;end
   end
   p_base[0]<=config_q[172:160];
   p_inc0[0]<=config_q[159:128];p_inc1[0]<=config_q[127:96];p_inc2[0]<=config_q[95:64];p_inc3[0]<=config_q[63:32];p_fcw[0]<=config_q[31:0];
   p_vadj[0]<=($signed({1'b0,sensitivity})*($signed({1'b0,vel_value})-16'sd239)+16'sd7)>>>3;
   p_outlevel[1]<=$signed({1'b0,p_base[0]})+($signed(p_vadj[0])<<<4);
   if(p_flute[1])begin
    p_target0[2]<=((p_outlevel[1]<0?32'sd0:p_outlevel[1])-$signed({1'b0,full_off0})<16)?32'sd1048576:((p_outlevel[1]<0?32'sd0:p_outlevel[1])-$signed({1'b0,full_off0}))<<<16;
    p_target1[2]<=((p_outlevel[1]<0?32'sd0:p_outlevel[1])-$signed({1'b0,full_off1})<16)?32'sd1048576:((p_outlevel[1]<0?32'sd0:p_outlevel[1])-$signed({1'b0,full_off1}))<<<16;
    p_target2[2]<=((p_outlevel[1]<0?32'sd0:p_outlevel[1])-$signed({1'b0,full_off2})<16)?32'sd1048576:((p_outlevel[1]<0?32'sd0:p_outlevel[1])-$signed({1'b0,full_off2}))<<<16;
   end else begin
   p_target0[2]<=((p_outlevel[1]<0?32'sd0:p_outlevel[1])-$signed({1'b0,(p_marimba[1]?mar_offset0:12'd224)}))<<<16;
   p_target1[2]<=((p_outlevel[1]<0?32'sd0:p_outlevel[1])-(p_marimba[1]?$signed({1'b0,mar_offset1}):(p_patch[1]?32'sd800:(p_tag[1][2:0]>=4?32'sd992:32'sd352))))<<<16;
   if((p_outlevel[1]<0?32'sd0:p_outlevel[1])-$signed({1'b0,(p_marimba[1]?mar_offset0:12'd224)})<16)p_target0[2]<=32'sd1048576;
   if(p_outlevel[1]-(p_marimba[1]?$signed({1'b0,mar_offset1}):(p_patch[1]?32'sd800:(p_tag[1][2:0]>=4?32'sd992:32'sd352)))<16)p_target1[2]<=32'sd1048576;
   end
   p_egstage[2]<=!p_down[1]?3'd3:p_stage[1];
   if(p_stage[1]==4 && !p_start[1])p_egstage[2]<=4;
   p_egbase[3]<=p_level[2];p_egtarget[3]<=32'sd1048576;p_eginc[3]<=p_inc3[2];
   case(p_egstage[2])
    0:begin p_egtarget[3]<=p_target0[2];p_eginc[3]<=p_inc0[2];end
    1:begin p_egtarget[3]<=p_target1[2];p_eginc[3]<=p_inc1[2];end
    2:begin p_egtarget[3]<=p_flute[2]?p_target2[2]:32'sd1048576;p_eginc[3]<=p_inc2[2];end
    default:begin end
   endcase
   if(p_egtarget[3]>p_egbase[3] && p_egbase[3]<32'sd112459776)p_egbase[4]<=32'sd112459776;
   p_factor[5]<=(32'sd285212672-p_egbase[4])>>>24;
   p_egprod[6]<=p_factor[5]*$signed({1'b0,p_eginc[5]});
   if(p_egtarget[6]>p_level[6])p_candidate[7]<=$signed(p_egbase[6])+p_egprod[6];
   else p_candidate[7]<=$signed(p_egbase[6])-$signed({1'b0,p_eginc[6]});
   p_egnext[8]<=p_candidate[7][31:0];p_nextstage[8]<=p_egstage[7];
   if(p_egstage[7]==4 || ((p_patch[7] || p_flute[7]) && p_egstage[7]==3 && p_down[7]))p_egnext[8]<=p_level[7];
   else if((p_egtarget[7]>p_level[7] && p_candidate[7]>=p_egtarget[7]) || (p_egtarget[7]<=p_level[7] && p_candidate[7]<=p_egtarget[7]))begin
    p_egnext[8]<=p_egtarget[7];
    if(p_egstage[7]<2 || p_egstage[7]==3 || ((p_patch[7] || p_flute[7]) && p_egstage[7]==2))p_nextstage[8]<=p_egstage[7]+1'b1;
   end
   if(p_boundary[8])begin p_level[9]<=p_egnext[8];p_stage[9]<=p_nextstage[8];end
   am_product<=$unsigned(chosen_level)*frame_am_pt;
   lut_level<=p_flute[8] && !p_string[8] && p_tag[8][2:0]==3 ? p_egnext[8]-$signed({6'd0,am_product[49:24]}) : p_egnext[8];
   lut_fraction[10]<=lut_level[13:0];lut_fraction[11]<=lut_fraction[10];
   lut_exponent[10]<=lut_level[31:24];lut_exponent[11]<=lut_exponent[10];lut_exponent[12]<=lut_exponent[11];lut_exponent[13]<=lut_exponent[12];
   p_explow[11]<=exp_q[23:0];p_expdiff[11]<=exp_q[47:24]-exp_q[23:0];
   p_expprod[12]<=p_expdiff[11]*lut_fraction[11];
   p_mantissa[13]<={1'b0,p_explow[12]}+(p_expprod[12]>>14);
   if(p_patch[13])p_newgain[14]<=24'd16384-(p_egnext[13]>>>14);
   else if(lut_exponent[13]>=14)p_newgain[14]<=p_mantissa[13]<<(lut_exponent[13]-8'd14);
   else p_newgain[14]<=p_mantissa[13]>>(8'd14-lut_exponent[13]);
   if(p_patch[14])begin
    p_dg[15]<=($signed({1'b0,p_newgain[14]})-$signed({1'b0,pipe_g1})+32'sd32)>>>6;
    if(p_boundary[14])p_silent[15]<=p_newgain[14]>16284 && pipe_g1>16284;
   end else begin
    p_dg[15]<=($signed({1'b0,p_newgain[14]})-$signed({1'b0,p_endpoint[14]})+32'sd32)>>>6;
    if(p_boundary[14])p_silent[15]<=p_newgain[14]<280 && p_endpoint[14]<280;
   end
   if(p_boundary[15])begin
    p_endpoint[16]<=p_newgain[15];p_delta[16]<=p_dg[15];
    p_gain[16]<=$signed({1'b0,(p_patch[15]?(p_endpoint[15]==0?24'd16383:p_endpoint[15]):p_endpoint[15])})+p_dg[15];
   end else p_gain[16]<=p_gain[15]+p_delta[15];
   // Preserve the old stage10 rounding and stage11 saturation boundaries.
   p_pitch_identity[1]<=p_ratio[0]==24'd4194304;
   for(ps=2;ps<11;ps=ps+1)if(pvld[ps-1])p_pitch_identity[ps]<=p_pitch_identity[ps-1];
   p_pitchround[10]<={1'b0,pitch_product_q[53:22]}+{32'd0,pitch_product_q[21]};
   p_pitchover[10]<=|pitch_product_q[55:54];
   if((!PITCH_ENABLE && !p_flute[10]) || p_pitch_identity[10])p_pitch[11]<=p_fcw[10];
   else p_pitch[11]<=p_pitchover[10] || p_pitchround[10][32]?32'hffffffff:p_pitchround[10][31:0];
  end
 end
 integer i;
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=0;issue_v<=0;issue_op<=0;v<=0;op<=0;pcm<=0;pcm_valid<=0;busy<=0;gate<=0;down<=0;
   pending_on<=0;pending_off<=0;start_on<=0;run_off<=0;initialized<=0;cold_on<=0;nes_cold<=0;
   frame_string_ratio<=24'd4194304;frame_flute_ratio<=24'd4194304;frame_am_pt<=0;prepare_wait<=0;flute_bus2<=0;frame_ratio<=24'd4194304;pitch_one<=0;pitch_three<=0;pitch_five<=0;pitch_seven<=0;
   pitch_product<=0;pitch_digits<=0;pitch_digit_index<=0;pitch_rounded<=0;pitch_overflow<=0;pitch_step<=0;
   deadline_miss<=0;clip_count<=0;range_errors<=0;cycles<=0;last_cycles<=0;voice_raw<=0;mix<=0;mix_ep<=0;mix_cel<=0;raw<=0;branch<=0;trim_product<=43'sd0;
   for(i=0;i<VOICES;i=i+1)begin pending_patch[i]<=0;run_patch[i]<=0;block_pos[i]<=0;pending_note[i]<=0;pending_vel[i]<=0;run_note[i]<=0;run_vel[i]<=0;fb0[i]<=0;fb1[i]<=0;finished[i]<=0;end
   phase<=0;fcw<=0;level<=0;stage<=0;endpoint<=0;current_gain<=0;delta_gain<=0;silent_block<=1;
   target0<=0;target1<=0;inc0<=0;inc1<=0;inc2<=0;inc3<=0;

  end else begin
   pcm_valid<=0;
   if(state!=0)cycles<=cycles+1'b1;
   if(sample_tick && state!=0)deadline_miss<=deadline_miss+1'b1;
   case(state)
    0:if(sample_tick)begin
     prepare_wait<=0;
     start_on<=pending_on;run_off<=pending_off;pending_on<=0;pending_off<=0;
     for(i=0;i<VOICES;i=i+1)begin
      if(pending_on[i])begin
       // Celesta reuse preserves phase/gain/feedback (factory key_sync=0).
       // Retriggers on the same Celesta slot wait for its local 64-sample boundary.
       if((pending_patch[i]==2'd1 || pending_patch[i]==2'd3) && pending_patch[i]==run_patch[i] && initialized[i] && block_pos[i]!=0)begin
        pending_on[i]<=1;start_on[i]<=0;
        if(pending_off[i])pending_off[i]<=1;
       end else begin
        busy[i]<=1;nes_cold[i]<=!initialized[i] || run_patch[i]!=5;
        cold_on[i]<=!initialized[i] || pending_patch[i]!=run_patch[i] || (pending_patch[i]!=2'd1 && pending_patch[i]!=2'd3);
        run_patch[i]<=pending_patch[i];initialized[i]<=1;finished[i]<=0;
        run_note[i]<=pending_note[i];run_vel[i]<=pending_vel[i];block_pos[i]<=0;
        if((pending_patch[i]!=2'd1 && pending_patch[i]!=2'd3) || pending_patch[i]!=run_patch[i] || !initialized[i])begin fb0[i]<=0;fb1[i]<=0;end
        down[i]<=!pending_off[i];
       end
      end
     end
     v<=0;op<=0;mix<=0;mix_ep<=0;mix_cel<=0;raw<=0;cycles<=0;state<=49;
    end
    49:begin
     for(i=0;i<VOICES;i=i+1)if(run_off[i])down[i]<=0;
     if(prepare_wait==23)begin frame_ratio<=pitch_ratio;frame_string_ratio<=string_ratio;frame_flute_ratio<=flute_pitch_ratio;frame_am_pt<=flute_am_pt;issue_v<=0;issue_op<=0;state<=50;end else prepare_wait<=prepare_wait+1'b1;
    end
    50:begin
     if(issue_op==5)begin
      issue_op<=0;
      if(issue_v==VOICES-1)state<=51;else issue_v<=issue_v+1'b1;
     end else issue_op<=issue_op+1'b1;
    end
    51:if(pvld[17] && p_tag[17]==((VOICES-1)*8+5))begin v<=0;op<=0;state<=1;end
    // Keep silent NES DC/envelope clocks evolving after release, as in the original APU.
    1:begin // Voice boundary: only local block boundary applies queued Note Off.
     if(!busy[v] && !start_on[v] && !nes_voice[v])begin
      voice_raw[v*32+:32]<=0;
      if(v==VOICES-1)state<=30;else begin v<=v+1'b1;state<=1;end
     end else if(nes_voice[v])begin op<=0;state<=62;end else begin
      if(run_off[v])down[v]<=0;
      raw<=0;op<=0;state<=3;
     end
    end
    2:state<=3;
    3:begin
     {phase,level,stage,endpoint,current_gain,delta_gain,silent_block,pitch_step}<=op_q;
     state<=18;
    end
    18:begin
     feedback_sum<=$signed({fb0[v][27],fb0[v]})+$signed({fb1[v][27],fb1[v]});state<=19;
    end
    19:begin
     if(celesta_voice[v])begin
      if(op==0)pm<=$signed({8'd0,phase[23:0]})+(feedback_sum>>>4);
      else if(op==1)pm<=$signed({8'd0,phase[23:0]})+branch;
      else pm<={8'd0,phase[23:0]};
     end else if(string_voice[v])begin
      // Algorithm2: 6->5->4->3 plus 2->1. Feedback7 on OP2 only.
      if(op==4)pm<=phase+((feedback_sum>>>2)<<<10);
      else if(op==1 || op==2 || op==3 || op==5)pm<=phase+(branch<<<10);
      else pm<=phase;
     end else if(flute_voice[v])begin
      if(op==0)pm<=phase+((feedback_sum>>>4)<<<10);
      else if(op==1 || op==5)pm<=phase+(branch<<<10);
      else if(op==3)pm<=phase+(flute_bus2<<<10);
      else pm<=phase;
     end else if(marimba_voice[v])begin
      // Algorithm7: OP6->OP5, (OP5+OP4)->OP3, OP2->OP1.
      // Factory feedback=0: OP6 has no feedback contribution.
      if(op==1 || op==3 || op==5)pm<=phase+(branch<<<10);
      else pm<=phase;
     end else if(op==0)pm<=phase+((feedback_sum>>>3)<<<10);
     else if(op[0])pm<=phase+(branch<<<10);
     else pm<=phase;
     op_gain<=silent_block?25'sd0:$signed({1'b0,current_gain[23:0]});
     state<=20;
    end
    20:state<=celesta_voice[v]?39:21; // sine ROM read
    39:begin log_env<=({pm[23],15'd0}|{2'd0,sin_log})+current_gain[15:0];state<=40;end
    40:state<=41;
    41:begin exp_magnitude<=({1'b0,1'b1,sin_exp})>>log_env[14:10];state<=42;end
    42:begin
     if(silent_block)result<=0;
     else if(log_env[15])result<=(-$signed({1'b0,exp_magnitude})-26'sd1)<<<13;
     else result<=$signed({1'b0,exp_magnitude})<<<13;
     state<=26;
    end
    21:begin sine_diff<=$signed({sine_q[35],sine_q[35:18]})-$signed({sine_q[17],sine_q[17:0]});state<=22;end
    22:begin sine_product<=sine_diff*$signed({1'b0,pm[19:0]});state<=23;end
    23:begin wave<=$signed({sine_q[17],sine_q[17:0]})+(sine_product>>>20);state<=24;end
    24:begin op_product<=wave*op_gain;state<=25;end
    25:begin
     result<=op_product>>>17;
     if((op_product>>>17)>44'sd33554431 || (op_product>>>17)<-44'sd33554432)range_errors<=range_errors+1'b1;
     state<=26;
    end
    26:begin

     if(string_voice[v])begin
      if(op==0 || op==1 || op==2 || op==4)branch<=result;
      if(op==3 || op==5)raw<=raw+$signed(result);
     end else if(flute_voice[v])begin
      // Algorithm16 buses: 6->5, 4->3, (5+3+2)->1; feedback on6.
      case(op)
       0,1:branch<=result;
       2:flute_bus2<=result;
       3,4:branch<=branch+result;
       5:raw<=$signed(result);
       default:begin end
      endcase
     end else if(marimba_voice[v])begin
      case(op)
       0,1,4:branch<=result;
       2:branch<=branch+result;
       default:begin end
      endcase
      if(op==3 || op==5)raw<=raw+$signed(result);
     end else begin
      if(op==0 || (!celesta_voice[v] && !op[0]))branch<=result;
      if((celesta_voice[v] && op!=0) || (!celesta_voice[v] && op[0]))raw<=raw+$signed(result);
     end
     finished[v][op]<=stage==4 && (!celesta_voice[v] || endpoint>16284);
     if((string_voice[v]?op==4:op==0) && (!celesta_voice[v] || !silent_block))begin fb0[v]<=fb1[v];fb1[v]<=result;end
     if(op==5)state<=27;else begin op<=op+1'b1;state<=3;end
    end
    27:begin
     voice_raw[v*32+:32]<=raw;block_pos[v]<=block_pos[v]+1'b1;
     // Every OP has reached R4/L4 before recycling the slot.
     if(!gate[v] && !pending_on[v] && (marimba_voice[v]?(finished[v][3] && finished[v][5]):(&finished[v])) && (!celesta_voice[v] || block_pos[v]==63))busy[v]<=0;
     state<=43;
    end
    43:begin
     // Scalar trim only after six-OP rendering; held patch/velocity select it.
     trim_product<=$signed(raw)*$signed({1'b0,trim_gain});
     // EP unchanged raw/16; Celesta Plugin PCM16 then preview gain1/2.
     if((raw>>>4)>=28'sd16777216)cel_pcm16<=16'sh7fff;
     else if((raw>>>4)< -28'sd16777216)cel_pcm16<=16'sh8000;
     else cel_pcm16<=raw>>>13;
     state<=44;
    end
    44:begin
     if(celesta_voice[v])begin mix<=mix+($signed(cel_pcm16)<<<7);mix_cel<=mix_cel+($signed(cel_pcm16)<<<7);end
     else begin mix<=mix+trimmed_raw;mix_ep<=mix_ep+trimmed_raw;end
     if(v==VOICES-1)state<=30;else begin v<=v+1'b1;state<=1;end
    end
    62:state<=63;
    63:if(nes_done)begin nes_cold[v]<=0;
     mix<=mix+nes_scaled;mix_ep<=mix_ep+nes_scaled;voice_raw[v*32+:32]<={{16{nes_pcm[15]}},nes_pcm};
     if(!nes_active && !pending_on[v])busy[v]<=0;
     state<=64;
    end
    64:begin if(v==VOICES-1)state<=30;else begin v<=v+1'b1;state<=1;end end
    30:begin scaled_mix<=mix;state<=32;end
    32:begin
     if(scaled_mix>34'sd8388607)begin pcm<=24'sh7fffff;clip_count<=clip_count+1'b1;end
     else if(scaled_mix< -34'sd8388608)begin pcm<=24'sh800000;clip_count<=clip_count+1'b1;end
     else pcm<=scaled_mix[23:0];
     pcm_valid<=1;last_cycles<=cycles;state<=0;
    end
    default:state<=0;
   endcase
   // Event capture wins a simultaneous boundary; events apply next sample.
   for(i=0;i<VOICES;i=i+1)begin
    if(note_on[i])begin
     pending_on[i]<=1;pending_off[i]<=0;pending_note[i]<=note;pending_vel[i]<=velocity;pending_patch[i]<=patch_select;busy[i]<=1;gate[i]<=1;
    end else if(note_off[i])begin pending_off[i]<=1;gate[i]<=0;end
   end
   // A release waits for this voice's next local block. Retain it until then.
   for(i=0;i<VOICES;i=i+1)begin
    if(state==0 && sample_tick && pending_off[i] && !pending_on[i] && block_pos[i]!=0)pending_off[i]<=1;
   end
  end
 end
endmodule
`default_nettype wire
