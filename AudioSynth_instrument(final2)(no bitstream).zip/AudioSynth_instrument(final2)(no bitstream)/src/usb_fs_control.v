`default_nettype none
// EP0 SETUP/data/status sequence from the local UKP, extended for MPS/short packets.
// Data is committed only after CRC and ACK. ctrl_done only after status stage.
module usb_fs_control(
 input wire clk,rst_n,start,input wire [63:0] setup,
 input wire [6:0] address,ep0_mps,
 output wire busy,output reg done,error,
 output reg data_valid /* synthesis syn_maxfan=16 */,output reg [6:0] data_length,output reg [511:0] data,
 output wire request_valid,input wire request_ready,
 output wire [1:0] request_kind,output wire request_toggle,
 output wire [3:0] request_length,output wire [63:0] request_data,
 input wire response_done,input wire [2:0] response_result,
 input wire [6:0] response_length,input wire [511:0] response_data,
 output wire [3:0] debug_state,output wire [2:0] debug_faults,
 output reg [3:0] debug_failure_stage,output reg [7:0] debug_reason,
 output reg [15:0] debug_retries
);
 localparam IDLE=0,SEND_SETUP=1,WAIT_SETUP=2,SEND_DATA=3,WAIT_DATA=4,
            SEND_STATUS=5,WAIT_STATUS=6,DELAY=7;
 reg [3:0] state,resume;
 reg [63:0] saved_setup;
 reg [15:0] remaining;
 reg read_request,toggle;
 reg [25:0] watchdog;
 reg [13:0] delay_count;
 reg [2:0] faults;
 reg retry_carry,retry_saturated;
 // A retry enters DELAY for 9600 clocks; carry/saturation are ready long
 // before the next retry. Preserve the original update edge and saturation.
 always @(posedge clk)begin
  retry_carry<=debug_retries[7:0]==8'hff;
  retry_saturated<=debug_retries==16'hffff;
 end
 assign debug_state=state;assign debug_faults=faults;
 assign busy=state!=IDLE;
 assign request_valid=state==SEND_SETUP || state==SEND_DATA || state==SEND_STATUS;
 assign request_kind=state==SEND_SETUP?2'd2:state==SEND_DATA?2'd0:read_request?2'd1:2'd0;
 assign request_toggle=state==SEND_SETUP?1'b0:state==SEND_STATUS?1'b1:toggle;
 assign request_length=state==SEND_SETUP?4'd8:4'd0;
 assign request_data=state==SEND_SETUP?saved_setup:64'd0;
 always @(posedge clk)begin
  if(!rst_n)begin state<=IDLE;resume<=IDLE;done<=0;error<=0;data_valid<=0;
   saved_setup<=0;remaining<=0;read_request<=0;toggle<=1;watchdog<=0;
   delay_count<=0;faults<=0;data_length<=0;data<=0;debug_failure_stage<=0;debug_reason<=0;debug_retries<=0;end
  else begin
   done<=0;data_valid<=0;
   if(state!=IDLE)watchdog<=watchdog+1'b1;
   case(state)
    IDLE:if(start)begin
     saved_setup<=setup;remaining<=setup[63:48];read_request<=setup[7];
     toggle<=1;watchdog<=0;faults<=0;error<=0;state<=SEND_SETUP;debug_failure_stage<=0;debug_reason<=0;debug_retries<=0;
    end
    SEND_SETUP:if(request_ready)state<=WAIT_SETUP;
    SEND_DATA:if(request_ready)state<=WAIT_DATA;
    SEND_STATUS:if(request_ready)state<=WAIT_STATUS;
    WAIT_SETUP,WAIT_DATA,WAIT_STATUS:if(response_done)begin
     debug_failure_stage<=state;
     if(response_result==0)begin
      faults<=0;
      if(state==WAIT_SETUP)begin
       if(remaining==0)state<=SEND_STATUS;
       else if(read_request)state<=SEND_DATA;
       else begin debug_reason<=3;error<=1;done<=1;state<=IDLE;end // no control OUT payload in this scope
      end else if(state==WAIT_DATA)begin
       if(response_length>remaining)begin debug_reason<=4;error<=1;done<=1;state<=IDLE;end
       else begin
        data_valid<=1;data_length<=response_length;data<=response_data;
        remaining<=remaining-response_length;toggle<=!toggle;
        if(response_length<ep0_mps || response_length==remaining)state<=SEND_STATUS;
        else state<=SEND_DATA;
       end
      end else begin
       debug_reason<=(!read_request && response_length!=0)?8'd5:8'd0;
       error<=(!read_request && response_length!=0);done<=1;state<=IDLE;
      end
     end else if(response_result==2 || (response_result==3 && faults==3))begin
      debug_reason<=response_result==2?8'd1:8'd2;error<=1;done<=1;state<=IDLE;
     end else begin
      if(!retry_saturated)debug_retries<={debug_retries[15:8]+{7'd0,retry_carry},debug_retries[7:0]+8'd1};
      if(response_result==3)faults<=faults+1'b1;
      resume<=state==WAIT_SETUP?SEND_SETUP:state==WAIT_DATA?SEND_DATA:SEND_STATUS;
      delay_count<=0;state<=DELAY;
     end
    end
    DELAY:if(delay_count==9599)state<=resume;else delay_count<=delay_count+1'b1;
    default:state<=IDLE;
   endcase
   if(state!=IDLE && watchdog==47999999)begin debug_reason<=6;debug_failure_stage<=state;error<=1;done<=1;state<=IDLE;end
  end
 end
endmodule
`default_nettype wire
