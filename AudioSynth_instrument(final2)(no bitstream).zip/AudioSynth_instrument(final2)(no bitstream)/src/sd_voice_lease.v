`default_nettype none
// Slot configuration-publication guard. Does not allocate musical
// notes or drive a core yet. req must remain valid/data stable until ready.
// kind:0 reserve,1 OP written,2 metadata written,3 commit,4 cancel.
module sd_voice_lease #(parameter integer CANCEL_ALL_ENABLE=0,parameter integer VOICES=40)(input wire clk,rst_n,req_valid,input wire [2:0] req_kind,
 input wire [5:0] req_slot,input wire [31:0] req_token,input wire [2:0] req_op,
 output wire req_ready,output reg resp_valid,resp_ok,output reg [31:0] resp_token,
 output reg op_accept,meta_accept,commit_valid,output reg [5:0] accepted_slot,
 output reg [VOICES-1:0] reserved,input wire cancel_all);
 // Token32 + six OP-complete bits + metadata-complete bit in the same RAM.
 // Only the occupied mask needs parallel visibility to the allocator.
 (* syn_ramstyle="block_ram" *)reg [38:0] tokens[0:63];
 reg [38:0] token_q;reg [31:0] counter;
 reg state;reg [2:0] kind,op;reg [5:0] slot;reg [31:0] token;
 assign req_ready=!state;
 always @(posedge clk)begin
  token_q<=tokens[req_slot];
  if(!rst_n)begin
   counter<=0;reserved<=0;state<=0;kind<=0;op<=0;slot<=0;token<=0;
   resp_valid<=0;resp_ok<=0;resp_token<=0;op_accept<=0;meta_accept<=0;commit_valid<=0;accepted_slot<=0;
  end else if(CANCEL_ALL_ENABLE && cancel_all)begin
   // Soft card/CPU loss invalidates pending work without reusing generations.
   reserved<=0;state<=0;resp_valid<=0;resp_ok<=0;
   op_accept<=0;meta_accept<=0;commit_valid<=0;
  end else begin
   resp_valid<=0;op_accept<=0;meta_accept<=0;commit_valid<=0;
   if(!state)begin
    if(req_valid)begin kind<=req_kind;slot<=req_slot;token<=req_token;op<=req_op;state<=1;end
   end else begin
    state<=0;resp_valid<=1;resp_ok<=0;resp_token<=token;accepted_slot<=slot;
    if(slot<VOICES)begin
     if(kind==0)begin
      // Refuse overflow instead of reusing a live generation identifier.
      if(counter!=32'hffffffff)begin counter<=counter+1'b1;tokens[slot]<={7'd0,counter+32'd1};reserved[slot]<=1;resp_token<=counter+1'b1;resp_ok<=1;end
     end else if(kind==4)begin
      // A delayed cancel must not invalidate a newer reservation either.
      if(reserved[slot] && token_q[31:0]==token)begin reserved[slot]<=0;resp_ok<=1;end
     end
     else if(reserved[slot] && token_q[31:0]==token)case(kind)
      1:if(op<6)begin tokens[slot]<=token_q|{1'b0,(6'b1<<op),32'd0};op_accept<=1;resp_ok<=1;end
      2:begin tokens[slot]<=token_q|39'h4000000000;meta_accept<=1;resp_ok<=1;end
      3:if(&token_q[38:32])begin reserved[slot]<=0;commit_valid<=1;resp_ok<=1;end
      default:begin end
     endcase
    end
   end
  end
 end
endmodule
`default_nettype wire
