`default_nettype none
// 64 complete 192-bit records in a 48-bit wide RAM. Four writes commit one
// record atomically; partial records are never visible. Engine events are at
// least five clocks apart. ready accounts for staging, reading and output.
module usb3_event_queue(
 input wire clk,rst_n,push,input wire [191:0] data,output wire ready,
 output reg valid,output reg [191:0] q,input wire pop,output reg [6:0] level);
 reg [47:0] mem[0:255];
 reg [191:0] stage;
 reg writing,reading;reg [1:0] wp;reg [2:0] rp;
 reg [5:0] wr_record,rd_record;reg [6:0] committed;
 reg [47:0] ram_q;
 wire take=pop && valid;
 assign ready=(level<64 || take) && (!writing || wp==3);
 wire put=push && ready;
 wire finish_write=writing && wp==3;
 wire begin_read=!reading && !valid && committed!=0;
 always @(posedge clk)begin
  if(writing)mem[{wr_record,wp}]<=stage[47:0];
  ram_q<=mem[{rd_record,rp[1:0]}];
  if(!rst_n)begin
   stage<=0;writing<=0;reading<=0;wp<=0;rp<=0;
   wr_record<=0;rd_record<=0;committed<=0;level<=0;valid<=0;q<=0;
  end else begin
   case({put,take})2'b10:level<=level+1'b1;2'b01:level<=level-1'b1;default:begin end endcase
   case({finish_write,begin_read})2'b10:committed<=committed+1'b1;2'b01:committed<=committed-1'b1;default:begin end endcase
   if(take)valid<=0;
   if(writing)begin
    stage<=stage>>48;wp<=wp+1'b1;
    if(wp==3)begin writing<=0;wr_record<=wr_record+1'b1;end
   end
   if(put)begin stage<=data;writing<=1;wp<=0;end
   if(begin_read)begin reading<=1;rp<=0;end
   if(reading)begin
    rp<=rp+1'b1;
    case(rp)
     1:q[47:0]<=ram_q;2:q[95:48]<=ram_q;3:q[143:96]<=ram_q;
     4:begin q[191:144]<=ram_q;valid<=1;reading<=0;rd_record<=rd_record+1'b1;end
     default:begin end
    endcase
   end
  end
 end
endmodule
`default_nettype wire
