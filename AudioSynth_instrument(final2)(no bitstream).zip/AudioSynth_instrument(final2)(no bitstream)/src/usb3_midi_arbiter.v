`default_nettype none
// One gate per (CH1/CH10,note), separate source ownership and sustain state.
// Local queue wins normal arbitration. Disconnect/timeout scans only that source.
module usb3_midi_arbiter #(parameter SD_ENABLE=0,parameter HW_PATCH=0)(
 input wire clk,rst_n,audio_ok,local_online,local_fault,
 input wire local_valid,input wire [39:0] local_data,
 input wire pc_valid,input wire [39:0] pc_data,input wire [95:0] pc_tag,output wire pc_ready,
 input wire pc_release,backend_fault,input wire [31:0] cycles,
 output reg event_valid,output reg [39:0] event_data,output reg [95:0] event_tag,
 output wire synth_online,output reg [31:0] local_overflow,
 output reg [31:0] dispatched,suppressed,recoveries,
 input wire sd_valid,input wire [39:0] sd_data,input wire [95:0] sd_tag,output wire sd_ready,input wire sd_release,
 input wire [15:0] dynamic_channels,input wire [7:0] string_patch,output wire local_ready);
 wire local_good=local_online && !local_fault;
 wire lv,lr;wire [79:0] ld;reg lp,panic;
 wire [4:0] local_level;
 assign local_ready=local_good && lr && !panic && local_level<15;
 usb3_buffered_fifo #(.W(80),.A(4),.STYLE("block_ram")) local_queue(clk,rst_n && local_good && !panic,
  local_valid && local_good,{string_patch,cycles,local_data},lr,lv,ld,lp,local_level);
 wire local_loss=local_valid && local_good && !lr && !panic;
 reg [15:0] old_dynamic;
 reg [255:0] local_held,pc_held,sd_held;
 reg local_pedal,pc_pedal,sd_pedal,old_good,old_backend;
 reg [5:0] pending_release;
 reg [2:0] state;reg [1:0] source;
 reg [39:0] selected;reg [95:0] selected_tag;
 reg [1:0] cleanup_source;reg [7:0] cleanup_index;reg [4:0] cooldown;
 wire selected_channel=!HW_PATCH && (selected[27:24]==0 || selected[27:24]==9) && !(SD_ENABLE && dynamic_channels[selected[27:24]]);
 wire [7:0] note_index={selected[27:24]==9,selected[23:17]};
 wire own_bit=source==0?local_held[note_index]:source==1?pc_held[note_index]:sd_held[note_index];
 wire other_bit=source==0?(pc_held[note_index]||sd_held[note_index]):source==1?(local_held[note_index]||sd_held[note_index]):(local_held[note_index]||pc_held[note_index]);
 wire is_on=selected[31:28]==2 && selected[16:10]!=0;
 wire is_off=selected[31:28]==1 || (selected[31:28]==2 && selected[16:10]==0);
 wire is_cc=selected[31:28]==3 && selected[27:24]==0;
 wire source_pedal=selected[16];
 wire other_pedal=source==0?(pc_pedal||sd_pedal):source==1?(local_pedal||sd_pedal):(local_pedal||pc_pedal);
 wire cleanup_own=cleanup_source==0?local_held[cleanup_index]:cleanup_source==1?pc_held[cleanup_index]:sd_held[cleanup_index];
 wire cleanup_other=cleanup_source==0?(pc_held[cleanup_index]||sd_held[cleanup_index]):cleanup_source==1?(local_held[cleanup_index]||sd_held[cleanup_index]):(local_held[cleanup_index]||pc_held[cleanup_index]);
 wire [3:0] cleanup_channel=cleanup_index[7]?4'd9:4'd0;
 assign pc_ready=state==0 && local_level==0 && !(local_valid && local_good) && pending_release==0 && !panic && audio_ok;
 assign sd_ready=SD_ENABLE && pc_ready && !pc_valid;
 assign synth_online=audio_ok && !panic;
 always @(posedge clk)begin
  if(!rst_n)begin
   local_held<=0;pc_held<=0;sd_held<=0;local_pedal<=0;pc_pedal<=0;sd_pedal<=0;old_good<=0;old_backend<=0;
   old_dynamic<=0;state<=0;pending_release<=0;source<=0;selected<=0;selected_tag<=0;
   cleanup_source<=0;cleanup_index<=0;cooldown<=0;lp<=0;panic<=0;
   event_valid<=0;event_data<=0;event_tag<=0;local_overflow<=0;dispatched<=0;suppressed<=0;recoveries<=0;
  end else begin
   event_valid<=0;lp<=0;panic<=0;old_good<=local_good;old_backend<=backend_fault;
   if(!HW_PATCH && old_good && !local_good)pending_release[1:0]<=2'b11;
   if(!HW_PATCH && pc_release)pending_release[3:2]<=2'b11;
   if(SD_ENABLE && !HW_PATCH && sd_release)pending_release[5:4]<=2'b11;
   if(local_loss && !(&local_overflow))local_overflow<=local_overflow+1'b1;
   if(local_loss || (backend_fault && !old_backend))begin
    // A real queue loss makes note ownership unknowable. Release all once;
    // original instrument offline safety clears its FIFO and every gate.
    panic<=1;local_held<=0;pc_held<=0;sd_held<=0;local_pedal<=0;pc_pedal<=0;sd_pedal<=0;
    pending_release<=0;state<=0;recoveries<=recoveries+1'b1;
   end else case(state)
    0:begin
     if(pending_release!=0)begin
      cooldown<=0;
      if(pending_release[0])begin cleanup_source<=0;cleanup_index<=0;pending_release[0]<=0;local_pedal<=0;end
      else if(pending_release[1])begin cleanup_source<=0;cleanup_index<=128;pending_release[1]<=0;end
      else if(pending_release[2])begin cleanup_source<=1;cleanup_index<=0;pending_release[2]<=0;pc_pedal<=0;end
      else if(pending_release[3])begin cleanup_source<=1;cleanup_index<=128;pending_release[3]<=0;end
      else if(pending_release[4])begin cleanup_source<=2;cleanup_index<=0;pending_release[4]<=0;sd_pedal<=0;end
      else begin cleanup_source<=2;cleanup_index<=128;pending_release[5]<=0;end
      state<=3;
     end else if(lv && audio_ok)begin
      selected<=ld[39:0];selected_tag<=(HW_PATCH && ld[39:36]==4'hf && ld[27:24]==1)?
       {8'd0,8'hf1,ld[79:72],40'd0,ld[71:40]}:{64'd0,ld[71:40]};source<=0;lp<=1;state<=1;
     end else if(pc_valid && pc_ready)begin selected<=pc_data;selected_tag<=pc_tag;source<=1;state<=1;end
     else if(sd_valid && sd_ready)begin selected<=sd_data;selected_tag<=sd_tag;source<=2;state<=1;end
    end
    1:begin
     state<=2;event_data<=selected;event_tag<=selected_tag;
     if(!source && !local_good)begin suppressed<=suppressed+1'b1;end
     else if(selected_channel && (is_on || is_off))begin
      if(source==0)local_held[note_index]<=is_on;else if(source==1)pc_held[note_index]<=is_on;else sd_held[note_index]<=is_on;
      if((is_on && !other_bit) || (is_off && own_bit && !other_bit))begin
       event_valid<=1;dispatched<=dispatched+1'b1;
      end else suppressed<=suppressed+1'b1;
     end else if(is_cc && selected_channel && selected[23:17]==64)begin
      if(source==0)local_pedal<=source_pedal;else if(source==1)pc_pedal<=source_pedal;else sd_pedal<=source_pedal;
      event_data[16:10]<=(source_pedal || other_pedal)?7'd127:7'd0;
      event_valid<=1;dispatched<=dispatched+1'b1;
     end else if(selected_channel && selected[31:28]==3 && (selected[23:17]==120 || selected[23:17]==123))begin
      pending_release[{source,selected[27:24]==9}]<=1;
     end else begin event_valid<=1;dispatched<=dispatched+1'b1;end
    end
    // Leave a full cycle between local FIFO pop and re-selection.
    2:state<=0;
    3:begin
     // Drop only the leaving source's pedal; preserve the other source pedal.
     event_valid<=!cleanup_index[7];
     event_data<={4'd0,4'hb,4'd3,4'd0,7'd64,((cleanup_source==0?(pc_pedal||sd_pedal):cleanup_source==1?(local_pedal||sd_pedal):(local_pedal||pc_pedal))?7'd127:7'd0),2'd3,8'hb0};
     event_tag<={8'd2,8'd0,16'd0,32'd0,cycles};if(!cleanup_index[7])dispatched<=dispatched+1'b1;state<=4;
    end
    4:begin
     if(cooldown!=0)cooldown<=cooldown-1'b1;
     else begin
      cooldown<=31;
      if(cleanup_source==0)local_held[cleanup_index]<=0;else if(cleanup_source==1)pc_held[cleanup_index]<=0;else sd_held[cleanup_index]<=0;
      if(cleanup_own && !cleanup_other)begin
       event_valid<=1;
       event_data<={4'd0,4'h8,4'd1,cleanup_channel,cleanup_index[6:0],7'd0,2'd3,{4'h8,cleanup_channel}};
       event_tag<={8'd2,8'd0,16'd0,32'd0,cycles};dispatched<=dispatched+1'b1;
      end
      if(cleanup_index[6:0]==127)state<=0;else cleanup_index<=cleanup_index+1'b1;
     end
    end
    default:state<=0;
   endcase
   old_dynamic<=dynamic_channels;
   if(SD_ENABLE && old_dynamic[0]!=dynamic_channels[0])begin local_held[127:0]<=0;pc_held[127:0]<=0;sd_held[127:0]<=0;local_pedal<=0;pc_pedal<=0;sd_pedal<=0;end
   if(SD_ENABLE && old_dynamic[9]!=dynamic_channels[9])begin local_held[255:128]<=0;pc_held[255:128]<=0;sd_held[255:128]<=0;end
  end
 end
endmodule
`default_nettype wire
