`default_nettype none
module instrument_celesta_config(input wire clk,input wire [9:0] addr,output wire [172:0] q);
 wire [1:0] family=addr[2:0]==0?2'd0:addr[2:0]==3?2'd1:2'd2;
 wire [31:0] fcw;
 instrument_celesta_frequency frequency(clk,{addr[9:3],family},fcw);
 reg [3:0] rate_group;reg [2:0] op;
 always @(posedge clk)begin
  op<=addr[2:0];case(addr[9:3])
7'd0:rate_group<=4'd0;
7'd1:rate_group<=4'd0;
7'd2:rate_group<=4'd0;
7'd3:rate_group<=4'd0;
7'd4:rate_group<=4'd0;
7'd5:rate_group<=4'd0;
7'd6:rate_group<=4'd0;
7'd7:rate_group<=4'd0;
7'd8:rate_group<=4'd0;
7'd9:rate_group<=4'd0;
7'd10:rate_group<=4'd0;
7'd11:rate_group<=4'd0;
7'd12:rate_group<=4'd0;
7'd13:rate_group<=4'd0;
7'd14:rate_group<=4'd0;
7'd15:rate_group<=4'd0;
7'd16:rate_group<=4'd0;
7'd17:rate_group<=4'd0;
7'd18:rate_group<=4'd0;
7'd19:rate_group<=4'd0;
7'd20:rate_group<=4'd0;
7'd21:rate_group<=4'd0;
7'd22:rate_group<=4'd0;
7'd23:rate_group<=4'd0;
7'd24:rate_group<=4'd0;
7'd25:rate_group<=4'd0;
7'd26:rate_group<=4'd0;
7'd27:rate_group<=4'd0;
7'd28:rate_group<=4'd0;
7'd29:rate_group<=4'd0;
7'd30:rate_group<=4'd1;
7'd31:rate_group<=4'd1;
7'd32:rate_group<=4'd1;
7'd33:rate_group<=4'd1;
7'd34:rate_group<=4'd1;
7'd35:rate_group<=4'd1;
7'd36:rate_group<=4'd1;
7'd37:rate_group<=4'd1;
7'd38:rate_group<=4'd1;
7'd39:rate_group<=4'd2;
7'd40:rate_group<=4'd2;
7'd41:rate_group<=4'd2;
7'd42:rate_group<=4'd2;
7'd43:rate_group<=4'd2;
7'd44:rate_group<=4'd2;
7'd45:rate_group<=4'd3;
7'd46:rate_group<=4'd3;
7'd47:rate_group<=4'd3;
7'd48:rate_group<=4'd3;
7'd49:rate_group<=4'd3;
7'd50:rate_group<=4'd3;
7'd51:rate_group<=4'd3;
7'd52:rate_group<=4'd3;
7'd53:rate_group<=4'd3;
7'd54:rate_group<=4'd4;
7'd55:rate_group<=4'd4;
7'd56:rate_group<=4'd4;
7'd57:rate_group<=4'd4;
7'd58:rate_group<=4'd4;
7'd59:rate_group<=4'd4;
7'd60:rate_group<=4'd4;
7'd61:rate_group<=4'd4;
7'd62:rate_group<=4'd4;
7'd63:rate_group<=4'd5;
7'd64:rate_group<=4'd5;
7'd65:rate_group<=4'd5;
7'd66:rate_group<=4'd5;
7'd67:rate_group<=4'd5;
7'd68:rate_group<=4'd5;
7'd69:rate_group<=4'd6;
7'd70:rate_group<=4'd6;
7'd71:rate_group<=4'd6;
7'd72:rate_group<=4'd6;
7'd73:rate_group<=4'd6;
7'd74:rate_group<=4'd6;
7'd75:rate_group<=4'd6;
7'd76:rate_group<=4'd6;
7'd77:rate_group<=4'd6;
7'd78:rate_group<=4'd7;
7'd79:rate_group<=4'd7;
7'd80:rate_group<=4'd7;
7'd81:rate_group<=4'd7;
7'd82:rate_group<=4'd7;
7'd83:rate_group<=4'd7;
7'd84:rate_group<=4'd7;
7'd85:rate_group<=4'd7;
7'd86:rate_group<=4'd7;
7'd87:rate_group<=4'd8;
7'd88:rate_group<=4'd8;
7'd89:rate_group<=4'd8;
7'd90:rate_group<=4'd8;
7'd91:rate_group<=4'd8;
7'd92:rate_group<=4'd8;
7'd93:rate_group<=4'd9;
7'd94:rate_group<=4'd9;
7'd95:rate_group<=4'd9;
7'd96:rate_group<=4'd9;
7'd97:rate_group<=4'd9;
7'd98:rate_group<=4'd9;
7'd99:rate_group<=4'd9;
7'd100:rate_group<=4'd9;
7'd101:rate_group<=4'd9;
7'd102:rate_group<=4'd10;
7'd103:rate_group<=4'd10;
7'd104:rate_group<=4'd10;
7'd105:rate_group<=4'd10;
7'd106:rate_group<=4'd10;
7'd107:rate_group<=4'd10;
7'd108:rate_group<=4'd10;
7'd109:rate_group<=4'd10;
7'd110:rate_group<=4'd10;
7'd111:rate_group<=4'd11;
7'd112:rate_group<=4'd11;
7'd113:rate_group<=4'd11;
7'd114:rate_group<=4'd11;
7'd115:rate_group<=4'd11;
7'd116:rate_group<=4'd11;
7'd117:rate_group<=4'd11;
7'd118:rate_group<=4'd11;
7'd119:rate_group<=4'd11;
7'd120:rate_group<=4'd11;
7'd121:rate_group<=4'd11;
7'd122:rate_group<=4'd11;
7'd123:rate_group<=4'd11;
7'd124:rate_group<=4'd11;
7'd125:rate_group<=4'd11;
7'd126:rate_group<=4'd11;
7'd127:rate_group<=4'd11;
endcase end
reg [31:0] a,bslow,bfast,c,d;reg [12:0] base;
always @* begin
case(rate_group)
4'd0:begin a=32'd38535167;bslow=32'd26342;bfast=32'd7707033;c=32'd15052;d=32'd75263;end
4'd1:begin a=32'd46242201;bslow=32'd30105;bfast=32'd9633791;c=32'd18815;d=32'd90316;end
4'd2:begin a=32'd53949234;bslow=32'd37631;bfast=32'd11560550;c=32'd22579;d=32'd105369;end
4'd3:begin a=32'd53949234;bslow=32'd45158;bfast=32'd13487308;c=32'd26342;d=32'd120422;end
4'd4:begin a=32'd53949234;bslow=32'd52684;bfast=32'd15414067;c=32'd30105;d=32'd150527;end
4'd5:begin a=32'd53949234;bslow=32'd60211;bfast=32'd19267583;c=32'd37631;d=32'd180633;end
4'd6:begin a=32'd53949234;bslow=32'd75263;bfast=32'd23121100;c=32'd45158;d=32'd210739;end
4'd7:begin a=32'd53949234;bslow=32'd90316;bfast=32'd26974617;c=32'd52684;d=32'd240844;end
4'd8:begin a=32'd53949234;bslow=32'd105369;bfast=32'd30828134;c=32'd60211;d=32'd301055;end
4'd9:begin a=32'd53949234;bslow=32'd120422;bfast=32'd38535167;c=32'd75263;d=32'd361267;end
4'd10:begin a=32'd53949234;bslow=32'd150527;bfast=32'd46242201;c=32'd90316;d=32'd421478;end
4'd11:begin a=32'd53949234;bslow=32'd180633;bfast=32'd53949234;c=32'd105369;d=32'd481689;end
default:begin a=0;bslow=0;bfast=0;c=0;d=0;end
endcase
case(op)
3'd0:base=13'd2976;
3'd1:base=13'd4064;
3'd2:base=13'd4000;
3'd3:base=13'd3712;
3'd4:base=13'd3648;
3'd5:base=13'd4064;
default:base=0;endcase
end
assign q={base,a,(op==1?bfast:bslow),c,d,fcw};
endmodule
`default_nettype wire
