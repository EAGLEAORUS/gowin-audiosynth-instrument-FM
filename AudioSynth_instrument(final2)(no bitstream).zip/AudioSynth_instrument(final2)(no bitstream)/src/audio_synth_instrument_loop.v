`default_nettype none
module audio_synth_instrument_loop #(parameter UI_ENABLE=0,PC_ENABLE=0,parameter SD_ONLY=0,parameter HW_PATCH=0,parameter integer VOICES_PER_CORE=10,parameter EXTERNAL_DISPLAY_SELECT=0)(
 input wire clk_50m,output wire es0_mclk,es1_mclk,
 output wire es7243_scl,inout wire es7243_sda,
 output wire es8156_scl,inout wire es8156_sda,
 input wire es0_dsclk,es0_alrck,es0_sdin,es1_dsclk,es1_dlrc,
 output wire es1_sdout,lin_led,
 input wire midi_evt_valid,input wire [39:0] midi_evt_data,
 input wire midi_online,midi_fault,midi_core_rst_n,
 output wire ws2812,input wire audio_ref_clk,audio_ref_locked,input wire k2_n,
 output wire analysis_valid,output wire [31:0] analysis_data,output wire analysis_stream_ok,analysis_reset_n,
 input wire signed [15:0] nes_pcm,output wire nes_rst_n,nes_sample_tick,
 input wire ui_patch_set,input wire [2:0] ui_patch,output wire [2:0] current_patch,output wire [6:0] current_volume,
 input wire [23:0] string_ratio,output wire [23:0] string_bend_ratio,
 input wire system_rst_n,input wire [95:0] event_tag,
 output wire capture_valid,output wire [47:0] capture_pcm,output wire [31:0] capture_index,
 output wire exec_valid,output wire [39:0] exec_data,output wire [95:0] exec_tag,
 output wire [767:0] actual_state,
 input wire [15:0] dynamic_mask,input wire cpu_enabled,
 output wire cpu_event_valid,output wire [39:0] cpu_event_data,output wire [95:0] cpu_event_tag,input wire cpu_event_ready,
 input wire cpu_ack_valid,input wire [95:0] cpu_ack_tag,
 output wire allocation_valid,output wire [5:0] allocation_slot,output wire [31:0] allocation_token,
 input wire config_valid,output wire config_ready,input wire [2:0] config_kind,
 input wire [5:0] config_slot,input wire [31:0] config_token,input wire [2:0] config_op,
 input wire [107:0] config_data,input wire [7:0] config_meta,
 output wire config_resp_valid,config_resp_ok,output wire [31:0] config_resp_token,config_faults,
 input wire [15:0] release_channels,input wire [3:0] release_sources,
 input wire control_valid,output wire control_ready,input wire [3:0] control_channel,input wire [34:0] control_data,
 input wire [8:0] library_count,
 output wire library_read,output wire [10:0] library_address,
 input wire [127:0] library_data,
 input wire hw_write,input wire [11:0] hw_address,input wire [31:0] hw_data,
 output wire [31:0] hw_read,output wire [15:0] hw_active,output wire [15:0] upper_busy,input wire string_mode,output wire [8:0] piano_patch,output wire [15:0] nes_status);
 reg [15:0] por=0;
 always @(posedge clk_50m)if(PC_ENABLE && !system_rst_n)por<=0;else if(!(&por))por<=por+1'b1;
 wire mclk,locked,core_rst_n;
 FM6_pll12288 clock_audio(mclk,locked,audio_ref_clk,!(&por) || !audio_ref_locked);
 assign es0_mclk=mclk;assign es1_mclk=mclk;
 audio_usb_reset reset_core(clk_50m,(&por)&&locked&&(!PC_ENABLE || system_rst_n),core_rst_n);
 // Preserve at least the old 0x50000-MCLK startup guard at 12.288MHz:
 // ceil(327680 * 50MHz / 12.288MHz) = 1,333,334 core cycles (26.66668ms).
 reg [20:0] startup=0;
 always @(posedge clk_50m)if(!core_rst_n)startup<=0;
 else if(startup!=21'd1333334)startup<=startup+1'b1;
 wire config_rst_n=core_rst_n && startup==21'd1333334;
 reg [7:0] ce_count=0;
 wire ce=ce_count==8'd247;
 always @(posedge clk_50m)if(ce)ce_count<=0;else ce_count<=ce_count+1'b1;
 wire adc_done,dac_done,adc_ack,dac_ack;
 (* syn_keep=1 *) wire adc_healthy,dac_healthy;
 wire adc_retry,dac_retry;
 wire adc_config_rst_n=config_rst_n && !adc_retry;
 wire dac_config_rst_n=config_rst_n && !dac_retry;
 audio_usb_codec_health adc_health(clk_50m,config_rst_n,adc_done,es0_dsclk,es0_alrck,adc_healthy,adc_retry);
 audio_usb_codec_health dac_health(clk_50m,config_rst_n,dac_done,es1_dsclk,es1_dlrc,dac_healthy,dac_retry);
 audio_usb_es7243e_config #(.DATA_WIDTH(16)) adc_config(clk_50m,ce,adc_config_rst_n,es7243_scl,es7243_sda,adc_done,adc_ack);
 (* syn_keep=1 *) wire [6:0] output_volume;
 wire [7:0] volume_code;wire volume_mute;
 (* syn_keep=1 *) wire [31:0] volume_events,volume_nacks;
 (* syn_keep=1 *) wire [7:0] applied_volume;
 (* syn_keep=1 *) wire applied_mute,volume_busy;
 FM6_output_volume volume_control(clk_50m,core_rst_n,midi_evt_valid,midi_evt_data,
  midi_online && !midi_fault && midi_core_rst_n,output_volume,volume_code,volume_mute,volume_events);
 audio_usb_es8156_config #(.VOLUME_ENABLE(1)) dac_config(
  .clk_50m(clk_50m),.ce(ce),.rstn(dac_config_rst_n),.i2c_sclk(es8156_scl),.i2c_sdat(es8156_sda),
  .reg_conf_done(dac_done),.i2c_ack(dac_ack),.volume_code(volume_code),.mute_request(volume_mute),
  .applied_volume(applied_volume),.applied_mute(applied_mute),.volume_busy(volume_busy),.volume_nacks(volume_nacks));
 // DAC/DDS startup never waits for ADC configuration or ADC clock activity.
 wire audio_ready=dac_config_rst_n && dac_done;
 wire frame_ready=adc_config_rst_n && adc_done && adc_healthy;
 audio_usb_ws2812_status rgb_status(clk_50m,(&por),dac_healthy,adc_healthy,ws2812);
 audio_usb_status_led status_led(clk_50m,core_rst_n,(dac_healthy && adc_healthy),lin_led);
 wire rx_rst_n,tx_rst_n,frame_rd_rst_n;
 audio_usb_reset #(.RELEASE_FALLING(1)) reset_rx(es0_dsclk,frame_ready,rx_rst_n);
 audio_usb_reset reset_tx(es1_dsclk,audio_ready,tx_rst_n);
 audio_usb_reset reset_frame_rd(clk_50m,frame_ready,frame_rd_rst_n);
 wire frame_valid,fifo_ready,out_valid;
 wire signed [23:0] pcm_l,pcm_r;wire [31:0] adc_analysis_data;
 (* syn_keep=1 *) wire [31:0] overflow,underrun,frame_errors;
 audio_usb_i2s_rx24 #(.DATA_WIDTH(16)) rx(es0_dsclk,rx_rst_n,es0_alrck,es0_sdin,frame_valid,pcm_l,pcm_r,frame_errors);
 // Independent ADC -> 50MHz analysis FIFO; the DAC is never an analysis consumer.
 usb_packet_async_fifo #(.WIDTH(32),.ADDR_BITS(3)) frame_fifo(
  es0_dsclk,rx_rst_n,frame_valid,{pcm_l[23:8],pcm_r[23:8]},fifo_ready,overflow,
  clk_50m,frame_rd_rst_n,out_valid,adc_analysis_data,1'b1);
 generate if(EXTERNAL_DISPLAY_SELECT)begin:adc_display_output
  // The top independently selects ADC or post-effects PCM.
  assign analysis_valid=out_valid && frame_rd_rst_n;
  assign analysis_stream_ok=frame_rd_rst_n;
  assign analysis_data=adc_analysis_data;
 end else begin:automatic_display_output
  // Display the actual instrument output, including the effect mix.
  // When the DAC is unavailable, the external ADC still drives the display.
  reg display_pcm,display_pcm_d;
  reg display_valid,display_stream_ok;
  (* syn_preserve=1 *) reg [31:0] display_sample;
  always @(posedge clk_50m)begin
   if(!core_rst_n)begin
    display_pcm<=0;display_pcm_d<=0;display_valid<=0;display_stream_ok<=0;
   end else begin
    display_pcm<=nes_rst_n;display_pcm_d<=display_pcm;
    display_valid<=display_pcm?capture_valid:out_valid && frame_rd_rst_n;
    display_stream_ok<=(display_pcm==display_pcm_d) && (display_pcm?nes_rst_n:frame_rd_rst_n);
   end
   display_sample<=display_pcm?{capture_pcm[47:32],capture_pcm[23:8]}:adc_analysis_data;
  end
  assign analysis_valid=display_valid;
  assign analysis_stream_ok=display_stream_ok;
  assign analysis_data=display_sample;
 end endgenerate
 assign analysis_reset_n=core_rst_n;
 wire [2:0] patch_select;
 instrument_patch_key #(.UI_ENABLE(UI_ENABLE)) patch_key(.clk(clk_50m),.rst_n(core_rst_n),.k2_n(k2_n),.patch_select(patch_select),.ui_set(ui_patch_set),.ui_patch(ui_patch));
 assign current_patch=patch_select;assign current_volume=output_volume;
 wire [623:0] synth_state;
 wire [15:0] upper_gate=synth_state[623:608];
 assign upper_busy=synth_state[607:592];
 instrument_tdm64_audio_adapter #(.TRACE_ENABLE(PC_ENABLE),.RELEASE_CONTROL_ENABLE(1),.CHANNEL_CONTROL_ENABLE(1),.SD_ONLY(SD_ONLY),.HW_PATCH(HW_PATCH),.VOICES_PER_CORE(VOICES_PER_CORE)) synth(clk_50m,audio_ready && midi_core_rst_n,midi_evt_valid,midi_evt_data,
  midi_online,midi_fault,patch_select,es1_dsclk,tx_rst_n,es1_dlrc,es1_sdout,underrun,
  nes_pcm,nes_rst_n,nes_sample_tick,string_ratio,string_bend_ratio,event_tag,
  capture_valid,capture_pcm,capture_index,exec_valid,exec_data,exec_tag,synth_state,dynamic_mask,cpu_enabled,cpu_event_valid,cpu_event_data,cpu_event_tag,cpu_event_ready,cpu_ack_valid,cpu_ack_tag,
 allocation_valid,allocation_slot,allocation_token,config_valid,config_ready,config_kind,config_slot,config_token,config_op,config_data,config_meta,
 config_resp_valid,config_resp_ok,config_resp_token,config_faults,release_channels,release_sources,control_valid,control_ready,control_channel,control_data,
  library_count,library_read,library_address,library_data,
  hw_write,hw_address,hw_data,hw_read,hw_active,string_mode,piano_patch,nes_status);
 wire [63:0] adc_counter_snapshot;wire [31:0] dac_counter_snapshot;
 wire adc_counter_valid,dac_counter_valid;
 usb3_status_cdc #(.W(64)) adc_stats(clk_50m,core_rst_n,es0_dsclk,rx_rst_n,
  {overflow,frame_errors},adc_counter_snapshot,adc_counter_valid);
 usb3_status_cdc #(.W(32)) dac_stats(clk_50m,core_rst_n,es1_dsclk,tx_rst_n,
  underrun,dac_counter_snapshot,dac_counter_valid);
 assign actual_state={upper_gate[15:10],dac_counter_valid,adc_counter_valid,adc_counter_snapshot,dac_counter_snapshot,volume_nacks,
  upper_gate[9:3],volume_busy,applied_mute,applied_volume,output_volume,
  VOICES_PER_CORE==16,upper_gate[2:0],synth_state[591:576],1'b0,patch_select,frame_ready,audio_ready,dac_healthy,adc_healthy,dac_done,adc_done,locked,1'b0,synth_state[575:0]};
 // Synth startup continues to depend only on the DAC.
endmodule
`default_nettype wire
