`default_nettype none
// ESP32 Bluetooth link boundary.
//
//  * UART1 of the ESP32 firmware is a raw MIDI byte pipe at 115200 8N1 with no
//    flow control and no AT command interpreter. MIDI bytes from the phone are
//    parsed here into committed 40-bit events; events from the FPGA side are
//    serialized back to bytes.
//  * The event stream leaving the MIDI arbiter is merged with the ESP32 source
//    by a purely combinational 2:1 select: the original path keeps its exact
//    cycle latency, the ESP32 source only uses otherwise idle cycles.
//  * A free-running 32-bit local timer supervises the link (0xFE heartbeat) and
//    schedules the built-in pattern generator. Link loss releases every voice.
//  * Uplink keepalive: 0xFE every 250 ms proves the FPGA->ESP32 pad and wire.
//    TELEMETRY adds a once-per-second CC frame carrying bring-up counters so a
//    plain MIDI monitor on the PC can read the link state. ECHO mirrors every
//    received byte back and exists only for link bring-up builds.
module bt_midi_bridge #(
 parameter integer ENABLE_AUTOPLAY=0,
 parameter integer AUTOPLAY_IDLE_CYCLES=150000000,
 parameter integer LINK_TIMEOUT_CYCLES=60000000,
 parameter integer BEACON_CYCLES=12500000,
 parameter integer TELEMETRY=0,
 parameter integer ECHO=0
)(
 input wire clk,rst_n,
 input wire uart_rx,output wire uart_tx,
 input wire [31:0] cycles,
 input wire [5:0] dbg_in,
 input wire arb_valid,input wire [39:0] arb_data,input wire [95:0] arb_tag,
 output wire evt_valid,output wire [39:0] evt_data,output wire [95:0] evt_tag
);
 // --- received byte path -------------------------------------------------
 wire rx_valid;wire [7:0] rx_data;wire rx_error;
 bt_uart_rx #(.DIV(434)) rx(clk,rst_n,uart_rx,rx_valid,rx_data,rx_error);
 wire parse_valid;wire [39:0] parse_data;wire heartbeat;
 bt_midi_parse parser(clk,rst_n,rx_valid,rx_data,parse_valid,parse_data,heartbeat);

 // --- local time base and supervision ------------------------------------
 reg [31:0] now;
 reg [31:0] last_link,last_activity;
 reg dead,dead_old;
 always @(posedge clk)begin
  if(!rst_n)begin
   now<=32'd0;last_link<=32'd0;last_activity<=32'd0;dead<=1;dead_old<=1;
  end else begin
   now<=now+1'b1;
   // Only a received byte can revive a timed-out link, even across counter wrap.
   if(rx_valid)begin last_link<=now;dead<=0;end
   else if(!dead && (now-last_link)>=LINK_TIMEOUT_CYCLES)dead<=1;
   // Only real MIDI messages count as activity: the 0xFE keepalive that the
   // ESP32 sends every 250ms must not keep the built-in generator suppressed.
   if(parse_valid||arb_valid)last_activity<=now;
   dead_old<=dead;
  end
 end
 wire dead_rise=dead && !dead_old;
 wire idle=(ENABLE_AUTOPLAY!=0)&&((now-last_activity)>=AUTOPLAY_IDLE_CYCLES);

 // --- link-loss release: sustain off then all-notes-off on all 16 channels ---
 reg [1:0] kill_step;
 reg [3:0] kill_channel;
 wire kill_valid=(kill_step!=2'd0);
 wire [39:0] kill_data=(kill_step==2'd2)?
  {4'd0,4'hb,4'd3,kill_channel,7'd123,7'd0,2'd3,(8'hb0|{4'd0,kill_channel})}:
  {4'd0,4'hb,4'd3,kill_channel,7'd64,7'd0,2'd3,(8'hb0|{4'd0,kill_channel})};

 // --- single-entry event slot --------------------------------------------
 reg pend_valid;
 reg [39:0] pend_data;
 wire slot_free=!pend_valid && !parse_valid && !kill_valid;
 wire auto_valid;wire [39:0] auto_data;
 bt_midi_autoplay #(.HOLD_CYCLES(12500000),.GAP_CYCLES(12500000)) autoplay(
  clk,rst_n,idle,slot_free,auto_valid,auto_data);
 wire src_valid=kill_valid||parse_valid||auto_valid;
 wire [39:0] src_data=kill_valid?kill_data:(parse_valid?parse_data:auto_data);
 always @(posedge clk)begin
  if(!rst_n)pend_valid<=0;
  else if(pend_valid)begin
   if(!arb_valid)pend_valid<=0;
  end else if(src_valid)begin
   pend_valid<=1;pend_data<=src_data;
  end
 end
 always @(posedge clk)begin
  if(!rst_n)begin kill_step<=2'd0;kill_channel<=4'd0;end
  else if(dead_rise)begin kill_step<=2'd1;kill_channel<=4'd0;end
  else if(kill_valid && !pend_valid)begin
   if(kill_step==2'd1)kill_step<=2'd2;
   else if(kill_channel==4'd15)kill_step<=2'd0;
   else begin kill_step<=2'd1;kill_channel<=kill_channel+1'b1;end
  end
 end

 // --- merged committed stream --------------------------------------------
 assign evt_valid=arb_valid||pend_valid;
 assign evt_data=arb_valid?arb_data:pend_data;
 assign evt_tag=arb_valid?arb_tag:{64'd0,cycles};

 // --- bring-up counters ---------------------------------------------------
 reg [7:0] rxbytes,txbytes;
 reg [1:0] rxerr;
 reg parse_seen,arb_seen,auto_seen;
 reg [5:0] dbg_seen;
 always @(posedge clk)begin
  if(!rst_n)begin
   rxbytes<=8'd0;rxerr<=2'd0;
   parse_seen<=0;arb_seen<=0;auto_seen<=0;dbg_seen<=6'd0;
  end else begin
   if(rx_valid)rxbytes<=rxbytes+1'b1;
   if(rx_error)rxerr<=rxerr+1'b1;
   if(parse_valid)parse_seen<=1;
   if(arb_valid)arb_seen<=1;
   if(auto_valid)auto_seen<=1;
   dbg_seen<=dbg_seen|dbg_in;
  end
 end
 wire [7:0] state_dbg={auto_seen,arb_seen,parse_seen,pend_valid,dead,idle,1'b0,1'b0};

 // --- uplink keepalive and once-per-second telemetry frame ---------------
 reg [23:0] beat_cnt;
 reg [1:0] beat_phase;
 reg frame_active;
 reg [3:0] frame_idx;
 reg beacon_pend;
 reg echo_pend;
 reg [7:0] echo_byte;
 reg [7:0] frame_byte;
 always @(*)begin
  case(frame_idx)
   4'd0,4'd3,4'd6,4'd9,4'd12:frame_byte=8'hb0;
   4'd1:frame_byte=8'h14;
   4'd2:frame_byte=rxbytes;
   4'd4:frame_byte=8'h15;
   4'd5:frame_byte=txbytes;
   4'd7:frame_byte=8'h16;
   4'd8:frame_byte=state_dbg;
   4'd10:frame_byte=8'h17;
   4'd11:frame_byte={6'd0,rxerr};
   4'd13:frame_byte=8'h18;
   default:frame_byte={2'd0,dbg_seen};
  endcase
 end
 wire inject_active=frame_active||beacon_pend||echo_pend;
 wire [7:0] inject_byte=echo_pend?echo_byte:(frame_active?frame_byte:8'hfe);
 wire tx_ready;
 wire [7:0] ser_byte_data;
 wire ser_byte_valid;
 wire bf_ready,bf_valid;
 wire [7:0] bf_data;
 wire inject_go=inject_active && !ser_byte_valid;
 // The serializer holds a byte while the FIFO is full.
 wire fifo_push=(ser_byte_valid||inject_go) && bf_ready;
 wire [7:0] fifo_data=ser_byte_valid?ser_byte_data:inject_byte;
 always @(posedge clk)begin
  if(!rst_n)begin
   beat_cnt<=24'd0;beat_phase<=2'd0;frame_active<=0;frame_idx<=4'd0;
   beacon_pend<=0;echo_pend<=0;echo_byte<=8'd0;txbytes<=8'd0;
  end else begin
   if(beat_cnt>=BEACON_CYCLES-1)begin
    beat_cnt<=24'd0;beat_phase<=beat_phase+1'b1;
    if(TELEMETRY!=0 && (&beat_phase) && now<32'd3750000000)begin frame_active<=1;frame_idx<=4'd0;end
    else begin beacon_pend<=1;echo_pend<=0;end
   end else beat_cnt<=beat_cnt+1'b1;
   if(ECHO!=0 && rx_valid)begin echo_pend<=1;echo_byte<=rx_data;end
   if(inject_go && bf_ready)begin
    txbytes<=txbytes+1'b1;
    if(echo_pend)echo_pend<=0;
    else if(frame_active)begin
     if(frame_idx==4'd14)frame_active<=0;else frame_idx<=frame_idx+1'b1;
    end else beacon_pend<=0;
   end
  end
 end

 // --- transmit path -------------------------------------------------------
 wire sf_ready,sf_valid;wire [39:0] sf_data;wire [31:0] sf_overflow;
 wire ser_evt_ready;
 midi_sync_fifo #(.WIDTH(40),.ADDR_BITS(3)) snoop(clk,rst_n,evt_valid,evt_data,
  sf_ready,sf_valid,sf_data,sf_valid&&ser_evt_ready,sf_overflow);
 bt_midi_serialize serializer(clk,rst_n,sf_valid,sf_data,ser_evt_ready,
  ser_byte_valid,ser_byte_data,bf_ready);
 wire [31:0] byte_overflow;
 midi_sync_fifo #(.WIDTH(8),.ADDR_BITS(3)) bytes(clk,rst_n,fifo_push,fifo_data,
  bf_ready,bf_valid,bf_data,bf_valid&&tx_ready,byte_overflow);
 bt_uart_tx #(.DIV(434)) u_tx(clk,rst_n,bf_valid,bf_data,tx_ready,uart_tx);
endmodule
`default_nettype wire
