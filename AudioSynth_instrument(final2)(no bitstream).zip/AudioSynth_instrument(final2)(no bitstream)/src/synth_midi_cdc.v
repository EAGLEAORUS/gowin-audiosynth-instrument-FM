`default_nettype none
// Whole MIDI event FIFO, plus an independent fail-closed session/overflow level.
// Never block USB/UART. On any overflow release the voice; unplug clears fault.
module synth_midi_cdc(input wire core_clk,common_ready,event_valid,
 input wire [39:0] event_data,input wire midi_online,midi_fault,
 input wire audio_clk,output wire audio_rst_n,event_out_valid,
 output wire [39:0] event_out,output wire audio_online,
 output wire [31:0] overflow,output reg fault);
 wire wr_rst_n,rd_rst_n,wr_ready;
 audio_usb_reset wr_reset(core_clk,common_ready,wr_rst_n);
 audio_usb_reset rd_reset(audio_clk,common_ready,rd_rst_n);
 assign audio_rst_n=rd_rst_n;
 always @(posedge core_clk)begin
  if(!wr_rst_n)fault<=0;
  else if(!midi_online)fault<=0;
  else if(midi_fault || (event_valid && !wr_ready))fault<=1;
 end
 usb_packet_async_fifo #(.WIDTH(40),.ADDR_BITS(5)) event_fifo(
 core_clk,wr_rst_n,event_valid && midi_online && !fault,event_data,wr_ready,overflow,
 audio_clk,rd_rst_n,event_out_valid,event_out,1'b1);
 (* syn_preserve=1 *) reg online_meta,online_sync;
 always @(posedge audio_clk)begin
  if(!rd_rst_n)begin online_meta<=0;online_sync<=0;end
  else begin online_meta<=midi_online && !midi_fault && !fault;online_sync<=online_meta;end
 end
 assign audio_online=online_sync;
endmodule
`default_nettype wire
