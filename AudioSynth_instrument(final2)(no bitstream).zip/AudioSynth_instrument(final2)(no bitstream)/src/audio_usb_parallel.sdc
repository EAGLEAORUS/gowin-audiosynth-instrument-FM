create_clock -name clk_50m -period 20.000 [get_ports {clk_50m}]
create_generated_clock -name clk_usb -source [get_ports {clk_50m}] -multiply_by 48 -divide_by 25 [get_pins {usb/clock_usb/PLL_inst/CLKOUT0}]
// PHY pins are asynchronous; cut only pad -> first synchronizer stage.
set_false_path -from [get_ports {usb_dp usb_dm}] -to [get_pins {*dp_meta_s0/D *dm_meta_s0/D}]
// Gray FIFO/memory paths cross domains under pointer synchronization.
// Bound propagation instead of cutting whole clock domains. Core captures a
// committed word only after two pointer synchronizer stages (>40ns).
set_max_delay -from [get_clocks {clk_usb}] -to [get_clocks {clk_50m}] 20.000
set_min_delay -from [get_clocks {clk_usb}] -to [get_clocks {clk_50m}] 0.000
set_max_delay -from [get_clocks {clk_50m}] -to [get_clocks {clk_usb}] 10.000
set_min_delay -from [get_clocks {clk_50m}] -to [get_clocks {clk_usb}] 0.000
// First Gray synchronizer stages intentionally sample asynchronously. Only
// their HOLD checks are excepted; bounded setup propagation above remains.
set_false_path -hold -to [get_regs {*records/rg_meta*_s0 *records/wg_meta*_s0 *usb/cdc_fault_meta_s0}]
// POR/PLL reset is asynchronous to USB. The first reset synchronizer may
// release near an edge; stage 2 synchronizes release before protocol use.
// The broad cross-domain min_delay otherwise treats its async CLEAR as a
// synchronous data capture. Exempt only this first-stage CLEAR hold check;
// stage-1 Q -> stage-2 D and every stage-2 check remain timed.
set_false_path -hold -to [get_pins {usb/reset_usb_0_s0/CLEAR}]
// USB write pointer can change every 10.417ns: also bound its Gray bits to
// <one source period; the wider payload remains under the 20ns bound above.
set_max_delay -to [get_regs {*records/wg_meta*_s0}] 10.000
// UART external receiver does not capture on an FPGA clock.
set_false_path -to [get_ports {uart_tx}]

// Independent hard audio PLL: 50*16/64=12.5MHz, no fabric clock divider.
create_generated_clock -name audio_mclk -source [get_ports {clk_50m}] -divide_by 4 [get_pins {audio/clock_audio/PLL_inst/CLKOUT0}]
// Each codec is a separate master, /4 BCLK, /256 LRCK. No phase assumption.
create_clock -name adc_bclk -period 320.000 -waveform {0 160} [get_ports {es0_dsclk}]
create_clock -name dac_bclk -period 320.000 -waveform {0 160} [get_ports {es1_dsclk}]
// ES7243E p12: data <=16ns, LRCK <=10ns after falling BCLK at 3.3V.
// 4ns board budget (assumption to measure), min=0 conservative.
set_input_delay -clock adc_bclk -clock_fall -max 20.000 [get_ports {es0_sdin}]
set_input_delay -clock adc_bclk -clock_fall -min 0.000 [get_ports {es0_sdin}]
set_input_delay -clock adc_bclk -clock_fall -max 14.000 [get_ports {es0_alrck}]
set_input_delay -clock adc_bclk -clock_fall -min 0.000 [get_ports {es0_alrck}]
set_input_delay -clock dac_bclk -clock_fall -max 14.000 [get_ports {es1_dlrc}]
set_input_delay -clock dac_bclk -clock_fall -min 0.000 [get_ports {es1_dlrc}]
// ES8156 p13: setup/hold=10ns. Include a 4ns output/clock skew budget.
set_output_delay -clock dac_bclk -max 14.000 [get_ports {es1_sdout}]
set_output_delay -clock dac_bclk -min -14.000 [get_ports {es1_sdout}]
// Frame FIFO: bound payload and Gray-pointer crossings, never clock groups.
set_max_delay -from [get_clocks {adc_bclk}] -to [get_clocks {dac_bclk}] 160.000
set_min_delay -from [get_clocks {adc_bclk}] -to [get_clocks {dac_bclk}] 0.000
set_max_delay -from [get_clocks {dac_bclk}] -to [get_clocks {adc_bclk}] 160.000
set_min_delay -from [get_clocks {dac_bclk}] -to [get_clocks {adc_bclk}] 0.000
set_false_path -hold -to [get_regs {*audio/frame_fifo/wg_meta*_s0 *audio/frame_fifo/rg_meta*_s0}]
// Only first-stage asynchronous reset assertion/release controls are excepted.
// Stage 1 Q -> stage 2 D and consumers remain timed in their clock domains.
set_false_path -to [get_pins {*audio/reset_rx/meta_s0/CLEAR *audio/reset_tx/meta_s0/CLEAR *audio/reset_core/meta_s0/CLEAR}]
// Slow asynchronous I2C ACK enters only two explicitly named first samplers.
set_false_path -from [get_ports {es7243_sda}] -to [get_regs {*audio/adc_config/u_i2c_com/sda_meta_s0}]
set_false_path -from [get_ports {es8156_sda}] -to [get_regs {*audio/dac_config/u_i2c_com/sda_meta_s0}]
// LED and I2C are externally observed asynchronous outputs; no FPGA-clock receiver.
set_false_path -to [get_ports {lin_led es7243_scl es8156_scl es7243_sda es8156_sda}]
// Only the FIFO committed-memory HOLD relation has no clock phase meaning.
// A read is qualified by TWO synchronized Gray-pointer stages. A bank cannot
// be rewritten until the read pointer returns through TWO write-domain stages.
// Thus each captured payload is immutable around the read edge; the explicit
// 160ns SETUP/max propagation bound above still applies to all 48 payload bits.
set_false_path -hold -from [get_regs {*audio/frame_fifo/mem_mem_RAMREG*}] -to [get_regs {*audio/frame_fifo/rd_data_reg*_s0}]

// Independent codec clock-health samplers; only external pad -> first stage.
set_false_path -from [get_ports {es0_dsclk}] -to [get_regs {*audio/adc_health/bclk_meta_s0}]
set_false_path -from [get_ports {es0_alrck}] -to [get_regs {*audio/adc_health/ws_meta_s0}]
set_false_path -from [get_ports {es1_dsclk}] -to [get_regs {*audio/dac_health/bclk_meta_s0}]
set_false_path -from [get_ports {es1_dlrc}] -to [get_regs {*audio/dac_health/ws_meta_s0}]
set_false_path -to [get_pins {*audio/reset_frame_rd/meta_s0/CLEAR}]
// WS2812 receiver has no FPGA clock input. Pulse timing is generated at 50MHz.
set_false_path -to [get_ports {ws2812}]

// Gowin models a clock port used as D as a clock-launched self endpoint;
// the -from pad exception above does not suppress that generated HOLD check.
// Only the two asynchronous first samplers are exempted. Their Q -> second
// sampler D paths and all consumers remain timed at 50MHz.
set_false_path -hold -to [get_regs {*audio/adc_health/bclk_meta_s0 *audio/dac_health/bclk_meta_s0}]
