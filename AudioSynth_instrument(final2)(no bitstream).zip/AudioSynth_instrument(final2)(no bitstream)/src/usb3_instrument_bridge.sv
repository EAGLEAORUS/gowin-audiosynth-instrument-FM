`default_nettype none
// Application protocol AUB1 on top of the FROZEN CH569 ALT1 transactions.
module usb3_instrument_bridge #(
 parameter integer WATCHDOG_CYCLES=25000000,parameter integer SD_ENABLE=0,parameter HW_PATCH=0
)(input wire clk,rst_n,audio_ok,
 input wire rx_clk,rx_req,rx_vld,output wire rx_ready,inout wire [15:0] hd,
 output wire tx_clk,tx_req,tx_vld,input wire tx_ready,
 input wire capture_valid,input wire [47:0] capture_pcm,input wire [31:0] capture_index,
 input wire exec_valid,input wire [39:0] exec_data,input wire [95:0] exec_tag,
 input wire [767:0] actual_state,input wire local_online,local_fault,input wire display_mode,input wire [11:0] colors,
 input wire [31:0] local_overflow,dispatched,suppressed,recoveries,
 output wire pc_valid,output wire [39:0] pc_data,output wire [95:0] pc_tag,input wire pc_ready,
 output reg pc_release,output wire patch_set,output wire [2:0] patch_value,input wire patch_ready,
 output reg [31:0] cycles,output wire backend_fault,input wire [15:0] dynamic_channels,input wire [15:0] upper_busy,input wire [15:0] nes_status);
 function automatic [31:0] crc32word(input [31:0] c,input [15:0] d);
  reg [31:0] v;begin v=c;for(integer k=0;k<16;k=k+1)v=(v>>1)^((v[0]^d[k])?32'hedb88320:32'd0);return v;end
 endfunction
 function automatic bit midi_good(input [15:0] a,b);
  reg [7:0] s;reg [3:0] ch;begin
   s=a[15:8];ch=s[3:0];
   if(SD_ENABLE && (HW_PATCH || dynamic_channels[ch]))return a[7:4]==0 && !b[7] && !b[15] && a[3:0]==s[7:4] &&
    ((s[7:4]==8 || s[7:4]==9 || s[7:4]==14) ||
     (s[7:4]==12 && b[15:8]==0) ||
     (s[7:4]==11 && (b[6:0]==0 || b[6:0]==1 || b[6:0]==7 || b[6:0]==11 || b[6:0]==64 || b[6:0]==75 || b[6:0]==76 || b[6:0]==77 || b[6:0]==93 || b[6:0]==73 || b[6:0]==120 || b[6:0]==123)));
   return a[7:4]==0 && (ch==0 || ch==9) && !b[7] && !b[15] && a[3:0]==s[7:4] &&
    ((s[7:4]==8 || s[7:4]==9) ? ((ch==0 && b[6:0]<=103) || (ch==9 && b[6:0]>=36 && b[6:0]<=51)) :
     s[7:4]==11 ? ((ch==0 && (b[6:0]==64 || b[6:0]==75 || b[6:0]==76 || b[6:0]==77 || b[6:0]==93 || b[6:0]==73)) || b[6:0]==120 || b[6:0]==123) :
     s[7:4]==14 && ch==0);
  end
 endfunction
 function automatic [39:0] midi_event(input [15:0] a,b);
  reg [3:0] kind;begin
   case(a[15:12])8:kind=1;9:kind=b[14:8]==0?4'd1:4'd2;11:kind=3;12:kind=4;default:kind=5;endcase
   return {4'd0,a[3:0],kind,a[11:8],b[6:0],b[14:8],2'd3,a[15:8]};
  end
 endfunction
 localparam IDLE=0,RX_WAIT1=1,RX_WAIT2=2,RX_SCAN=3,VALIDATE=4,COMMAND=5,
  EV_ADDR=6,EV_WAIT1=7,EV_FIRST=8,EV_WAIT2=9,EV_SECOND=10,EV_SEND=11,
  PATCH=12,CMD_FINISH=13,REPORT_BEGIN=14,REPORT_WRITE=15,
  UP_BEGIN=16,STATUS_PAYLOAD=17,RECORD_SELECT=18,PCM_WRITE=19,EVENT_WRITE=20,
  ZERO_PAYLOAD=21,HEADER_WRITE=22,CRC_WAIT1=23,CRC_WAIT2=24,CRC_SCAN=25,
  CRC_LOW=26,CRC_HIGH=27,TX_GAP=28,TX_START=29,TX_WAIT=30,TX_SETTLE=31;
 reg [5:0] state;
 wire request_valid,link_bad,pad_bad,tx_done;reg release_request,tx_start;
 wire [15:0] operation;wire [31:0] total,token,hw_crc,hw_seq;
 reg [8:0] rx_addr;wire [15:0] rx_q;reg [11:0] tx_length;wire [8:0] bus_addr;
 reg [15:0] tx_mem[0:511];reg [15:0] tx_q;reg [8:0] scan_addr;
 wire tx_reading=state==TX_START || state==TX_WAIT || state==TX_SETTLE;
 reg tx_we;reg [8:0] tx_wa;reg [15:0] tx_wd;
 always @(posedge clk)begin
  if(tx_we)tx_mem[tx_wa]<=tx_wd;
  tx_q<=tx_mem[tx_reading?bus_addr:scan_addr];
 end
 usb3_alt_link link(clk,rst_n,rx_clk,rx_req,rx_vld,rx_ready,hd,tx_clk,tx_req,tx_vld,tx_ready,
  request_valid,release_request,operation,total,token,hw_crc,hw_seq,link_bad,pad_bad,
  rx_addr,rx_q,tx_start,tx_length,{16'd0,tx_q},bus_addr,tx_done);
 reg capture_enable,clear_capture,old_audio_ok;reg [31:0] capture_epoch,frame_epoch;
 wire pcm_ready,pcm_valid,echo_ready,echo_valid;
 wire [87:0] pcm_data;wire [191:0] echo_data;
 wire [11:0] pcm_level;wire [6:0] echo_level;reg pcm_pop,echo_pop;
 reg [31:0] pcm_drops,echo_drops,app_crc_errors,malformed,duplicates,commands_completed,watchdog_releases;
 reg [31:0] watchdog;reg session;
 // Effects can complete after the following DAC tick at full 64-voice
 // load. Number PCM in output order and keep wall-clock sample indices
 // for status, APB and MIDI events.
 reg [31:0] pcm_sample_index;
 always @(posedge clk)begin
  if(!rst_n || !audio_ok)pcm_sample_index<=32'd1;
  else if(capture_valid)pcm_sample_index<=pcm_sample_index+1'b1;
 end
 usb3_buffered_fifo #(.W(88),.A(11)) pcm_queue(clk,rst_n && !clear_capture,
  capture_valid && capture_enable && audio_ok,{cycles,actual_state[607]?pcm_sample_index:capture_index,capture_pcm[23:0]},pcm_ready,
  pcm_valid,pcm_data,pcm_pop,pcm_level);
 usb3_event_queue echo_queue(clk,rst_n,
  exec_valid,{capture_index,cycles,exec_tag[31:0],exec_tag[63:32],8'd0,exec_tag[87:80],exec_tag[95:88],exec_data},
  echo_ready,echo_valid,echo_data,echo_pop,echo_level);
 assign backend_fault=actual_state[447:416]!=0;
 reg [31:0] transaction_token,transaction_total,transaction_hw_crc,transaction_hw_seq;
 reg [15:0] transaction_op;
 reg transaction_bad,transaction_pad_bad;
 reg [8:0] index;
 reg [31:0] crc,received_crc,rx_magic,rx_sequence,rx_token;
 reg [15:0] rx_version,rx_type,rx_length,rx_flags,first_payload;
 reg reserved_bad,body_pad_bad;
 reg [31:0] command_seq,command_crc,command_arrival,command_result,accepted;
 reg last_valid,new_command;reg [31:0] last_seq,last_crc,last_result,last_accepted;
 reg [15:0] midi_first,midi_second;reg [5:0] event_index,event_count;
 reg validate_events,event_bad,cc_mode;
 reg [31:0] emit_wait;
 assign pc_valid=state==EV_SEND && audio_ok;
 assign pc_data=midi_event(midi_first,midi_second);
 assign pc_tag={8'd1,{2'd0,event_index},16'd0,command_seq,command_arrival};
 assign patch_set=state==PATCH;
 assign patch_value=first_payload[2:0];
 reg [31:0] upload_index,packet_sequence,first_sample,first_time;
 reg [31:0] frame_pcm_drops,frame_echo_drops;
 reg [15:0] frame_type,record_count,payload_bytes,format_code,frame_flags;
 reg [1535:0] snapshot;
 reg [191:0] current_event;reg [23:0] current_pcm;
 reg [3:0] part;reg [8:0] write_addr;
 reg report_mode;reg [31:0] frame_crc,report_time;reg [15:0] delay_count;
 wire [31:0] next_rx_crc=crc32word(crc,rx_q),next_tx_crc=crc32word(crc,tx_q);
 reg [15:0] header_word,report_word;
 always @* begin
  header_word=0;
  case(index)
   0:header_word=16'h5541;1:header_word=16'h3142;2:header_word=1;3:header_word=frame_type;
   4:header_word=payload_bytes;5:header_word=frame_flags;
   6:header_word=packet_sequence[15:0];7:header_word=packet_sequence[31:16];
   8:header_word=transaction_token[15:0];9:header_word=transaction_token[31:16];
   10:header_word=first_sample[15:0];11:header_word=first_sample[31:16];
   12:header_word=first_time[15:0];13:header_word=first_time[31:16];
   14:header_word=record_count;15:header_word=format_code;16:header_word=16'd48000;18:header_word=1;
   20:header_word=frame_pcm_drops[15:0];21:header_word=frame_pcm_drops[31:16];
   22:header_word=frame_echo_drops[15:0];23:header_word=frame_echo_drops[31:16];
   24:header_word=last_seq[15:0];25:header_word=last_seq[31:16];
   26:header_word=last_result[15:0];27:header_word=last_result[31:16];
   28:header_word=frame_epoch[15:0];29:header_word=frame_epoch[31:16];
   default:begin end
  endcase
  report_word=0;
  case(index)
   0:report_word=16'h5348;1:report_word=16'h5250;2:report_word=1;3:report_word=transaction_op;
   4:report_word=transaction_total[15:0];5:report_word=transaction_total[31:16];
   6:report_word=transaction_op==1?(transaction_total>>12):(transaction_total>>10);
   7:report_word=transaction_op==1?(transaction_total>>28):(transaction_total>>26);
   8:report_word=transaction_hw_crc[15:0];9:report_word=transaction_hw_crc[31:16];
   10:report_word=transaction_hw_seq[15:0];11:report_word=transaction_hw_seq[31:16];
   12:report_word=command_result[15:0];13:report_word=command_result[31:16];
   14:report_word=command_seq[15:0];15:report_word=command_seq[31:16];
   16:report_word=accepted[15:0];17:report_word=accepted[31:16];
   18:report_word=command_crc[15:0];19:report_word=command_crc[31:16];
   20:report_word=report_time[15:0];21:report_word=report_time[31:16];
   22:report_word=local_overflow[15:0];23:report_word=local_overflow[31:16];
   24:report_word=0;25:report_word=1;26:report_word=app_crc_errors[15:0];27:report_word=app_crc_errors[31:16];
   28:report_word=transaction_token[15:0];29:report_word=transaction_token[31:16];
   30:report_word=~crc[15:0];31:report_word=~crc[31:16];default:begin end
  endcase
 end
 // All FSM writers share ONE synchronous RAM port. This is essential:
 // multiple procedural addresses infer a huge register bank and write mux.
 always @* begin
  tx_we=0;tx_wa=write_addr;tx_wd=0;
  case(state)
   REPORT_WRITE:begin tx_we=1;tx_wa=index;tx_wd=report_word;end
   STATUS_PAYLOAD:begin tx_we=1;tx_wa=9'd32+index;tx_wd=snapshot[index*16+:16];end
   PCM_WRITE:begin tx_we=1;case(part)0:tx_wd=current_pcm[15:0];1:tx_wd={current_pcm[7:0],current_pcm[23:16]};default:tx_wd=current_pcm[23:8];endcase end
   EVENT_WRITE:begin tx_we=1;tx_wd=current_event[part*16+:16];end
   ZERO_PAYLOAD:begin tx_we=write_addr<510;tx_wd=0;end
   HEADER_WRITE:begin tx_we=1;tx_wa=index;tx_wd=header_word;end
   CRC_LOW:begin tx_we=1;tx_wa=510;tx_wd=frame_crc[15:0];end
   CRC_HIGH:begin tx_we=1;tx_wa=511;tx_wd=frame_crc[31:16];end
   default:begin end
  endcase
 end
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=IDLE;cycles<=0;release_request<=0;tx_start<=0;tx_length<=63;rx_addr<=0;scan_addr<=0;
   capture_enable<=0;clear_capture<=0;old_audio_ok<=0;capture_epoch<=0;frame_epoch<=0;pcm_pop<=0;echo_pop<=0;pc_release<=0;
   pcm_drops<=0;echo_drops<=0;app_crc_errors<=0;malformed<=0;duplicates<=0;commands_completed<=0;watchdog_releases<=0;
   session<=0;watchdog<=0;transaction_token<=0;transaction_total<=0;transaction_hw_crc<=0;transaction_hw_seq<=0;
   transaction_op<=0;transaction_bad<=0;transaction_pad_bad<=0;index<=0;crc<=32'hffffffff;
   received_crc<=0;rx_magic<=0;rx_sequence<=0;rx_token<=0;rx_version<=0;rx_type<=0;rx_length<=0;rx_flags<=0;first_payload<=0;
   reserved_bad<=0;body_pad_bad<=0;command_seq<=0;command_crc<=0;command_arrival<=0;command_result<=0;accepted<=0;
   last_valid<=0;last_seq<=0;last_crc<=0;last_result<=0;last_accepted<=0;new_command<=0;
   midi_first<=0;midi_second<=0;event_index<=0;event_count<=0;validate_events<=0;event_bad<=0;cc_mode<=0;emit_wait<=0;
   upload_index<=0;packet_sequence<=0;first_sample<=0;first_time<=0;frame_type<=0;record_count<=0;payload_bytes<=0;format_code<=0;frame_flags<=0;
   frame_pcm_drops<=0;frame_echo_drops<=0;snapshot<=0;current_event<=0;current_pcm<=0;part<=0;write_addr<=0;report_mode<=0;frame_crc<=0;report_time<=0;delay_count<=0;
  end else begin
   cycles<=cycles+1'b1;old_audio_ok<=audio_ok;release_request<=0;tx_start<=0;pcm_pop<=0;echo_pop<=0;pc_release<=0;clear_capture<=0;
   if(old_audio_ok && !audio_ok)begin capture_epoch<=capture_epoch+1'b1;clear_capture<=1;end
   if(capture_valid && capture_enable && audio_ok && !pcm_ready && !(&pcm_drops))pcm_drops<=pcm_drops+1'b1;
   if(exec_valid && !echo_ready && !(&echo_drops))echo_drops<=echo_drops+1'b1;
   if(session)begin
    if(watchdog==WATCHDOG_CYCLES-1)begin session<=0;pc_release<=1;watchdog<=0;watchdog_releases<=watchdog_releases+1'b1;end
    else watchdog<=watchdog+1'b1;
   end
   case(state)
    IDLE:if(request_valid)begin
     transaction_token<=token;transaction_total<=total;transaction_op<=operation;
     transaction_hw_crc<=hw_crc;transaction_hw_seq<=hw_seq;transaction_bad<=link_bad;transaction_pad_bad<=pad_bad;
     watchdog<=0;session<=1;new_command<=0;command_arrival<=cycles;
     if(operation==1)begin
      index<=0;rx_addr<=0;crc<=32'hffffffff;received_crc<=0;reserved_bad<=0;body_pad_bad<=0;
      command_result<=0;accepted<=0;state<=RX_WAIT1;
     end else begin upload_index<=0;state<=UP_BEGIN;end
    end
    RX_WAIT1:state<=RX_WAIT2;
    RX_WAIT2:state<=RX_SCAN;
    RX_SCAN:begin
     if(index<510)crc<=next_rx_crc;
     case(index)
      0:rx_magic[15:0]<=rx_q;1:rx_magic[31:16]<=rx_q;2:rx_version<=rx_q;3:rx_type<=rx_q;
      4:rx_length<=rx_q;5:rx_flags<=rx_q;6:rx_sequence[15:0]<=rx_q;7:rx_sequence[31:16]<=rx_q;
      8:rx_token[15:0]<=rx_q;9:rx_token[31:16]<=rx_q;32:first_payload<=rx_q;
      510:received_crc[15:0]<=rx_q;511:received_crc[31:16]<=rx_q;default:begin end
     endcase
     if(index>=10 && index<32 && rx_q!=0)reserved_bad<=1;
     if(index>=32 && index<510)begin
      if({index,1'b0}>=rx_length+64 && rx_q!=0)body_pad_bad<=1;
      if(rx_length[0] && {index,1'b0}==rx_length+63 && rx_q[15:8]!=0)body_pad_bad<=1;
     end
     if(index==511)state<=VALIDATE;
     else begin index<=index+1'b1;rx_addr<=rx_addr+1'b1;state<=RX_WAIT1;end
    end
    VALIDATE:begin
     command_seq<=rx_sequence;command_crc<=received_crc;
     if(received_crc!=~crc)begin command_result<=1;app_crc_errors<=app_crc_errors+1'b1;state<=REPORT_BEGIN;end
     else if(transaction_bad || rx_magic!=32'h31425541 || rx_version!=1 || rx_length>128 || rx_flags!=0 || rx_token!=transaction_token || reserved_bad)begin
      command_result<=2;malformed<=malformed+1'b1;state<=REPORT_BEGIN;
     end else if(transaction_pad_bad || body_pad_bad)begin command_result<=6;malformed<=malformed+1'b1;state<=REPORT_BEGIN;end
     else if(last_valid && rx_sequence==last_seq)begin
      if(received_crc==last_crc)begin command_result<=last_result;accepted<=last_accepted;duplicates<=duplicates+1'b1;end
      else command_result<=3;
      state<=REPORT_BEGIN;
     end else if(last_valid && rx_sequence<last_seq)begin command_result<=3;state<=REPORT_BEGIN;end
     else begin new_command<=1;state<=COMMAND;end
    end
    COMMAND:begin
     cc_mode<=0;event_index<=0;event_bad<=0;emit_wait<=0;
     case(rx_type)
      1:begin if(rx_length!=0)command_result<=4;state<=CMD_FINISH;end
      2:begin
       if(rx_length!=1 || first_payload>1)command_result<=4;
       else begin capture_enable<=first_payload[0];clear_capture<=1;capture_epoch<=capture_epoch+1'b1;end
       state<=CMD_FINISH;
      end
      3:begin
       if(rx_length==0 || rx_length[1:0]!=0 || !audio_ok)begin command_result<=!audio_ok?5:4;state<=CMD_FINISH;end
       else begin event_count<=rx_length>>2;validate_events<=1;state<=EV_ADDR;end
      end
      4:begin if(rx_length!=1 || first_payload>4)begin command_result<=4;state<=CMD_FINISH;end else state<=PATCH;end
      5:begin
       midi_first<=16'hb00b;midi_second<=first_payload;event_count<=1;cc_mode<=1;
       if(rx_length!=2 || !midi_good(16'hb00b,first_payload) || !audio_ok)begin command_result<=!audio_ok?5:4;state<=CMD_FINISH;end
       else state<=EV_SEND;
      end
      6:begin if(rx_length!=0)command_result<=4;else pc_release<=1;state<=CMD_FINISH;end
      default:begin command_result<=4;state<=CMD_FINISH;end
     endcase
    end
    EV_ADDR:begin rx_addr<=9'd32+{event_index,1'b0};state<=EV_WAIT1;end
    EV_WAIT1:state<=EV_FIRST;
    EV_FIRST:begin midi_first<=rx_q;rx_addr<=rx_addr+1'b1;state<=EV_WAIT2;end
    EV_WAIT2:state<=EV_SECOND;
    EV_SECOND:begin
     midi_second<=rx_q;
     if(validate_events)begin
      if(!midi_good(midi_first,rx_q))event_bad<=1;
      if(event_index+1==event_count)begin
       if(event_bad || !midi_good(midi_first,rx_q))begin command_result<=4;state<=CMD_FINISH;end
       else begin validate_events<=0;event_index<=0;state<=EV_ADDR;end
      end else begin event_index<=event_index+1'b1;state<=EV_ADDR;end
     end else state<=EV_SEND;
    end
    EV_SEND:begin
     if(pc_ready && pc_valid)begin
      accepted<=accepted+1'b1;emit_wait<=0;
      if(event_index+1==event_count)state<=CMD_FINISH;
      else begin event_index<=event_index+1'b1;state<=EV_ADDR;end
     end else if(emit_wait==249999)begin command_result<=7;state<=CMD_FINISH;end
     else emit_wait<=emit_wait+1'b1;
    end
    PATCH:if(patch_ready)state<=CMD_FINISH;
    CMD_FINISH:begin
     if(new_command)begin last_valid<=1;last_seq<=command_seq;last_crc<=command_crc;last_result<=command_result;last_accepted<=accepted;commands_completed<=commands_completed+1'b1;end
     state<=REPORT_BEGIN;
    end
    REPORT_BEGIN:begin report_mode<=1;index<=0;crc<=32'hffffffff;report_time<=cycles;tx_length<=63;state<=REPORT_WRITE;end
    REPORT_WRITE:begin
     
     if(index<30)crc<=crc32word(crc,report_word);
     if(index==31)begin delay_count<=0;state<=TX_GAP;end else index<=index+1'b1;
    end
    UP_BEGIN:begin
     frame_epoch<=capture_epoch;frame_pcm_drops<=pcm_drops;frame_echo_drops<=echo_drops;report_mode<=0;record_count<=0;payload_bytes<=0;part<=0;write_addr<=32;first_sample<=capture_index;first_time<=cycles;
     frame_flags<={10'd0,local_fault,local_online,audio_ok,echo_drops!=0,pcm_drops!=0,capture_enable};
     if(upload_index==0)begin
      frame_type<=16'h8001;format_code<=0;payload_bytes<=192;record_count<=1;index<=0;
      snapshot<={(HW_PATCH?nes_status:16'd0),(actual_state[607]?upper_busy:16'd0),{19'd0,colors,display_mode},{28'd0,local_fault,local_online,audio_ok,capture_enable},transaction_hw_seq,transaction_hw_crc,packet_sequence,
       {9'd0,echo_level,4'd0,pcm_level},watchdog_releases,recoveries,suppressed,dispatched,local_overflow,
       last_accepted,last_result,last_seq,commands_completed,duplicates,malformed,app_crc_errors,echo_drops,pcm_drops,capture_index,cycles,32'h20261025,actual_state};
      state<=STATUS_PAYLOAD;
     end else begin
      frame_type<=echo_valid?16'h8003:16'h8002;format_code<=echo_valid?16'd24:16'h1802;state<=RECORD_SELECT;
     end
    end
    STATUS_PAYLOAD:begin
     
     if(index==95)begin write_addr<=128;state<=ZERO_PAYLOAD;end else index<=index+1'b1;
    end
    RECORD_SELECT:begin
     if(frame_type==16'h8003 && echo_valid && record_count<39)begin
      current_event<=echo_data;echo_pop<=1;part<=0;
      if(record_count==0)begin first_sample<=echo_data[191:160];first_time<=echo_data[159:128];end
      state<=EVENT_WRITE;
     end else if(frame_type==16'h8002 && capture_enable && pcm_valid && record_count<159 &&
       (record_count==0 || pcm_data[55:24]==first_sample+record_count))begin
      current_pcm<=pcm_data[23:0];pcm_pop<=1;part<=0;
      if(record_count==0)begin first_sample<=pcm_data[55:24];first_time<=pcm_data[87:56];end
      state<=PCM_WRITE;
     end else state<=ZERO_PAYLOAD;
    end
    PCM_WRITE:begin

     write_addr<=write_addr+1'b1;
     if(part==2)begin record_count<=record_count+1'b1;payload_bytes<=payload_bytes+6;state<=RECORD_SELECT;end else part<=part+1'b1;
    end
    EVENT_WRITE:begin
     write_addr<=write_addr+1'b1;
     if(part==11)begin record_count<=record_count+1'b1;payload_bytes<=payload_bytes+24;state<=RECORD_SELECT;end else part<=part+1'b1;
    end
    ZERO_PAYLOAD:begin
     if(write_addr<510)begin write_addr<=write_addr+1'b1;end
     else begin index<=0;state<=HEADER_WRITE;end
    end
    HEADER_WRITE:begin
     
     if(index==31)begin scan_addr<=0;index<=0;crc<=32'hffffffff;state<=CRC_WAIT1;end else index<=index+1'b1;
    end
    CRC_WAIT1:state<=CRC_WAIT2;
    CRC_WAIT2:state<=CRC_SCAN;
    CRC_SCAN:begin
     crc<=next_tx_crc;
     if(index==509)begin frame_crc<=~next_tx_crc;state<=CRC_LOW;end
     else begin scan_addr<=scan_addr+1'b1;index<=index+1'b1;state<=CRC_WAIT1;end
    end
    CRC_LOW:begin state<=CRC_HIGH;end
    CRC_HIGH:begin tx_length<=1023;delay_count<=0;state<=TX_GAP;end
    TX_GAP:if(delay_count==255)state<=TX_START;else delay_count<=delay_count+1'b1;
    TX_START:begin tx_start<=1;state<=TX_WAIT;end
    TX_WAIT:if(tx_done)begin delay_count<=0;state<=TX_SETTLE;end
    TX_SETTLE:if(delay_count==31)begin
     if(report_mode)begin release_request<=1;state<=IDLE;end
     else begin
      packet_sequence<=packet_sequence+1'b1;upload_index<=upload_index+1'b1;
      if(upload_index+1==(transaction_total>>10))state<=REPORT_BEGIN;else state<=UP_BEGIN;
     end
    end else delay_count<=delay_count+1'b1;
    default:state<=IDLE;
   endcase
  end
 end
endmodule
`default_nettype wire
