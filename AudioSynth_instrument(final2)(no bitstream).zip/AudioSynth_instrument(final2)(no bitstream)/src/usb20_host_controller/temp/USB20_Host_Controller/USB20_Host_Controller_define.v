`define module_name USB20_Host_Controller_Top
`define addr_width 15
`define mem_space 32767
