`default_nettype none
// Single direct-device transaction layer; dynamic tokens replace UKP ROM literals.
// kind: 0 IN, 1 OUT, 2 SETUP, 3 SOF. Result: OK/NAK/STALL/ERROR/DUPLICATE.
module usb_fs_transaction(
 input wire clk,rst_n,input wire start,input wire [1:0] kind,
 input wire [6:0] address,input wire [3:0] endpoint,input wire [10:0] frame_number,
 input wire toggle,input wire [3:0] out_length,input wire [63:0] out_data,
 input wire [6:0] max_packet,
 output wire ready,output reg done,output reg [2:0] result,
 output reg [6:0] in_length,output reg [511:0] in_data,
 output reg tx_start,output reg [3:0] tx_length,output reg [87:0] tx_packet,
 input wire tx_ready,tx_done,rx_done,rx_error,rx_crc_ok,
 input wire [6:0] rx_length,input wire [535:0] rx_packet,
 input wire [7:0] rx_faults,input wire rx_active,
 output reg [127:0] diagnostic
);
 function [4:0] crc5;input [10:0] bits;reg [4:0] c;integer i;
  begin c=31;for(i=0;i<11;i=i+1)c=(c>>1)^((c[0]^bits[i])?5'h14:5'd0);crc5=~c;end
 endfunction
 function [15:0] crc16;input [63:0] d;input [3:0] n;reg [15:0] c;integer i;
  begin c=16'hffff;for(i=0;i<64;i=i+1)if(i<n*8)c=(c>>1)^((c[0]^d[i])?16'ha001:16'd0);crc16=~c;end
 endfunction
 localparam IDLE=0,TOKEN=1,GAP=2,DATA=3,RESPONSE=4,ACK_GAP=5,ACK=6;
 reg [2:0] state /* synthesis syn_maxfan = 16 */;
 reg [2:0] k_result;
 reg [1:0] k_kind;
 reg k_toggle;
 reg [6:0] k_max;
 reg [12:0] timer;
 reg response_expired;
 always @(posedge clk)begin
  if(!rst_n)response_expired<=0;
  else response_expired<=state==RESPONSE && timer==13'd8190;
 end
 reg [87:0] data_packet;
 reg [3:0] data_length;
 // USB 2.0 7.1.18.1: >=2 FS bit times from EOP SE0->J to SOP.
 // tx_done is after the driven J; rx_done is near the middle of received J.
 // A fresh token used to launch immediately from IDLE (about 1.5 bits).
 // Guard only fresh transactions; existing DATA/ACK turnaround stays bounded.
 reg [4:0] interpacket_guard;
 // Byte fields: token/address/endpoint/TX flags/RX PID/length/PHY mask/reason.
 // reason: 0 OK,1 no SOP,2 incomplete RX,3 PHY,4 unexpected PID,5 CRC16,6 size,7 NAK,8 STALL,9 duplicate.
 wire [10:0] token_bits=(kind==3)?frame_number:{endpoint,address};
 wire [15:0] out_crc=crc16(out_data,out_length);
 wire [7:0] pid=rx_packet[7:0];
 assign ready=state==IDLE && tx_ready && interpacket_guard==0 && !rx_active;
 always @(posedge clk)begin
  if(!rst_n)interpacket_guard<=0;
  else if(tx_done || rx_done)interpacket_guard<=16;
  else if(interpacket_guard!=0)interpacket_guard<=interpacket_guard-1'b1;
 end
 always @(posedge clk)begin
  if(!rst_n)begin state<=IDLE;tx_start<=0;done<=0;timer<=0;result<=3;
   tx_length<=0;tx_packet<=0;in_length<=0;in_data<=0;k_result<=3;
   k_kind<=0;k_toggle<=0;k_max<=0;data_packet<=0;data_length<=0;diagnostic<=0;end
  else begin
   tx_start<=0;done<=0;
   case(state)
    IDLE:if(start && ready)begin
     k_kind<=kind;k_toggle<=toggle;k_max<=max_packet;timer<=0;
     diagnostic<=0;
     diagnostic[7:0]<=kind==0?8'h69:kind==1?8'he1:kind==2?8'h2d:8'ha5;
     diagnostic[15:8]<={1'b0,address};diagnostic[23:16]<={4'd0,endpoint};
     diagnostic[71:64]<={7'd0,toggle};
     diagnostic[79:72]<=kind==2 || !toggle?8'hc3:8'h4b;
     diagnostic[87:80]<={3'd0,crc5(token_bits)};diagnostic[103:88]<=out_crc;
     tx_length<=3;
     tx_packet<={64'd0,crc5(token_bits),token_bits,
                 (kind==0?8'h69:kind==1?8'he1:kind==2?8'h2d:8'ha5)};
     tx_start<=1;state<=TOKEN;
     data_packet<=0;data_packet[7:0]<=(kind==2 || !toggle)?8'hc3:8'h4b;
     data_packet[8+:64]<=out_data;
     data_packet[(out_length+1)*8+:16]<=out_crc;
     data_length<=out_length+4'd3;
    end
    TOKEN:if(tx_done)begin
     timer<=0;diagnostic[24]<=1;
     if(k_kind==3)begin result<=0;done<=1;state<=IDLE;end
     else if(k_kind==0)state<=RESPONSE;
     else state<=GAP;
    end
    GAP:if(timer==16)begin tx_packet<=data_packet;tx_length<=data_length;tx_start<=1;state<=DATA;end
        else timer<=timer+1'b1;
    DATA:if(tx_done)begin state<=RESPONSE;timer<=0;diagnostic[25]<=1;end
    RESPONSE:begin
     timer<=timer+1'b1;
     if(rx_active)diagnostic[26]<=1;
     if(rx_done)begin
      diagnostic[27]<=1;diagnostic[39:32]<=pid;
      diagnostic[47:40]<={1'b0,rx_length};diagnostic[55:48]<=rx_faults;
      diagnostic[28]<=rx_crc_ok;
      // Capture speculatively; result/ACK gates all external consumption.
      // Keep CRC/PID/MPS comparisons off the 512-bit capture enable.
      in_length<=(rx_length>=3)?rx_length-7'd3:7'd0;
      in_data<=rx_packet[8+:512];
      if(rx_error)begin diagnostic[63:56]<=3;result<=3;done<=1;state<=IDLE;end
      else if(rx_length==1 && pid==8'h5a)begin diagnostic[63:56]<=7;result<=1;done<=1;state<=IDLE;end
      else if(rx_length==1 && pid==8'h1e)begin diagnostic[63:56]<=8;result<=2;done<=1;state<=IDLE;end
      else if(k_kind!=0 && rx_length==1 && pid==8'hd2)begin result<=0;done<=1;state<=IDLE;end
      else if(k_kind==0 && (pid==8'hc3 || pid==8'h4b) && rx_length>=3 &&
              rx_length<=k_max+7'd3 && rx_crc_ok)begin
       k_result<=((pid==8'h4b)==k_toggle)?3'd0:3'd4;
       diagnostic[63:56]<=((pid==8'h4b)==k_toggle)?8'd0:8'd9;
       timer<=0;state<=ACK_GAP;
      end else begin
       diagnostic[63:56]<=(pid!=8'hc3 && pid!=8'h4b)?8'd4:
         (rx_length<3 || rx_length>k_max+7'd3)?8'd6:!rx_crc_ok?8'd5:8'd4;
       result<=3;done<=1;state<=IDLE;end
     end else if(response_expired)begin diagnostic[63:56]<=diagnostic[26]?8'd2:8'd1;result<=3;done<=1;state<=IDLE;end
    end
    ACK_GAP:if(timer==16)begin tx_packet<=88'hd2;tx_length<=1;tx_start<=1;state<=ACK;end
            else timer<=timer+1'b1;
    ACK:if(tx_done)begin diagnostic[29]<=1;result<=k_result;done<=1;state<=IDLE;end
    default:state<=IDLE;
   endcase
  end
 end
endmodule
`default_nettype wire
