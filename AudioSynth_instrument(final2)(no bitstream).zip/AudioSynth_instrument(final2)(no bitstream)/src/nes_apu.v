`default_nettype none
// One NES composite note (four APU channels), NOT four independent MIDI voices.
// Core clock is the existing 50MHz domain. sample_tick is the existing DAC frame.
module nes_apu(
 input wire clk,rst_n,sample_tick,event_valid,input wire [39:0] event_data,input wire online,
 output reg signed [15:0] pcm,output reg pcm_valid,
 output wire active,output wire [3:0] vol4,output wire [23:0] fcw_debug,
 output wire [15:0] levels_debug
);
 wire [6:0] key=event_data[23:17],velocity=event_data[16:10];
 wire selected=online && event_valid && event_data[39:36]==0 && event_data[27:24]==9 && event_data[9:8]==3 &&
  ((event_data[35:32]==9 && event_data[7:0]==8'h99) ||
   (event_data[35:32]==8 && event_data[7:0]==8'h89) ||
   (event_data[35:32]==11 && event_data[7:0]==8'hb9));
 wire on_event=selected && key>=36 && key<=51 && event_data[31:28]==2 && velocity!=0;
 reg [6:0] held_note;reg [23:0] fcw;reg [3:0] volume;
 wire off_event=(!online) || (selected && key==held_note && (event_data[31:28]==1 || (event_data[31:28]==2 && velocity==0))) ||
  (selected && event_data[31:28]==3 && (key==120 || key==123));
 wire [6:0] unused_midi;wire [23:0] mapped_fcw;wire [3:0] mapped_volume,noise_volume,noise_env;
 wire [6:0] key_offset=key-7'd36;
 nes_note_map mapping(key_offset[3:0],unused_midi,mapped_fcw);
 nes_volume_tables volumes(velocity,volume,noise_env,mapped_volume,noise_volume);
 always @(posedge clk)begin
  if(!rst_n)begin held_note<=0;fcw<=0;volume<=0;end
  else if(on_event)begin held_note<=key;fcw<=mapped_fcw;volume<=mapped_volume;end
  else if(!active)volume<=0;
 end
 wire [16:0] gain;wire [3:0] env_state;
 nes_note_gate envelope(clk,rst_n,sample_tick,on_event,off_event,active,gain,env_state);
 wire [3:0] p1,p2,tr,nz;wire [23:0] phase1,phase2,phase3;
 wire noise_busy;wire [14:0] noise_state;
 nes_osc_pulse pulse1(clk,rst_n,sample_tick,on_event,active,fcw,2'd1,volume,p1,phase1);
 nes_osc_pulse pulse2(clk,rst_n,sample_tick,on_event,active,fcw,2'd0,volume,p2,phase2);
 nes_osc_tri triangle(clk,rst_n,sample_tick,on_event,active,fcw,tr,phase3);
 nes_env_4bit noise_envelope(clk,rst_n,sample_tick,on_event,1'b0,4'd1,noise_env);
 nes_osc_noise noise(clk,rst_n,sample_tick,on_event,active,4'd9,1'b0,noise_volume,nz,noise_busy,noise_state);
 wire [16:0] raw_mix;
 nes_mixer_lut mixer(p1,p2,tr,nz,raw_mix);
 assign vol4=volume;assign fcw_debug=fcw;assign levels_debug={p1,p2,tr,nz};
 reg [2:0] stage;reg [16:0] mix_sample,previous_mix,gain_sample;
 reg signed [26:0] dc_y,dc_next;
 reg signed [17:0] audio_sample;
 reg signed [35:0] fade_product;
 wire signed [27:0] delta=$signed({1'b0,mix_sample,8'd0})-$signed({1'b0,previous_mix,8'd0});
 wire signed [27:0] dc_sum=delta+$signed(dc_y)-($signed(dc_y)>>>9);
 wire signed [26:0] dc_shift=dc_next>>>8;
 wire signed [36:0] rounded_product=$signed({fade_product[35],fade_product})+37'sd65536;
 wire signed [36:0] scaled=rounded_product>>>17; // Q16 gain plus fixed 1/2
 always @(posedge clk)begin
  if(!rst_n)begin
   pcm<=0;pcm_valid<=0;stage<=0;mix_sample<=0;previous_mix<=0;gain_sample<=0;
   dc_y<=0;dc_next<=0;audio_sample<=0;fade_product<=0;
  end else begin
   pcm_valid<=0;
   if(sample_tick)begin mix_sample<=raw_mix;stage<=1;end
   else case(stage)
    1:begin dc_next<=dc_sum[26:0];gain_sample<=gain;stage<=2;end
    2:begin dc_y<=dc_next;previous_mix<=mix_sample;audio_sample<=dc_shift[17:0];stage<=3;end
    3:begin fade_product<=audio_sample*$signed({1'b0,gain_sample});stage<=4;end
    4:begin
     if(scaled>32767)pcm<=16'sh7fff;
     else if(scaled< -32768)pcm<=16'sh8000;
     else pcm<=scaled[15:0];
     pcm_valid<=1;stage<=0;
    end
    default:stage<=0;
   endcase
  end
 end
endmodule
`default_nettype wire
