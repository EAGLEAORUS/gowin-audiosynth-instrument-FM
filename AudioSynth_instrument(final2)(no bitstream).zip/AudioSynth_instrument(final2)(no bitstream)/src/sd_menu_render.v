`default_nettype none
// Three registered reads match tft_st7789's existing coordinate hold time.
// Cold uploads are hidden; cursor/resident updates retain the current picture.
// Cell bit7 colors an ink pixel red, used for the flashing recording dot.
module sd_menu_render(input wire clk,rst_n,frame_start,input wire[8:0] x,input wire[7:0] y,
 input wire begin_page,commit,input wire glyph_we,input wire[10:0] glyph_write_addr,input wire[15:0] glyph_data,
 input wire cell_we,input wire[6:0] cell_write_addr,input wire[7:0] cell_data,input wire[2:0] selected,
 output reg[15:0] pixel,output wire ready);
 wire[6:0] cell_address={y[7:5],4'd0}+{2'd0,y[7:5],2'd0}+{2'd0,x[8:4]};
 wire[7:0] cell_q;wire[15:0] glyph_q;
 sd_menu_cache cache(clk,rst_n,begin_page,commit,glyph_we,glyph_write_addr,glyph_data,cell_we,cell_write_addr,cell_data,cell_address,cell_q,{cell_q[6:0],y[3:0]},glyph_q,ready);
 reg visible;reg[2:0] cursor;
 always @(posedge clk)begin
  if(!rst_n)begin visible<=0;cursor<=0;end
  else if(!ready || begin_page)visible<=0;
  else if(frame_start)begin visible<=1;cursor<=selected;end
 end
 wire text_region=x<320 && !y[4] && y[7:5]<=5;
 always @(posedge clk)begin
  if(!rst_n || !ready || !visible || begin_page)pixel<=16'h0841;
  else if(text_region && glyph_q[15-x[3:0]])pixel<=cell_q[7]?16'hf800:16'hffff;
  else if(text_region && y[7:5]==0)pixel<=16'h18e3;
  else if(text_region && y[7:5]==cursor+3'd1)pixel<=16'h0295;
  else pixel<=16'h0841;
 end
endmodule
`default_nettype wire
