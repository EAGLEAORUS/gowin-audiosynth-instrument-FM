`default_nettype none
module tft_render #(parameter SD_ENABLE=0,parameter SD_ONLY=0)(input wire clk,rst_n,frame_start,input wire [8:0] x,input wire [7:0] y,
 input wire [3:0] page,cursor,input wire [1:0] target,input wire [2:0] patch,input wire mode,
 input wire [6:0] volume,delay_value,chorus_value,reverb_value,
 input wire [2:0] wave_color,spectrum_color,overload_color,xy_color,
 output wire [15:0] pixel,input wire [31:0] sd_status);
 tft_render_status #(.SD_ENABLE(SD_ENABLE),.SD_ONLY(SD_ONLY)) render(clk,rst_n,frame_start,x,y,page,cursor,target,patch,mode,
  volume,delay_value,chorus_value,reverb_value,wave_color,spectrum_color,overload_color,xy_color,pixel,sd_status,7'd0);
endmodule

module tft_render_status #(parameter SD_ENABLE=0,parameter SD_ONLY=0,parameter COMPACT_FX=0)(input wire clk,rst_n,frame_start,input wire [8:0] x,input wire [7:0] y,
 input wire [3:0] page,cursor,input wire [1:0] target,input wire [2:0] patch,input wire mode,
 input wire [6:0] volume,delay_value,chorus_value,reverb_value,
 input wire [2:0] wave_color,spectrum_color,overload_color,xy_color,
 output reg [15:0] pixel,input wire [31:0] sd_status,input wire [6:0] phaser_depth);
 reg [31:0] sd;reg [3:0] p,c;reg [1:0] t;reg [2:0] pa;reg mo;
 reg [6:0] vo,de,ch,re,ph;reg [2:0] wc,sc,oc,xc;
 always @(posedge clk)begin
  if(!rst_n)begin sd<=0;p<=0;c<=0;t<=0;pa<=0;mo<=0;vo<=127;de<=0;ch<=0;re<=0;ph<=0;wc<=5;sc<=3;oc<=6;xc<=2;end
  else if(frame_start)begin
   sd<=sd_status;p<=page;c<=cursor;t<=target;pa<=patch;mo<=mode;vo<=volume;de<=delay_value;ch<=chorus_value;re<=reverb_value;ph<=phaser_depth;
   wc<=wave_color;sc<=spectrum_color;oc<=overload_color;xc<=xy_color;
  end
 end
 wire [3:0] row=y[7:4];wire [4:0] col=x[8:4];
 reg [6:0] line;reg [3:0] count;
 wire [2:0] color=t==0?wc:t==1?sc:t==2?oc:xc;
 always @*begin
  line=0;
  case(p)
  4'd0:case(row)
   4'd0:line=6'd1;
   4'd2:line=6'd2;
   4'd3:line=6'd3;
   4'd4:line=SD_ENABLE?7'd64:7'd0;
   4'd5:line=SD_ENABLE?7'd80:7'd0;
   4'd7:line=6'd47;
   4'd8:line=COMPACT_FX?7'd85:7'd39;
   4'd9:line=COMPACT_FX?7'd86:7'd40;
   4'd10:line=COMPACT_FX?7'd87:7'd41;
   4'd11:line=COMPACT_FX?7'd0:7'd42;
   4'd14:line=6'd38;
   default:line=0;
  endcase
  4'd1:case(row)
   4'd0:line=7'd84;
   4'd2:line=6'd5;
   4'd3:line=6'd6;
   4'd4:line=6'd7;
   4'd5:line=6'd8;
   4'd14:line=6'd38;
   default:line=0;
  endcase
  4'd9:case(row)
   4'd0:line=6'd9;
   4'd2:line=6'd10;
   4'd3:line=6'd11;
   4'd4:line=6'd12;
   4'd5:line=6'd13;
   4'd6:line=6'd57;
   4'd7:line=6'd7;
   4'd8:line=6'd8;
   4'd14:line=6'd38;
   default:line=0;
  endcase
  4'd2:case(row)
   0:line=7'd83;2:line=7'd81;3:line=7'd82;4:line=7'd7;5:line=7'd8;14:line=7'd38;default:line=0;
  endcase
  4'd3:case(row)
   4'd0:line=6'd14;
   4'd2:line=6'd15;
   4'd3:line=6'd7;
   4'd4:line=6'd8;
   4'd14:line=6'd38;
   default:line=0;
  endcase
  4'd4:case(row)
   4'd0:line=6'd16;
   4'd2:line=6'd17;
   4'd3:line=6'd18;
   4'd4:line=6'd7;
   4'd5:line=6'd8;
   4'd14:line=6'd38;
   default:line=0;
  endcase
  4'd5:case(row)
   4'd0:line=6'd19;
   4'd2:line=6'd20;
   4'd3:line=6'd21;
   4'd4:line=6'd7;
   4'd5:line=6'd8;
   4'd14:line=6'd38;
   default:line=0;
  endcase
  4'd6:case(row)
   4'd0:line=6'd22;
   4'd2:line=6'd23;
   4'd3:line=6'd24;
   4'd4:line=6'd25;
   4'd5:line=6'd26;
   4'd6:line=6'd7;
   4'd7:line=6'd8;
   4'd14:line=6'd38;
   default:line=0;
  endcase
  4'd7:case(row)
   4'd2:line=6'd31;
   4'd3:line=6'd32;
   4'd4:line=6'd33;
   4'd5:line=6'd34;
   4'd6:line=6'd35;
   4'd7:line=6'd36;
   4'd8:line=6'd37;
   4'd9:line=6'd7;
   4'd10:line=6'd8;
   4'd14:line=6'd38;
   default:line=0;
  endcase
   default:line=0;
  endcase
  if(p==8)line=row==0?7'd79:7'd64+{3'd0,row};
  if(p==0 && row==6)line=SD_ONLY?7'd0:pa==4?6'd58:6'd43+{3'd0,pa};
  if(p==0 && row==12)line=mo?6'd49:6'd48;
  if(SD_ENABLE && p==0 && row==13)line=SD_ONLY?(sd[31]?7'd82:7'd0):sd[0]?7'd82:7'd81;
  if(p==9 && row==12)line=pa==4?6'd58:6'd43+{3'd0,pa};
  if(p==5 && row==12)line=mo?6'd49:6'd48;
  if(p==7 && row==0)line=6'd27+{4'd0,t};
  if(p==7 && row==12)line=6'd50+{3'd0,color};
  case(p)
   0:count=SD_ENABLE?4:2;1,2,4,5:count=4;9:count=7;6:count=6;3:count=3;7:count=9;default:count=0;
  endcase
 end
 wire [7:0] text_q;reg [7:0] code;wire [15:0] bits;
 tft_text_rom labels(clk,{line,col},text_q);
 reg [6:0] value;reg [3:0] digit;
 wire right_effect=COMPACT_FX && col>=10;
 wire [4:0] digit_col=right_effect ? col-5'd10 : col;
 wire effect_digits=p==0 && digit_col>=4 && digit_col<=6 &&
  (COMPACT_FX ? (row==8 || row==9 || (row==10 && !right_effect)) : (row>=8 && row<=11));
 always @*begin
  value=COMPACT_FX ? (row==8 ? (right_effect?de:vo) : row==9 ? (right_effect?re:ch) : ph) :
        (row==8?vo:row==9?de:row==10?ch:re);
  digit=0;
  // 0..127 uses small bounded comparisons/subtractions, no hardware division.
  if(digit_col==4)digit=value>=100?4'd1:4'd0;
  else if(digit_col==5)begin
   if(value>=120)digit=2;else if(value>=110)digit=1;else if(value>=100)digit=0;
   else if(value>=90)digit=9;else if(value>=80)digit=8;else if(value>=70)digit=7;
   else if(value>=60)digit=6;else if(value>=50)digit=5;else if(value>=40)digit=4;
   else if(value>=30)digit=3;else if(value>=20)digit=2;else if(value>=10)digit=1;
  end else begin
   if(value>=120)digit=value-7'd120;else if(value>=110)digit=value-7'd110;
   else if(value>=100)digit=value-7'd100;else if(value>=90)digit=value-7'd90;
   else if(value>=80)digit=value-7'd80;else if(value>=70)digit=value-7'd70;
   else if(value>=60)digit=value-7'd60;else if(value>=50)digit=value-7'd50;
   else if(value>=40)digit=value-7'd40;else if(value>=30)digit=value-7'd30;
   else if(value>=20)digit=value-7'd20;else if(value>=10)digit=value-7'd10;else digit=value[3:0];
  end
  code=text_q;
  if(p==8 && row==0 && col>=5 && col<=7)begin
   case(col)5:digit=sd[23:16]/100;6:digit=(sd[23:16]%100)/10;7:digit=sd[23:16]%10;endcase
   case(digit)0:code=90;1:code=38;2:code=101;3:code=102;4:code=103;5:code=104;6:code=105;7:code=106;8:code=56;9:code=107;endcase
  end
  if(p==8 && row==0 && col>=11 && col<=12)begin
   digit=col==11?sd[28:24]/10:sd[28:24]%10;
   case(digit)0:code=90;1:code=38;2:code=101;3:code=102;4:code=103;5:code=104;6:code=105;7:code=106;8:code=56;9:code=107;endcase
  end
  if(effect_digits)begin
   case(digit)
    4'd0:code=7'd90;
    4'd1:code=7'd38;
    4'd2:code=7'd101;
    4'd3:code=7'd102;
    4'd4:code=7'd103;
    4'd5:code=7'd104;
    4'd6:code=7'd105;
    4'd7:code=7'd106;
    4'd8:code=7'd56;
    4'd9:code=7'd107;
    default:code=0;
   endcase
  end
  if(col==0 && ((p==9 && row=={1'b0,pa}+4'd2) || (p==3 && row==2) ||
   (p==5 && row==(mo?3:2)) || (p==7 && row=={1'b0,color}+4'd2)))code=7'd108;
 end
 tft_font_rom glyphs(clk,{code,y[3:0]},bits);
 wire highlighted=p==8?(row>=1 && row<=14 && row==c+1):(row>=2 && row<count+2 && row==c+2);
 always @(posedge clk)begin
  if(!rst_n)pixel<=0;
  else if(bits[15-x[3:0]])pixel<=16'hffff;
  else if(highlighted)pixel<=16'h0295;
  else if(row==0)pixel<=p!=8?16'h18e3:!sd[0]?16'h7800:sd[3]?16'h8800:sd[2]?16'h7b40:sd[1]?16'h0260:16'h18e3;
  else pixel<=16'h0841;
 end
endmodule
`default_nettype wire
