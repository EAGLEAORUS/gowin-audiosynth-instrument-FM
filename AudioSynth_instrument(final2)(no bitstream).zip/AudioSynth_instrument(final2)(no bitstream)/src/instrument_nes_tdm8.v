`default_nettype none
// Eight independent 8bit contexts share one arithmetic lane at the FM clock.
module instrument_nes_tdm8 #(parameter PRESETS=0)(
 input wire clk,rst_n,sample_tick,event_valid,online,
 input wire [39:0] event_data,input wire [1:0] event_source,
 input wire [3:0] release_sources,input wire release_channel,
 output reg [7:0] busy,gate,output wire idle,
 output reg signed [18:0] sample_sum,
 input wire preset_write,input wire [11:0] preset_address,input wire [31:0] preset_data,
 output wire [31:0] preset_status
);
 wire [7:0] note_on,note_off;
 wire [6:0] note,velocity;
 wire [15:0] assigned_sources;
 wire [7:0] releasing=busy & ~gate;
 instrument_tdm64_allocator #(.VOICES(8),.SOURCE_ENABLE(1),.SD_ONLY(1),.NES_ENABLE(1)) allocator(
  .clk(clk),.rst_n(rst_n),.event_valid(event_valid),.event_data(event_data),.online(online),
  .voice_busy(busy),.voice_gate(gate),.voice_releasing(releasing),.note_on(note_on),.note_off(note_off),
  .note(note),.velocity(velocity),.assigned_notes(),.assigned_channels(),.routed_events(),.steal_count(),
  .retrigger_count(),.patch_select(3'd5),.dynamic_mask(16'd0),.reserved(8'd0),
  .event_source(event_source),.assigned_sources(assigned_sources),.release_sources(release_sources),
  .release_channels({6'd0,release_channel,9'd0}),.pedal_snapshot(),.event_string(1'b0),.held_string());

 localparam [2:0] IDLE=0, LOAD=1, START=2, WAIT_RESULT=3, FETCH=4;
 reg [2:0] state,slot;
 reg [7:0] initialized,pending_on,pending_off,frame_on,frame_off;
 reg [7:0] pending_kill,frame_kill;
 wire panic=event_valid && event_data[31:28]==3 &&
            event_data[27:24]==9 && event_data[23:17]==120;
 wire [7:0] owned_sources;
 genvar source_slot;
 generate for(source_slot=0;source_slot<8;source_slot=source_slot+1)begin:kill_owner
  assign owned_sources[source_slot]=release_sources[assigned_sources[source_slot*2+:2]];
 end endgenerate
 reg [3:0] key[0:7];
 reg [6:0] strength[0:7];
 reg signed [18:0] sum;
 wire signed [15:0] voice_sample,stock_pcm,preset_pcm;
 wire stock_done,stock_active,preset_done,preset_active;
 wire use_preset,preset_reset;
 reg running_preset;
 assign voice_sample=running_preset?preset_pcm:stock_pcm;
 wire voice_done=running_preset?preset_done:stock_done;
 wire voice_active=running_preset?preset_active:stock_active;
 wire signed [18:0] next_sum=sum+{{3{voice_sample[15]}},voice_sample};
 (* syn_ramstyle="block_ram" *) reg [185:0] context_mem[0:7];
 reg [185:0] context_q;
 wire [182:0] context_out;
 wire [189:0] preset_context;
 generate if(PRESETS)begin:preset_library
  reg [10:0] cursor;
  reg [5:0] count;
  reg [4:0] selected;
  reg [4:0] patch[0:7];
  reg [31:0] word_q;
  wire [5:0] voice_addr;
  wire [10:0] read_addr={patch[slot],state==WAIT_RESULT?voice_addr:6'd0};
  (* syn_ramstyle="block_ram" *) reg [31:0] mem[0:2047];
  wire put=preset_write && preset_address==12'h424 && count==0;
  assign preset_reset=preset_write && preset_address==12'h428 && preset_data[5:0]==0;
  assign use_preset=count!=0 && word_q[1:0]!=0;
  assign preset_status={21'd0,selected,count};
  always @(posedge clk)begin
   if(put)mem[cursor]<=preset_data;
   word_q<=mem[read_addr];
  end
  integer j;
  always @(posedge clk)begin
   if(!rst_n)begin cursor<=0;count<=0;selected<=0;end
   else if(preset_write)case(preset_address)
    12'h420:if(count==0)cursor<=preset_data[10:0];
    12'h424:if(count==0)cursor<=cursor+1'b1;
    12'h428:if(preset_data[5:0]<=32)begin count<=preset_data[5:0];selected<=0;end
    12'h42c:if({1'b0,preset_data[4:0]}<count)selected<=preset_data[4:0];
    default:begin end
   endcase
   for(j=0;j<8;j=j+1)if(note_on[j])patch[j]<=selected;
  end
  nes_preset_voice voice(.clk(clk),.rst_n(rst_n && !preset_reset),
   .go(state==START && use_preset),.restart(frame_on[slot]),.release_note(frame_off[slot]),
   .key(key[slot]),.velocity(strength[slot]),.context_in({context_q,4'd0}),
   .context_out(preset_context),.addr(voice_addr),.word(word_q),
   .done(preset_done),.active(preset_active),.pcm(preset_pcm));
 end else begin:no_library
  assign preset_status=0;
  assign preset_reset=0;
  assign use_preset=0;
  assign preset_context=0;
  assign preset_done=0;
  assign preset_active=0;
  assign preset_pcm=0;
 end endgenerate
 wire [185:0] update_context=running_preset?preset_context[189:4]:{3'd0,context_out};
 always @(posedge clk)if(!rst_n)running_preset<=0;
  else if(state==START)running_preset<=use_preset;
 assign idle=state==IDLE;
 nes_context_voice voice(.clk(clk),.rst_n(rst_n && !preset_reset),.go(state==START && !use_preset),
  .cold(!initialized[slot]),.restart(frame_on[slot]),.release_note(frame_off[slot]),
  .context_in(context_q[182:0]),.key_index(key[slot]),.velocity(strength[slot]),
  .context_out(context_out),.done(stock_done),.pcm(stock_pcm),.active(stock_active));
 always @(posedge clk)begin
  if(state==WAIT_RESULT && voice_done)begin
   context_mem[slot]<=update_context;
   context_q<=update_context;
  end else context_q<=context_mem[slot];
 end

 integer i;
 always @(posedge clk)begin
  if(!rst_n || preset_reset)begin
   state<=IDLE;slot<=0;busy<=0;gate<=0;initialized<=0;
   pending_on<=0;pending_off<=0;frame_on<=0;frame_off<=0;pending_kill<=0;frame_kill<=0;sum<=0;sample_sum<=0;
   for(i=0;i<8;i=i+1)begin key[i]<=0;strength[i]<=0;end
  end else begin
   case(state)
    IDLE:if(sample_tick)begin
     frame_on<=pending_on;frame_off<=pending_off;pending_on<=0;pending_off<=0;
     frame_kill<=pending_kill;pending_kill<=0;
     slot<=0;sum<=0;state<=LOAD;
    end
    LOAD:if(busy[slot] && PRESETS && frame_kill[slot] && !frame_on[slot])begin
     busy[slot]<=0;gate[slot]<=0;initialized[slot]<=0;
     if(slot==7)begin sample_sum<=sum;state<=IDLE;end
     else slot<=slot+1'b1;
    end else if(busy[slot])state<=PRESETS?FETCH:START;
     else if(slot==7)begin sample_sum<=sum;state<=IDLE;end
     else slot<=slot+1'b1;
    FETCH:state<=START;
    START:state<=WAIT_RESULT;
    WAIT_RESULT:if(voice_done)begin
     initialized[slot]<=1;
     if(!voice_active)begin busy[slot]<=0;gate[slot]<=0;end
     sum<=next_sum;
     if(slot==7)begin sample_sum<=next_sum;state<=IDLE;end
     else begin slot<=slot+1'b1;state<=LOAD;end
    end
    default:state<=IDLE;
   endcase
   for(i=0;i<8;i=i+1)begin
    if(PRESETS && busy[i] && (panic || release_channel || owned_sources[i] || !online))begin
     pending_kill[i]<=1;pending_on[i]<=0;gate[i]<=0;
    end
    if(gate[i] && (note_off[i] || release_channel || owned_sources[i]))begin
     pending_off[i]<=1;gate[i]<=0;
    end
    if(note_on[i])begin
     key[i]<=note[3:0]-4'd4; // 36..51 to pad 0..15, modulo 16
     strength[i]<=velocity;
     busy[i]<=1;gate[i]<=1;pending_on[i]<=1;pending_off[i]<=0;pending_kill[i]<=0;
    end
   end
  end
 end
endmodule
`default_nettype wire
