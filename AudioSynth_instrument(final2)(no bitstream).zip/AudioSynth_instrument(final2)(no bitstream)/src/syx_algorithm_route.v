`default_nettype none
// Isolated prototype for the existing core10's26-bit operator result domain.
// Operator arithmetic/EG/phase state remain owned by core10, not this router.
// Flags follow the32 MSFA graphs (see adjacent SD_MSFA_NOTICE.txt).
module syx_algorithm_route(
 input wire [31:0] phase,input wire [7:0] flags,input wire [2:0] feedback,
 input wire signed [25:0] fb_old,fb_new,result,
 input wire signed [31:0] bus1,bus2,input wire signed [33:0] carriers,
 output wire [31:0] modulated_phase,
 output reg signed [31:0] next_bus1,next_bus2,
 output reg signed [33:0] next_carriers,output wire store_feedback);
 wire signed [26:0] fb_sum=$signed({fb_old[25],fb_old})+$signed({fb_new[25],fb_new});
 reg signed [31:0] fb_term;
 // The two history samples are averaged before applying the feedback level.
 always @*case(feedback)
  1:fb_term=$signed(fb_sum)>>>8;2:fb_term=$signed(fb_sum)>>>7;
  3:fb_term=$signed(fb_sum)>>>6;4:fb_term=$signed(fb_sum)>>>5;
  5:fb_term=$signed(fb_sum)>>>4;6:fb_term=$signed(fb_sum)>>>3;
  7:fb_term=$signed(fb_sum)>>>2;default:fb_term=0;
 endcase
 wire signed [31:0] source_bus=flags[5:4]==1?bus1:flags[5:4]==2?bus2:32'sd0;
 wire [31:0] modulation=source_bus+(flags[6]?fb_term:32'sd0);
 assign modulated_phase=phase+(modulation<<10); // explicit modulo2^32
 wire signed [31:0] wide_result={{6{result[25]}},result};
 wire signed [33:0] sum_result={{8{result[25]}},result};
 always @*begin
  next_bus1=bus1;next_bus2=bus2;next_carriers=carriers;
  case(flags[1:0])
   0:next_carriers=flags[2]?carriers+sum_result:sum_result;
   1:next_bus1=flags[2]?bus1+wide_result:wide_result;
   2:next_bus2=flags[2]?bus2+wide_result:wide_result;
   default:begin end
  endcase
 end
 assign store_feedback=flags[7];
endmodule
`default_nettype wire
