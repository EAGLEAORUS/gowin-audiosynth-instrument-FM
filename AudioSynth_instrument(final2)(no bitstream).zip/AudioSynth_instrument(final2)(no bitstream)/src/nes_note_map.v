`default_nettype none
module nes_note_map(
 input wire [3:0] key_index,output wire [6:0] midi_note,output wire [23:0] fcw
);
(* syn_ramstyle = "registers", ram_style = "distributed" *) reg [30:0] note_map[0:15];
initial begin
 note_map[0]={7'd60,24'd91445};
 note_map[1]={7'd62,24'd102643};
 note_map[2]={7'd64,24'd115213};
 note_map[3]={7'd65,24'd122064};
 note_map[4]={7'd67,24'd137012};
 note_map[5]={7'd69,24'd153791};
 note_map[6]={7'd71,24'd172625};
 note_map[7]={7'd72,24'd182890};
 note_map[8]={7'd74,24'd205287};
 note_map[9]={7'd76,24'd230426};
 note_map[10]={7'd77,24'd244128};
 note_map[11]={7'd79,24'd274025};
 note_map[12]={7'd81,24'd307582};
 note_map[13]={7'd83,24'd345249};
 note_map[14]={7'd84,24'd365779};
 note_map[15]={7'd86,24'd410573};
end
assign {midi_note,fcw}=note_map[key_index];
endmodule
`default_nettype wire
