`default_nettype none
// Migrated 24-bit register table. All writes ACK before done; NACK restarts list.
module audio_usb_es7243e_config #(parameter integer DATA_WIDTH=24) (
    input wire clk_50m, input wire ce, 
    input  wire rstn,           
    output wire i2c_sclk,
    inout  wire i2c_sdat,
    output wire reg_conf_done,  
    output wire i2c_ack         
);
    reg  [1:0]  config_step;
    reg  [23:0] i2c_data;
    reg  [15:0] reg_data;
    reg         start;
    reg         reg_conf_done_reg;
    reg  [8:0]  reg_index;
    wire        ack;
    wire        tr_end;
    audio_usb_i2c_write u_i2c_com (
        .clk_50m(clk_50m), .ce(ce),
        .rstn       (rstn       ),
        .ack        (ack        ),
        .i2c_data   (i2c_data   ),
        .start      (start      ),
        .tr_end     (tr_end     ),
        .i2c_sclk   (i2c_sclk   ),
        .i2c_sdat   (i2c_sdat   )
    );
    assign reg_conf_done = reg_conf_done_reg;
    reg ack_ok;
    always @(posedge clk_50m) begin
        if (ce) begin
        if (!rstn)
            ack_ok <= 1'b0;
        else if (tr_end && (ack == 1'b0))
            ack_ok <= 1'b1;
        end
    end
    assign i2c_ack = ack_ok;
    reg [7:0] dev_addr;         
    reg       addr_locked;      
    always @(posedge clk_50m) begin
        if (ce) begin
        if (!rstn) begin
            config_step       <= 2'd0;
            start             <= 1'b0;
            reg_index         <= 9'd0;
            reg_conf_done_reg <= 1'b0;
            dev_addr          <= 8'h20;
            addr_locked       <= 1'b0;
        end
        else if (reg_conf_done_reg == 1'b0) begin
            if (reg_index <= 9'd38) begin
                case (config_step)
                    2'd0: begin
                        i2c_data    <= {dev_addr, reg_data};
                        start       <= 1'b1;
                        config_step <= 2'd1;
                    end
                    2'd1: begin
                        if (tr_end) begin
                            start       <= 1'b0;
                            config_step <= 2'd2;
                        end
                    end
                    2'd2: begin
                        if (ack) begin
                            reg_index <= 9'd0;
                            if (!addr_locked) dev_addr <= (dev_addr == 8'h2E) ? 8'h20 : dev_addr + 8'h02;
                        end else begin
                            addr_locked <= 1'b1;
                            reg_index <= reg_index + 1'b1;
                        end
                        config_step <= 2'd0;
                    end
                    default: config_step <= 2'd0;
                endcase
            end
            else
                reg_conf_done_reg <= 1'b1;
        end
        end
    end
    always @(*) begin
        case (reg_index)
             9'd0 : reg_data = 16'h1000;   
             9'd1 : reg_data = 16'h013A;
             9'd2 : reg_data = 16'h0080;
             9'd3 : reg_data = 16'h0402;
             9'd4 : reg_data = 16'h0401;
             9'd5 : reg_data = 16'hF901;
             9'd6 : reg_data = 16'h001E;
             9'd7 : reg_data = 16'h0100;   
             9'd8 : reg_data = 16'h0200;
             9'd9 : reg_data = 16'h0320;
             9'd10: reg_data = 16'h0D00;
             9'd11: reg_data = 16'hF900;
             9'd12: reg_data = 16'h0402;
             9'd13: reg_data = 16'h0401;
             9'd14: reg_data = 16'h0500;
             9'd15: reg_data = 16'h0603;   
             9'd16: reg_data = 16'h0700;
             9'd17: reg_data = 16'h08FF;   
             9'd18: reg_data = 16'h09C5;
             9'd19: reg_data = 16'h0A81;   
             9'd20: reg_data = (DATA_WIDTH==16)?16'h0B0C:16'h0B00;   
             9'd21: reg_data = 16'h0EBF;
             9'd22: reg_data = 16'h0F80;
             9'd23: reg_data = 16'h140C;
             9'd24: reg_data = 16'h150C;
             9'd25: reg_data = 16'h1702;
             9'd26: reg_data = 16'h1826;
             9'd27: reg_data = 16'h1977;
             9'd28: reg_data = 16'h1AF4;
             9'd29: reg_data = 16'h1B66;
             9'd30: reg_data = 16'h1C44;
             9'd31: reg_data = 16'h1E00;
             9'd32: reg_data = 16'h1F0C;
             9'd33: reg_data = 16'h2010;
             9'd34: reg_data = 16'h2110;
             9'd35: reg_data = 16'h00C0;   
             9'd36: reg_data = 16'h013A;
             9'd37: reg_data = 16'h163F;
             9'd38: reg_data = 16'h1600;
             default: reg_data = 16'hFFFF;
        endcase
    end
endmodule

`default_nettype wire
