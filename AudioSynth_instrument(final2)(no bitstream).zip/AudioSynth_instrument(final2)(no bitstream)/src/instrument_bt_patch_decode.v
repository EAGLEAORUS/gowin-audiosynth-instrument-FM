`default_nettype none
// Private UART MIDI Program Change: CH1, program 0..4 uses existing patch IDs.
// No new register owner: accepted request enters instrument_patch_key UI input.
module instrument_bt_patch_decode(
 input wire event_valid,input wire [39:0] event_data,
 output wire patch_set,output wire [2:0] patch_value
);
 assign patch_set=event_valid && event_data[39:36]==0 &&
  event_data[35:32]==4'hc && event_data[31:28]==4'd4 &&
  event_data[27:24]==0 && event_data[9:8]==2 &&
  event_data[7:0]==8'hc0 && event_data[23:17]<=7'd4;
 assign patch_value=event_data[19:17];
endmodule
`default_nettype wire
