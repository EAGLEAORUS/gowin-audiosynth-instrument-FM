`default_nettype none
// State requests are pulses in the same 50MHz domain as their owners.
// The screen reads actual owner state, never a private copy of K1/K2 state.
module tft_menu #(parameter SD_ONLY=0)(input wire clk,rst_n,turn,clockwise,press,
 input wire [2:0] patch,input wire mode,
 output reg [3:0] page,cursor,output reg [1:0] color_target,
 output reg patch_set,output reg [2:0] patch_value,output reg mode_set,mode_value,
 output reg [2:0] wave_color,spectrum_color,overload_color,xy_color,input wire home_press,input wire menu_home,output reg sd_action_valid,output reg [3:0] sd_action);
 reg [3:0] count;
 always @*case(page)
  0,1,2,4,5:count=4;9:count=7;6:count=6;3:count=3;7:count=9;default:count=2;
 endcase
 always @(posedge clk)begin
  if(!rst_n)begin
   sd_action_valid<=0;sd_action<=0;page<=0;cursor<=0;color_target<=0;patch_set<=0;patch_value<=0;mode_set<=0;mode_value<=0;
   wave_color<=5;spectrum_color<=3;overload_color<=6;xy_color<=2;
  end else begin
   patch_set<=0;mode_set<=0;sd_action_valid<=0;
   if(menu_home)begin page<=0;cursor<=0;end
   else if(page==8)begin
    if(home_press)begin sd_action_valid<=1;sd_action<=3;end
    else if(turn)begin sd_action_valid<=1;sd_action<=clockwise?1:0;end
    else if(press)begin sd_action_valid<=1;sd_action<=2;end
   end
   else if(home_press)begin page<=4'd0;cursor<=4'd0;end
   else if(turn)begin
    if(clockwise)cursor<=cursor==count-1?4'd0:cursor+1'b1;
    else cursor<=cursor==0?count-1:cursor-1'b1;
   end else if(press)begin
    case(page)
     0:begin
      page<=cursor==0?(SD_ONLY?8:2):cursor==1?4:8;cursor<=0;
      if(SD_ONLY && cursor==0)begin sd_action_valid<=1;sd_action<=5;end
      else if(cursor>=2)begin sd_action_valid<=1;sd_action<=cursor==2?4:6;end
     end
     1:begin
      if(cursor<2)begin page<=cursor==0?9:3;cursor<=0;end
      else begin page<=cursor==2?2:0;cursor<=0;end
     end
     2:begin
      page<=cursor==0?1:cursor==1?8:0;cursor<=0;
      if(cursor<2)begin sd_action_valid<=1;sd_action<=cursor==1?5:7;end
     end
     9:begin
      if(cursor<5)begin patch_set<=1;patch_value<=cursor[2:0];end
      else begin page<=cursor==5?1:0;cursor<=0;end
     end
     3:begin if(cursor!=0)begin page<=cursor==1?1:0;cursor<=0;end end
     4:begin
      if(cursor<2)begin page<=cursor==0?5:6;cursor<=0;end
      else begin page<=0;cursor<=0;end
     end
     5:begin
      if(cursor<2)begin mode_set<=1;mode_value<=cursor[0];end
      else begin page<=cursor==2?4:0;cursor<=0;end
     end
     6:begin
      if(cursor<4)begin color_target<=cursor[1:0];page<=7;cursor<=0;end
      else begin page<=cursor==4?4:0;cursor<=0;end
     end
     7:begin
      if(cursor<7)case(color_target)
       0:wave_color<=cursor[2:0];1:spectrum_color<=cursor[2:0];
       2:overload_color<=cursor[2:0];3:xy_color<=cursor[2:0];
      endcase
      else begin page<=cursor==7?6:0;cursor<=0;end
     end
     default:begin page<=0;cursor<=0;end
    endcase
   end
  end
 end
endmodule
`default_nettype wire
