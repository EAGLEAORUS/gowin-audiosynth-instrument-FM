`default_nettype none
// Based on the supplied board example's GRB/MSB-first wire protocol:
// at 50 MHz, bit=62 clocks (1.24us), T0H=20 (0.40us), T1H=42 (0.84us).
// One on-board LED, registered output, whole-color snapshot per frame.
module audio_usb_ws2812_status #(
 parameter integer REFRESH_CYCLES=500000, RESET_CYCLES=20000,
 parameter integer BIT_CYCLES=62, T0H=20, T1H=42
)(input wire clk,rst_n,dac_ok,adc_ok,output reg dout);
 localparam [23:0] RED_GRB=24'h002000, ICE_BLUE_GRB=24'h180820, GREEN_GRB=24'h200000;
 wire [23:0] color=!dac_ok?RED_GRB:(!adc_ok?ICE_BLUE_GRB:GREEN_GRB);
 reg [23:0] shift;
 reg [31:0] idle_count;
 reg [6:0] phase;
 reg [4:0] bit_index;
 reg busy,first_frame;
 always @(posedge clk)begin
  if(!rst_n)begin
   dout<=0;shift<=0;idle_count<=0;phase<=0;bit_index<=0;busy<=0;first_frame<=1;
  end else if(!busy)begin
   dout<=0;
   if(idle_count==(first_frame?RESET_CYCLES-1:REFRESH_CYCLES-1))begin
    shift<=color;idle_count<=0;phase<=0;bit_index<=0;busy<=1;first_frame<=0;
   end else idle_count<=idle_count+32'd1;
  end else begin
   dout<=phase<(shift[23]?T1H:T0H);
   if(phase==BIT_CYCLES-1)begin
    phase<=0;
    if(bit_index==23)begin busy<=0;idle_count<=0;end
    else begin bit_index<=bit_index+5'd1;shift<={shift[22:0],1'b0};end
   end else phase<=phase+7'd1;
  end
 end
endmodule
`default_nettype wire
