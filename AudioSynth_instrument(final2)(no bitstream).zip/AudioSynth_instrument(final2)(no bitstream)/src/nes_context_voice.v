`default_nettype none
// One shared NES arithmetic lane.183bit context is stored in one existing FM
// OP records per allocated note; no per-pad duplication of the waveform engine.
module nes_context_voice(
 input wire clk,rst_n,go,cold,restart,release_note,
 input wire [182:0] context_in,input wire [3:0] key_index,input wire [6:0] velocity,
 output wire [182:0] context_out,output reg done,output reg signed [15:0] pcm,output wire active
);
 reg [3:0] key_q;reg [6:0] velocity_q;
 reg [3:0] step;reg [23:0] phase;reg [10:0] age;reg pending;
 reg [16:0] gain;reg [1:0] estate;reg [7:0] ramp,error;
 reg [23:0] acc;reg divider;reg [3:0] env;reg [14:0] lfsr;reg [23:0] residue;
 reg [16:0] previous;reg signed [26:0] y,ynext;reg [16:0] mix_sample;
 reg signed [17:0] audio;reg signed [35:0] product;
 assign context_out={phase,age,pending,gain,estate,ramp,error,acc,divider,env,lfsr,residue,previous,y};
 assign active=estate!=0;
 wire [6:0] unused_note;wire [23:0] fcw;nes_note_map pitch(key_q,unused_note,fcw);
 wire [24:0] advanced={1'b0,acc}+25'd48079;
 wire qframe=advanced>=25'd9600000;wire decay=qframe && divider==1;
 wire [3:0] env_now=decay?(env!=0?env-1'b1:4'd0):env;
 wire [3:0] vol,nvol;
 nes_volume_tables volume(velocity_q,vol,env_now,vol,nvol);
 wire [3:0] p1=active && phase[23:21]>=6?vol:4'd0;
 wire [3:0] p2=active && phase[23:21]==7?vol:4'd0;
 wire [3:0] tr=active?(phase[23]?phase[22:19]:4'd15-phase[22:19]):4'd0;
 wire [3:0] nz=active && lfsr[0]?nvol:4'd0;
 wire [16:0] mixed;nes_mixer_lut mixer(p1,p2,tr,nz,mixed);
 wire [8:0] ae={1'b0,error}+9'd64,re={1'b0,error}+9'd16;
 wire signed [27:0] delta=$signed({1'b0,mix_sample,8'd0})-$signed({1'b0,previous,8'd0});
 wire signed [27:0] dy=delta+$signed(y)-($signed(y)>>>9);
 wire signed [36:0] rounded=$signed({product[35],product})+37'sd65536;
 wire signed [36:0] scaled=rounded>>>17;
 always @(posedge clk)begin
  if(!rst_n)begin step<=0;done<=0;pcm<=0;key_q<=0;velocity_q<=0;phase<=0;age<=0;pending<=0;gain<=0;estate<=0;ramp<=0;error<=48;acc<=0;divider<=0;env<=15;lfsr<=1;residue<=0;previous<=0;y<=0;ynext<=0;mix_sample<=0;audio<=0;product<=0;end
  else begin
   done<=0;
   case(step)
    0:if(go)begin key_q<=key_index;velocity_q<=velocity;
     if(cold)begin phase<=0;age<=0;pending<=0;gain<=0;estate<=0;ramp<=0;error<=48;acc<=0;divider<=0;env<=15;lfsr<=1;residue<=0;previous<=0;y<=0;end
     else {phase,age,pending,gain,estate,ramp,error,acc,divider,env,lfsr,residue,previous,y}<=context_in;
     step<=1;
    end
    1:begin
     // Start and release can be queued between the same two audio frames.
     // Keep that release while restarting the minimum-gate envelope.
     if(restart)begin phase<=0;age<=0;pending<=release_note;gain<=0;estate<=1;ramp<=0;error<=48;acc<=0;divider<=0;env<=15;lfsr<=1;residue<=0;end
     else if(release_note && active)pending<=1;
     step<=2;
    end
    2:begin
     mix_sample<=mixed;
     acc<=qframe?advanced-25'd9600000:advanced[23:0];
     if(qframe)begin divider<=decay?4'd0:divider+1'b1;env<=env_now;end
     if(active)begin
      phase<=phase+fcw;residue<=residue+28'd1789773;
      if(age<1440)age<=age+1'b1;
      case(estate)
       1:begin gain<=gain+17'd682+(ae>=96?17'd1:17'd0);error<=ae>=96?ae-9'd96:ae[7:0];if(ramp==95)begin estate<=2;ramp<=0;end else ramp<=ramp+1'b1;end
       2:gain<=17'd65536;
       3:begin gain<=gain-17'd273-(re>=240?17'd1:17'd0);error<=re>=240?re-9'd240:re[7:0];if(ramp==239)begin estate<=0;gain<=0;end else ramp<=ramp+1'b1;end
       default:gain<=0;
      endcase
      if(estate!=3 && pending && age>=1439)begin estate<=3;ramp<=0;error<=120;end
     end
     step<=3;
    end
    3:begin
     ynext<=dy[26:0];
     if(residue>=28'd12192000)begin residue<=residue-28'd12192000;lfsr<={lfsr[0]^lfsr[1],lfsr[14:1]};end
     step<=4;
    end
    4:begin y<=ynext;previous<=mix_sample;audio<=ynext>>>8;step<=5;end
    5:begin product<=audio*$signed({1'b0,gain});step<=6;end
    6:begin
     if(scaled>32767)pcm<=16'sh7fff;else if(scaled< -32768)pcm<=16'sh8000;else pcm<=scaled[15:0];
     done<=1;step<=0;
    end
    default:step<=0;
   endcase
  end
 end
endmodule
`default_nettype wire
