`default_nettype none
// All controls are in the existing 50MHz committed MIDI event domain.
// Q0.20 intensities, alpha Q0.24; 1kHz ticks from 48 audio frames.
module instrument_effects_control(
 input wire clk,rst_n,sample_tick,event_valid,input wire [39:0] event_data,input wire online,
 output reg [6:0] delay_value,chorus_value,reverb_value,
 output reg [17:0] delay_mix,delay_feedback,chorus_mix,reverb_mix,
 output reg [23:0] chorus_depth,
 output reg [17:0] g0,g1,g2,g3,
 output reg [31:0] accepted,updates,
 output reg [20:0] smooth_delay,smooth_chorus,smooth_reverb
);
 wire selected=event_valid && online && event_data[39:36]==0 && event_data[35:32]==4'hb &&
  event_data[31:28]==3 && event_data[27:24]==0 && event_data[9:8]==3 && event_data[7:0]==8'hb0;
 wire [6:0] ctrl=event_data[23:17],val=event_data[16:10];
 wire [20:0] td,tc,tr;
 instrument_effects_target target_d(delay_value,td);
 instrument_effects_target target_c(chorus_value,tc);
 instrument_effects_target target_r(reverb_value,tr);
 reg [5:0] frame_count;reg [3:0] state;
 reg signed [21:0] dd,dc,dr;
 reg signed [42:0] pd,pc,pr;
 reg [20:0] nd,nc,nr;reg [10:0] ra,rb;reg [9:0] frac;
 wire [89:0] qa,qb;reg [89:0] base;
 instrument_effects_reverb_pair pair_rom(clk,ra,qa,qb);
 reg signed [18:0] df[0:4];reg signed [29:0] ip[0:4];
 reg [38:0] md,gd,mc;reg [24:0] depth;
 integer i;
 function [20:0] smooth_next;
 input [20:0] old;input signed [42:0] prod;input signed [21:0] delta;
 reg signed [43:0] v;reg signed [21:0] step;
 begin
  v=prod;v=v+(prod<0 ? 44'sd8388607 : 44'sd8388608);step=v>>>24;
  if(step==0 && delta!=0)step=delta<0 ? -22'sd1 : 22'sd1;
  smooth_next=$signed({1'b0,old})+step;
 end endfunction
 function [17:0] interpolate;
 input [17:0] lo;input signed [29:0] product;
 reg signed [30:0] v;
 begin v=product;v=v+(product<0 ? 31'sd511 : 31'sd512);interpolate=$signed({1'b0,lo})+(v>>>10);end
 endfunction
 always @(posedge clk)begin
  if(!rst_n)begin
   delay_value<=0;chorus_value<=0;reverb_value<=0;accepted<=0;updates<=0;
   frame_count<=0;state<=0;smooth_delay<=0;smooth_chorus<=0;smooth_reverb<=0;
   delay_mix<=0;delay_feedback<=0;chorus_mix<=0;chorus_depth<=0;reverb_mix<=0;
   g0<=79598;g1<=77086;g2<=74285;g3<=71587;ra<=0;rb<=1;
  end else begin
   if(selected)case(ctrl)
    77:begin delay_value<=val;if(!(&accepted))accepted<=accepted+1'b1;end
    93:begin chorus_value<=val;if(!(&accepted))accepted<=accepted+1'b1;end
    73:begin reverb_value<=val;if(!(&accepted))accepted<=accepted+1'b1;end
    default:begin end
   endcase
   if(sample_tick)begin
    frame_count<=frame_count==47 ? 0 : frame_count+1'b1;
    if(frame_count==0)begin
     dd<=$signed({1'b0,td})-$signed({1'b0,smooth_delay});
     dc<=$signed({1'b0,tc})-$signed({1'b0,smooth_chorus});
     dr<=$signed({1'b0,tr})-$signed({1'b0,smooth_reverb});state<=1;
    end
   end
   case(state)
    1:begin pd<=dd*21'sd818234;pc<=dc*21'sd818234;pr<=dr*21'sd818234;state<=2;end
    2:begin
     nd<=delay_value==0 ? 21'd0 : smooth_next(smooth_delay,pd,dd);
     nc<=chorus_value==0 ? 21'd0 : smooth_next(smooth_chorus,pc,dc);
     nr<=reverb_value==0 ? 21'd0 : smooth_next(smooth_reverb,pr,dr);state<=3;
    end
    3:begin
     smooth_delay<=nd;smooth_chorus<=nc;smooth_reverb<=nr;
     md<=nd*18'd98304;gd<=nd*18'd107479;mc<=nc*18'd85197;depth<=nc*5'd15;
     ra<=nr[20:10];rb<=nr[20:10]==1024 ? 11'd1024 : nr[20:10]+11'd1;frac<=nr[9:0];state<=4;
    end
    4:state<=5;
    5:begin
     base<=qa;
     for(i=0;i<5;i=i+1)df[i]<=$signed({1'b0,qb[18*i+:18]})-$signed({1'b0,qa[18*i+:18]});
     state<=6;
    end
    6:begin for(i=0;i<5;i=i+1)ip[i]<=df[i]*$signed({1'b0,frac});state<=7;end
    7:begin
     delay_mix<=(md+39'd524288)>>20;delay_feedback<=(gd+39'd524288)>>20;
     chorus_mix<=(mc+39'd524288)>>20;chorus_depth<=depth[23:0];
     reverb_mix<=interpolate(base[89:72],ip[4]);g0<=interpolate(base[71:54],ip[3]);
     g1<=interpolate(base[53:36],ip[2]);g2<=interpolate(base[35:18],ip[1]);g3<=interpolate(base[17:0],ip[0]);
     if(!(&updates))updates<=updates+1'b1;state<=0;
    end
    default:begin end
   endcase
  end
 end
endmodule
`default_nettype wire
