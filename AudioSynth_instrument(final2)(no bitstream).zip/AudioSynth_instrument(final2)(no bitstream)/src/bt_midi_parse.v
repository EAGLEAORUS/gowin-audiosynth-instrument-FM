`default_nettype none
// MIDI 1.0 byte stream -> the project's committed 40-bit event, bit-for-bit
// the same layout usb_midi_payload_decode emits. Running status, 2/3-byte
// channel messages, system common, SysEx discard. Realtime bytes (F8..FF) do
// not disturb the parser; 0xFE is reported as the ESP32 link heartbeat.
module bt_midi_parse(
 input wire clk,rst_n,byte_valid,input wire [7:0] byte_data,
 output reg evt_valid,output reg [39:0] evt_data,output reg heartbeat
);
 reg [7:0] status;
 reg [1:0] need,got;
 reg [6:0] d1,d2;
 reg sysex;
 wire data_byte=!byte_data[7];
 wire [6:0] nd1=(got==2'd0)?byte_data[6:0]:d1;
 wire [6:0] nd2=(got==2'd0)?7'd0:byte_data[6:0];
 wire [3:0] hi=status[7:4];
 reg [3:0] kind;
 reg [3:0] cin;
 always @(*)begin
  kind=4'd0;cin=4'd0;
  case(hi)
   4'h8:begin kind=4'd1;cin=4'h8;end
   4'h9:begin kind=(nd2==7'd0)?4'd1:4'd2;cin=4'h9;end
   4'ha:begin kind=4'd6;cin=4'ha;end
   4'hb:begin kind=4'd3;cin=4'hb;end
   4'hc:begin kind=4'd4;cin=4'hc;end
   4'hd:begin kind=4'd7;cin=4'hd;end
   4'he:begin kind=4'd5;cin=4'he;end
   default:kind=4'd0;
  endcase
 end
 always @(posedge clk)begin
  if(!rst_n)begin
   status<=8'd0;need<=2'd0;got<=2'd0;d1<=7'd0;d2<=7'd0;sysex<=0;
   evt_valid<=0;evt_data<=40'd0;heartbeat<=0;
  end else begin
   evt_valid<=0;heartbeat<=0;
   if(byte_valid)begin
    if(data_byte)begin
     if(!sysex && status!=8'd0)begin
      if(got+2'd1==need)begin
       got<=2'd0;
       if(status<8'hf0)begin
        evt_valid<=1;
        evt_data<={4'd0,cin,kind,status[3:0],nd1,nd2,(need+2'd1),status};
       end else begin
        // System common F1/F2/F3: no running status afterwards.
        evt_valid<=1;
        evt_data<={4'd0,(status==8'hf2)?4'h3:4'h2,4'd8,4'd0,nd1,nd2,(need+2'd1),status};
        status<=8'd0;need<=2'd0;d1<=7'd0;d2<=7'd0;
       end
      end else begin
       got<=got+2'd1;d1<=nd1;d2<=nd2;
      end
     end
    end else if(byte_data>=8'hf8)begin
     if(byte_data==8'hfe)heartbeat<=1;
    end else if(byte_data==8'hf0)begin
     sysex<=1;status<=8'd0;need<=2'd0;got<=2'd0;
    end else if(byte_data==8'hf7)begin
     sysex<=0;status<=8'd0;need<=2'd0;got<=2'd0;
    end else begin
     sysex<=0;got<=2'd0;d1<=7'd0;d2<=7'd0;
     case(byte_data)
      8'hf1,8'hf3:begin status<=byte_data;need<=2'd1;end
      8'hf2:begin status<=byte_data;need<=2'd2;end
      8'hf6:begin
       status<=8'd0;need<=2'd0;
       evt_valid<=1;evt_data<={4'd0,4'h5,4'd8,4'd0,7'd0,7'd0,2'd1,8'hf6};
      end
      default:begin
       // Channel voice messages 0x80..0xEF: keep running status and the
       // number of data bytes (2 for Program Change and Channel Pressure).
       if(byte_data<8'hf0)begin
        status<=byte_data;
        need<=(byte_data[7:4]==4'hc||byte_data[7:4]==4'hd)?2'd1:2'd2;
       end else begin
        status<=8'd0;need<=2'd0;
       end
      end
     endcase
    end
   end
  end
 end
endmodule
`default_nettype wire
