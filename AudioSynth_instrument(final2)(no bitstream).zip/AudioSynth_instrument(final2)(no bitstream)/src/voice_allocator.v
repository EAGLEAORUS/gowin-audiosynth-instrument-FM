`default_nettype none
// Four-note allocator, accepting every event at audio clk, never only at tick.
// Total LRU order uses 2-bit ranks, avoiding timestamp rollover ambiguity.
module voice_allocator #(parameter [3:0] MIDI_CHANNEL=4'd0)(
 input wire clk,rst_n,event_valid,input wire [39:0] event_data,input wire online,
 input wire [3:0] voice_busy,voice_gate,voice_releasing,
 output reg [3:0] note_on,note_off,
 output wire [6:0] note,velocity,
 output wire [27:0] assigned_notes,output wire [15:0] assigned_channels,
 output reg [31:0] routed_events,steal_count,retrigger_count);
 wire [3:0] kind=event_data[31:28],channel=event_data[27:24];
 assign note=event_data[23:17];assign velocity=event_data[16:10];
 wire selected=channel==MIDI_CHANNEL && note>=48 && note<=72;
 wire on_event=selected && kind==2 && velocity!=0;
 wire off_event=selected && (kind==1 || (kind==2 && velocity==0));
 wire all_off=channel==MIDI_CHANNEL && kind==3 && (note==120 || note==123);
 reg [3:0] owned;
 reg [6:0] held_note[0:3];reg [3:0] held_channel[0:3];reg [1:0] rank[0:3];
 integer i,chosen,match_index,idle_index,release_index,oldest_index;
 reg [1:0] release_rank,oldest_rank;reg stealing,retriggering;
 genvar g;generate for(g=0;g<4;g=g+1)begin:debug_mapping
  assign assigned_notes[g*7+:7]=held_note[g];
  assign assigned_channels[g*4+:4]=held_channel[g];
 end endgenerate
 always @* begin
  chosen=-1;match_index=-1;idle_index=-1;release_index=-1;oldest_index=-1;
  release_rank=3;oldest_rank=3;note_on=0;note_off=0;stealing=0;retriggering=0;
  for(i=0;i<4;i=i+1)begin
   if(owned[i] && voice_busy[i] && held_note[i]==note && held_channel[i]==channel && match_index<0)match_index=i;
   if(!voice_busy[i] && idle_index<0)idle_index=i;
   if(voice_busy[i] && voice_releasing[i] && (release_index<0 || rank[i]<release_rank))begin release_index=i;release_rank=rank[i];end
   if(voice_busy[i] && (oldest_index<0 || rank[i]<oldest_rank))begin oldest_index=i;oldest_rank=rank[i];end
  end
  if(!online)note_off=voice_gate;
  else if(event_valid)begin
   if(on_event)begin
    if(match_index>=0)chosen=match_index;
    else if(idle_index>=0)chosen=idle_index;
    else if(release_index>=0)chosen=release_index;
    else chosen=oldest_index;
    if(chosen>=0)begin
     note_on=4'b0001<<chosen;
     stealing=voice_busy[chosen] && chosen!=match_index;
     retriggering=chosen==match_index;
    end
   end else if(off_event || all_off)begin
    for(i=0;i<4;i=i+1)
     if(owned[i] && voice_gate[i] && held_channel[i]==channel && (all_off || held_note[i]==note))note_off[i]=1;
   end
  end
 end
 integer k;
 always @(posedge clk)begin
  if(!rst_n)begin
   owned<=0;routed_events<=0;steal_count<=0;retrigger_count<=0;
   for(k=0;k<4;k=k+1)begin held_note[k]<=0;held_channel[k]<=0;rank[k]<=k[1:0];end
  end else begin
   for(k=0;k<4;k=k+1)begin
    if(!voice_busy[k])owned[k]<=0;
    if(note_on[k])begin owned[k]<=1;held_note[k]<=note;held_channel[k]<=channel;rank[k]<=2'd3;end
    else if(chosen>=0 && note_on!=0 && rank[k]>rank[chosen])rank[k]<=rank[k]-2'd1;
   end
   if(online && event_valid && (note_on!=0 || note_off!=0))routed_events<=routed_events+32'd1;
   if(stealing)steal_count<=steal_count+32'd1;
   if(retriggering)retrigger_count<=retrigger_count+32'd1;
  end
 end
endmodule
`default_nettype wire
