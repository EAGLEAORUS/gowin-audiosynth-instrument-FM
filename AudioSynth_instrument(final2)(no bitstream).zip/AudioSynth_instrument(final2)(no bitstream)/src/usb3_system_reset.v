`default_nettype none
// KEY0 asserts immediately; release requires 10ms continuously released.
// Each consuming clock domain still uses its own reset-release synchronizer.
module usb3_system_reset #(parameter integer RELEASE_CYCLES=500000)(
 input wire clk,key0_n,output wire rst_n);
 (* syn_preserve=1 *) reg key_meta=0,key_sync=0;
 reg [$clog2(RELEASE_CYCLES+1)-1:0] count=0;
 reg released=0;
 always @(posedge clk or negedge key0_n)if(!key0_n)key_meta<=0;else key_meta<=1;
 always @(posedge clk)key_sync<=key_meta;
 always @(posedge clk or negedge key0_n)begin
  if(!key0_n)begin count<=0;released<=0;end
  else if(!key_sync)begin count<=0;released<=0;end
  else if(count<RELEASE_CYCLES)count<=count+1'b1;
  else released<=1;
 end
 assign rst_n=key0_n && released;
endmodule
`default_nettype wire
