`default_nettype none
// Integration boundary only: DOES NOT enumerate USB or drive D+/D-.
// All ports are synchronous to clk. rst_n must be released in this domain.
module usb_midi_debug #(parameter CLK_HZ=50000000,parameter BAUD=115200,
 parameter PACKET_ADDR_BITS=3,parameter EVENT_ADDR_BITS=6,
 parameter LOG_ADDR_BITS=6,parameter RAW_ADDR_BITS=3,parameter SERVICE_ENABLE=0)(
 input wire clk,input wire rst_n,
 input wire packet_valid,input wire [6:0] packet_length,input wire [511:0] packet_data,
 input wire raw_enable,input wire status_valid,input wire [2:0] status_code,
 output wire uart_tx,
 output wire evt_valid,input wire evt_ready,output wire [39:0] evt_data,
 output wire [31:0] packet_overflow,event_overflow,
 output wire [31:0] event_log_overflow,raw_log_overflow,status_log_overflow,
 output wire [31:0] malformed_count,unsupported_count,
 output wire recovery_required,output wire packet_ready,raw_ready,
 input wire service_lock,service_valid,input wire [7:0] service_data,output wire service_ready
);
 wire pv,pp,ep;
 wire [518:0] pkt;
 wire [39:0] event_word;
 midi_sync_fifo_packed #(519,PACKET_ADDR_BITS) packets(clk,rst_n,packet_valid,{packet_length,packet_data},packet_ready,pv,pkt,pp,packet_overflow);
 usb_midi_payload_decode decode(clk,rst_n,pv,pp,pkt,ep,event_word,malformed_count,unsupported_count);
 midi_sync_fifo_fwft_ram #(40,EVENT_ADDR_BITS) events(clk,rst_n,ep,event_word,,evt_valid,evt_data,evt_ready,event_overflow);
 midi_debug_logger #(CLK_HZ,BAUD,LOG_ADDR_BITS,RAW_ADDR_BITS,SERVICE_ENABLE) logger(
  clk,rst_n,ep,event_word,(packet_valid && raw_enable && packet_length<=64) || (status_valid && status_code==7),
  {packet_length,packet_data},status_valid && status_code!=7,status_code,uart_tx,
  event_log_overflow,raw_log_overflow,status_log_overflow,
  status_valid && status_code==7 && packet_length<=64,raw_ready,service_lock,service_valid,service_data,service_ready);
 assign recovery_required=(packet_overflow!=0)||(event_overflow!=0);
endmodule
`default_nettype wire
