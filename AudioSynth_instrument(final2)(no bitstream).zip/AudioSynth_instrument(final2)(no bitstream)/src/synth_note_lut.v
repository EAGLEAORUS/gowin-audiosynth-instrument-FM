`default_nettype none
// Orca CH01 received 48..72 -> concert C4..C6 (+12 semitones).
module synth_note_lut(input wire [6:0] note,output reg [31:0] increment);
 always @* begin
  case(note)
   7'd48:increment=32'd23012828;
   7'd49:increment=32'd24381242;
   7'd50:increment=32'd25831026;
   7'd51:increment=32'd27367019;
   7'd52:increment=32'd28994347;
   7'd53:increment=32'd30718440;
   7'd54:increment=32'd32545054;
   7'd55:increment=32'd34480283;
   7'd56:increment=32'd36530588;
   7'd57:increment=32'd38702809;
   7'd58:increment=32'd41004198;
   7'd59:increment=32'd43442435;
   7'd60:increment=32'd46025656;
   7'd61:increment=32'd48762484;
   7'd62:increment=32'd51662052;
   7'd63:increment=32'd54734038;
   7'd64:increment=32'd57988693;
   7'd65:increment=32'd61436880;
   7'd66:increment=32'd65090107;
   7'd67:increment=32'd68960566;
   7'd68:increment=32'd73061175;
   7'd69:increment=32'd77405619;
   7'd70:increment=32'd82008396;
   7'd71:increment=32'd86884869;
   7'd72:increment=32'd92051312;
   default:increment=32'd0;
  endcase
 end
endmodule
`default_nettype wire
