`default_nettype none
// Four 16-voice lanes in production. Allocation, generation checks and atomic
// publication are owned by its caller. Never write a sounding slot's config.
module instrument_tdm64_bank #(parameter integer KILL_ENABLE=0,parameter CHANNEL_CONTROL_ENABLE=0,parameter SD_ONLY=0,parameter NES_ENABLE=0,parameter integer VOICES_PER_CORE=10)(
 input wire clk,rst_n,sample_tick,input wire[4*VOICES_PER_CORE-1:0] note_on,note_off,
 input wire[6:0] note,velocity,input wire[2:0] patch_select,
 input wire[23:0] pitch_ratio,flute_pitch_ratio,string_ratio,input wire[17:0] flute_am_pt,
 input wire cfg_we,meta_we,input wire[5:0] cfg_slot,input wire[2:0] cfg_op,
 input wire[107:0] cfg_data,input wire[7:0] meta_data,
 output wire[4*VOICES_PER_CORE-1:0] busy,gate,releasing,output wire[4*VOICES_PER_CORE*32-1:0] voice_raw,
 output wire[3:0] lane_idle,lane_valid,output wire[135:0] ep_mix,cel_mix,
 output wire[127:0] lane_deadline,lane_ranges,output wire[63:0] lane_cycles,
 input wire[4*VOICES_PER_CORE-1:0] kill_slot,
 input wire[3:0] note_channel,input wire control_we,input wire[3:0] control_channel,input wire[34:0] control_data);
 localparam integer CONFIG_ADDR_BITS=$clog2(6*VOICES_PER_CORE);
 // The four lanes read one shared channel table through four registered
 // read ports. Only the tiny read registers are duplicated, never16 states.
 reg [34:0] controls[0:15];reg [15:0] controls_valid;
 always @(posedge clk)begin
  if(CHANNEL_CONTROL_ENABLE && control_we)controls[control_channel]<=control_data;
  if(!rst_n)controls_valid<=0;
  else if(CHANNEL_CONTROL_ENABLE && control_we)controls_valid[control_channel]<=1;
 end
 genvar g;generate for(g=0;g<4;g=g+1)begin:lanes
  localparam [6:0] FIRST_SLOT=g*VOICES_PER_CORE, END_SLOT=(g+1)*VOICES_PER_CORE;
  wire selected=cfg_slot>=FIRST_SLOT && cfg_slot<END_SLOT;
  wire [5:0] local_slot=cfg_slot-FIRST_SLOT;
  wire [CONFIG_ADDR_BITS-1:0] address_slot=local_slot;
  wire [CONFIG_ADDR_BITS-1:0] config_address=(address_slot<<2)+(address_slot<<1)+cfg_op;
  wire signed[23:0] unused_pcm;wire[31:0] unused_clips;
  wire[3:0] control_read_channel;reg[34:0] control_q;reg control_q_valid;
  always @(posedge clk)begin control_q<=controls[control_read_channel];control_q_valid<=controls_valid[control_read_channel];end
  instrument_tdm64_core #(.VOICES(VOICES_PER_CORE),.PITCH_ENABLE(1),.KILL_ENABLE(KILL_ENABLE),.CHANNEL_CONTROL_ENABLE(CHANNEL_CONTROL_ENABLE),.CHANNEL_CONTROL_EXTERNAL(1),.SD_ONLY(SD_ONLY),.NES_ENABLE(NES_ENABLE)) core(
   .clk(clk),.rst_n(rst_n),.sample_tick(sample_tick),.note_on(note_on[g*VOICES_PER_CORE+:VOICES_PER_CORE]),.note_off(note_off[g*VOICES_PER_CORE+:VOICES_PER_CORE]),
   .note(note),.velocity(velocity),.patch_select(patch_select),.pitch_ratio(pitch_ratio),.flute_pitch_ratio(flute_pitch_ratio),.string_ratio(string_ratio),.flute_am_pt(flute_am_pt),
   .pcm(unused_pcm),.pcm_valid(lane_valid[g]),.busy(busy[g*VOICES_PER_CORE+:VOICES_PER_CORE]),.gate(gate[g*VOICES_PER_CORE+:VOICES_PER_CORE]),.releasing(releasing[g*VOICES_PER_CORE+:VOICES_PER_CORE]),.voice_raw(voice_raw[g*VOICES_PER_CORE*32+:VOICES_PER_CORE*32]),.idle(lane_idle[g]),
   .ep_mix(ep_mix[g*34+:34]),.cel_mix(cel_mix[g*34+:34]),.deadline_miss(lane_deadline[g*32+:32]),.range_errors(lane_ranges[g*32+:32]),.last_cycles(lane_cycles[g*16+:16]),.clip_count(unused_clips),
   .cfg_we(cfg_we && selected && cfg_op<6),.cfg_write_address(config_address),.cfg_write_data(cfg_data),
   .meta_we(meta_we && selected),.meta_slot(local_slot[3:0]),.meta_data(meta_data),.kill_slot(kill_slot[g*VOICES_PER_CORE+:VOICES_PER_CORE]),
   .note_channel(note_channel),.control_we(1'b0),.control_channel(control_channel),.control_data(control_data),
   .control_read_channel(control_read_channel),.external_control_q(control_q),.external_control_valid(control_q_valid));
 end endgenerate
endmodule
`default_nettype wire
