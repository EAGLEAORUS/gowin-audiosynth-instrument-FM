`default_nettype none
// 128 logarithmic intervals spanning nominal 20Hz..20kHz; edges use Q8 FFT-bin units.
module live_tables(input wire [6:0] column,input wire [4:0] level,output reg [9:0] low_bin,high_bin,output reg [32:0] threshold,output reg [7:0] low_fraction,high_fraction);
always @* begin
case(column)
7'd0:begin low_bin=10'd0;high_bin=10'd0;low_fraction=8'd109;high_fraction=8'd115;end
7'd1:begin low_bin=10'd0;high_bin=10'd0;low_fraction=8'd115;high_fraction=8'd122;end
7'd2:begin low_bin=10'd0;high_bin=10'd0;low_fraction=8'd122;high_fraction=8'd128;end
7'd3:begin low_bin=10'd0;high_bin=10'd0;low_fraction=8'd128;high_fraction=8'd136;end
7'd4:begin low_bin=10'd0;high_bin=10'd0;low_fraction=8'd136;high_fraction=8'd143;end
7'd5:begin low_bin=10'd0;high_bin=10'd0;low_fraction=8'd143;high_fraction=8'd151;end
7'd6:begin low_bin=10'd0;high_bin=10'd0;low_fraction=8'd151;high_fraction=8'd159;end
7'd7:begin low_bin=10'd0;high_bin=10'd0;low_fraction=8'd159;high_fraction=8'd168;end
7'd8:begin low_bin=10'd0;high_bin=10'd0;low_fraction=8'd168;high_fraction=8'd178;end
7'd9:begin low_bin=10'd0;high_bin=10'd0;low_fraction=8'd178;high_fraction=8'd187;end
7'd10:begin low_bin=10'd0;high_bin=10'd0;low_fraction=8'd187;high_fraction=8'd198;end
7'd11:begin low_bin=10'd0;high_bin=10'd0;low_fraction=8'd198;high_fraction=8'd209;end
7'd12:begin low_bin=10'd0;high_bin=10'd0;low_fraction=8'd209;high_fraction=8'd220;end
7'd13:begin low_bin=10'd0;high_bin=10'd0;low_fraction=8'd220;high_fraction=8'd233;end
7'd14:begin low_bin=10'd0;high_bin=10'd0;low_fraction=8'd233;high_fraction=8'd245;end
7'd15:begin low_bin=10'd0;high_bin=10'd1;low_fraction=8'd245;high_fraction=8'd3;end
7'd16:begin low_bin=10'd1;high_bin=10'd1;low_fraction=8'd3;high_fraction=8'd17;end
7'd17:begin low_bin=10'd1;high_bin=10'd1;low_fraction=8'd17;high_fraction=8'd33;end
7'd18:begin low_bin=10'd1;high_bin=10'd1;low_fraction=8'd33;high_fraction=8'd49;end
7'd19:begin low_bin=10'd1;high_bin=10'd1;low_fraction=8'd49;high_fraction=8'd65;end
7'd20:begin low_bin=10'd1;high_bin=10'd1;low_fraction=8'd65;high_fraction=8'd83;end
7'd21:begin low_bin=10'd1;high_bin=10'd1;low_fraction=8'd83;high_fraction=8'd102;end
7'd22:begin low_bin=10'd1;high_bin=10'd1;low_fraction=8'd102;high_fraction=8'd122;end
7'd23:begin low_bin=10'd1;high_bin=10'd1;low_fraction=8'd122;high_fraction=8'd143;end
7'd24:begin low_bin=10'd1;high_bin=10'd1;low_fraction=8'd143;high_fraction=8'd165;end
7'd25:begin low_bin=10'd1;high_bin=10'd1;low_fraction=8'd165;high_fraction=8'd188;end
7'd26:begin low_bin=10'd1;high_bin=10'd1;low_fraction=8'd188;high_fraction=8'd213;end
7'd27:begin low_bin=10'd1;high_bin=10'd1;low_fraction=8'd213;high_fraction=8'd239;end
7'd28:begin low_bin=10'd1;high_bin=10'd2;low_fraction=8'd239;high_fraction=8'd10;end
7'd29:begin low_bin=10'd2;high_bin=10'd2;low_fraction=8'd10;high_fraction=8'd39;end
7'd30:begin low_bin=10'd2;high_bin=10'd2;low_fraction=8'd39;high_fraction=8'd70;end
7'd31:begin low_bin=10'd2;high_bin=10'd2;low_fraction=8'd70;high_fraction=8'd102;end
7'd32:begin low_bin=10'd2;high_bin=10'd2;low_fraction=8'd102;high_fraction=8'd136;end
7'd33:begin low_bin=10'd2;high_bin=10'd2;low_fraction=8'd136;high_fraction=8'd172;end
7'd34:begin low_bin=10'd2;high_bin=10'd2;low_fraction=8'd172;high_fraction=8'd210;end
7'd35:begin low_bin=10'd2;high_bin=10'd2;low_fraction=8'd210;high_fraction=8'd250;end
7'd36:begin low_bin=10'd2;high_bin=10'd3;low_fraction=8'd250;high_fraction=8'd36;end
7'd37:begin low_bin=10'd3;high_bin=10'd3;low_fraction=8'd36;high_fraction=8'd81;end
7'd38:begin low_bin=10'd3;high_bin=10'd3;low_fraction=8'd81;high_fraction=8'd128;end
7'd39:begin low_bin=10'd3;high_bin=10'd3;low_fraction=8'd128;high_fraction=8'd178;end
7'd40:begin low_bin=10'd3;high_bin=10'd3;low_fraction=8'd178;high_fraction=8'd230;end
7'd41:begin low_bin=10'd3;high_bin=10'd4;low_fraction=8'd230;high_fraction=8'd30;end
7'd42:begin low_bin=10'd4;high_bin=10'd4;low_fraction=8'd30;high_fraction=8'd88;end
7'd43:begin low_bin=10'd4;high_bin=10'd4;low_fraction=8'd88;high_fraction=8'd150;end
7'd44:begin low_bin=10'd4;high_bin=10'd4;low_fraction=8'd150;high_fraction=8'd215;end
7'd45:begin low_bin=10'd4;high_bin=10'd5;low_fraction=8'd215;high_fraction=8'd28;end
7'd46:begin low_bin=10'd5;high_bin=10'd5;low_fraction=8'd28;high_fraction=8'd100;end
7'd47:begin low_bin=10'd5;high_bin=10'd5;low_fraction=8'd100;high_fraction=8'd177;end
7'd48:begin low_bin=10'd5;high_bin=10'd6;low_fraction=8'd177;high_fraction=8'd1;end
7'd49:begin low_bin=10'd6;high_bin=10'd6;low_fraction=8'd1;high_fraction=8'd87;end
7'd50:begin low_bin=10'd6;high_bin=10'd6;low_fraction=8'd87;high_fraction=8'd177;end
7'd51:begin low_bin=10'd6;high_bin=10'd7;low_fraction=8'd177;high_fraction=8'd16;end
7'd52:begin low_bin=10'd7;high_bin=10'd7;low_fraction=8'd16;high_fraction=8'd116;end
7'd53:begin low_bin=10'd7;high_bin=10'd7;low_fraction=8'd116;high_fraction=8'd222;end
7'd54:begin low_bin=10'd7;high_bin=10'd8;low_fraction=8'd222;high_fraction=8'd77;end
7'd55:begin low_bin=10'd8;high_bin=10'd8;low_fraction=8'd77;high_fraction=8'd195;end
7'd56:begin low_bin=10'd8;high_bin=10'd9;low_fraction=8'd195;high_fraction=8'd63;end
7'd57:begin low_bin=10'd9;high_bin=10'd9;low_fraction=8'd63;high_fraction=8'd195;end
7'd58:begin low_bin=10'd9;high_bin=10'd10;low_fraction=8'd195;high_fraction=8'd77;end
7'd59:begin low_bin=10'd10;high_bin=10'd10;low_fraction=8'd77;high_fraction=8'd223;end
7'd60:begin low_bin=10'd10;high_bin=10'd11;low_fraction=8'd223;high_fraction=8'd122;end
7'd61:begin low_bin=10'd11;high_bin=10'd12;low_fraction=8'd122;high_fraction=8'd29;end
7'd62:begin low_bin=10'd12;high_bin=10'd12;low_fraction=8'd29;high_fraction=8'd201;end
7'd63:begin low_bin=10'd12;high_bin=10'd13;low_fraction=8'd201;high_fraction=8'd126;end
7'd64:begin low_bin=10'd13;high_bin=10'd14;low_fraction=8'd126;high_fraction=8'd62;end
7'd65:begin low_bin=10'd14;high_bin=10'd15;low_fraction=8'd62;high_fraction=8'd8;end
7'd66:begin low_bin=10'd15;high_bin=10'd15;low_fraction=8'd8;high_fraction=8'd221;end
7'd67:begin low_bin=10'd15;high_bin=10'd16;low_fraction=8'd221;high_fraction=8'd190;end
7'd68:begin low_bin=10'd16;high_bin=10'd17;low_fraction=8'd190;high_fraction=8'd172;end
7'd69:begin low_bin=10'd17;high_bin=10'd18;low_fraction=8'd172;high_fraction=8'd167;end
7'd70:begin low_bin=10'd18;high_bin=10'd19;low_fraction=8'd167;high_fraction=8'd176;end
7'd71:begin low_bin=10'd19;high_bin=10'd20;low_fraction=8'd176;high_fraction=8'd199;end
7'd72:begin low_bin=10'd20;high_bin=10'd21;low_fraction=8'd199;high_fraction=8'd238;end
7'd73:begin low_bin=10'd21;high_bin=10'd23;low_fraction=8'd238;high_fraction=8'd37;end
7'd74:begin low_bin=10'd23;high_bin=10'd24;low_fraction=8'd37;high_fraction=8'd110;end
7'd75:begin low_bin=10'd24;high_bin=10'd25;low_fraction=8'd110;high_fraction=8'd201;end
7'd76:begin low_bin=10'd25;high_bin=10'd27;low_fraction=8'd201;high_fraction=8'd55;end
7'd77:begin low_bin=10'd27;high_bin=10'd28;low_fraction=8'd55;high_fraction=8'd185;end
7'd78:begin low_bin=10'd28;high_bin=10'd30;low_fraction=8'd185;high_fraction=8'd81;end
7'd79:begin low_bin=10'd30;high_bin=10'd31;low_fraction=8'd81;high_fraction=8'd255;end
7'd80:begin low_bin=10'd31;high_bin=10'd33;low_fraction=8'd255;high_fraction=8'd197;end
7'd81:begin low_bin=10'd33;high_bin=10'd35;low_fraction=8'd197;high_fraction=8'd164;end
7'd82:begin low_bin=10'd35;high_bin=10'd37;low_fraction=8'd164;high_fraction=8'd158;end
7'd83:begin low_bin=10'd37;high_bin=10'd39;low_fraction=8'd158;high_fraction=8'd180;end
7'd84:begin low_bin=10'd39;high_bin=10'd41;low_fraction=8'd180;high_fraction=8'd232;end
7'd85:begin low_bin=10'd41;high_bin=10'd44;low_fraction=8'd232;high_fraction=8'd59;end
7'd86:begin low_bin=10'd44;high_bin=10'd46;low_fraction=8'd59;high_fraction=8'd175;end
7'd87:begin low_bin=10'd46;high_bin=10'd49;low_fraction=8'd175;high_fraction=8'd69;end
7'd88:begin low_bin=10'd49;high_bin=10'd52;low_fraction=8'd69;high_fraction=8'd1;end
7'd89:begin low_bin=10'd52;high_bin=10'd54;low_fraction=8'd1;high_fraction=8'd227;end
7'd90:begin low_bin=10'd54;high_bin=10'd57;low_fraction=8'd227;high_fraction=8'd238;end
7'd91:begin low_bin=10'd57;high_bin=10'd61;low_fraction=8'd238;high_fraction=8'd36;end
7'd92:begin low_bin=10'd61;high_bin=10'd64;low_fraction=8'd36;high_fraction=8'd136;end
7'd93:begin low_bin=10'd64;high_bin=10'd68;low_fraction=8'd136;high_fraction=8'd28;end
7'd94:begin low_bin=10'd68;high_bin=10'd71;low_fraction=8'd28;high_fraction=8'd227;end
7'd95:begin low_bin=10'd71;high_bin=10'd75;low_fraction=8'd227;high_fraction=8'd224;end
7'd96:begin low_bin=10'd75;high_bin=10'd80;low_fraction=8'd224;high_fraction=8'd21;end
7'd97:begin low_bin=10'd80;high_bin=10'd84;low_fraction=8'd21;high_fraction=8'd133;end
7'd98:begin low_bin=10'd84;high_bin=10'd89;low_fraction=8'd133;high_fraction=8'd53;end
7'd99:begin low_bin=10'd89;high_bin=10'd94;low_fraction=8'd53;high_fraction=8'd39;end
7'd100:begin low_bin=10'd94;high_bin=10'd99;low_fraction=8'd39;high_fraction=8'd96;end
7'd101:begin low_bin=10'd99;high_bin=10'd104;low_fraction=8'd96;high_fraction=8'd227;end
7'd102:begin low_bin=10'd104;high_bin=10'd110;low_fraction=8'd227;high_fraction=8'd179;end
7'd103:begin low_bin=10'd110;high_bin=10'd116;low_fraction=8'd179;high_fraction=8'd215;end
7'd104:begin low_bin=10'd116;high_bin=10'd123;low_fraction=8'd215;high_fraction=8'd81;end
7'd105:begin low_bin=10'd123;high_bin=10'd130;low_fraction=8'd81;high_fraction=8'd40;end
7'd106:begin low_bin=10'd130;high_bin=10'd137;low_fraction=8'd40;high_fraction=8'd95;end
7'd107:begin low_bin=10'd137;high_bin=10'd144;low_fraction=8'd95;high_fraction=8'd253;end
7'd108:begin low_bin=10'd144;high_bin=10'd153;low_fraction=8'd253;high_fraction=8'd8;end
7'd109:begin low_bin=10'd153;high_bin=10'd161;low_fraction=8'd8;high_fraction=8'd132;end
7'd110:begin low_bin=10'd161;high_bin=10'd170;low_fraction=8'd132;high_fraction=8'd121;end
7'd111:begin low_bin=10'd170;high_bin=10'd179;low_fraction=8'd121;high_fraction=8'd237;end
7'd112:begin low_bin=10'd179;high_bin=10'd189;low_fraction=8'd237;high_fraction=8'd231;end
7'd113:begin low_bin=10'd189;high_bin=10'd200;low_fraction=8'd231;high_fraction=8'd110;end
7'd114:begin low_bin=10'd200;high_bin=10'd211;low_fraction=8'd110;high_fraction=8'd139;end
7'd115:begin low_bin=10'd211;high_bin=10'd223;low_fraction=8'd139;high_fraction=8'd70;end
7'd116:begin low_bin=10'd223;high_bin=10'd235;low_fraction=8'd70;high_fraction=8'd168;end
7'd117:begin low_bin=10'd235;high_bin=10'd248;low_fraction=8'd168;high_fraction=8'd185;end
7'd118:begin low_bin=10'd248;high_bin=10'd262;low_fraction=8'd185;high_fraction=8'd131;end
7'd119:begin low_bin=10'd262;high_bin=10'd277;low_fraction=8'd131;high_fraction=8'd18;end
7'd120:begin low_bin=10'd277;high_bin=10'd292;low_fraction=8'd18;high_fraction=8'd111;end
7'd121:begin low_bin=10'd292;high_bin=10'd308;low_fraction=8'd111;high_fraction=8'd166;end
7'd122:begin low_bin=10'd308;high_bin=10'd325;low_fraction=8'd166;high_fraction=8'd195;end
7'd123:begin low_bin=10'd325;high_bin=10'd343;low_fraction=8'd195;high_fraction=8'd211;end
7'd124:begin low_bin=10'd343;high_bin=10'd362;low_fraction=8'd211;high_fraction=8'd228;end
7'd125:begin low_bin=10'd362;high_bin=10'd383;low_fraction=8'd228;high_fraction=8'd3;end
7'd126:begin low_bin=10'd383;high_bin=10'd404;low_fraction=8'd3;high_fraction=8'd64;end
7'd127:begin low_bin=10'd404;high_bin=10'd426;low_fraction=8'd64;high_fraction=8'd171;end
default:begin low_bin=0;high_bin=0;low_fraction=0;high_fraction=0;end
endcase
end
always @* begin
case(level)
5'd0:threshold=33'd83;
5'd1:threshold=33'd128;
5'd2:threshold=33'd197;
5'd3:threshold=33'd304;
5'd4:threshold=33'd468;
5'd5:threshold=33'd721;
5'd6:threshold=33'd1111;
5'd7:threshold=33'd1710;
5'd8:threshold=33'd2633;
5'd9:threshold=33'd4055;
5'd10:threshold=33'd6245;
5'd11:threshold=33'd9617;
5'd12:threshold=33'd14809;
5'd13:threshold=33'd22805;
5'd14:threshold=33'd35118;
5'd15:threshold=33'd54079;
5'd16:threshold=33'd83278;
5'd17:threshold=33'd128242;
5'd18:threshold=33'd197483;
5'd19:threshold=33'd304109;
5'd20:threshold=33'd468306;
5'd21:threshold=33'd721157;
5'd22:threshold=33'd1110529;
5'd23:threshold=33'd1710133;
5'd24:threshold=33'd2633479;
5'd25:threshold=33'd4055364;
5'd26:threshold=33'd6244963;
5'd27:threshold=33'd9616785;
5'd28:threshold=33'd14809142;
5'd29:threshold=33'd22804990;
5'd30:threshold=33'd35118009;
5'd31:threshold=33'd54079154;
default:threshold=1;
endcase
end
endmodule
`default_nettype wire
`default_nettype none
// Peak of the continuous piecewise-linear power envelope over one log band.
// Endpoint interpolation is Q8, rounded; interior native-bin peaks are retained.
// Eight shift/add cycles share one adder and require no additional multiplier.
module live_band_peak(
 input wire clk,rst_n,start,input wire [9:0] low_bin,high_bin,
 input wire [7:0] low_fraction,high_fraction,input wire [32:0] power_data,
 output reg [9:0] power_address,output reg done,output reg [32:0] peak
);
 localparam [2:0] IDLE=0,WAIT_READ=1,EVALUATE=2,INTERPOLATE=3,FINISH=4;
 reg [2:0] state,count;
 reg [9:0] first_bin,last_bin;
 reg [7:0] first_fraction,last_fraction,fraction;
 reg [32:0] previous_power;
 reg [41:0] low_shift,high_shift,accumulator;
 reg left_edge;
 wire [32:0] interpolated=accumulator[40:8];
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   state<=IDLE;count<=0;first_bin<=0;last_bin<=0;first_fraction<=0;last_fraction<=0;
   fraction<=0;previous_power<=0;low_shift<=0;high_shift<=0;accumulator<=0;left_edge<=0;
   power_address<=0;done<=0;peak<=0;
  end else begin
   done<=0;
   case(state)
    IDLE:if(start)begin
     first_bin<=low_bin;last_bin<=high_bin;first_fraction<=low_fraction;last_fraction<=high_fraction;
     power_address<=low_bin;peak<=0;state<=WAIT_READ;
    end
    WAIT_READ:state<=EVALUATE;
    EVALUATE:begin
     if(power_address==first_bin)begin
      previous_power<=power_data;power_address<=power_address+10'd1;state<=WAIT_READ;
     end else if(power_address==first_bin+10'd1 || power_address==last_bin+10'd1)begin
      low_shift<={9'd0,previous_power};high_shift<={9'd0,power_data};
      accumulator<={9'd0,previous_power}+42'd128;count<=0;
      if(power_address==first_bin+10'd1)begin fraction<=first_fraction;left_edge<=1;end
      else begin fraction<=last_fraction;left_edge<=0;end
      state<=INTERPOLATE;
     end else begin
      if(power_data>peak)peak<=power_data;
      previous_power<=power_data;power_address<=power_address+10'd1;state<=WAIT_READ;
     end
    end
    INTERPOLATE:begin
     accumulator<=accumulator+(fraction[0]?high_shift:low_shift);
     low_shift<=low_shift<<1;high_shift<=high_shift<<1;fraction<=fraction>>1;
     if(count==7)state<=FINISH;else count<=count+1'b1;
    end
    FINISH:if(left_edge)begin
     if(first_bin==last_bin)begin
      peak<=interpolated;
      low_shift<={9'd0,previous_power};high_shift<={9'd0,power_data};
      accumulator<={9'd0,previous_power}+42'd128;fraction<=last_fraction;count<=0;left_edge<=0;
      state<=INTERPOLATE;
     end else begin
      peak<=(interpolated>power_data)?interpolated:power_data;
      previous_power<=power_data;power_address<=power_address+10'd1;state<=WAIT_READ;
     end
    end else begin
     if(interpolated>peak)peak<=interpolated;
     done<=1;state<=IDLE;
    end
    default:state<=IDLE;
   endcase
  end
 end
endmodule
`default_nettype wire
