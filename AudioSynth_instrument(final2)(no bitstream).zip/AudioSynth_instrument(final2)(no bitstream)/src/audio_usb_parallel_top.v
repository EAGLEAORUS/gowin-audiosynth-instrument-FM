`default_nettype none
// Unified production top: independent USB session and audio reset/clock trees.
module audio_usb_parallel_top #(parameter SYNTH_ENABLE=0)(
 input wire clk_50m,inout wire usb_dp,usb_dm,output wire uart_tx,
 output wire es0_mclk,es1_mclk,es7243_scl,inout wire es7243_sda,
 output wire es8156_scl,inout wire es8156_sda,
 input wire es0_dsclk,es0_alrck,es0_sdin,es1_dsclk,es1_dlrc,
 output wire es1_sdout,lin_led,ws2812
);
 wire evt_valid,online,fault,usb_core_rst_n;
 wire [39:0] evt_data;
 usb_midi_fs_top usb(.clk_50m(clk_50m),.usb_dp(usb_dp),.usb_dm(usb_dm),.uart_tx(uart_tx),
 .audio_evt_valid(evt_valid),.audio_evt_data(evt_data),.audio_online(online),
 .audio_fault(fault),.audio_core_rst_n(usb_core_rst_n));
 audio_usb_loop24 #(.SYNTH_ENABLE(SYNTH_ENABLE)) audio(clk_50m,es0_mclk,es1_mclk,es7243_scl,es7243_sda,
 es8156_scl,es8156_sda,es0_dsclk,es0_alrck,es0_sdin,es1_dsclk,es1_dlrc,es1_sdout,lin_led,evt_valid,evt_data,online,fault,usb_core_rst_n,ws2812);
endmodule
`default_nettype wire
