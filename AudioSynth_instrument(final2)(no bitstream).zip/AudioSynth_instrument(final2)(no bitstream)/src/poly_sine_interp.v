`default_nettype none
// Same verified 1024-word ROM, two neighboring reads and 14-bit linear phase
// interpolation. No new tuning data or recorded audio; phase stays independent.
module poly_sine_interp(input wire clk,input wire [31:0] phase,
 output reg signed [15:0] sample);
 wire [9:0] address=phase[31:22];
 wire [9:0] next_address=address+10'd1;
 wire signed [15:0] base,next;
 reg [13:0] fraction;
 synth_sine_rom lower(clk,address,base);
 synth_sine_rom upper(clk,next_address,next);
 always @(posedge clk)fraction<=phase[21:8];
 wire signed [16:0] difference=$signed({next[15],next})-$signed({base[15],base});
 wire signed [31:0] delta=difference*$signed({1'b0,fraction});
 wire signed [31:0] base_fixed=$signed({{16{base[15]}},base})<<<14;
 wire signed [31:0] interpolated=base_fixed+delta;
 wire signed [31:0] rounded=(interpolated>=0)?
  ((interpolated+32'sd8192)>>>14):-(((-interpolated)+32'sd8192)>>>14);
 always @(posedge clk)begin
  if(rounded>32'sd32767)sample<=16'sh7fff;
  else if(rounded< -32'sd32768)sample<=16'sh8000;
  else sample<=rounded[15:0];
 end
endmodule
`default_nettype wire
