# CH569 USB3 整机集成

## 2026-10-28：已验收候选正式同步回src

按用户要求，将crcguard1已验收候选的7个差异文件同步至本目录src：HSPI每事务序号0、寄存TX CRC帧头清零、注册接收解析器、TX12.5MHz及配套SDC、PCM2048帧、回传队列64条和引擎FWFT BSRAM FIFO。原音频/键盘/效果器/TFT/KEY0顶层及CST不改。两个GPRJ均已引用104份HDL，不需要再从build候选目录添加源文件或手工增加顶层实例。

手动构建入口仍为 `AudioSynth_instrument.gprj`，顶层 `audio_synth_instrument_top`，SystemVerilog2017，当前布局/布线选项2/2。关闭旧工程会话（不要保存旧状态），重新打开GPRJ，依次重新执行综合、布局布线和STA检查。已清除旧GUI完成标记；历史impl文件保留，不能当作本次更新生成的位流直接下载。

当前配套CH569为v9（修订90001）、PC为Arietta Studio1.0.3。本次仅源码集成/编译展开和关键模型复核，不重新运行全量综合/PnR/STA或下载；新手动构建位流仍须核对实际时序并实板验收。历史候选Setup/Hold零违例不能替代新构建结果。

旧文件备份、源SHA及验证结果：[本次集成记录](../docs/usb3-instrument/SRC_INTEGRATION_20261028.md)。下载仍只允许重新确认唯一138K ID0x0001081B后的SRAM Program and Verify，不写FPGA Flash；保留原保护位/OTP设置。下面保留2026-10-26旧集成记录，已被本段的新状态覆盖。

2026-10-26，按用户追加授权，已将通过RTL联调与整机STA的pnr12业务候选合入本目录的src、两份GPRJ及CST/SDC。104份启用HDL，原42引脚保留，追加24个HSPI信号和KEY0/AA13。SRAM完整读回通过，真实USB3第二笔UP失败，业务实板验收未完成；用户已要求暂停，详见[关键调试检查点](../docs/usb3-instrument/PAUSE_20261026.md)。

原文件逐项备份在 `../build/usb3-instrument-20261025/results/integrate9/before`；任务开始时的源码快照在 `../build/usb3-instrument-20261025/before`。原impl中的位流、网表和报告仍保留历史输出，**不代表当前源码版本**。本轮所有综合、布局布线及测试均在新的隔离目录运行。

当前状态与最终验收以 [任务状态](../docs/usb3-instrument/STATUS.md) 为准；[AUB1协议](../docs/usb3-instrument/PROTOCOL.md) 和 `../fpga/integration/ch569_usb3_v1/host` 提供Python业务接口。仅SRAM Program and Verify，不写FPGA Flash，不编译/替换/烧写CH569固件。

KEY0为低有效系统复位，稳定松开10ms后按域释放。每次FPGA SRAM加载后需实体重启CH569同步HSPI序号。PC使用359F:3001 WinUSB SuperSpeed；旧COM9/COM10及旧pattern脚本不适用于业务验收。


## 2026-10-30 SD-OFFLINE-01资源基线

三个队列RTL已更新，现有音色/接口保持，源文件与build/sd-offline-20261029/build2/manifest.json匹配。CLS54307/BSRAM292，综合/PnR/STA及SRAM/实际Arietta后端MIDI回归通过；原impl输出保留且不代表新源码。SD动态音色/自主播放菜单/LED指引尚未集成。见[本轮报告](../docs/sd-offline/REPORT_20261029.md)。


## 2026-10-30 238块BSRAM候选合回

238块build3候选的6RTL已合回src，顶层调用链/ready连接/EXP实例及两GPRJ111输入SHA核对通过，顶层与受测版本相同。保持Place2/Route2，旧impl非本次新结果。等待用户手动综合/PnR，本轮无构建或下载，板卡仍292块。见[集成记录](../docs/bsram-opt/OPTIMIZATION_20261030.md)。
